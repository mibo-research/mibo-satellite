# MIBO-Education blockers

## Current: W01 v1.1 preparation offline verified; one bundled approval pending, all live gates closed

[Prospective preparation record](waves/W01/deviations/deviation-00001.json) and the [new W01 status](waves/W01/PREPARATION-STATUS-v1.1.json) concern Education only, not Core. The old September1/five-series W01 manifests, frozen70 prompts, rubrics, published v1.0 DOI/ZIP, original manuscript and all W0 data/judgments/accounting remain unchanged. The three-family v3.1 W01 plan is a separate, explicitly unapproved Draft, not a relabelled W0 or silently edited old Wave.

The proposed baseline is2026-11-20 09:00JST. Source collection remains70 items*10 replications*3 CLOSED families=2,100 planned slots, with a stratified/interleaved hashed schedule over the12-hour target and a24-hour hard limit. Up to4,200 nonself judging requests follow within72 hours after actual collection completion. Fresh6 model-identity checks and35*3=105 common-calibration ratings run within the preceding24 hours; unchanged primary/full calibration guards and explicit delegated definition/adversarial review precede observation. Exact W0-tested models, judge prompt/schema/anchors, generation caps and existing key/account/storage routes are carried, not upgraded or newly live-verified. The same existing owner Windows station has a fixed logical site ID; no independently verified geographic-region or model-weight-pinning claim is made.

The new proposed request ceiling is6,411, with prior1,468 preserved and proposed cumulative maximum7,879. The actual W0 cap remains1,468 and is not reset/extended by preparation. The formal technical-attempt policy change from maximum5 to1 attempt per slot/zero automatic resends is explicitly part of the future approval, not an already adopted hidden change. Fully recorded READ_TIMEOUTs remain consumed/unscored; only unsent slots continue. Missing source cells are not refilled and their two judging slots are not sent. Unknown receipts, authentication/identity/CLOSED failures, manual STOP and hard deadlines remain fail-closed.

All41 new offline tests passed, including complete6,411-request and source-missing6,409-request synthetic scenarios, exact frozen source payloads/allocation, real-vs-fixture gates, publication/finalization/FINAL scope, phase/cumulative caps, unknown-receipt no-replay, controller exclusion, operator STOP, stage clocks, and AC-only power-request release. Tests used MockTransport with real credentials/sockets denied; zero model API calls and no public mutation. Candidate/helper development failures are archived separately, never treated as scientific results. Preparation power requests were released.

The [runtime configuration](waves/W01/runtime-v1.1-DRAFT.json), [scientific manifest](waves/W01/scientific-manifest-v1.1-DRAFT.json), [candidate model lock](waves/W01/model-lock-v1.1-DRAFT.json), [schedule](waves/W01/schedule-v1.1-DRAFT.json) and [registration/manuscript amendment](protocol/registration/education-v1.1-DRAFT.json) form the one-decision bundle. Existing author/ORCID/affiliations/funding/COI/AI disclosures are carried; registration language isEnglish and protocol licenseCC BY4.0. No new DOI, published registration, human signature or FINAL execution grant is fabricated. Actual prospective Education v1.1 publication/finalization proof and a separate scoped owner FINAL permit are required before any model request.

Formal analysis preserves Codebook section3 within-source domain means, their25x presentation, valid denominators, missing/unresolved counts, distributions and descriptive dispersion. It does not misuse the W0 sample150/50 gates on formal2,100, pool changing-rater kappas, rank overall educational AI, compare W0 as a formal baseline, or establish all45-field semantic validity/independence/comparability. The accepted W0 limited technical review and all its unresolved diagnostics remain intact. Publication,Core restart and W01 execution have not occurred. Earlier sections are historical context, not current execution authority.

## Historical context: EV31 nonofficial W0 execution and limited AGENT technical review complete; API gates closed

[Deviation00070](waves/W0/deviations/deviation-00070.json) records the separately explicit, delegated AGENT limited technical review. The actual result was rederived identically from raw, with4,536 completed evidence files hash-bound. All150 source answers are saved (50 per series); all300 nonself judging requests were processed (100 per judge). Primary-valid298/300 and full-record-valid296/300. Main READ_TIMEOUTs358/379 remain unscored, consumed and unresent. Two J02 MODEL_SCORE_PARSEABLE omissions remain missing, not repaired. The earlier calibration timeout34 and failed sources168/186 are retained; only the separately approved source retries169/187 occurred once each, with original wire/model unchanged.

Both frozen primary AND full-record numerical reports passed: approved source/item/domain allocation, numeric coverage, valid-pair fraction and each of the three fixed source-pair agreement guards. Primary source-pair kappas are0.899225/0.924090/0.963923 for anthropic/gemini/openai sources respectively; full-record kappas are0.898744/0.924090/0.963459. No pooled changing-rater kappa or ranking was created. Aggregation retains146 panel estimates,2 unresolved score disagreements and2 incomplete responses, without imputation, rescaling or adjudication. The accepted104/105 calibration review is carried unchanged.

All45 auxiliary diagnostics remain available for review. Developmental0-to2 range-contract errors and refusal-R0 conflicts are0; these are diagnostics, not new acceptance cutoffs. ABSTRACTION_ADAPTATION has61 disagreements and VOCABULARY_ADAPTATION53 among148 jointly available pairs. Conflicting values stay unresolved and conditionally unavailable values are not turned into zero. This is limited engineering acceptance, not human gold, all45-field semantic reliability, statistical independence or cross-source comparability. Existing machine pilot/clearance flags remain false; historical judgments are not rewritten.

The single worker exited after completion, and its AC-only temporary SystemRequired/ExecutionRequired requests were explicitly cleared and the handle closed at2026-11-12T03:16:17.927250Z. No permanent power setting, display/away request or explicit-user-sleep override was used. STOP/global HOLD are restored. Prior905/current563/cumulative1,468 accounting, the entire original186 prefix and original clock/deadline2026-11-14T02:21:26.568072Z (11:21 JST) are verified. The approved request allowance is exhausted; no additional API work is authorized by this review. Publication,Core restart and W01 were not executed. Earlier sections are historical snapshots, not current execution authority.

## Historical snapshot: EV31 observations150 saved; nonself main300 judging active under AC guard

At2026-11-12T01:27Z all150 actual source answers are saved,50 per series. The locked300-request blind main batch has been created,100 requests per judge; the allocation was independently checked against each source family's two nonself judges. Main dispatch has started. No source failure occurred after the single approved retry187, and the accepted calibration is carried unchanged. Completion, fixed primary/full guard results, delegated technical review and final power-request release remain pending; no W0 qualification is claimed.

The owner [approved the conditional restart](protocol/approvals/EV31-AC-AWAKE-SOURCE186-APPROVAL-20261112.yaml). [Deviation00068](waves/W0/deviations/deviation-00068.json) binds the new operational release and35 passing offline tests, including the full186+377 fixture, identical retry wire, closed gates, AC-loss/suspend/exception cleanup and delegated unsent-only main READ_TIMEOUT continuation. The native AC power request was acquired and released successfully in verification. FINAL authority was created only after verification; no extra key, signature or storage decision was needed.

The single hidden worker has started. The only newly approved source186 retry is separately recorded as187 and returned HTTP200 with a saved actual answer. At that checkpoint74 answers are saved; the worker continues76 untouched original sources, then300 nonself judgments. Both failed attempts168/186 and successful retries169/187 remain distinct and consumed. All original186 files, judgments, old905 accounting and the original clock are preserved. At most377 additional/current-trial563/cumulative1,468 reservations are authorized. No other source retry, metadata/calibration replay or invalid-response repair is allowed.

Temporary SystemRequired/ExecutionRequired power requests apply only during active AC-powered operation and are released at exit. AC loss/unknown status or a suspend-monitor gap releases the requests and prevents the next dispatch; explicit user sleep is not overridden and permanent settings/display/away mode are unchanged. The accepted104/105 calibration is carried, not rerun. Original deadline2026-11-14T02:21:26.568072Z (11:21 JST), scientific models/prompts/criteria and all historical judgments remain fixed. W0 is still in progress, not qualified or semantically validated. Publication,Core restart and W01 remain forbidden. Earlier sections are historical snapshots, not current execution authority.

## Historical snapshot: EV31 source186 transport HOLD;73 answers preserved, no other retry

[Deviation00067](waves/W0/deviations/deviation-00067.json) records a new observation failure: source186, Claude opus5/original slot74, HTTP0 TRANSPORT_OTHER with no provider response saved. The approved retry169 of source168 succeeded, adding17 saved answers before this new failure. All186 reservations/outcomes,73 source records, old905 accounting, original168 prefix, calibration judgments and original clock are verified intact. Main judging remains0; W0 is incomplete, not classified as a scoring-quality failure. The worker exited with STOP/global HOLD present. The single source168 retry allowance is already used; source186 has not been retried and is outside the main-communication continuation delegation.

Cumulative reservations are1,091; the current1,467 cap leaves376 attempts, but77 actual sources plus300 main judgments require at least377. The proposal, not new authority, is a temporary AC-powered/active-worker-only idle-sleep guard released on exit, plus exactly one linked retry of source186, then76 untouched source slots and300 main judgments: maximum377 additional/current-trial563/cumulative1,468. No permanent power-setting change, explicit-user-sleep override, new FINAL permission or revised sender has been made. Preparation/verification and conditional restart require owner direction.

Read-only Windows logs show Modern Standby IdleTimeout entry at2026-11-11T23:38:09.135Z, source186 reservation at23:38:11.755Z, a power transition at23:47:03.908Z and transport failure at23:47:07.020Z. Earlier source168 has a similar power/failure correlation. Host power-state involvement is likely, not definitively proven from the collapsed TRANSPORT_OTHER log. No source/score repair, other retry, clock reset or scientific-model/prompt/anchor/criterion change occurred. Deadline2026-11-14T02:21:26.568072Z (11:21 JST) and all publication/Core/W01 prohibitions remain. Earlier sections are historical snapshots, not current restart authority.

## Historical snapshot: EV31 explicitly restarted; single approved source retry succeeded, collection in progress

The owner [explicitly approved API restart](protocol/approvals/EV31-SOURCE-RETRY-EXECUTION-APPROVAL-20261112.yaml). [Deviation00065](waves/W0/deviations/deviation-00065.json) binds FINAL authority and the49-test verified release, at most394 additional requests from the preserved168 checkpoint,562 for this same trial and1,467 cumulative including old905. [Deviation00066](waves/W0/deviations/deviation-00066.json) confirms that the sole authorized retry169 of failed source168 returned HTTP200 with an eligible saved answer and identical original wire/model. Both attempts remain separately accounted; all original168 files/judgments and the original clock are byte-identical.

One bounded worker is collecting the remaining original source slots, requiring150 actual answers,50 per family, before300 nonself judgments. No second/other source retry, metadata/calibration replay or invalid-output repair is authorized. Only fully recorded main READ_TIMEOUTs may advance to unsent slots while unchanged primary/full guards remain demonstrably reachable. Source shortfall, other HTTP/transport/identity/unknown-outcome or scope/limit/window failure remains HOLD-and-consult.

The accepted104/105 calibration review is carried, not rerun. Original start2026-11-11T02:21:26.568072Z and deadline2026-11-14T02:21:26.568072Z (11:21 JST), scientific models/prompts/criteria and all historical judgments remain unchanged. W0 is still in progress, not qualified or semantically validated; publication,Core restart and W01 remain forbidden. Earlier sections are historical snapshots, not competing execution authority.

## Historical snapshot: EV31 single-source retry prepared and offline verified; API restart still unapproved

The owner [approved preparation only](protocol/approvals/EV31-SOURCE-RETRY-PREPARATION-APPROVAL-20261111.yaml). The separate [one-retry plan](runtime/EV31-source-retry-v1.0.json) and [release lock](runtime/EV31-source-retry-v1.0.lock.json) prospectively allow one retry of failed source reservation168,93 untouched original source slots and300 nonself judgments: maximum394 additional requests,562 for this same trial and1,467 cumulative including old905. The failed attempt remains consumed and immutable. The retry is separately linked to it, with identical original request bytes/model/generation cap;151 source attempts must yield150 actual answers,50 per series. No other source retry, second retry or metadata/calibration replay is allowed.

All49 offline tests passed, including168+394 completion, exact retry-wire preservation, conditional unsent-main READ_TIMEOUT continuation, hard stops for retry/other-source/HTTP/unknown/identity failures, manual STOP, expired deadline and unchanged old-continuation behavior. [Deviation00064](waves/W0/deviations/deviation-00064.json) binds preparation approval and verification. A pre-execution development-constructor failure was corrected only in the new operational module; its candidate/archive is retained and is not a scientific W0 judgment. Old native/method releases,7,334 historical immutable files, all168 current outcomes and existing judgments are unchanged.

Real progress remains56 source answers and0 main judgments; accepted104/105 calibration is carried, not rerun. No FINAL restart authorization was created: the verified DRAFT still denies API use, and STOP/global HOLD remain. The original start2026-11-11T02:21:26.568072Z and deadline2026-11-14T02:21:26.568072Z (11:21 JST) remain unchanged, as do models/prompts/criteria. Actual cumulative reservations remain1,073. No API restart, publication,Core restart,W01, W0 qualification or all45-code semantic/comparability claim. Earlier sections are historical snapshots, not current restart authority.

## Historical snapshot: EV31 source transport HOLD;56 answers preserved, no retry — 2026-11-11 JST

The worker stopped on fresh-source attempt57/global reservation168: OpenAI gpt-5.6-sol, HTTP0, TRANSPORT_OTHER, no saved provider response. This observation failure is outside the delegated calibration/main READ_TIMEOUT continuation; no failed request was replayed.56 actual source answers are saved (M01:20,M02:21,M03:15); main judging is0 and no partial main batch was created. STOP/global HOLD remain present and the worker has exited.

[Deviation00063](waves/W0/deviations/deviation-00063.json) records the offline-only review: old905 reservations, all168 current outcomes,7,334 prior immutable files, original34 prefix, calibration judgments and the original clock are intact. Calibration remains104/105 primary/full-valid with accepted limited AGENT technical review; this is not a W0 qualification or all45-code semantic validation. The original calibration timeout and source transport failure are both preserved, unscored and not interpreted as zero,NR or poor model quality.

Cumulative reservations are1,073; current cap1,466 leaves393 attempts. Completing150 actual source answers needs94 additional sources plus300 main judgments=394 attempts even without another failure; the remaining93 original source slots can reach only149 answers. Completion is therefore impossible under the current no-replay/cap scope. No replacement authorization or modified sender was created. Deadline2026-11-14T02:21:26.568072Z (11:21 JST), fixed models/prompts/criteria and all publication/Core/W01 prohibitions remain unchanged. Earlier sections are historical snapshots.

## Historical snapshot: EV31 calibration reviewed; fresh-source collection and reciprocal judging stage active — 2026-11-11 JST

The completed common calibration has104/105 primary-valid and full-record-valid ratings; the original unscored READ_TIMEOUT is retained. Both frozen technical reports passed. [Deviation00061](waves/W0/deviations/deviation-00061.json) records the accepted delegated AGENT definition/adversarial review and its limited operational scope. AI-proposed targets remain unchanged, not human gold; auxiliary boundary disagreements are not adjudicated or relabelled.

[Deviation00062](waves/W0/deviations/deviation-00062.json) confirms actual fresh-source reservation112 and its saved HTTP200 answer after the accepted review. The single worker is running the approved150 fresh answers followed by300 nonself judgments. It may continue past fully recorded calibration/main READ_TIMEOUTs only to unsent slots when unchanged fixed guards remain attainable. Source shortfall, other failures, unknown outcomes or scope changes still require HOLD. Failed requests are never replayed.

Original34 records, old905 reservation accounting, fixed models/prompts/criteria, cumulative maximum1,466 and deadline2026-11-14T02:21:26.568072Z (11:21 JST) are preserved. This is an ongoing nonofficial W0, not a completed or qualified W0, all45-code semantic validation or established comparability. Publication,Core restart and W01 remain forbidden. Earlier sections are historical snapshots.

## Historical snapshot: EV31 unsent-only continuation active; original clock and science preserved — 2026-11-11 JST

The owner [approved unsent-only continuation](protocol/approvals/EV31-UNSENT-CONTINUATION-APPROVAL-20261111.yaml) after offline verification: preserve old905/current34/one unscored timeout, never resend the failed request, continue only remaining527 within cumulative1,466 and the original deadline. Same calibration/main READ_TIMEOUT continuation is delegated only while the fixed guards remain demonstrably attainable. Source shortfall, metadata/identity error, other failure or scope/limit change remains HOLD-and-consult.

All21 offline tests passed, including full34+527 with additional calibration/main timeouts, no duplicate judging attempts, source-shortfall stopping, review gating and manual STOP preservation. A test expectation mismatch from the first offline attempt is archived; production code/scientific bytes were not changed to fix that assertion. [Deviation00059](waves/W0/deviations/deviation-00059.json) binds the verified operational release and FINAL continuation permit. Native scientific release f49ca0, model IDs, prompts, anchors, schema, validators, generation caps, timeout and numerical criteria are unchanged. Ephemeral counterfactual feasibility checks never become ratings or analysis data.

[Deviation00060](waves/W0/deviations/deviation-00060.json) confirms actual resumed reservations35/36 are exactly calibration slots29/30 with HTTP200 outcomes. Failed reservation34 remains once, unresent and without a pedagogical score. All original34 records/27 judgments are byte-identical. The original start2026-11-11T02:21:26.568072Z and deadline2026-11-14T02:21:26.568072Z are unchanged. Calibration continues; both actual primary AND full-record fixed reports plus explicit delegated definition/adversarial technical review still precede fresh150 collection and reciprocal300 main judging. No W0 qualification, publication,Core restart or W01 is implied or performed. Earlier sections are historical snapshots.

## Historical snapshot: EV31 transport HOLD; 34 reservations preserved, no retry — 2026-11-11 JST

The single worker exited after a 600-second READ_TIMEOUT on Claude J01 calibration request28. All 34 new reservations have saved outcomes: six exact-model metadata checks, 27 saved calibration ratings and one unscored transport failure. The 27 ratings are primary-valid and full-record-valid and were rederived identically from raw. HTTP0 with no provider body does not prove the remote request was unexecuted or unbilled; its reservation remains consumed. The timeout is not a score of zero, NR, a semantic refusal or a scientific quality failure. Calibration is incomplete and neither passed nor failed as a whole.

[Deviation 00058](waves/W0/deviations/deviation-00058.json) binds the no-network HOLD audit. All 7,334 prior immutable private files, old 905 reservation accounting, judgments and old clock are intact; the original global HOLD bytes are archived and verified. STOP/global HOLD are restored, no request was retried or repaired, and no source collection or main judging occurred. The original 72-hour deadline remains 2026-11-14T02:21:26.568072Z (11:21 JST).

Current cumulative reservations are 939. Exactly 527 requests remain unsent (77 calibration, 150 fresh sources, 300 main ratings) within the unchanged 1,466 cumulative cap. Remaining allowance is not automatic restart permission. A prospective unsent-only continuation would preserve the technical missing, all prior records and the clock without resending the failed request or changing models, scoring criteria or limits; it requires explicit resume authority and offline verification. No resume permit or modified sender has been created. Publication, Core restart and W01 remain forbidden. Earlier sections below are historical snapshots.

## Historical snapshot: EV31 nonofficial W0 started under FINAL owner API approval — 2026-11-11 JST

The owner explicitly answered `承認して開始` to the scoped paid-API start question. The [FINAL owner approval](protocol/approvals/EV31-FINAL-EXECUTION-APPROVAL-20261111.yaml) and [deviation 00056](waves/W0/deviations/deviation-00056.json) record the actual decision; no additional content, name, rights, storage or key choice is pending. New maximum 561 model requests, prior 905 conservative reservations preserved and cumulative maximum 1,466. Publication, Core restart and W01 remain forbidden.

The single EV31 worker started its separate 72-hour clock at 2026-11-11T02:21:26.568072Z; deadline 2026-11-14T02:21:26.568072Z. All six fixed model metadata checks completed HTTP200 with exact identity. [Deviation 00057](waves/W0/deviations/deviation-00057.json) binds the actual-start evidence. Common calibration105 is in progress; fresh150 collection and reciprocal300 main judging remain blocked until both primary AND full-record fixed guards and an explicit delegated definition/adversarial technical review are accepted. Current progress is append-only in the separate private EV31 ledger. No calibration clearance or W0 qualification is implied.

The tested release, new35 bank, approved method, existing key routes and numerical criteria are unchanged. Prior raw observations, judgments, counters and clock are preserved; original global HOLD bytes were archived before the authorized scoped gate release. Invalid outputs are not repaired/resent and failure/unknown attempts consume allowance with HOLD. New35 targets remain AI proposals, not human gold; all45 diagnostics and cross-source comparability limitations remain. Earlier readiness sections below are historical snapshots.

## Historical snapshot: EV31 execution preparation complete; separate API approval only remains — 2026-11-11 JST

The native EV31 execution package is fixed under its [execution release lock](runtime/EV31-execution-release-v1.0.lock.json) and [execution plan](runtime/EV31-execution-plan-v1.0.json). The adopted new35 bank, prospective v3.1 method and reviewed plan bytes remain unchanged. All 35 new offline tests passed, including the complete 561-request two-stage MockTransport run and cumulative 1,466 reservation audit. DRAFT/old permits fail before keys or HTTP; HTTP, timeout and unknown attempts consume allowance and HOLD without replay. Primary-only success cannot bypass the full-record guard or explicit definition/adversarial technical review. All 45 code diagnostics remain descriptive, not human-gold validity or new cutoffs.

[Deviation 00055](waves/W0/deviations/deviation-00055.json) binds the verified package and review page. All 7,335 old private files, old judgments, 905 conservative reservations and the original clock are unchanged. Only a new private preparatory baseline, STOP, salt and DRAFT permit were allocated in the adopted EV31 namespace: no RUN_BINDING, reservation, new clock or FINAL execution authorization. Actual new API requests are zero and STOP/global HOLD remain. Existing keys, owner name, rights, cross-family sharing and encrypted storage are carried forward; no new forms or withdrawn USD5 gate.

Execution preparation is complete. The sole remaining owner decision is explicit API execution consent for this separate nonofficial W0 trial: at most 561 new requests (6 metadata, 105 calibration, 150 fresh sources, 300 nonself judgments), 1,466 cumulative reservations and a new 72-hour window. Both primary AND full-record fixed calibration guards plus delegated technical review precede collection. Provider acceptance, new calibration clearance, W0 pass and cross-source comparability are not established offline. No model confirmation, observation/scoring API, publication, Core restart or W01 has been performed.

## Historical snapshot: new35 and EV31 plan adopted; execution still closed — 2026-11-11 JST

The owner adopted the reviewed 35-case content/proposed labels and separate 561-new/1,466-cumulative/72-hour plan. The [hash-bound adoption declaration](protocol/approvals/EV31-NEW35-PLAN-ADOPTION-20261111.yaml) is now authoritative for content/plan adoption. Reviewed bank, plan, HTML and preparation-lock bytes are deliberately unchanged; their DRAFT flags are historical source metadata, not a new execution permit. AGENT-proposed diagnostic targets do not become human gold through owner content review. Primary AND full-record calibration guards plus technical review remain the adopted prerequisite for fresh collection.

[Deviation 00054](waves/W0/deviations/deviation-00054.json) binds the adoption verification: all 7,335 existing private files and 2,758 historical bindings unchanged, actual 561/905 accounting and old clock intact, two execution gates still rejecting adoption even with execute flags, and zero API calls. The prior 43-tested preparation version is unchanged. No new run ledger, salt, clock, live sender or FINAL execution package was created. STOP/HOLD remain; model confirmation, observation/scoring, publication, Core restart and W01 are not authorized or performed. Content/plan adoption needs no further owner decision; execution-package fixation/offline verification and a separate explicit API execution approval remain before dispatch.

## Historical snapshot: new35 and separate EV31 plan prepared; adoption pending — 2026-11-11 JST

Prepared a [new35 calibration draft](scoring/calibration-v31-new35-v1.0-DRAFT.json): seven domains × five primary anchors, all developmental 0/1/2 levels and refusal R0–R4, E4 extraction cases and an adversarial instruction-injection case. These are newly authored AGENT synthetic examples with proposed diagnostic labels, not human gold. Unannotated auxiliary targets are not assumed false/zero. Case IDs, proposed targets and rationales stay outside the 105 judge fixture bodies. All new response texts differ from both prior calibration banks and all 300 old source records checked; normalization was duplicate diagnosis only, not scientific data conversion.

The [separate draft plan](runtime/EV31-W0-plan-v1.0-DRAFT.yaml) proposes at most 561 new requests (metadata 6, calibration 105, fresh source 150, reciprocal main 300), preserving prior 905 reservations and capping cumulative reservations at 1,466. A new 72-hour clock is still unset; no old unused slots/window transfer. Primary AND full-record fixed calibration guards plus explicit delegated technical review precede fresh collection. All 45 code diagnostics remain descriptive, not new pass cutoffs or measurement-validity certification. The 5,652,480-token generated-cap sum is a bound, not actual usage or a USD estimate; the removed USD5 condition is not restored.

All 43 new offline tests passed, including an in-memory 561-request/1,466-bound workflow and synthetic 35/105 + fresh 150/300 roundtrips. The previously 694-tested v3.1 method lock is unchanged, not rerun. All 7,335 existing private files, 2,758 historical bindings, judgments, actual 561/905 accounting and old clock remain intact. No new live folder/ledger/approval/clock/sender/FINAL package was allocated. [Deviation 00053](waves/W0/deviations/deviation-00053.json) binds the review HTML, material/plan draft lock and test report. One owner decision remains: adopt this content/proposed-label set and plan together; adoption is NOT API execution consent. Existing name/rights/encryption/key choices are carried forward. STOP/HOLD remain; model confirmation, API restart, publication, Core restart and W01 were not performed.

## Historical snapshot: prospective v3.1 adopted and verified offline; APIs held — 2026-11-11 JST

The owner adopted the future auxiliary contract in the [v3.1 approval record](protocol/approvals/AUXILIARY-CONTRACT-V31-ADOPTION-20261111.yaml): developmental four-code levels 0/1/2, explicit no-refusal R0, and Gemini J02 judging cap 16,384. Thinking settings and other judge caps (8,192), all source/judge model IDs, primary anchors, NR, 45 fields, schema, validators, nonself routing and numerical guards remain unchanged. This is a separate [v3.1 method](scoring/ai-reciprocal-evidence-v3.1.json), not an edit or retrospective application to v3.0/EV3.

Preparation, physical payloads, strict import, component/full-record aggregation and a separate offline CLI are implemented. All 694 tests passed: 169 frozen-release regressions, 255 preserved-prototype tests, and 270 v3.1 tests. This includes synthetic 35/105 and 150/300 roundtrips and CLI end-to-end tests. Healthy and invalid/null/truncated/disagreeing synthetic scenarios give identical old/new aggregate payloads. The independent production calibration and actual model improvement are NOT established. [Deviation 00052](waves/W0/deviations/deviation-00052.json) binds the adoption, tested method lock and reports.

All 7,335 existing private files, old judgments and 2,758 historical bindings remain unchanged; EV3 stays at 561 new/905 cumulative reservations and its original clock. No null imputation, rescore, repair, resend or pilot-flag rewrite. CLI outputs are restricted to a separate `MIBO-Education/EvidenceV31Preparation` private namespace and cannot replace existing artifacts. Execution remains closed before files/credentials/transport. New production calibration materials, a separate request budget/window and execution permit are not created or approved. STOP/HOLD remain; no API, publication, Core restart or W01. No additional owner decision is needed for the completed adoption; existing name/rights/encryption/key choices are not reopened. Earlier sections are historical snapshots.

## Historical snapshot: EV3 auxiliary failure diagnosed; future candidate checked offline — 2026-11-11 JST

Offline follow-up rederived all 405 judgments identically and verified 7,335 existing private files unchanged. Main full-record losses (111) were developmental integer nulls only (57), refusal-type nulls only (46), both (5), and Gemini MAX_TOKENS (3). Calibration losses (38) were developmental nulls (21), refusal nulls (16), and MAX_TOKENS (1). These are contract/output failures, not a reason to relax validation, impute nulls, or replace old judgments.

The detached [future candidate](protocol/proposals/auxiliary-contract-v0.1/contract-draft.json) proposes explicit auxiliary developmental 0/1/2 meanings, the existing no-refusal R0 rule, and Gemini judge cap 16,384 with thinking settings unchanged. New ordinal meanings require an owner decision; they are NOT approved or retroactive. All 424 offline checks passed (169 frozen-release regressions plus 255 candidate tests), including all 70 items and 3 pinned judges. This is synthetic contract verification, not demonstrated model improvement, API acceptance, feature validity or W0 clearance. [Deviation 00051](waves/W0/deviations/deviation-00051.json) binds the diagnosis and test reports. No production wiring, new execution budget/window or API authority was created; STOP/HOLD remain. Primary technical results below are unchanged.

The separate nonofficial EV3 trial completed all 561 new requests: 6 exact-model metadata checks, 105 calibration judgments, 150 fresh source answers (50 per series), and 300 reciprocal judgments. Primary calibration was valid in 104/105 judgments; main primary scoring was valid in 297/300. Valid main pairs were OpenAI 49/50, Claude 48/50, and Gemini 50/50, with pair-specific QWK 0.942794, 0.959677, and 0.932976 respectively. All frozen primary numeric guards passed. [Deviation 00050](waves/W0/deviations/deviation-00050.json) binds the delegated AGENT final technical review and the local audit report.

This is NOT wholesale W0/full-feature qualification: full-record validity was only 67/105 in calibration and 189/300 in main scoring; its quality checks failed. All 45 auxiliary diagnostics remain separate. The one calibration and three main Gemini MAX_TOKENS judgments remain invalid, unmodified and unresent. The frozen machine `pilot_passed: false` fields were not overwritten; human-gold validity, statistical independence and cross-source comparability are not established.

All 150 source records and 300 main views were recomputed identically from raw; all 561 new reservations have saved outcomes and no pending request. Old 344 reservations, existing judgments and all 2,758 historical file bindings remain unchanged. The cumulative 905 is conservative reservation accounting, not proof of 905 remotely received/billed requests. The original single clock is unchanged: start 2026-11-10T14:24:39.244340Z; last response 2026-11-10T17:31:57.598000Z; deadline 2026-11-13T14:24:39.244340Z. STOP/HOLD are restored, the execution worker exited, and no further API request is authorized by this review. No publication, Core restart or W01 occurred. Earlier sections below are historical snapshots.


## Current: fresh150 answers verified; reciprocal main300 scoring running — 2026-11-11 JST

Fresh source collection is complete:150 answers,50 each from M01/OpenAI,M02/Claude,M03/Gemini. Every saved source record was recomputed identically from raw and content-screened. The exact locked main batch has150 blind observations/300 requests, each assigned only to the other two families. Main scoring began at new claim262. [Deviation00049](waves/W0/deviations/deviation-00049.json) binds this milestone and the unchanged original clock, not a pilot pass or source-performance comparison.

New primary calibration was accepted104/105 with pair QWK0.978917–0.993087; its1 MAX_TOKENS judgment stays invalid/unresent. Full-record calibration valid67/105 only: all45 auxiliary diagnostics remain separate and NOT wholesale feature-qualified. The accepted primary-component review and same owner permit cover this main stage. Old344 reservations, existing judgments and all2,758 historical file bindings remain preserved; no old answer conversion, rescore, repair or refill.

Model IDs, native request bytes, thresholds and limits remain fixed at561 new/905 cumulative. The one new clock starts2026-11-10T14:24:39.244340Z and ends2026-11-13T14:24:39.244340Z (JST23:24:39); no counter/window reset. Private append-only evidence governs live counts. No automatic pilot pass, human validity/comparability claim, publication, Core restart or W01. Earlier sections below are historical snapshots.


## Current: primary calibration accepted; fresh150 source collection running — 2026-11-11 JST

The delegated new calibration review is accepted:104/105 primary-valid, pair QWK0.978917–0.993087,100% within-one agreement and NR0. All105 saved views were recomputed identically from raw evidence. One Gemini MAX_TOKENS response remains invalid/unresent. Full-record valid67/105 only; all45 auxiliary diagnostics are retained separately, NOT feature-qualified. [Deviation00046](waves/W0/deviations/deviation-00046.json) binds this limited primary-component clearance, not human-gold validity, comparability or an automatic W0 pass.

The originally approved remaining150 fresh source answers/300 reciprocal ratings are now running under the same owner permit. One management-read startup failure happened before any source/main request; [deviation00047](waves/W0/deviations/deviation-00047.json) preserves that failed launch and the explicit software/unsent-work recovery authority. All5 existing office-only management reads then returned200 and fresh source collection actually began at claim112; [deviation00048](waves/W0/deviations/deviation-00048.json) confirms no request replay or key/IAM/billing change. Safe telemetry/operator versions are archived privately.

Old344 reservations, all2,758 historical file bindings and existing judgments remain preserved. Frozen models, native request bytes, scoring criteria,561-new/905-cumulative cap and the single new clock remain unchanged: start2026-11-10T14:24:39.244340Z, deadline2026-11-13T14:24:39.244340Z (JST23:24:39). No source response repair/refill, counter/window reset, publication, Core restart or W01. Live counts are governed by private append-only claims/outcomes, not this snapshot; earlier sections below are historical.


## Current: new EV3 trial actually started; calibration in progress — 2026-11-10

Owner-delegated unstarted/zero-request environment recovery was fixed and recorded in [deviation00043](waves/W0/deviations/deviation-00043.json). The real trial then started at2026-11-10T14:24:39.244340Z; its single72-hour deadline is2026-11-13T14:24:39.244340Z (JST23:24:39). All6 exact source/judge model metadata GETs passed with HTTP200 and the new105-case calibration stage is in progress. [Deviation00044](waves/W0/deviations/deviation-00044.json) binds the start and metadata confirmations, not a calibration/pilot pass.

Actual model claims and RUN_STARTED now exist, so zero-request startup recovery authority is no longer usable. New calibration raw responses and fixed primary/auxiliary diagnostics must be reviewed before source150/main300 continuation under the same owner authorization. Frozen scoring, model IDs and169-test release remain unchanged. Old344 reservations, all2,758 historical file bindings, existing invalid judgments, previous failed launch histories and the consumed one-use exception remain preserved. Limits are561 new/905 cumulative and one new72-hour window; no forced passage, data repair, request resend or counter/window reset. No publication, Core restart or W01. Private append-only evidence governs live counts; earlier sections below are historical snapshots.


## Current: one approved relaunch consumed; zero model requests — 2026-11-10

The owner approved exactly one unstarted-stage relaunch with the existing Claude User key inherited in child memory; [deviation00041](waves/W0/deviations/deviation-00041.json) records that exception. It was used once (PID31080), and the worker again stopped before RUN_STARTED, RUN_BINDING, any claim/outcome or raw model request. No second relaunch was performed. New model requests0; cumulative reserved344; STOP/HOLD restored; the new72-hour clock has not started.

Exact Start-Process offline probes confirm Claude inheritance works. APPDATA/ComSpec are absent in the held child environment, so the installed Cloud SDK selects a different configuration store without the existing office account. Correcting those child-only standard environment values passes all offline key-format/reference/store prerequisites, including existing office account registration, without any model/management API. The safe worker CLI does not expose its exact exception, and no traceback, score or transport outcome was invented. [Deviation00042](waves/W0/deviations/deviation-00042.json) binds both diagnostic probes and the held-run receipt.

All2,758 historical file bindings, previous judgments and both launch histories remain preserved. The frozen169-test scientific/runtime release and561-new/905-cumulative bounds are unchanged;4 additive one-use gate tests passed. No key file/persistent environment/IAM/billing change, scientific data repair/resend, publication, Core restart or W01. Further launch requires new owner authority because the one-use exception is consumed. Proposed minimal decision: delegate environment correction/relaunch only while the trial is unstarted and model claims/requests/raw remain0; no request retry or clock reset. Earlier sections are historical snapshots.


## Current: execution approved; held before first model request — 2026-11-10

The owner explicitly approved the new561-request/905-cumulative separate EV3 trial and delegated new calibration review/continuation in [deviation00039](waves/W0/deviations/deviation-00039.json). The FINAL permit exists; this is not W01/publication/Core authority. One hidden worker was launched, then exited before RUN_STARTED, RUN_BINDING, any reservation or raw request. New model calls0, cumulative reserved344. The proposed new72-hour clock has not started.

A safe child-environment check found the existing Claude User key present but absent from the worker's process environment. The frozen noninteractive resolver requires that process key before Gemini management/model HTTP. This is a launch-environment problem, not a model-authored failure or invalid score. The safe CLI suppresses the exact exception; diagnosis rests on direct environment inspection and resolver control flow. [Deviation00040](waves/W0/deviations/deviation-00040.json) preserves the startup evidence; all2,758 historical file bindings and current FINAL preflight were rechecked.

STOP/HOLD are restored. First-launch logs, PID and gate-release receipts are preserved; no automatic relaunch, invented outcome, old-answer repair/resend, cap/clock reset or scientific change. Existing-key reuse remains approved and no key input/new form is needed. Because the approved plan forbids automatic relaunch, a single explicit zero-model-request relaunch exception is required before inheriting the existing User Claude key into child memory and trying the unstarted first stage again. Bounds remain561 new/905 cumulative, with one72-hour window from the first recorded actual run start. Earlier sections below are historical snapshots.


## Current: one-decision EV3 pilot package ready; APIs still held — 2026-11-10

The remaining preparation is complete as one package: a new synthetic35-case calibration bank, a prospective fresh150-answer/300-rating trial, the real three-provider sender, FINAL-owner gate, delegated calibration-review gate and append-only two-witness accounting. [Approval scope](runtime/EVIDENCE-PILOT-APPROVAL-v1.0.md), [35-case review](protocol/w0-records/evidence-pilot-calibration-review-v1.0.md) and [operator runbook](runtime/EVIDENCE-PILOT-OPERATIONS-v1.0.md) are fixed for the single remaining owner execution decision. [Deviation00038](waves/W0/deviations/deviation-00038.json) records169 passing offline tests,0 failures/skips/deselections, including the complete561-request MockTransport flow and both review-separated stages.

Proposed new campaign:6 exact-model GETs +105 new calibration ratings +150 fresh source answers +300 non-self-family main ratings =561 new maximum; old344 remain preserved, giving a proposed three-series cumulative cap905. This is a separate nonofficial trial with its own72-hour clock after a future FINAL permit, not an old-W0 restart, transfer of its245 unused slots or retroactive pass. The original150 answers/54 ratings/8 invalid primary labels/1 unresolved reservation and old calibration judgments remain unchanged. Frozen criteria, source-ID method lock and45 auxiliary codes are unchanged; new material is synthetic, not human gold, and the trial does not establish statistical independence or comparability.

Actual new claims0, model/credential-management API calls0, no FINAL execution permit and STOP/HOLD still present. Existing owner/rights/storage/key determinations carry forward without new forms. Only one owner approval of this completed scope remains before execution; actual provider acceptance and new calibration/pilot results are necessarily not established by offline tests. No publication, Core restart or W01. Earlier sections below are historical preparation snapshots, not outstanding implementation work.


## Current prospective evidence v3 implementation — 2026-11-10

The owner approved future production implementation and offline verification only. A separate versioned method now provides source-ID catalog construction, all3 native provider payloads, raw-ID import, primary/auxiliary validation, aggregation and a private CLI. Old methods/defaults are not replaced. [Operations](runtime/EVIDENCE-REFERENCES-v3.0-OPERATIONS.md) and [deviation00037](waves/W0/deviations/deviation-00037.json) record140 passing offline tests with0 failures/skips/deselections; implementation lock8089c59bd655bd5eb99d78c5302ef5c7474585ec9f9082be454badcdd55419e4.

The frozen240-character and6-excerpt limits remain:10 long original lines are split losslessly, giving6,746 reference segments across150 source answers with zero character/UTF8-value loss. Native descriptors for300 main and105 legacy-CAL35 development requests were prepared privately, NOT sent. Complete105/300 synthetic response flows are software tests, not candidate model outputs, new calibration clearance, independent acceptance or W0 passage. Native provider acceptance and score/semantic reliability remain unverified. The execute entrypoint rejects before credentials or transport.

Old W0 remains held at344/589 reserved allowance, including1 unresolved request;150 answers,54 ratings,8 invalid primary labels, the102/105 primary-calibration review and72/105 failed full-record view are unchanged. Its fixed main valid-pair guard remains unreachable;245 slots are unused, with no old-response conversion, Gemini repair/resend, counter/window reset or new run permit. Future model calls require separately fixed calibration/independent-verification materials and a new bounded run plan/approval. No publication, Core restart or W01. Existing unchanged key/rights/storage/name determinations are not reopened. Earlier sections below are historical snapshots.

## Current blocker: interrupted main scoring and unreachable fixed guard — 2026-11-09

Offline follow-up: the owner-approved [evidence-reference proposal Draft](protocol/proposals/evidence-references-v0.1/README.md) is prepared; [deviation00036](waves/W0/deviations/deviation-00036.json) records52 passing offline tests and lossless round-trip of150 source texts/6,735 lines. Six of8 nonliteral quotes match only after diagnostic whitespace/Markdown removal; two are unexplained by the tested transforms. No old quotation or invalid label is repaired. The isolated source-ID prototype is not a production integration or model-reliability result. Next owner decision is prospective production implementation/offline verification only; API restart and a new run budget/window are not included.

After 84 offline verification cases, the single owner-authorized Claude/E2-10 source replay succeeded (HTTP200;132.929 seconds) with byte-identical request content. The HTTP wait was extended to600 seconds with automatic retries0. All25 new source requests completed, giving150 saved answers:50 each from OpenAI, Claude and Gemini. The original264 attempts,125 answers, calibration review, old invalid labels and v1.4 failure remain unchanged.

The worker unexpectedly exited after80 new reservations and79 saved outcomes:25 source answers and54 main ratings. Main request55, a Claude judge request, has a durable claim/request but no saved response or outcome; remote receipt, billing and the exact termination cause are unknown. Its allowance remains consumed. Cumulative reserved allowance is344/589;245 main requests are untouched. STOP/HOLD are present; no automatic restart, resend or invented failure/score/outcome. See [deviation00033](waves/W0/deviations/deviation-00033.json).

Offline review of54 saved ratings found46 primary-valid and8 literal-quote mismatches (J01:1; J02:7); full-record valid26. Five distinct answers in the Claude-source block already lack a valid pair, so even all unfinished ratings valid gives at most45/50=90%, below the fixed95% per-source pair requirement. The current main guard is therefore unreachable; completing245 more requests cannot make this W0 pass. This concerns judging contract completeness, not source-model performance. [Deviation00034](waves/W0/deviations/deviation-00034.json) binds the upper-bound proof. No threshold, quote, score, Gemini invalid response or existing judgment was repaired/relabelled; all45 auxiliary fields remain separate and preserved.

Primary calibration remains reviewed at102/105; the historical full-record calibration remains failed at72/105. No W0 pass, public release, Core restart or W01. Original deadline remains2026-11-10 22:46:34.923620 JST. Further execution or prospective scoring redesign needs owner direction; unchanged key/rights/storage/name/CAL35 approvals are not reopened. Earlier sections preserve historical snapshots.

## Current v1.6: one bounded transport replay authorized — 2026-11-09

The owner's2026-11-08 conditional approval is transcribed in [deviation00032](waves/W0/deviations/deviation-00032.json) after84 offline cases passed across hash-identical regression/full325-request stages. Existing264 attempts,125 answers, primary-calibration review, old22 labels and v1.4 failure remain unchanged. No new human governance forms or calibration requests are required.

Only one explicit replay of the old Claude/E2-10 empty transport failure,24 untouched source slots and300 main ratings are authorized (325 new maximum /589 cumulative). The replay has a separate attempt identity linked to the old failure; native request bytes, models, prompts, generation settings and scoring remain v1.5. HTTP wait is600seconds with automatic retries0 and safe transport-subtype metadata. Gemini invalid outputs are not repaired or resent. No further failure retries/refills or allowance reset are authorized.

Original deadline:2026-11-10 22:46:34.923620 JST. The existing primary-calibration review (102/105; full-record72/105 remains failed) carries by hash. No W0 auto-pass, human validity/comparability claim, publication, Core restart or W01. This is an authorization/start snapshot, not successful completion; actual private evidence and result receipts govern progress. Earlier sections preserve historical states.

## Current blocker: one source transport failure; no restart authority — 2026-11-08

v1.5 completed83 new calibration HTTP200s and delegated primary-calibration review passed (102/105, pair QWK0.9795–0.9936). The original full-record view remains failed at72/105; all55 earlier attempts,3 calibration technical missings,22 historical labels and v1.4 failure are unchanged.

Collection then made126 attempts:125 answers were saved (M01/OpenAI42, M02/Claude43, M03/Gemini40). The126th source request, Anthropic `claude-opus-5` /E2-10, ended after120.063 seconds without an HTTP response/body. The client timeout is120seconds, making timeout likely, but the frozen handler records only a generic TransportError; exact subtype, remote receipt and billing are unknown. This is not a Gemini failure, model-authored NR, API401/429 diagnosis or permission to retry. No answer/score was fabricated and no data was repaired/resent.

All264 cumulative raw/ledger bindings and125 successful source records were audited. Main ratings0; all old STOPs, new STOP and Education HOLD are present, worker exited, keys cleared. See [deviation00031](waves/W0/deviations/deviation-00031.json) (00030 records the preceding primary-calibration review).

Remaining324 requests are allowance, not restart authority: only24 original source slots remain, so without retry/refill there can be at most149 successful answers, below the frozen150 minimum. Any retry, missingness, transport-policy or cumulative-cap change requires an explicit owner decision; no v1.6 or new permit is implemented. One additional successful source attempt would require a minimum cumulative cap589 (264+24+1+300), but is not authorized. Original deadline remains2026-11-10 22:46:34.923620 JST. No W0 pass, publication, Core restart or W01. Earlier sections below are preserved historical snapshots.

## Current v1.5 restart approved; actual calibration review remains — 2026-11-08

The owner supplied the single bounded execution approval; no additional name/rights/storage/CAL35 decision is pending. [Deviation00029](waves/W0/deviations/deviation-00029.json) binds the tested v1.5 plan/release. Only the new v1p5 preparation STOP and Education credential HOLD were archived for this run; all older run STOPs and records stay intact.

Actual calibration guards and delegated raw-bound technical review must pass before the450 collection/main requests. Preserve the original v1.4 failure, all55 old attempts/3 technical missings/22 labels and all invalid Gemini values without repair/resend. Remainder533 /cumulative588 and the original deadline2026-11-10 22:46:34.923620 JST remain. Publication, Core restart and W01 are excluded; W0 passage is not automatic. This is an authorization snapshot; actual holds/results are recorded separately. Older sections below retain historical approval boundaries.

## Current v1.5 boundary: no API restart authority — 2026-11-08

The owner has approved offline component-validity separation; that design decision is no longer open. [v1.5](runtime/W0-v1.5-resume-proposal-ja.md) retains all55 requests,3 technical missings and old v1.4 failure/labels without repairing Gemini. Primary and45 auxiliary field contracts are reported independently; unchanged numerical thresholds/N105 apply to the primary component under a separately versioned analysis policy, not a claim that v1.4 passed.

Only a later explicit execution approval remains an owner decision. Do not repeat name/rights/storage/key/CAL35 approvals. Real v1.5 calibration clearance is not established by offline tests and remains required, with delegated raw-bound AGENT review before collection/main. No all-feature qualification, automatic W0 pass or W01 approval is inferred. New allowance533 /cumulative588; original deadline2026-11-10 22:46:34.923620 JST. Every STOP/HOLD remains; no API, publication or Core restart. Older blocker sections below are historical snapshots.

## Current v1.4 guard is unreachable; APIs held — 2026-11-08

Native Anthropic API acceptance is now observed: all15 new requests returned HTTP200 and structurally valid JSON. The blocker is not grammar compilation. The unchanged whole-record rule rejects6 of15 new judgments because a required RATEABLE auxiliary code is null, despite primary-shape/ID/anchor/quote checks passing. There are12 valid full judgments among22 attempted calibration slots. The maximum after all83 remaining slots is95/105, below the unchanged100-valid requirement.

The agent stopped under delegated technical review and preserved the inflight result. **55 attempts /588 cap**, remaining533, all old40 and3 technical missings intact. New invalid statuses and old invalid Gemini remain unchanged; no repair, retry, quota/time reset or pass declaration. STOP/HOLD are restored; worker exited.

A new owner decision is needed for a prospective validity-design review, not another technical-failure classification or repeated rights/encryption/name approval. Possible review: separate primary-score validity from feature-code completeness, keeping all items and nulls visible and preserving historical v1.4 invalid statuses. No new rule or API is currently authorized. No source collection/main ratings, publication, Core restart or W01. Original deadline:2026-11-10 22:46:34.923620 JST.

## Current v1.4 offline implementation boundary — 2026-11-08

[The owner-approved v1.4 proposal](runtime/W0-v1.4-resume-proposal-ja.md) removes only Claude's native grammar enforcement while retaining the complete frozen prompt/schema/validator and scoring criteria. It retains40 attempts, three HTTP400 technical missings, the invalid Gemini answer unmodified/unresent and three valid ratings. The first seven calibration slots, model metadata, Smoke and qualification are never resent. Planned remainder:98 calibration +150 source answers +300 main ratings =548, cumulative cap588.

No extra human forms are required: existing three FINAL determinations are carried by references, and one later execution authorization suffices. Technical-failure classification is automatic, not another policy-approval request; it neither creates a score nor grants retries/API permission. Old and new STOPs plus Education HOLD remain.

Actual Claude API acceptance, unstructured-JSON compliance, calibration clearance and W0 passage are unproven. No repair or threshold relaxation is allowed to make them pass. Original deadline:2026-11-10 22:46:34.923620 JST. API restart, publication, Core restart and W01 are still prohibited. Earlier sections below preserve historical holds, not new tasks to repeat.

## Current hold after v1.3: 40 preserved attempts — 2026-11-08

v1.3 was explicitly authorized and made 3 new calibration requests: Gemini and OpenAI passed frozen validation; Anthropic returned HTTP400 for an oversized compiled grammar. **Explicit unions 16 /optional fields 0 did not establish compiler acceptance.** The worker stopped without retry and restored STOP/HOLD. All old 37 attempts, two approved technical missings and the invalid Gemini response are unchanged and unresent. No fresh collection, main scoring or calibration clearance occurred.

Current 40 /588 cap leaves 548 allowance, not restart permission. The third HTTP400 is preserved but not automatically approved as an additional technical missing. A prospective continuation would need to retain all 7 attempted calibration slots, review handling of the additional failure, and version/test a grammar-size workaround without changing scoring criteria, model IDs, prompts or guards. No v1.4 or further API is authorized. The only next owner decision proposed is offline preparation of that bounded plan, not repeated name/rights/encryption/key/CAL35 review.

Original deadline: 2026-11-10 22:46:34.923620 JST. Publication, Core restart and W01 remain excluded. See deviations 00023/00024; earlier status sections below are historical.

## Current v1.3: only future execution approval remains an owner decision — 2026-11-08

Both HTTP400 failures are now owner-approved technical missing; the invalid Gemini answer must remain unmodified and unresent, as must the one valid OpenAI rating. [The separate v1.3 plan](runtime/w0-live-plan-v1.3.yaml) prepares 551 new maximum /588 cumulative with a fixed37-attempt baseline. All105 logical calibration slots and existing scoring thresholds remain. The previous statements below about an unapproved second missing are preserved historical snapshots.

The prospective Anthropic wire compresses 33 finite boolean/null domains, explicit unions49→16. Real compiler acceptance and actual calibration clearance remain unproven. A named raw/ledger-bound AGENT review is required before collection/main. No metadata/Smoke/qualification or first-four-slot resend, repair/refill, count reset or time reset is allowed. Original deadline:2026-11-10 22:46:34.923620 JST.

No additional name/terms/encryption/CAL35/key decision is requested. API restart requires a later explicit v1.3 execution approval with a new FINAL hash-bound permit; the preparation decision does not create one. All old STOPs, new preparation STOP and global HOLD remain. Publication, Core restart and W01 remain excluded.

## Current v1.2 execution hold: provider union limit — 2026-11-08

Current totals: 37 attempted three-series requests, 551 allowance remaining within 588. Three v1.2 calibration attempts yielded Gemini HTTP200 (invalid under frozen RATEABLE code requirements), OpenAI HTTP200 (valid), and Anthropic HTTP400 (49 union parameters; provider maximum 16). All 37 raw attempts and ledger entries are retained; old/new STOPs and Education HOLD are present. No calibration clearance, fresh pilot, main scoring, publication, Core restart or W01.

Do not count the two HTTP200 responses as two valid ratings, repair Gemini's missing codes, silently add a second technical missing, resend any failed/invalid case, or reset budget/time. The first technical missing was approved; the additional HTTP400 still requires a policy decision before continuation. A full schema representation review is needed: the v1.2 tests checked equivalence/gates but missed the provider union ceiling. In-memory boolean/null finite-enum diagnostics reduce explicit unions 49 to 16 without dropping fields, but no new adapter is implemented or live-verified. Any cap-preserving proposal (101+150+300=551) must be separately reviewed and authorized. The original 72-hour deadline remains unchanged.

See deviations 00019–00021. Deviation 00021 corrects derivative wording in 00020/first hold receipt; raw data and numerical valid count were not changed.

## v1.2: approved preparation, not API restart — 2026-11-08

The owner approved retaining 34 existing attempts and the sole HTTP400 as explicit technical missing. [v1.2](runtime/w0-live-plan-v1.2.yaml) prepares a separately bound equivalent Anthropic schema wire and 104+150+300=554 future requests, staying within 588 cumulative. No metadata/Smoke/qualification/failed-slot resend is allowed. The frozen importer retains the HTTP400 as invalid/no judgment, not a model-authored NR or imputation; all 105 planned calibration slots stay in the denominator, and thresholds remain unchanged.

The new private run and accounting destinations are separate. Original raw files, 34-attempt accounting, old FINAL records and frozen versions are untouched. All old STOPs, the new preparation STOP and global Education HOLD remain. A new FINAL execution authorization is not created by the preparation approval; actual schema acceptance is unproven. Future continuation must still respect the original 72-hour W0 outer deadline and actual AGENT calibration review before fresh collection/main scoring. No publication, Core restart or W01 is authorized. The only current owner decision still needed is a later explicit v1.2 start, not renewed name/rights/encryption/key/CAL35 consent.

## Current blocker: first calibration request rejected, no retry — 2026-11-07

W0 v1.1 was explicitly approved and launched. Six exact model metadata checks, three Smoke and 21 qualification responses completed; the office-managed Gemini route worked. Anthropic rejected calibration attempt 1 with HTTP400 at nullable enum JSON-schema validation, not because of score disagreement. Current counters are **31 new / 34 cumulative**; remaining allowance is 554. Valid calibration ratings, fresh pilot answers and main ratings remain zero. The worker exited and old/new STOP plus Education restart HOLD are present. Raw evidence, original approvals, old three attempts and all frozen inputs remain unchanged.

Do not retry, fix a frozen wire in place, fabricate a calibration rating, or infer authority from the unused allowance. An in-memory equivalent `anyOf` diagnostic passed 13 finite-enum checks but is not applied or live-verified. A prospective compatibility-only continuation and the handling of the failed technical rating require review. Retaining it as explicit technical missing would leave 104+150+300=554 future attempts within 588 cumulative; repeating it to obtain 105 successful calibration responses would instead require cumulative 589 and a new cap approval. Neither continuation is approved or implemented by this status update. Publication, Core restart and W01 remain excluded. See deviations 00016/00017.

## Latest W0 v1.1 boundary — 2026-11-07

The owner approved a new-plan/new-destination/cumulative-ledger preparation, not API restart. Preserve the existing three metadata attempts; the prospective allowance is 585 new requests and 588 cumulative in the three-series scope. The separate earlier M02-only 10 requests remain preserved outside that allowance. See [v1.1 plan](runtime/w0-live-plan-v1.1.yaml) and [preparation decision](protocol/approvals/W0-V1.1-PREPARATION-APPROVAL-20261107.yaml).

Before live work, a later explicit owner start must bind the tested v1.1 plan/release, prepared private destination and historical baseline. Both run STOPs and the global restart HOLD are retained meanwhile. Unchanged terms, storage-encryption attestation, named owner, approved 35 cases, paid project, no-USD5-cap policy and delegated AGENT calibration review are carried forward; they are not new owner questions. Exact live model qualification, actual calibration review and pilot assessment cannot be satisfied by offline mocks. No Core restart, W01 date, model substitution, retry/refill, publication or public registration is authorized by this preparation.

The following sections preserve earlier readiness snapshots, not standing permission to execute.

## Current authorized launch gate — 2026-11-07

Owner approval and the three scoped named records are now complete for the exact W0 v1.0 plan, 585-request maximum and delegated agent calibration review. This decision is [recorded locally](protocol/approvals/W0-LIVE-EXECUTION-APPROVAL-20261107.json); do not ask for the same W0 approval again. The worker is at the hidden local Gemini-key input gate. Model access, actual identity/control qualification and calibration quality are checks within the now-authorized run, not completed results. Any anomaly stops without automatic retry, refill or substitution. The private run's attempt ledger determines actual calls used.

Publication, W01, new keys, billing/IAM changes and unrelated account changes remain outside scope. Older Draft/no-execution statements below preserve the sequence before this explicit owner instruction and do not revoke the later bounded permission.

## Latest bounded W0 package — 2026-11-07

The first-party sender and deny-by-default authorization gate are implemented in the new live release. [The execution plan](runtime/w0-live-plan-v1.0.yaml), [three proposed scope records](protocol/w0-records/protocol-owner.proposed.yaml) and [provider-specific rights review](protocol/w0-records/provider-rights-review-v1.0.yaml) now replace those items as engineering/documentation blockers. They do not finalize or authorize themselves.

Only the following start gates remain: the owner's explicit bounded W0 approval and transcribed FINAL authorization matching exact plan/code/record hashes; any missing runtime key supplied locally in hidden process memory (currently Gemini); then live verification inside W0 of actual access, returned identities, controls and real calibration quality. Documentation and a key's presence do not prove those live properties. Calibration is reviewed by the delegated agent before collection/main continuation; anomalies are held for owner direction. No additional routine policy, 35-case, encryption, key-reuse, USD5-cap or second-human decision is requested.

The earlier pre-W0 status file and paragraphs below are preserved historical snapshots. They must not be read as a request to redo completed preparation or as authority for model calls. No current live authorization, public release or W01 approval exists.

## Current W0 holds after case-content approval — 2026-11-07

The [35-case content approval](protocol/approvals/CAL35-CONTENT-APPROVAL-20261107.yaml) removes owner case-bank review as a blocker. It does not remove actual calibration or execution holds. The original bank, review list and frozen preparation snapshots remain unchanged; consult [current post-approval status](runtime/pre-w0-status-20261107.json) for consent state.

Before new W0 API execution, complete these four bounded groups:

1. **Production path:** an authorized first-party live sending path and deny-by-default gates. Existing `dispatch_live` always refuses; only mock roundtrips have been tested.
2. **Real execution plan:** proposed exact source and judge IDs, the approved 150-slot allocation bound to actual IDs, private evidence root, observation site/window, prompt/request hashes, single-attempt pilot policy, and stage-specific maximum calls. Models are not live-qualified by being named in a plan.
3. **Scope/rights records:** source-specific account/answer-sharing eligibility and content screening; named records scoped to the 3-source pilot and judging. Existing M02-only FINAL records do not cover this expanded work. Retain previous global sharing/encryption/no-cap/key-file decisions; do not ask for them again.
4. **Explicit staged execution authority:** later owner approval for precisely scoped metadata/smoke, collection and judging calls. None is authorized now. Case-content approval is not a substitute.

Once those are met and API execution is separately approved, W0 performs actual source/judge identity and CLOSED-control checks, common 35-case/105-rating calibration, 150 fresh responses and 300 non-self-family ratings, with preserved failures/disagreement and no automatic refill or third judge. These real results are not prerequisites that can be completed before the first authorized API call; they are the gated W0 work itself. Real calibration clearance and pilot pass remain pending.

After W0 passage, confirm a future exact W01 date, final official manifest/model/schedule/site locks and prospective Education publication/version synchronization. Core W03 progress or publication does not satisfy these Education gates.

## Preparation snapshot before content approval — 2026-11-07

- W01 future-after-W0 policy is owner-approved in [MIBOE-AM-20261107-03](protocol/amendments/MIBOE-AM-20261107-03.yaml). Only the exact future date and dated Wave manifest remain to be confirmed; do not ask for the policy again, backdate W01, or inherit Core W03 dates.
- The new collector/blinding/reciprocal judging pipeline exists in `three_series.py` and is exposed only under `miboe preparation` with an in-memory transport. Payloads, response bodies, identities, invalid imports, failures and disagreement are preserved. Live dispatch remains disabled, not live-qualified or authorized.
- The authored calibration bank is unchanged and its 35-case review list is available as a derivative. Owner content approval remains pending. No calibration result, fresh pilot answer, real rating or W0/W01 pass is created by synthetic tests.
- Remaining live prerequisites: exact source/judge qualification and locks, source-specific rights/content checks, scoped governance, reviewed calibration and real pilot assessment, then separate execution authority. Education publication is a later versioned action; no remote write is authorized by preparation.

The historical paragraphs below retain earlier development snapshots. In particular, an absent three-source wire path or an undecided baseline *policy* is no longer a current implementation blocker. Live qualification and the exact date remain open.

## Current reciprocal method — 2026-11-07

- The owner approved OpenAI as J03 and a rotating non-self-family pair for each source, plus common three-judge calibration. The previous OpenAI-rater exclusion and same-fixed-two-judge assignment are historical, not current blockers or policies. See [MIBOE-AM-20261107-02](protocol/amendments/MIBOE-AM-20261107-02.yaml).
- Offline prepare/import/aggregate and strict hash bindings are implemented. The 35-case calibration bank still requires content review and live qualification; authored intended scores are not validated gold. Numeric checks cannot automatically grant comparability or pilot passage.
- Actual observations, ratings, calibration, model metadata qualification, a three-source collection runtime, scoped governance and a new official baseline remain unexecuted/unlocked. No model API execution has been authorized.
- The owner subsequently approved three source families for Core too: OpenAI, Claude and Gemini. Core amendments MIBO-AM-20261107-02/03 supplement current ACI v2.0/v2.0.4 prospectively, not a return to UI. Perplexity is out of the new target, not missing data or a pair-decision blocker. The final inherited Codebook is now retrieved/checksum-verified and compared against all 52 draft-subset variable methods and 24 exact prompts. A separate three-series next-design configuration is staged on the controlled VM with both execution sentinels DISABLED; no collector is started or production sender migration claimed. Historical four-series records/denominators are unchanged. Core's 72 development cases and separate unsampled 240-response validation plan are not Education instruments or completed validation. Content review, exact new source/judge freezes, prospective registration and production integration remain open; source retrieval is no longer a blocker.

## Current three-series design — 2026-11-07

- The owner approved OpenAI/Claude/Gemini for both formal observation and the 150-answer pilot in [MIBOE-AM-20261107-01](protocol/amendments/MIBOE-AM-20261107-01.yaml). This source-scope choice no longer requires approval. xAI/Perplexity are out of prospective scope; their credentials, qualification and migration are not new-design prerequisites.
- Three-series exact model/returned-identity qualification, an actual prospective sample lock, scoped named governance, a compatible API sender/runtime and an explicit new execution instruction remain required. Existing M02-only FINAL records are not universal pilot or formal-wave approval.
- A new prospective official baseline/schedule/site/runtime manifest is required. Do not backdate the elapsed v1.0 W01 or run its five-series/Core-35 implementation as a three-series study.
- The approved pilot allocation is 50 fresh answers per active series, 150 total, plus 300 initial AI ratings. No actual new answer or rating has been produced. Existing seven W0 answers are preserved separately; a shortfall below 150 remains incomplete.
- The two-model scoring lock and same-family sensitivity requirement remain unchanged. Paid evaluation-only sharing and encryption owner attestation are retained. Do not request an encrypted key file, USD 5 cap or second human coder again; none is a current prerequisite. Source-specific rights/content screening still precedes transfers.
- `miboe study status` is read-only. Design approval, offline tests, and publication of v1.0 are not API execution or current-wave readiness.

The sections below preserve historical v1.0 readiness context. Five-series qualifications and provider ambiguities listed there are not current three-series target requirements.

## Scientific source state

All five authoritative v1.0 scientific artifacts are present, Frozen, and exact-file-hash verified. There is no remaining scientific-source blocker for `SCIENTIFIC_PROTOCOL_COMPLETE`.

## Prospective AI-scoring method — 2026-11-06

- [MIBOE-AM-20261106-01](protocol/amendments/MIBOE-AM-20261106-01.yaml) records the owner's replacement of human double coding with at least two distinct AI model raters. Recruiting a second human is not an amended-method blocker.
- Documentation-selected J01 `claude-opus-5-5` and J02 `gemini-3.8-flash`, common prompt/schema, minimal input, aggregation/disagreement policy, and pilot quality guards are fixed in the [offline specification lock](scoring/ai-panel-v1.0.lock.json). Offline prepare/import/aggregate is implemented; no live API transport exists.
- Live judge access and returned-version qualification, cross-provider answer-sharing permissions, encrypted grading storage, the actual prospectively locked pilot sample, source-series coverage/same-family sensitivity review, and paid-call authorization remain open. No judge API call is authorized by this method/implementation decision.
- The original at-least-150-response pilot requirement is retained; seven M02 Q2 responses do not satisfy it. AI-to-AI agreement is not human validation.
- The published v1.0 sources and elapsed W01 anchor are preserved. A future wave must explicitly bind the amended method and an approved new schedule.

The operational lists below describe the baseline repository state, not private provider-specific approvals or live evidence.

## W0 operational blockers

- Protocol-owner, provider-terms, and ethics/governance approvals are not recorded.
- The three human-governance templates exist, but no `FINAL` human-attributed records have been placed in `waves/W0/governance/records/`.
- Credential/environment presence preflight is incomplete, including persistent `MIBOE_W0_EVIDENCE_ROOT`; GitHub execution also requires the protected W0 environment and runner markers.
- No live-verified exact W0 model-lock exists.
- No locked W0 execution schedule exists.
- All five provider credentials were absent during the first operational-qualification run, so model-list/get and generation evidence could not be captured.
- M02 is resolved for W0 as permanent lineage `MIBO-SL-002 — Claude` with exact candidate `claude-opus-5`; its Models API metadata, returned identity, stop reason, and thinking/output-cap evidence remain uncaptured.
- W0-Q1 live smoke gates are absent for M01-M05.
- W0-Q2 seven-item provider qualification gates are absent for M01-M05.
- The W0-Q3 Core-35 production-flow dress rehearsal has not passed.

## W01 operational blockers

- Exact provider API model IDs have not been resolved or locked.
- The interleaved schedule seed, schedule file, and schedule SHA-256 are not locked.
- The observer site or region is not locked.
- Required provider parameter mappings are unresolved for M01–M05.
- CLOSED eligibility has not been operationally verified for M01–M04.
- Protocol owner, provider terms review, and institutional ethics/governance determination are not recorded.
- The Wave lock timestamp is missing and execution is not permitted.

## Provider-specific ambiguities

- M01–M05: any provider-required generation or reasoning-control field must be mapped and frozen without adding optional sampling overrides.
- M01–M05: the effective visible-output cap must target 8192 tokens; M04 uses Responses API `max_output_tokens`, while M02 and M05 use `max_tokens`. Any provider hard-limit exception must be recorded before W01.
- M01–M04: absence of tools, web, retrieval, RAG, files, memory, and external functions must be verified for the selected exact API surface.
- M01–M05: exact requested model IDs must still be live-verified against provider-returned identity fields; M02's canonical ID is provider-documented as pinned, but serving-infrastructure behavioral variation remains possible.
- M05 is scientifically assigned to the separate NATIVE mirror and must not be pooled with CLOSED; the exact NATIVE API surface still requires a runtime lock.
- Any unavoidable provider-controlled system layer, forced streaming, or internal regional routing limitation must be documented explicitly rather than represented as absent.

Consumer UI equivalence is not an ambiguity to resolve for W01. The official MIBO-Education surface is the first-party API, and UI equivalence is outside scope rather than a blocker.

Consequently: `ENGINEERING_READY=true`, `SCIENTIFIC_PROTOCOL_COMPLETE=true`, `W0_READY=false`, and `W01_READY=false`.

"""Offline-only future prompt candidate; no sender, credentials or response repair."""
from __future__ import annotations

import copy
import json
from pathlib import Path

from miboe import evidence_pilot_method as parent
from miboe import reciprocal_engine as e, scoring, schema_wire_v14 as wire

DIRECTORY = Path(__file__).resolve().parent
ROOT = DIRECTORY.parents[2]
CANDIDATE = "MIBOE-AUX-CONTRACT-DRAFT-v0.1"


def load_candidate():
    plan = parent.load_plan(ROOT)
    draft = json.loads((DIRECTORY / "contract-draft.json").read_text("utf-8"))
    e.require(draft["candidate_id"] == CANDIDATE
        and draft["parent_method_lock_sha256"] == plan["lock"]["lock_sha256"], "candidate provenance differs")
    e.require(draft["status"] == "PROPOSAL_ONLY_NOT_APPROVED_NOT_EXECUTABLE"
        and draft["API_calls_authorized"] is False, "proposal cannot authorize execution")
    return plan, draft


def prepare_synthetic_request(observation, judge_id):
    """Prepare only independently constructed test input, never old study output."""
    plan, draft = load_candidate()
    e.require(type(observation) is dict and observation.get("synthetic_fixture_only") is True,
        "prototype accepts explicitly synthetic fixture input only")
    row = {k: copy.deepcopy(v) for k, v in observation.items() if k != "synthetic_fixture_only"}
    scoring._validate_blind(row, plan["legacy"])
    catalog = parent.refs.build_catalog(row["visible_response"], max_characters=plan["max_excerpt_characters"])
    visible = {**row, "evidence_catalog": [{"id": s["id"], "text": s["text"]} for s in catalog["segments"]]}
    judge = next(j for j in plan["config"]["judges"] if j["judge_id"] == judge_id)
    cap = draft["changes_proposed"]["gemini_judge_maxOutputTokens"]["candidate"] if judge["provider"] == "gemini" else 8192
    system = plan["system"] + "\n\n" + (DIRECTORY / "judge-addendum-draft.txt").read_text("utf-8")
    request = e.prepare_request(judge, visible, system=system,
        rubric=scoring._rubric(plan["legacy"], row["item_id"]), schema=scoring._native_schema(plan["schema"]),
        instruction_schema=plan["schema"], phase="main", cap=cap)
    request = e.sealed({k: v for k, v in request.items() if k != "request_id"}
        | {"candidate_id": CANDIDATE, "synthetic_fixture_only": True}, "request_id")
    return {"candidate_id": CANDIDATE, "synthetic_fixture_only": True,
        "request": request, "wire": wire.request(request), "catalog": catalog,
        "API_calls_authorized": False, "live_provider_acceptance_verified": False}


def assert_live_authorized(*args, **kwargs):
    raise ValueError("proposal is offline only: no production or API execution authority")

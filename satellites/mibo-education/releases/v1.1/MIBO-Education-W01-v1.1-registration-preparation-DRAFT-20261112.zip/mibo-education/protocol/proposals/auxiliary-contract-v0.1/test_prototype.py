"""Synthetic contract tests only: no API, no corrected historical model response."""
from __future__ import annotations

import copy
import importlib.util
import json
from pathlib import Path

import pytest

from miboe import evidence_pilot_runtime as rt, reciprocal_engine as e, scoring
from miboe.errors import ValidationError
from test_reciprocal_scoring import judgment, row

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("auxiliary_contract_prototype", HERE / "prototype.py")
candidate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(candidate)
ROOT = candidate.ROOT


@pytest.fixture(scope="module")
def plan():
    return rt.load_plan(ROOT)["method"]


def fixture(plan, item="E1-01"):
    observation = row(plan, item=item)
    return observation, judgment(plan, observation)


@pytest.mark.parametrize("item", [f"E{d}-{i:02d}" for d in range(1, 8) for i in range(1, 11)])
@pytest.mark.parametrize("judge", ["J01", "J02", "J03"])
def test_all70_items_three_pinned_judges_only_prompt_and_Gemini_cap_change(plan, item, judge):
    observation, _ = fixture(plan, item)
    marker = {**observation, "synthetic_fixture_only": True}
    original_input = copy.deepcopy(marker)
    prepared = candidate.prepare_synthetic_request(marker, judge)
    q, body = prepared["request"], prepared["wire"]["body"]
    assert marker == original_input and prepared["API_calls_authorized"] is False
    assert q["requested_model"] == next(j["requested_model"] for j in plan["config"]["judges"] if j["judge_id"] == judge)
    if judge == "J01":
        payload = json.loads(body["messages"][0]["content"])
        assert body["max_tokens"] == 8192 and "output_config" not in body
        system = body["system"]
    elif judge == "J02":
        payload = json.loads(body["contents"][0]["parts"][0]["text"])
        assert body["generationConfig"]["maxOutputTokens"] == 16384
        assert "thinkingConfig" not in body["generationConfig"]
        system = body["systemInstruction"]["parts"][0]["text"]
    else:
        payload = json.loads(body["input"][0]["content"][0]["text"])
        assert body["max_output_tokens"] == 8192 and body["text"]["format"]["strict"] is True
        system = body["instructions"]
    assert system.startswith(plan["system"] + "\n\n")
    assert payload["output_schema"] == plan["schema"]
    assert payload["rubric"] == scoring._rubric(plan["legacy"], item)
    assert len(payload["output_schema"]["properties"]["codes"]["properties"]) == 45
    assert set(payload) == {"rubric", "output_schema", "observation"}
    assert set(payload["observation"]) == scoring.BLIND_FIELDS | {"evidence_catalog"}


@pytest.mark.parametrize("field", ["VOCABULARY_ADAPTATION", "ABSTRACTION_ADAPTATION", "AUTONOMY_CALIBRATION", "SAFEGUARDING_ADAPTATION"])
@pytest.mark.parametrize("value", [None, -1, 3, True, "0"])
def test_frozen_validator_still_rejects_invalid_developmental_values(plan, field, value):
    observation, result = fixture(plan)
    result["codes"][field] = value
    with pytest.raises(ValidationError):
        scoring.validate_judgment(plan["legacy"], observation, result)


@pytest.mark.parametrize("field", ["VOCABULARY_ADAPTATION", "ABSTRACTION_ADAPTATION", "AUTONOMY_CALIBRATION", "SAFEGUARDING_ADAPTATION"])
@pytest.mark.parametrize("value", [0, 1, 2])
def test_valid_explicit_integer_contract_not_semantic_correctness(plan, field, value):
    observation, result = fixture(plan)
    result["codes"][field] = value
    scoring.validate_judgment(plan["legacy"], observation, result)


def test_no_refusal_is_R0_not_null(plan):
    observation, result = fixture(plan)
    assert result["codes"]["REFUSAL_PRESENT"] is False and result["codes"]["REFUSAL_TYPE"] == "R0"
    scoring.validate_judgment(plan["legacy"], observation, result)
    result["codes"]["REFUSAL_TYPE"] = None
    with pytest.raises(ValidationError):
        scoring.validate_judgment(plan["legacy"], observation, result)


def test_conditional_nulls_and_NR_remain_legal(plan):
    observation, result = fixture(plan)
    scoring.validate_judgment(plan["legacy"], observation, result)
    assert result["codes"]["E2_SUPPORT_QUALITY"] is None
    assert result["codes"]["MODEL_SCORE_PARSEABLE"] is None
    nr = {**result, "status": "NR", "primary_score": None, "anchor_reference": None,
        "nr_reason": "Synthetic unobservable response", "evidence": []}
    nr["codes"] = dict.fromkeys(result["codes"], None)
    scoring.validate_judgment(plan["legacy"], observation, nr)


@pytest.mark.parametrize("mutation", ["boolean", "accuracy", "refusal", "E2", "E4", "emergent", "evidence", "anchor", "missing_code"])
def test_other_frozen_contract_errors_remain_invalid(plan, mutation):
    observation, result = fixture(plan)
    if mutation == "boolean": result["codes"]["DIRECT_ANSWER"] = None
    elif mutation == "accuracy": result["accuracy_code"] = 2
    elif mutation == "refusal": result["codes"]["REFUSAL_TYPE"] = "R1"
    elif mutation == "E2": result["codes"]["E2_SUPPORT_QUALITY"] = 2
    elif mutation == "E4": result["codes"]["MODEL_ASSIGNED_TOTAL_SCORE"] = 0
    elif mutation == "emergent": result["codes"]["EMERGENT_BEHAVIOR"] = True
    elif mutation == "evidence": result["evidence"] = ["not in the synthetic observation"]
    elif mutation == "anchor": result["anchor_reference"] = "E1-01:0"
    elif mutation == "missing_code": del result["codes"]["VOCABULARY_ADAPTATION"]
    with pytest.raises(ValidationError):
        scoring.validate_judgment(plan["legacy"], observation, result)


def test_real_input_and_every_live_approval_flag_are_rejected(plan):
    observation, _ = fixture(plan)
    with pytest.raises(ValueError, match="synthetic"):
        candidate.prepare_synthetic_request(observation, "J02")
    for flags in ({}, {"execute_approved": True}, {"owner_approved": True, "fixture_only": False}):
        with pytest.raises(ValueError, match="offline only"):
            candidate.assert_live_authorized(**flags)


def test_frozen_release_and_old_cap_are_unchanged():
    p = rt.load_plan(ROOT)
    assert p["config"]["maximum_generation_tokens"] == 8192
    assert p["config"]["maximum_new_requests"] == 561
    assert p["config"]["maximum_cumulative_requests"] == 905
    assert p["method"]["lock"]["lock_sha256"] == "8089c59bd655bd5eb99d78c5302ef5c7474585ec9f9082be454badcdd55419e4"

"""DRAFT only: lossless evidence references. No API, score validation or legacy repair."""
from __future__ import annotations

import hashlib
import json

VERSION = "MIBOE-EVIDENCE-REFERENCES-DRAFT-v0.1"


def digest(value):
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def build_catalog(text):
    if type(text) is not str:
        raise ValueError("source text must be a string")
    segments, start = [], 0
    for index, part in enumerate(text.splitlines(keepends=True), 1):
        end = start + len(part)
        segments.append({"id": f"S{index:06d}", "start": start, "end": end, "text": part})
        start = end
    assert start == len(text) and "".join(s["text"] for s in segments) == text
    value = {"version": VERSION, "source_utf8_sha256": hashlib.sha256(text.encode("utf-8")).hexdigest(),
             "indexing": "UNICODE_CODE_POINTS_END_EXCLUSIVE", "segments": segments}
    return {**value, "catalog_sha256": digest(value)}


def resolve(text, catalog, reference_ids):
    """Resolve only explicit new-contract IDs; never fuzzy-match an old quotation."""
    # Python equality conflates False/0 and 1/1.0. Bind exact canonical JSON,
    # not type-coercing dict equality, before using any catalog offsets.
    try:
        matches = type(catalog) is dict and digest(catalog) == digest(build_catalog(text))
    except (TypeError, ValueError, UnicodeError):
        matches = False
    if not matches:
        raise ValueError("source/catalog binding mismatch")
    if type(reference_ids) is not list or any(type(v) is not str for v in reference_ids):
        raise ValueError("reference_ids must be a list of exact string IDs")
    by_id = {s["id"]: s for s in catalog["segments"]}
    if any(v not in by_id for v in reference_ids):
        raise ValueError("unknown source reference; no inference or repair")
    selected = [by_id[v] for v in reference_ids]
    excerpts = [text[s["start"]:s["end"]] for s in selected]
    assert all(q in text for q in excerpts)
    return {"status": "RESOLVED_REFERENCES_NOT_SCORE_OR_SUPPORT_VALIDATION",
            "version": VERSION, "source_utf8_sha256": catalog["source_utf8_sha256"],
            "catalog_sha256": catalog["catalog_sha256"], "selected_ids": list(reference_ids),
            "excerpts": excerpts, "provenance": "DETERMINISTIC_SOURCE_REFERENCE_RESOLUTION",
            "score_or_legacy_validity_created": False}

# MIBO-Education

## Current: W01 v1.1 preparation offline verified; one bundled approval pending, all live gates closed

[Prospective preparation record](waves/W01/deviations/deviation-00001.json) and the [new W01 status](waves/W01/PREPARATION-STATUS-v1.1.json) concern Education only, not Core. The old September1/five-series W01 manifests, frozen70 prompts, rubrics, published v1.0 DOI/ZIP, original manuscript and all W0 data/judgments/accounting remain unchanged. The three-family v3.1 W01 plan is a separate, explicitly unapproved Draft, not a relabelled W0 or silently edited old Wave.

The proposed baseline is2026-11-20 09:00JST. Source collection remains70 items*10 replications*3 CLOSED families=2,100 planned slots, with a stratified/interleaved hashed schedule over the12-hour target and a24-hour hard limit. Up to4,200 nonself judging requests follow within72 hours after actual collection completion. Fresh6 model-identity checks and35*3=105 common-calibration ratings run within the preceding24 hours; unchanged primary/full calibration guards and explicit delegated definition/adversarial review precede observation. Exact W0-tested models, judge prompt/schema/anchors, generation caps and existing key/account/storage routes are carried, not upgraded or newly live-verified. The same existing owner Windows station has a fixed logical site ID; no independently verified geographic-region or model-weight-pinning claim is made.

The new proposed request ceiling is6,411, with prior1,468 preserved and proposed cumulative maximum7,879. The actual W0 cap remains1,468 and is not reset/extended by preparation. The formal technical-attempt policy change from maximum5 to1 attempt per slot/zero automatic resends is explicitly part of the future approval, not an already adopted hidden change. Fully recorded READ_TIMEOUTs remain consumed/unscored; only unsent slots continue. Missing source cells are not refilled and their two judging slots are not sent. Unknown receipts, authentication/identity/CLOSED failures, manual STOP and hard deadlines remain fail-closed.

All41 new offline tests passed, including complete6,411-request and source-missing6,409-request synthetic scenarios, exact frozen source payloads/allocation, real-vs-fixture gates, publication/finalization/FINAL scope, phase/cumulative caps, unknown-receipt no-replay, controller exclusion, operator STOP, stage clocks, and AC-only power-request release. Tests used MockTransport with real credentials/sockets denied; zero model API calls and no public mutation. Candidate/helper development failures are archived separately, never treated as scientific results. Preparation power requests were released.

The [runtime configuration](waves/W01/runtime-v1.1-DRAFT.json), [scientific manifest](waves/W01/scientific-manifest-v1.1-DRAFT.json), [candidate model lock](waves/W01/model-lock-v1.1-DRAFT.json), [schedule](waves/W01/schedule-v1.1-DRAFT.json) and [registration/manuscript amendment](protocol/registration/education-v1.1-DRAFT.json) form the one-decision bundle. Existing author/ORCID/affiliations/funding/COI/AI disclosures are carried; registration language isEnglish and protocol licenseCC BY4.0. No new DOI, published registration, human signature or FINAL execution grant is fabricated. Actual prospective Education v1.1 publication/finalization proof and a separate scoped owner FINAL permit are required before any model request.

Formal analysis preserves Codebook section3 within-source domain means, their25x presentation, valid denominators, missing/unresolved counts, distributions and descriptive dispersion. It does not misuse the W0 sample150/50 gates on formal2,100, pool changing-rater kappas, rank overall educational AI, compare W0 as a formal baseline, or establish all45-field semantic validity/independence/comparability. The accepted W0 limited technical review and all its unresolved diagnostics remain intact. Publication,Core restart and W01 execution have not occurred. Earlier sections are historical context, not current execution authority.

## Historical context: EV31 nonofficial W0 execution and limited AGENT technical review complete; API gates closed

[Deviation00070](waves/W0/deviations/deviation-00070.json) records the separately explicit, delegated AGENT limited technical review. The actual result was rederived identically from raw, with4,536 completed evidence files hash-bound. All150 source answers are saved (50 per series); all300 nonself judging requests were processed (100 per judge). Primary-valid298/300 and full-record-valid296/300. Main READ_TIMEOUTs358/379 remain unscored, consumed and unresent. Two J02 MODEL_SCORE_PARSEABLE omissions remain missing, not repaired. The earlier calibration timeout34 and failed sources168/186 are retained; only the separately approved source retries169/187 occurred once each, with original wire/model unchanged.

Both frozen primary AND full-record numerical reports passed: approved source/item/domain allocation, numeric coverage, valid-pair fraction and each of the three fixed source-pair agreement guards. Primary source-pair kappas are0.899225/0.924090/0.963923 for anthropic/gemini/openai sources respectively; full-record kappas are0.898744/0.924090/0.963459. No pooled changing-rater kappa or ranking was created. Aggregation retains146 panel estimates,2 unresolved score disagreements and2 incomplete responses, without imputation, rescaling or adjudication. The accepted104/105 calibration review is carried unchanged.

All45 auxiliary diagnostics remain available for review. Developmental0-to2 range-contract errors and refusal-R0 conflicts are0; these are diagnostics, not new acceptance cutoffs. ABSTRACTION_ADAPTATION has61 disagreements and VOCABULARY_ADAPTATION53 among148 jointly available pairs. Conflicting values stay unresolved and conditionally unavailable values are not turned into zero. This is limited engineering acceptance, not human gold, all45-field semantic reliability, statistical independence or cross-source comparability. Existing machine pilot/clearance flags remain false; historical judgments are not rewritten.

The single worker exited after completion, and its AC-only temporary SystemRequired/ExecutionRequired requests were explicitly cleared and the handle closed at2026-11-12T03:16:17.927250Z. No permanent power setting, display/away request or explicit-user-sleep override was used. STOP/global HOLD are restored. Prior905/current563/cumulative1,468 accounting, the entire original186 prefix and original clock/deadline2026-11-14T02:21:26.568072Z (11:21 JST) are verified. The approved request allowance is exhausted; no additional API work is authorized by this review. Publication,Core restart and W01 were not executed. Earlier sections are historical snapshots, not current execution authority.

## Historical snapshot: EV31 observations150 saved; nonself main300 judging active under AC guard

At2026-11-12T01:27Z all150 actual source answers are saved,50 per series. The locked300-request blind main batch has been created,100 requests per judge; the allocation was independently checked against each source family's two nonself judges. Main dispatch has started. No source failure occurred after the single approved retry187, and the accepted calibration is carried unchanged. Completion, fixed primary/full guard results, delegated technical review and final power-request release remain pending; no W0 qualification is claimed.

The owner [approved the conditional restart](protocol/approvals/EV31-AC-AWAKE-SOURCE186-APPROVAL-20261112.yaml). [Deviation00068](waves/W0/deviations/deviation-00068.json) binds the new operational release and35 passing offline tests, including the full186+377 fixture, identical retry wire, closed gates, AC-loss/suspend/exception cleanup and delegated unsent-only main READ_TIMEOUT continuation. The native AC power request was acquired and released successfully in verification. FINAL authority was created only after verification; no extra key, signature or storage decision was needed.

The single hidden worker has started. The only newly approved source186 retry is separately recorded as187 and returned HTTP200 with a saved actual answer. At that checkpoint74 answers are saved; the worker continues76 untouched original sources, then300 nonself judgments. Both failed attempts168/186 and successful retries169/187 remain distinct and consumed. All original186 files, judgments, old905 accounting and the original clock are preserved. At most377 additional/current-trial563/cumulative1,468 reservations are authorized. No other source retry, metadata/calibration replay or invalid-response repair is allowed.

Temporary SystemRequired/ExecutionRequired power requests apply only during active AC-powered operation and are released at exit. AC loss/unknown status or a suspend-monitor gap releases the requests and prevents the next dispatch; explicit user sleep is not overridden and permanent settings/display/away mode are unchanged. The accepted104/105 calibration is carried, not rerun. Original deadline2026-11-14T02:21:26.568072Z (11:21 JST), scientific models/prompts/criteria and all historical judgments remain fixed. W0 is still in progress, not qualified or semantically validated. Publication,Core restart and W01 remain forbidden. Earlier sections are historical snapshots, not current execution authority.

## Historical snapshot: EV31 source186 transport HOLD;73 answers preserved, no other retry

[Deviation00067](waves/W0/deviations/deviation-00067.json) records a new observation failure: source186, Claude opus5/original slot74, HTTP0 TRANSPORT_OTHER with no provider response saved. The approved retry169 of source168 succeeded, adding17 saved answers before this new failure. All186 reservations/outcomes,73 source records, old905 accounting, original168 prefix, calibration judgments and original clock are verified intact. Main judging remains0; W0 is incomplete, not classified as a scoring-quality failure. The worker exited with STOP/global HOLD present. The single source168 retry allowance is already used; source186 has not been retried and is outside the main-communication continuation delegation.

Cumulative reservations are1,091; the current1,467 cap leaves376 attempts, but77 actual sources plus300 main judgments require at least377. The proposal, not new authority, is a temporary AC-powered/active-worker-only idle-sleep guard released on exit, plus exactly one linked retry of source186, then76 untouched source slots and300 main judgments: maximum377 additional/current-trial563/cumulative1,468. No permanent power-setting change, explicit-user-sleep override, new FINAL permission or revised sender has been made. Preparation/verification and conditional restart require owner direction.

Read-only Windows logs show Modern Standby IdleTimeout entry at2026-11-11T23:38:09.135Z, source186 reservation at23:38:11.755Z, a power transition at23:47:03.908Z and transport failure at23:47:07.020Z. Earlier source168 has a similar power/failure correlation. Host power-state involvement is likely, not definitively proven from the collapsed TRANSPORT_OTHER log. No source/score repair, other retry, clock reset or scientific-model/prompt/anchor/criterion change occurred. Deadline2026-11-14T02:21:26.568072Z (11:21 JST) and all publication/Core/W01 prohibitions remain. Earlier sections are historical snapshots, not current restart authority.

## Historical snapshot: EV31 explicitly restarted; single approved source retry succeeded, collection in progress

The owner [explicitly approved API restart](protocol/approvals/EV31-SOURCE-RETRY-EXECUTION-APPROVAL-20261112.yaml). [Deviation00065](waves/W0/deviations/deviation-00065.json) binds FINAL authority and the49-test verified release, at most394 additional requests from the preserved168 checkpoint,562 for this same trial and1,467 cumulative including old905. [Deviation00066](waves/W0/deviations/deviation-00066.json) confirms that the sole authorized retry169 of failed source168 returned HTTP200 with an eligible saved answer and identical original wire/model. Both attempts remain separately accounted; all original168 files/judgments and the original clock are byte-identical.

One bounded worker is collecting the remaining original source slots, requiring150 actual answers,50 per family, before300 nonself judgments. No second/other source retry, metadata/calibration replay or invalid-output repair is authorized. Only fully recorded main READ_TIMEOUTs may advance to unsent slots while unchanged primary/full guards remain demonstrably reachable. Source shortfall, other HTTP/transport/identity/unknown-outcome or scope/limit/window failure remains HOLD-and-consult.

The accepted104/105 calibration review is carried, not rerun. Original start2026-11-11T02:21:26.568072Z and deadline2026-11-14T02:21:26.568072Z (11:21 JST), scientific models/prompts/criteria and all historical judgments remain unchanged. W0 is still in progress, not qualified or semantically validated; publication,Core restart and W01 remain forbidden. Earlier sections are historical snapshots, not competing execution authority.

## Historical snapshot: EV31 single-source retry prepared and offline verified; API restart still unapproved

The owner [approved preparation only](protocol/approvals/EV31-SOURCE-RETRY-PREPARATION-APPROVAL-20261111.yaml). The separate [one-retry plan](runtime/EV31-source-retry-v1.0.json) and [release lock](runtime/EV31-source-retry-v1.0.lock.json) prospectively allow one retry of failed source reservation168,93 untouched original source slots and300 nonself judgments: maximum394 additional requests,562 for this same trial and1,467 cumulative including old905. The failed attempt remains consumed and immutable. The retry is separately linked to it, with identical original request bytes/model/generation cap;151 source attempts must yield150 actual answers,50 per series. No other source retry, second retry or metadata/calibration replay is allowed.

All49 offline tests passed, including168+394 completion, exact retry-wire preservation, conditional unsent-main READ_TIMEOUT continuation, hard stops for retry/other-source/HTTP/unknown/identity failures, manual STOP, expired deadline and unchanged old-continuation behavior. [Deviation00064](waves/W0/deviations/deviation-00064.json) binds preparation approval and verification. A pre-execution development-constructor failure was corrected only in the new operational module; its candidate/archive is retained and is not a scientific W0 judgment. Old native/method releases,7,334 historical immutable files, all168 current outcomes and existing judgments are unchanged.

Real progress remains56 source answers and0 main judgments; accepted104/105 calibration is carried, not rerun. No FINAL restart authorization was created: the verified DRAFT still denies API use, and STOP/global HOLD remain. The original start2026-11-11T02:21:26.568072Z and deadline2026-11-14T02:21:26.568072Z (11:21 JST) remain unchanged, as do models/prompts/criteria. Actual cumulative reservations remain1,073. No API restart, publication,Core restart,W01, W0 qualification or all45-code semantic/comparability claim. Earlier sections are historical snapshots, not current restart authority.

## Historical snapshot: EV31 source transport HOLD;56 answers preserved, no retry — 2026-11-11 JST

The worker stopped on fresh-source attempt57/global reservation168: OpenAI gpt-5.6-sol, HTTP0, TRANSPORT_OTHER, no saved provider response. This observation failure is outside the delegated calibration/main READ_TIMEOUT continuation; no failed request was replayed.56 actual source answers are saved (M01:20,M02:21,M03:15); main judging is0 and no partial main batch was created. STOP/global HOLD remain present and the worker has exited.

[Deviation00063](waves/W0/deviations/deviation-00063.json) records the offline-only review: old905 reservations, all168 current outcomes,7,334 prior immutable files, original34 prefix, calibration judgments and the original clock are intact. Calibration remains104/105 primary/full-valid with accepted limited AGENT technical review; this is not a W0 qualification or all45-code semantic validation. The original calibration timeout and source transport failure are both preserved, unscored and not interpreted as zero,NR or poor model quality.

Cumulative reservations are1,073; current cap1,466 leaves393 attempts. Completing150 actual source answers needs94 additional sources plus300 main judgments=394 attempts even without another failure; the remaining93 original source slots can reach only149 answers. Completion is therefore impossible under the current no-replay/cap scope. No replacement authorization or modified sender was created. Deadline2026-11-14T02:21:26.568072Z (11:21 JST), fixed models/prompts/criteria and all publication/Core/W01 prohibitions remain unchanged. Earlier sections are historical snapshots.

## Historical snapshot: EV31 calibration reviewed; fresh-source collection and reciprocal judging stage active — 2026-11-11 JST

The completed common calibration has104/105 primary-valid and full-record-valid ratings; the original unscored READ_TIMEOUT is retained. Both frozen technical reports passed. [Deviation00061](waves/W0/deviations/deviation-00061.json) records the accepted delegated AGENT definition/adversarial review and its limited operational scope. AI-proposed targets remain unchanged, not human gold; auxiliary boundary disagreements are not adjudicated or relabelled.

[Deviation00062](waves/W0/deviations/deviation-00062.json) confirms actual fresh-source reservation112 and its saved HTTP200 answer after the accepted review. The single worker is running the approved150 fresh answers followed by300 nonself judgments. It may continue past fully recorded calibration/main READ_TIMEOUTs only to unsent slots when unchanged fixed guards remain attainable. Source shortfall, other failures, unknown outcomes or scope changes still require HOLD. Failed requests are never replayed.

Original34 records, old905 reservation accounting, fixed models/prompts/criteria, cumulative maximum1,466 and deadline2026-11-14T02:21:26.568072Z (11:21 JST) are preserved. This is an ongoing nonofficial W0, not a completed or qualified W0, all45-code semantic validation or established comparability. Publication,Core restart and W01 remain forbidden. Earlier sections are historical snapshots.

## Historical snapshot: EV31 unsent-only continuation active; original clock and science preserved — 2026-11-11 JST

The owner [approved unsent-only continuation](protocol/approvals/EV31-UNSENT-CONTINUATION-APPROVAL-20261111.yaml) after offline verification: preserve old905/current34/one unscored timeout, never resend the failed request, continue only remaining527 within cumulative1,466 and the original deadline. Same calibration/main READ_TIMEOUT continuation is delegated only while the fixed guards remain demonstrably attainable. Source shortfall, metadata/identity error, other failure or scope/limit change remains HOLD-and-consult.

All21 offline tests passed, including full34+527 with additional calibration/main timeouts, no duplicate judging attempts, source-shortfall stopping, review gating and manual STOP preservation. A test expectation mismatch from the first offline attempt is archived; production code/scientific bytes were not changed to fix that assertion. [Deviation00059](waves/W0/deviations/deviation-00059.json) binds the verified operational release and FINAL continuation permit. Native scientific release f49ca0, model IDs, prompts, anchors, schema, validators, generation caps, timeout and numerical criteria are unchanged. Ephemeral counterfactual feasibility checks never become ratings or analysis data.

[Deviation00060](waves/W0/deviations/deviation-00060.json) confirms actual resumed reservations35/36 are exactly calibration slots29/30 with HTTP200 outcomes. Failed reservation34 remains once, unresent and without a pedagogical score. All original34 records/27 judgments are byte-identical. The original start2026-11-11T02:21:26.568072Z and deadline2026-11-14T02:21:26.568072Z are unchanged. Calibration continues; both actual primary AND full-record fixed reports plus explicit delegated definition/adversarial technical review still precede fresh150 collection and reciprocal300 main judging. No W0 qualification, publication,Core restart or W01 is implied or performed. Earlier sections are historical snapshots.

## Historical snapshot: EV31 transport HOLD; 34 reservations preserved, no retry — 2026-11-11 JST

The single worker exited after a 600-second READ_TIMEOUT on Claude J01 calibration request28. All 34 new reservations have saved outcomes: six exact-model metadata checks, 27 saved calibration ratings and one unscored transport failure. The 27 ratings are primary-valid and full-record-valid and were rederived identically from raw. HTTP0 with no provider body does not prove the remote request was unexecuted or unbilled; its reservation remains consumed. The timeout is not a score of zero, NR, a semantic refusal or a scientific quality failure. Calibration is incomplete and neither passed nor failed as a whole.

[Deviation 00058](waves/W0/deviations/deviation-00058.json) binds the no-network HOLD audit. All 7,334 prior immutable private files, old 905 reservation accounting, judgments and old clock are intact; the original global HOLD bytes are archived and verified. STOP/global HOLD are restored, no request was retried or repaired, and no source collection or main judging occurred. The original 72-hour deadline remains 2026-11-14T02:21:26.568072Z (11:21 JST).

Current cumulative reservations are 939. Exactly 527 requests remain unsent (77 calibration, 150 fresh sources, 300 main ratings) within the unchanged 1,466 cumulative cap. Remaining allowance is not automatic restart permission. A prospective unsent-only continuation would preserve the technical missing, all prior records and the clock without resending the failed request or changing models, scoring criteria or limits; it requires explicit resume authority and offline verification. No resume permit or modified sender has been created. Publication, Core restart and W01 remain forbidden. Earlier sections below are historical snapshots.

## Historical snapshot: EV31 nonofficial W0 started under FINAL owner API approval — 2026-11-11 JST

The owner explicitly answered `承認して開始` to the scoped paid-API start question. The [FINAL owner approval](protocol/approvals/EV31-FINAL-EXECUTION-APPROVAL-20261111.yaml) and [deviation 00056](waves/W0/deviations/deviation-00056.json) record the actual decision; no additional content, name, rights, storage or key choice is pending. New maximum 561 model requests, prior 905 conservative reservations preserved and cumulative maximum 1,466. Publication, Core restart and W01 remain forbidden.

The single EV31 worker started its separate 72-hour clock at 2026-11-11T02:21:26.568072Z; deadline 2026-11-14T02:21:26.568072Z. All six fixed model metadata checks completed HTTP200 with exact identity. [Deviation 00057](waves/W0/deviations/deviation-00057.json) binds the actual-start evidence. Common calibration105 is in progress; fresh150 collection and reciprocal300 main judging remain blocked until both primary AND full-record fixed guards and an explicit delegated definition/adversarial technical review are accepted. Current progress is append-only in the separate private EV31 ledger. No calibration clearance or W0 qualification is implied.

The tested release, new35 bank, approved method, existing key routes and numerical criteria are unchanged. Prior raw observations, judgments, counters and clock are preserved; original global HOLD bytes were archived before the authorized scoped gate release. Invalid outputs are not repaired/resent and failure/unknown attempts consume allowance with HOLD. New35 targets remain AI proposals, not human gold; all45 diagnostics and cross-source comparability limitations remain. Earlier readiness sections below are historical snapshots.

## Historical snapshot: EV31 execution preparation complete; separate API approval only remains — 2026-11-11 JST

The native EV31 execution package is fixed under its [execution release lock](runtime/EV31-execution-release-v1.0.lock.json) and [execution plan](runtime/EV31-execution-plan-v1.0.json). The adopted new35 bank, prospective v3.1 method and reviewed plan bytes remain unchanged. All 35 new offline tests passed, including the complete 561-request two-stage MockTransport run and cumulative 1,466 reservation audit. DRAFT/old permits fail before keys or HTTP; HTTP, timeout and unknown attempts consume allowance and HOLD without replay. Primary-only success cannot bypass the full-record guard or explicit definition/adversarial technical review. All 45 code diagnostics remain descriptive, not human-gold validity or new cutoffs.

[Deviation 00055](waves/W0/deviations/deviation-00055.json) binds the verified package and review page. All 7,335 old private files, old judgments, 905 conservative reservations and the original clock are unchanged. Only a new private preparatory baseline, STOP, salt and DRAFT permit were allocated in the adopted EV31 namespace: no RUN_BINDING, reservation, new clock or FINAL execution authorization. Actual new API requests are zero and STOP/global HOLD remain. Existing keys, owner name, rights, cross-family sharing and encrypted storage are carried forward; no new forms or withdrawn USD5 gate.

Execution preparation is complete. The sole remaining owner decision is explicit API execution consent for this separate nonofficial W0 trial: at most 561 new requests (6 metadata, 105 calibration, 150 fresh sources, 300 nonself judgments), 1,466 cumulative reservations and a new 72-hour window. Both primary AND full-record fixed calibration guards plus delegated technical review precede collection. Provider acceptance, new calibration clearance, W0 pass and cross-source comparability are not established offline. No model confirmation, observation/scoring API, publication, Core restart or W01 has been performed.

## Historical snapshot: new35 and EV31 plan adopted; execution still closed — 2026-11-11 JST

The owner adopted the reviewed 35-case content/proposed labels and separate 561-new/1,466-cumulative/72-hour plan. The [hash-bound adoption declaration](protocol/approvals/EV31-NEW35-PLAN-ADOPTION-20261111.yaml) is now authoritative for content/plan adoption. Reviewed bank, plan, HTML and preparation-lock bytes are deliberately unchanged; their DRAFT flags are historical source metadata, not a new execution permit. AGENT-proposed diagnostic targets do not become human gold through owner content review. Primary AND full-record calibration guards plus technical review remain the adopted prerequisite for fresh collection.

[Deviation 00054](waves/W0/deviations/deviation-00054.json) binds the adoption verification: all 7,335 existing private files and 2,758 historical bindings unchanged, actual 561/905 accounting and old clock intact, two execution gates still rejecting adoption even with execute flags, and zero API calls. The prior 43-tested preparation version is unchanged. No new run ledger, salt, clock, live sender or FINAL execution package was created. STOP/HOLD remain; model confirmation, observation/scoring, publication, Core restart and W01 are not authorized or performed. Content/plan adoption needs no further owner decision; execution-package fixation/offline verification and a separate explicit API execution approval remain before dispatch.

## Historical snapshot: new35 and separate EV31 plan prepared; adoption pending — 2026-11-11 JST

Prepared a [new35 calibration draft](scoring/calibration-v31-new35-v1.0-DRAFT.json): seven domains × five primary anchors, all developmental 0/1/2 levels and refusal R0–R4, E4 extraction cases and an adversarial instruction-injection case. These are newly authored AGENT synthetic examples with proposed diagnostic labels, not human gold. Unannotated auxiliary targets are not assumed false/zero. Case IDs, proposed targets and rationales stay outside the 105 judge fixture bodies. All new response texts differ from both prior calibration banks and all 300 old source records checked; normalization was duplicate diagnosis only, not scientific data conversion.

The [separate draft plan](runtime/EV31-W0-plan-v1.0-DRAFT.yaml) proposes at most 561 new requests (metadata 6, calibration 105, fresh source 150, reciprocal main 300), preserving prior 905 reservations and capping cumulative reservations at 1,466. A new 72-hour clock is still unset; no old unused slots/window transfer. Primary AND full-record fixed calibration guards plus explicit delegated technical review precede fresh collection. All 45 code diagnostics remain descriptive, not new pass cutoffs or measurement-validity certification. The 5,652,480-token generated-cap sum is a bound, not actual usage or a USD estimate; the removed USD5 condition is not restored.

All 43 new offline tests passed, including an in-memory 561-request/1,466-bound workflow and synthetic 35/105 + fresh 150/300 roundtrips. The previously 694-tested v3.1 method lock is unchanged, not rerun. All 7,335 existing private files, 2,758 historical bindings, judgments, actual 561/905 accounting and old clock remain intact. No new live folder/ledger/approval/clock/sender/FINAL package was allocated. [Deviation 00053](waves/W0/deviations/deviation-00053.json) binds the review HTML, material/plan draft lock and test report. One owner decision remains: adopt this content/proposed-label set and plan together; adoption is NOT API execution consent. Existing name/rights/encryption/key choices are carried forward. STOP/HOLD remain; model confirmation, API restart, publication, Core restart and W01 were not performed.

## Historical snapshot: prospective v3.1 adopted and verified offline; APIs held — 2026-11-11 JST

The owner adopted the future auxiliary contract in the [v3.1 approval record](protocol/approvals/AUXILIARY-CONTRACT-V31-ADOPTION-20261111.yaml): developmental four-code levels 0/1/2, explicit no-refusal R0, and Gemini J02 judging cap 16,384. Thinking settings and other judge caps (8,192), all source/judge model IDs, primary anchors, NR, 45 fields, schema, validators, nonself routing and numerical guards remain unchanged. This is a separate [v3.1 method](scoring/ai-reciprocal-evidence-v3.1.json), not an edit or retrospective application to v3.0/EV3.

Preparation, physical payloads, strict import, component/full-record aggregation and a separate offline CLI are implemented. All 694 tests passed: 169 frozen-release regressions, 255 preserved-prototype tests, and 270 v3.1 tests. This includes synthetic 35/105 and 150/300 roundtrips and CLI end-to-end tests. Healthy and invalid/null/truncated/disagreeing synthetic scenarios give identical old/new aggregate payloads. The independent production calibration and actual model improvement are NOT established. [Deviation 00052](waves/W0/deviations/deviation-00052.json) binds the adoption, tested method lock and reports.

All 7,335 existing private files, old judgments and 2,758 historical bindings remain unchanged; EV3 stays at 561 new/905 cumulative reservations and its original clock. No null imputation, rescore, repair, resend or pilot-flag rewrite. CLI outputs are restricted to a separate `MIBO-Education/EvidenceV31Preparation` private namespace and cannot replace existing artifacts. Execution remains closed before files/credentials/transport. New production calibration materials, a separate request budget/window and execution permit are not created or approved. STOP/HOLD remain; no API, publication, Core restart or W01. No additional owner decision is needed for the completed adoption; existing name/rights/encryption/key choices are not reopened. Earlier sections are historical snapshots.

## Historical snapshot: EV3 auxiliary failure diagnosed; future candidate checked offline — 2026-11-11 JST

Offline follow-up rederived all 405 judgments identically and verified 7,335 existing private files unchanged. Main full-record losses (111) were developmental integer nulls only (57), refusal-type nulls only (46), both (5), and Gemini MAX_TOKENS (3). Calibration losses (38) were developmental nulls (21), refusal nulls (16), and MAX_TOKENS (1). These are contract/output failures, not a reason to relax validation, impute nulls, or replace old judgments.

The detached [future candidate](protocol/proposals/auxiliary-contract-v0.1/contract-draft.json) proposes explicit auxiliary developmental 0/1/2 meanings, the existing no-refusal R0 rule, and Gemini judge cap 16,384 with thinking settings unchanged. New ordinal meanings require an owner decision; they are NOT approved or retroactive. All 424 offline checks passed (169 frozen-release regressions plus 255 candidate tests), including all 70 items and 3 pinned judges. This is synthetic contract verification, not demonstrated model improvement, API acceptance, feature validity or W0 clearance. [Deviation 00051](waves/W0/deviations/deviation-00051.json) binds the diagnosis and test reports. No production wiring, new execution budget/window or API authority was created; STOP/HOLD remain. Primary technical results below are unchanged.

The separate nonofficial EV3 trial completed all 561 new requests: 6 exact-model metadata checks, 105 calibration judgments, 150 fresh source answers (50 per series), and 300 reciprocal judgments. Primary calibration was valid in 104/105 judgments; main primary scoring was valid in 297/300. Valid main pairs were OpenAI 49/50, Claude 48/50, and Gemini 50/50, with pair-specific QWK 0.942794, 0.959677, and 0.932976 respectively. All frozen primary numeric guards passed. [Deviation 00050](waves/W0/deviations/deviation-00050.json) binds the delegated AGENT final technical review and the local audit report.

This is NOT wholesale W0/full-feature qualification: full-record validity was only 67/105 in calibration and 189/300 in main scoring; its quality checks failed. All 45 auxiliary diagnostics remain separate. The one calibration and three main Gemini MAX_TOKENS judgments remain invalid, unmodified and unresent. The frozen machine `pilot_passed: false` fields were not overwritten; human-gold validity, statistical independence and cross-source comparability are not established.

All 150 source records and 300 main views were recomputed identically from raw; all 561 new reservations have saved outcomes and no pending request. Old 344 reservations, existing judgments and all 2,758 historical file bindings remain unchanged. The cumulative 905 is conservative reservation accounting, not proof of 905 remotely received/billed requests. The original single clock is unchanged: start 2026-11-10T14:24:39.244340Z; last response 2026-11-10T17:31:57.598000Z; deadline 2026-11-13T14:24:39.244340Z. STOP/HOLD are restored, the execution worker exited, and no further API request is authorized by this review. No publication, Core restart or W01 occurred. Earlier sections below are historical snapshots.


## Current: fresh150 answers verified; reciprocal main300 scoring running — 2026-11-11 JST

Fresh source collection is complete:150 answers,50 each from M01/OpenAI,M02/Claude,M03/Gemini. Every saved source record was recomputed identically from raw and content-screened. The exact locked main batch has150 blind observations/300 requests, each assigned only to the other two families. Main scoring began at new claim262. [Deviation00049](waves/W0/deviations/deviation-00049.json) binds this milestone and the unchanged original clock, not a pilot pass or source-performance comparison.

New primary calibration was accepted104/105 with pair QWK0.978917–0.993087; its1 MAX_TOKENS judgment stays invalid/unresent. Full-record calibration valid67/105 only: all45 auxiliary diagnostics remain separate and NOT wholesale feature-qualified. The accepted primary-component review and same owner permit cover this main stage. Old344 reservations, existing judgments and all2,758 historical file bindings remain preserved; no old answer conversion, rescore, repair or refill.

Model IDs, native request bytes, thresholds and limits remain fixed at561 new/905 cumulative. The one new clock starts2026-11-10T14:24:39.244340Z and ends2026-11-13T14:24:39.244340Z (JST23:24:39); no counter/window reset. Private append-only evidence governs live counts. No automatic pilot pass, human validity/comparability claim, publication, Core restart or W01. Earlier sections below are historical snapshots.


## Current: primary calibration accepted; fresh150 source collection running — 2026-11-11 JST

The delegated new calibration review is accepted:104/105 primary-valid, pair QWK0.978917–0.993087,100% within-one agreement and NR0. All105 saved views were recomputed identically from raw evidence. One Gemini MAX_TOKENS response remains invalid/unresent. Full-record valid67/105 only; all45 auxiliary diagnostics are retained separately, NOT feature-qualified. [Deviation00046](waves/W0/deviations/deviation-00046.json) binds this limited primary-component clearance, not human-gold validity, comparability or an automatic W0 pass.

The originally approved remaining150 fresh source answers/300 reciprocal ratings are now running under the same owner permit. One management-read startup failure happened before any source/main request; [deviation00047](waves/W0/deviations/deviation-00047.json) preserves that failed launch and the explicit software/unsent-work recovery authority. All5 existing office-only management reads then returned200 and fresh source collection actually began at claim112; [deviation00048](waves/W0/deviations/deviation-00048.json) confirms no request replay or key/IAM/billing change. Safe telemetry/operator versions are archived privately.

Old344 reservations, all2,758 historical file bindings and existing judgments remain preserved. Frozen models, native request bytes, scoring criteria,561-new/905-cumulative cap and the single new clock remain unchanged: start2026-11-10T14:24:39.244340Z, deadline2026-11-13T14:24:39.244340Z (JST23:24:39). No source response repair/refill, counter/window reset, publication, Core restart or W01. Live counts are governed by private append-only claims/outcomes, not this snapshot; earlier sections below are historical.


## Current: new EV3 trial actually started; calibration in progress — 2026-11-10

Owner-delegated unstarted/zero-request environment recovery was fixed and recorded in [deviation00043](waves/W0/deviations/deviation-00043.json). The real trial then started at2026-11-10T14:24:39.244340Z; its single72-hour deadline is2026-11-13T14:24:39.244340Z (JST23:24:39). All6 exact source/judge model metadata GETs passed with HTTP200 and the new105-case calibration stage is in progress. [Deviation00044](waves/W0/deviations/deviation-00044.json) binds the start and metadata confirmations, not a calibration/pilot pass.

Actual model claims and RUN_STARTED now exist, so zero-request startup recovery authority is no longer usable. New calibration raw responses and fixed primary/auxiliary diagnostics must be reviewed before source150/main300 continuation under the same owner authorization. Frozen scoring, model IDs and169-test release remain unchanged. Old344 reservations, all2,758 historical file bindings, existing invalid judgments, previous failed launch histories and the consumed one-use exception remain preserved. Limits are561 new/905 cumulative and one new72-hour window; no forced passage, data repair, request resend or counter/window reset. No publication, Core restart or W01. Private append-only evidence governs live counts; earlier sections below are historical snapshots.


## Current: one approved relaunch consumed; zero model requests — 2026-11-10

The owner approved exactly one unstarted-stage relaunch with the existing Claude User key inherited in child memory; [deviation00041](waves/W0/deviations/deviation-00041.json) records that exception. It was used once (PID31080), and the worker again stopped before RUN_STARTED, RUN_BINDING, any claim/outcome or raw model request. No second relaunch was performed. New model requests0; cumulative reserved344; STOP/HOLD restored; the new72-hour clock has not started.

Exact Start-Process offline probes confirm Claude inheritance works. APPDATA/ComSpec are absent in the held child environment, so the installed Cloud SDK selects a different configuration store without the existing office account. Correcting those child-only standard environment values passes all offline key-format/reference/store prerequisites, including existing office account registration, without any model/management API. The safe worker CLI does not expose its exact exception, and no traceback, score or transport outcome was invented. [Deviation00042](waves/W0/deviations/deviation-00042.json) binds both diagnostic probes and the held-run receipt.

All2,758 historical file bindings, previous judgments and both launch histories remain preserved. The frozen169-test scientific/runtime release and561-new/905-cumulative bounds are unchanged;4 additive one-use gate tests passed. No key file/persistent environment/IAM/billing change, scientific data repair/resend, publication, Core restart or W01. Further launch requires new owner authority because the one-use exception is consumed. Proposed minimal decision: delegate environment correction/relaunch only while the trial is unstarted and model claims/requests/raw remain0; no request retry or clock reset. Earlier sections are historical snapshots.


## Current: execution approved; held before first model request — 2026-11-10

The owner explicitly approved the new561-request/905-cumulative separate EV3 trial and delegated new calibration review/continuation in [deviation00039](waves/W0/deviations/deviation-00039.json). The FINAL permit exists; this is not W01/publication/Core authority. One hidden worker was launched, then exited before RUN_STARTED, RUN_BINDING, any reservation or raw request. New model calls0, cumulative reserved344. The proposed new72-hour clock has not started.

A safe child-environment check found the existing Claude User key present but absent from the worker's process environment. The frozen noninteractive resolver requires that process key before Gemini management/model HTTP. This is a launch-environment problem, not a model-authored failure or invalid score. The safe CLI suppresses the exact exception; diagnosis rests on direct environment inspection and resolver control flow. [Deviation00040](waves/W0/deviations/deviation-00040.json) preserves the startup evidence; all2,758 historical file bindings and current FINAL preflight were rechecked.

STOP/HOLD are restored. First-launch logs, PID and gate-release receipts are preserved; no automatic relaunch, invented outcome, old-answer repair/resend, cap/clock reset or scientific change. Existing-key reuse remains approved and no key input/new form is needed. Because the approved plan forbids automatic relaunch, a single explicit zero-model-request relaunch exception is required before inheriting the existing User Claude key into child memory and trying the unstarted first stage again. Bounds remain561 new/905 cumulative, with one72-hour window from the first recorded actual run start. Earlier sections below are historical snapshots.


## Current: one-decision EV3 pilot package ready; APIs still held — 2026-11-10

The remaining preparation is complete as one package: a new synthetic35-case calibration bank, a prospective fresh150-answer/300-rating trial, the real three-provider sender, FINAL-owner gate, delegated calibration-review gate and append-only two-witness accounting. [Approval scope](runtime/EVIDENCE-PILOT-APPROVAL-v1.0.md), [35-case review](protocol/w0-records/evidence-pilot-calibration-review-v1.0.md) and [operator runbook](runtime/EVIDENCE-PILOT-OPERATIONS-v1.0.md) are fixed for the single remaining owner execution decision. [Deviation00038](waves/W0/deviations/deviation-00038.json) records169 passing offline tests,0 failures/skips/deselections, including the complete561-request MockTransport flow and both review-separated stages.

Proposed new campaign:6 exact-model GETs +105 new calibration ratings +150 fresh source answers +300 non-self-family main ratings =561 new maximum; old344 remain preserved, giving a proposed three-series cumulative cap905. This is a separate nonofficial trial with its own72-hour clock after a future FINAL permit, not an old-W0 restart, transfer of its245 unused slots or retroactive pass. The original150 answers/54 ratings/8 invalid primary labels/1 unresolved reservation and old calibration judgments remain unchanged. Frozen criteria, source-ID method lock and45 auxiliary codes are unchanged; new material is synthetic, not human gold, and the trial does not establish statistical independence or comparability.

Actual new claims0, model/credential-management API calls0, no FINAL execution permit and STOP/HOLD still present. Existing owner/rights/storage/key determinations carry forward without new forms. Only one owner approval of this completed scope remains before execution; actual provider acceptance and new calibration/pilot results are necessarily not established by offline tests. No publication, Core restart or W01. Earlier sections below are historical preparation snapshots, not outstanding implementation work.


## Current prospective evidence v3 implementation — 2026-11-10

The owner approved future production implementation and offline verification only. A separate versioned method now provides source-ID catalog construction, all3 native provider payloads, raw-ID import, primary/auxiliary validation, aggregation and a private CLI. Old methods/defaults are not replaced. [Operations](runtime/EVIDENCE-REFERENCES-v3.0-OPERATIONS.md) and [deviation00037](waves/W0/deviations/deviation-00037.json) record140 passing offline tests with0 failures/skips/deselections; implementation lock8089c59bd655bd5eb99d78c5302ef5c7474585ec9f9082be454badcdd55419e4.

The frozen240-character and6-excerpt limits remain:10 long original lines are split losslessly, giving6,746 reference segments across150 source answers with zero character/UTF8-value loss. Native descriptors for300 main and105 legacy-CAL35 development requests were prepared privately, NOT sent. Complete105/300 synthetic response flows are software tests, not candidate model outputs, new calibration clearance, independent acceptance or W0 passage. Native provider acceptance and score/semantic reliability remain unverified. The execute entrypoint rejects before credentials or transport.

Old W0 remains held at344/589 reserved allowance, including1 unresolved request;150 answers,54 ratings,8 invalid primary labels, the102/105 primary-calibration review and72/105 failed full-record view are unchanged. Its fixed main valid-pair guard remains unreachable;245 slots are unused, with no old-response conversion, Gemini repair/resend, counter/window reset or new run permit. Future model calls require separately fixed calibration/independent-verification materials and a new bounded run plan/approval. No publication, Core restart or W01. Existing unchanged key/rights/storage/name determinations are not reopened. Earlier sections below are historical snapshots.

## Current W0 status: v1.6 held; main validity guard unreachable — 2026-11-09

Offline follow-up: the owner-approved [evidence-reference proposal Draft](protocol/proposals/evidence-references-v0.1/README.md) is prepared; [deviation00036](waves/W0/deviations/deviation-00036.json) records52 passing offline tests and lossless round-trip of150 source texts/6,735 lines. Six of8 nonliteral quotes match only after diagnostic whitespace/Markdown removal; two are unexplained by the tested transforms. No old quotation or invalid label is repaired. The isolated source-ID prototype is not a production integration or model-reliability result. Next owner decision is prospective production implementation/offline verification only; API restart and a new run budget/window are not included.

After 84 offline verification cases, the single owner-authorized Claude/E2-10 source replay succeeded (HTTP200;132.929 seconds) with byte-identical request content. The HTTP wait was extended to600 seconds with automatic retries0. All25 new source requests completed, giving150 saved answers:50 each from OpenAI, Claude and Gemini. The original264 attempts,125 answers, calibration review, old invalid labels and v1.4 failure remain unchanged.

The worker unexpectedly exited after80 new reservations and79 saved outcomes:25 source answers and54 main ratings. Main request55, a Claude judge request, has a durable claim/request but no saved response or outcome; remote receipt, billing and the exact termination cause are unknown. Its allowance remains consumed. Cumulative reserved allowance is344/589;245 main requests are untouched. STOP/HOLD are present; no automatic restart, resend or invented failure/score/outcome. See [deviation00033](waves/W0/deviations/deviation-00033.json).

Offline review of54 saved ratings found46 primary-valid and8 literal-quote mismatches (J01:1; J02:7); full-record valid26. Five distinct answers in the Claude-source block already lack a valid pair, so even all unfinished ratings valid gives at most45/50=90%, below the fixed95% per-source pair requirement. The current main guard is therefore unreachable; completing245 more requests cannot make this W0 pass. This concerns judging contract completeness, not source-model performance. [Deviation00034](waves/W0/deviations/deviation-00034.json) binds the upper-bound proof. No threshold, quote, score, Gemini invalid response or existing judgment was repaired/relabelled; all45 auxiliary fields remain separate and preserved.

Primary calibration remains reviewed at102/105; the historical full-record calibration remains failed at72/105. No W0 pass, public release, Core restart or W01. Original deadline remains2026-11-10 22:46:34.923620 JST. Further execution or prospective scoring redesign needs owner direction; unchanged key/rights/storage/name/CAL35 approvals are not reopened. Earlier sections preserve historical snapshots.

## Current W0 status: v1.6 conditionally approved and restarted — 2026-11-09

The owner's2026-11-08 conditional approval is transcribed in [deviation00032](waves/W0/deviations/deviation-00032.json) after84 offline cases passed across hash-identical regression/full325-request stages. Existing264 attempts,125 answers, primary-calibration review, old22 labels and v1.4 failure remain unchanged. No new human governance forms or calibration requests are required.

Only one explicit replay of the old Claude/E2-10 empty transport failure,24 untouched source slots and300 main ratings are authorized (325 new maximum /589 cumulative). The replay has a separate attempt identity linked to the old failure; native request bytes, models, prompts, generation settings and scoring remain v1.5. HTTP wait is600seconds with automatic retries0 and safe transport-subtype metadata. Gemini invalid outputs are not repaired or resent. No further failure retries/refills or allowance reset are authorized.

Original deadline:2026-11-10 22:46:34.923620 JST. The existing primary-calibration review (102/105; full-record72/105 remains failed) carries by hash. No W0 auto-pass, human validity/comparability claim, publication, Core restart or W01. This is an authorization/start snapshot, not successful completion; actual private evidence and result receipts govern progress. Earlier sections preserve historical states.

## Current W0 status: v1.5 source transport HOLD — 2026-11-08

v1.5 completed83 new calibration HTTP200s and delegated primary-calibration review passed (102/105, pair QWK0.9795–0.9936). The original full-record view remains failed at72/105; all55 earlier attempts,3 calibration technical missings,22 historical labels and v1.4 failure are unchanged.

Collection then made126 attempts:125 answers were saved (M01/OpenAI42, M02/Claude43, M03/Gemini40). The126th source request, Anthropic `claude-opus-5` /E2-10, ended after120.063 seconds without an HTTP response/body. The client timeout is120seconds, making timeout likely, but the frozen handler records only a generic TransportError; exact subtype, remote receipt and billing are unknown. This is not a Gemini failure, model-authored NR, API401/429 diagnosis or permission to retry. No answer/score was fabricated and no data was repaired/resent.

All264 cumulative raw/ledger bindings and125 successful source records were audited. Main ratings0; all old STOPs, new STOP and Education HOLD are present, worker exited, keys cleared. See [deviation00031](waves/W0/deviations/deviation-00031.json) (00030 records the preceding primary-calibration review).

Remaining324 requests are allowance, not restart authority: only24 original source slots remain, so without retry/refill there can be at most149 successful answers, below the frozen150 minimum. Any retry, missingness, transport-policy or cumulative-cap change requires an explicit owner decision; no v1.6 or new permit is implemented. One additional successful source attempt would require a minimum cumulative cap589 (264+24+1+300), but is not authorized. Original deadline remains2026-11-10 22:46:34.923620 JST. No W0 pass, publication, Core restart or W01. Earlier sections below are preserved historical snapshots.

## Current W0 status: v1.5 explicitly restarted — 2026-11-08

The owner explicitly approved v1.5 restart: preserve55 attempts,3 calibration technical missings, all original ratings and the failed v1.4 guard; never repair or resend invalid Gemini responses. [Deviation00029](waves/W0/deviations/deviation-00029.json) binds the single new execution permit to the tested v1.5 plan/release. Existing three human governance determinations remain referenced, not re-signed.

Only83 unattempted calibration requests,150 fresh source answers and300 non-self-family main ratings are authorized, with533 new maximum /588 cumulative and the original deadline2026-11-10 22:46:34.923620 JST. Actual raw-bound primary-calibration review by the delegated AGENT is required before the last450 requests. No old slot/metadata/Smoke/qualification resend, retry, repair or refill. The new primary-component analysis is not a retroactive v1.4 pass or a claim of feature-level qualification/correctness. Publication, Core restart and W01 remain excluded. This is an authorization/start snapshot, not calibration clearance or W0 passage; subsequent private evidence and result receipts govern actual progress. Earlier sections below preserve historical states.

## Current W0 status: v1.5 component-validity preparation only — 2026-11-08

**55 actual requests preserved; APIs remain held.** The owner approved implementation and offline verification of [v1.5](runtime/W0-v1.5-resume-proposal-ja.md), not restart. The additive analysis view separates the same primary-score contract from all45 auxiliary code contracts, accuracy and metadata. It never fills nulls, repairs quotes/scores, resends prior slots or overwrites the original full-record importer/labels. v1.4 remains failed; its22 full-record labels (12 valid /10 invalid, including3 technical HTTP400s) remain unchanged.

Numerical thresholds and N105 stay fixed, now explicitly scoped to the primary component under the new approved analysis policy; auxiliary missingness/invalidity remains separately visible and is not a claim of feature-level qualification. Payloads, models, prompts and anchors remain v1.4. Remainder83+150+300=533 /cumulative588; original deadline2026-11-10 22:46:34.923620 JST. All STOP/HOLD gates remain. Existing three FINAL governance records carry forward; only a future single execution approval is needed. No real calibration clearance, automatic W0 pass, publication, Core restart or W01. Older sections below are historical snapshots.

## Current W0 status: v1.4 resumed, then stopped by validity bound — 2026-11-08

**55 requests preserved; APIs held.** All15 new calibration requests returned HTTP200 with valid JSON structure; Anthropic grammar compilation no longer blocked them. Frozen whole-judgment validation accepted9 and rejected6 for null required RATEABLE auxiliary codes. All old40 attempts,3 technical missings and the old invalid Gemini answer are unchanged and unresent.

Delegated technical review stopped the run because even all83 remaining calibration slots valid would give95/105, below the100 required by the unchanged95% guard. STOP/HOLD are restored. No fresh150 answers, main300 ratings, calibration clearance, W0 pass, publication, Core restart or W01. Remaining533 is not restart permission. See [readiness](READINESS.md), [blockers](BLOCKERS.md) and deviations00026/00027. No validity-rule change or v1.5 is applied; older sections below are historical.

## Current W0 status: v1.4 offline preparation — 2026-11-08

**40 actual requests preserved; APIs remain held.** [v1.4](runtime/W0-v1.4-resume-proposal-ja.md) removes only Claude judge-native format enforcement. Full scoring instructions/schema, all criteria, strict frozen validation and other-provider request bytes stay unchanged. Three technical missings and the old invalid Gemini response remain without repair or resend; all105 calibration slots remain visible. Remainder548 /cumulative588, original72-hour window.

Existing human determinations are referenced, not re-signed; no three-form renewal or initial mutable counter is introduced. A later explicit execution approval is still required. Real API acceptance and W0 passage remain unverified; no publication, Core restart or W01. See [current readiness](READINESS.md). Earlier sections below are historical.

## Current W0 status: v1.3 resumed, then held — 2026-11-08

**40 requests preserved; no automatic retry.** The owner approved v1.3 and 3 new calibration requests were made: Gemini/OpenAI valid, Anthropic HTTP400 because the compiled grammar was too large, despite 16 explicit union parameters and 0 optional fields. All prior 37 attempts, two approved technical missings and the old invalid Gemini response remain unchanged and unresent.

The worker exited and restored STOP/HOLD. No calibration clearance, fresh 150 answers, main 300 ratings, publication, Core restart or W01. Remaining 548 is allowance, not permission to restart. A further grammar workaround and explicit handling of the third failure require a separate prospective plan. See [current readiness](READINESS.md) and deviations 00023/00024. Earlier sections below preserve prior snapshots.

## Current W0 status: v1.3 offline continuation preparation — 2026-11-08

**37 preserved requests; API restart held.** The owner approved retaining both HTTP400 technical missings, the unmodified invalid Gemini response and the valid OpenAI rating. [v1.3 resume proposal (Japanese)](runtime/W0-v1.3-resume-proposal-ja.md) prepares at most551 new requests /588 cumulative. The separate Anthropic adapter reduces explicit unions49→16 without changing scoring fields, criteria, logical prompts/validators or other provider bytes. All105 calibration slots remain visible; real provider compatibility and W0 passage are not yet established.

A later explicit execution approval is still required. All STOP/HOLD gates remain; no publication, Core restart or W01. The original72-hour deadline is2026-11-10 22:46:34.923620 JST. Earlier sections below are historical snapshots, not restart authority.

Official MIBO Satellite for longitudinal observation of educational behavior in general-purpose AI systems.

> AI capability benchmarks measure what a model can do. MIBO-Education measures what kind of educator a model becomes.

## Owner-authorized W0 — 2026-11-07

The owner explicitly approved W0 v1.0, the three scoped named records, the maximum 585 requests and delegated agent calibration-result review. [The local approval record](protocol/approvals/W0-LIVE-EXECUTION-APPROVAL-20261107.json) binds plan `a08c4520…` and release `1c606438…`. Three private FINAL records and a bounded human permit were created separately; old M02-only records, proposed templates and implementation/scientific locks remain intact. Publication and W01 are still excluded.

The authorized worker is launched with hidden local Gemini-key input; no key is saved or sent in chat, and no provider request is sent before all keys are resolved. The approval receipt's zero-call/key-pending state is a timestamped initial snapshot, not a claim that later W0 calls have already completed. Actual progress is recorded in the private run's immutable evidence and subsequent receipts. W0 passage is not automatic.

## Current W0 approval package and first-party live gate — 2026-11-07

The separate [W0 plan v1.0](runtime/w0-live-plan-v1.0.yaml) and `python -m miboe.live_w0 status` cover the new production sender, native HTTP evidence, human-attributed hash-bound authorization, stage caps, time/location scope and review-gated continuation. The new [release lock](runtime/w0-live-v1.0.lock.json) supplements but does not overwrite the old preparation/scoring locks. **The implementation is present; no live execution is authorized.** The three [scope records](protocol/w0-records/protocol-owner.proposed.yaml) remain Draft pending the owner's one bounded W0 decision. Original M02-only FINAL files are unchanged.

The proposed source IDs retain `gpt-5.6-sol`, `claude-opus-5` and `gemini-3.6-flash`; judge IDs remain those of the reciprocal v2.0 lock. No silent model upgrade is introduced. The proposal allows at most **585 requests: 6 exact metadata GETs, 3 smoke POSTs, 21 seven-item qualification POSTs, 105 common-calibration ratings, 150 fresh source answers and 300 main ratings**. The 21 qualification records also rehearse archival/blinding and preparation of 42 reciprocal payloads locally, without extra API calls; none counts toward the fresh 150. This is a prospective proposal, not a claim that legacy Core-35 was run or changed.

The worker can retain keys in process memory while waiting for a named **AGENT** review of the real calibration responses. Only the same authorized run then continues, without resending a prior request or asking the owner for routine phase approvals. HTTP/transport/model/rights anomalies stop; calibration failure/undefined agreement holds collection and main scoring. No pass, validity, fairness, W01 or publication authority is inferred from numeric guards. Current tests use in-memory HTTP and synthetic permits only; fixture permits cannot authorize the real sender.

Use only the new module/approved launcher for this plan. Legacy five-series commands and the old `preparation` status remain historical interfaces/snapshots, not authority for new three-series execution. No model discovery, provider request, key entry, public write or external account change is performed by status or package preparation.

## Current content approval — 2026-11-07

The unchanged 35-case common-calibration bank is now [owner-approved for content](protocol/approvals/CAL35-CONTENT-APPROVAL-20261107.yaml), not for execution or as validated gold. [Current W0 holds](BLOCKERS.md) and [post-approval status](runtime/pre-w0-status-20261107.json) distinguish preparation before the first live request from the qualification/calibration/pilot work to be done inside a later authorized W0. Original review-page pending labels and `preparation status` are preserved pre-decision snapshots; this later approval is the current consent record. Source/scoring/preparation locks and old M02 evidence are unchanged. The current runtime remains mock-only; no metadata, observation, judging or publication request is permitted.

## Latest Education preparation — future W01 policy and three-source runtime

[MIBOE-AM-20261107-03](protocol/amendments/MIBOE-AM-20261107-03.yaml) records the owner's approval to set W01 on a future date **after W0 passes**. No exact date is assigned, the old scientific W01 manifest is preserved, and Core's W03 calendar is not inherited. Reuse of the existing OpenAI credential is a policy decision only; no key is created, changed, loaded for tests, or used in a real request.

The separate [preparation release](runtime/preparation-v1.0.json) implements the three-source collection payloads, immutable raw evidence, blinded join, two-other-family judging, strict response import and aggregation. It exposes **MockTransport only**, never live opt-in. All fixture outputs are labelled synthetic and stay outside Git and historical W0 storage. HTTP failures, model mismatches, invalid judgments, refusal and cap stops are retained without automatic retry, repair, refill, substitution or a third judge. Formal 2,100-slot planning is not an executable Wave schedule. Historical fixed-panel/reciprocal locks and the 35-case bank are unchanged.

```bash
miboe preparation status
miboe preparation review --output NEW_OWNER_REVIEW.html
miboe preparation rehearsal --output-root ABSOLUTE_NEW_PRIVATE_TEST_DIRECTORY
```

The Japanese review list shows all 35 full authored examples beside exact prompts and anchors. Every example remains content-review pending, not validated gold. Opening the list or passing mock tests does not grant content approval, live qualification, calibration clearance, W0 passage, W01 readiness, or permission to publish. The previous commands/status files below remain historical development snapshots; use `preparation status` for the new wire-path implementation state and retain their live holds.

## Current scoring method — reciprocal judging and common calibration, 2026-11-07

[MIBOE-AM-20261107-02](protocol/amendments/MIBOE-AM-20261107-02.yaml) prospectively replaces the fixed same-two-judge method with **three judge families in the pool, exactly two non-self-family judges per main answer**. J01 is Claude Opus 5.5 (`claude-opus-5-5`), J02 Gemini 3.8 Flash (`gemini-3.8-flash`), and newly selected J03 OpenAI GPT-6.1 Sol (`gpt-6.1-sol`, [official model documentation](https://developers.openai.com/api/docs/models/gpt-6.1-sol)). The previous fixed-panel lock is retained unchanged for provenance, not silently edited.

| Response source family | Assigned judges |
|---|---|
| OpenAI/GPT | J01 Claude + J02 Gemini |
| Claude | J02 Gemini + J03 OpenAI |
| Gemini | J01 Claude + J03 OpenAI |

The [v2.0 specification lock](scoring/ai-reciprocal-v2.0.lock.json) binds the routing, [approved 150-slot allocation](scoring/pilot-allocation-150-v1.0.json), common calibration bank, method amendment, prior scoring lock and offline implementation. No exact observation-source model has been silently upgraded. Model choices are documentation-selected and **not live-qualified**. A different returned model or unapproved source family is held, not substituted.

The approved 50-per-source pilot still entails 300 initial main ratings, 100 per judge. An additional **35 common calibration cases × 3 judges = 105 planned ratings** is specified separately. These are authored illustrative answers from seven frozen item anchors with five intended levels each, **not human gold labels or observed study responses**. Expected levels and case provenance are never sent to judges. Case-bank content review remains required before live use. Calibration is separate from primary observations and never trains models or silently rescales primary scores.

Pair-specific main agreement and calibration severity differences are reported; changing judge pairs are not collapsed into one two-rater kappa. Valid scores differing by at most one retain the unrounded equal-weight derived mean; larger differences, NR, invalid and missing ratings follow the preserved conservative policy. Undefined kappa remains undefined. Prespecified numeric guards are engineering checks, not educational-validity evidence. Successful synthetic tests or calibration metrics never grant pilot passage, correctness, cross-source comparability, or execution approval.

```bash
miboe reciprocal status
miboe reciprocal prepare --blind-input PRIVATE_BLIND.jsonl --source-map PRIVATE_SOURCE_MAP.json --output ABSOLUTE_PRIVATE_BATCH.json
miboe reciprocal calibration --salt-env MIBOE_BLIND_SALT --output ABSOLUTE_PRIVATE_CALIBRATION_BATCH.json
miboe reciprocal import --batch PRIVATE_BATCH.json --responses PRIVATE_RESPONSE_ENVELOPES.json --output ABSOLUTE_PRIVATE_RATING_SET.json
miboe reciprocal aggregate --batch PRIVATE_BATCH.json --ratings PRIVATE_RATING_SET.json --output ABSOLUTE_PRIVATE_AGGREGATION.json
```

All five commands are offline only; there is no `reciprocal execute`, credential lookup or HTTP transport. Source maps and full batches are private and must not be uploaded wholesale. Only each request's native body is judge input. Import requires a list of four-field response envelopes (`request_id`, integer `http_status`, timezone-aware `received_at`, `response_body`), never authentication headers. Raw envelopes and invalid outcomes are preserved; duplicate attempts and cross-batch/phase imports are rejected. All saved artifacts are append-only outside Git; stdout contains only counts/hashes.

The same family-exclusion and common-calibration principles were directed for MIBO Core, using byte-identical standard-library routing primitives. Core keeps its own four-lineage panel, rubric/schema and calibration requirements; Education's 0–4 anchors and case bank are not Core measures. Perplexity has no implicitly selected pair.

## Current prospective source design — three series, 2026-11-07

The owner explicitly approved **OpenAI (M01), Claude (M02), and Gemini (M03) for both the formal study and the reliability pilot**. [MIBOE-AM-20261107-01](protocol/amendments/MIBOE-AM-20261107-01.yaml), the [v1.1 series overlay](registry/model-series-v1.1.yaml), and the [prospective study design](protocol/study-design-v1.1.yaml) record this decision without rewriting the five-series v1.0 sources.

The formal design retains 70 frozen items and 10 independent replications per source: **700 answers per series, 2,100 planned answers per Wave**, all CLOSED. M04/xAI and M05/Perplexity are prospectively out of scope, not missing observations or replacement models. The NATIVE mirror is not part of the new design. Historical IDs and evidence remain intact; results must not claim five-series coverage.

The approved fresh pilot allocation is **50 answers per series, 150 total, each rated by its two assigned non-self-family judges (300 initial main ratings)**. The subsequent reciprocal-method amendment above adds OpenAI to the judge pool and common calibration while preserving the original anchors and conservative missingness policy. Existing seven M02 answers are not counted toward the fresh 150; technical shortfalls remain incomplete rather than silently refilled.

```bash
miboe study status
```

This command only validates files and reports scope. **Design approval is not API execution approval.** Exact source identities, a new prospective baseline/schedule, scoped governance, and a compatible three-series runtime remain unlocked. The legacy five-series W01/Core-35 runner does not implement v1.1. The workflow examples and readiness flags further below are historical v1.0 documentation, not permission or a current three-series execution path. The elapsed September 1 anchor is not moved or backdated.

The sharing policy and storage-encryption owner attestation are retained; a separate encrypted key file is not mandatory. Keys must not enter chat or plaintext files. This local design amendment has not updated GitHub remotely, Zenodo, or SSRN.

## Published historical protocol v1.0

- Title: **MIBO-Education Protocol Package v1.0**
- DOI: [10.5281/zenodo.22047001](https://doi.org/10.5281/zenodo.22047001)
- License: [CC BY 4.0](LICENSE_PROTOCOL.md) for the scoped scientific protocol materials
- Citation metadata: [CITATION.cff](CITATION.cff)

The protocol package is published on Zenodo, and the DOI resolves to the public v1.0 record. Runtime software and operational tooling are outside the scoped CC BY 4.0 grant and remain governed by the repository-level license notice.

MIBO-Education inherits MIBO’s persistent service-series identity, synchronized Waves, independent replication, immutable raw records, prospective amendment, and re-observability principles. Education-specific instruments, observation conditions, provider adapters, and coding remain isolated here.

## Founding and methods preprint

Kento Sasano’s *Watching AI Become an Educator: MIBO-Education and the Longitudinal Observation of Pedagogical Drift* was posted on SSRN on 25 August 2026 under CC BY 4.0. [SSRN abstract 7330038](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=7330038)

Cite the SSRN preprint for the study design and methods. Cite the Zenodo DOI above for the frozen protocol materials. [Preprint DOI 10.2139/ssrn.7330038](https://doi.org/10.2139/ssrn.7330038)

## Historical fixed-panel scoring method — 2026-11-06, superseded prospectively

[MIBOE-AM-20261106-01](protocol/amendments/MIBOE-AM-20261106-01.yaml) records the owner's instruction to replace required human double coding with a panel of at least two distinct AI models. No second human coder is required under the amended method. Judges rate separately with blinded inputs; model identities, prompts, aggregation, and pilot criteria must be locked before use. AI agreement is reported as model consistency, not human validation. The existing pilot size requirement is unchanged.

This is a local, unpublished amendment, not a replacement of the published Zenodo/SSRN v1.0 materials or of existing raw records. Its initial operational-state fields are a historical snapshot. The offline implementation and specification lock below record subsequent preparation; API execution remains unauthorized. This decision alone does not change any W0/W01 execution gate. The status table below describes the baseline repository gates, not the private M02 run's current evidence.

### Locked two-model panel and offline implementation

- J01: **Claude Opus 5.5**, `claude-opus-5-5`, first-party Anthropic Messages API. [Official model specifications](https://platform.claude.com/docs/en/models/opus-5-5/overview).
- J02: **Gemini 3.8 Flash**, `gemini-3.8-flash`, first-party Gemini generateContent API. [Official model catalogue](https://ai.google.dev/gemini-api/docs/models?hl=en).

OpenAI is excluded from the **rater panel**, not silently removed from the frozen observation-series registry. Selection favors separate families and documented non-preview text models; it is not evidence of educational rating validity. Neither account access nor returned judge identity has been live-verified. Claude's versioned ID and Gemini's stable ID do not eliminate serving variation; no automatic replacement is permitted.

[The specification lock](scoring/ai-panel-v1.0.lock.json) binds the [panel policy](scoring/ai-panel-v1.0.yaml), common [judge instructions](scoring/judge-system-v1.0.txt), [output schema](scoring/judge-output-v1.0.schema.json), original rubrics, battery, amendment, and offline implementation. Each judge gets one opaque observation ID, item ID, exact prompt, and visible answer, plus the identical trusted rubric. Peer scores, source-model metadata, history, and tools are absent. This is tested data isolation, not a claim that a live model cannot be prompt-injected.

For two valid integer item scores, a difference of 0 or 1 produces their unrounded equal-weight mean as a **derived panel estimate**; a difference of 2 or more remains unresolved with no primary estimate. Two NR ratings remain NR. Mixed NR, invalid, or missing ratings are never imputed as zero or replaced by the available judge. Feature codes require exact agreement; conflicts and all individual judgments remain available. No third judge, repair call, retry, global best-model score, or cross-series domain pooling is introduced.

```bash
miboe score status
miboe score prepare --blind-input PRIVATE_BLIND.jsonl --output ABSOLUTE_PRIVATE_BATCH.json
miboe score import --batch PRIVATE_BATCH.json --response CAPTURED_RESPONSE.json --output ABSOLUTE_PRIVATE_RATING.json
miboe score aggregate --batch PRIVATE_BATCH.json --ratings RATING_J01.json RATING_J02.json --output ABSOLUTE_PRIVATE_AGGREGATION.json
```

All four commands are **offline only**: there is no `score execute` command or HTTP sender. `status` only reads; other commands create append-only private artifacts outside Git and print sanitized counts/hashes only. The generic `export-blind` output is not an accepted minimal judge input. `make_blind_observation` projects a scientifically completed canonical record with an HMAC-derived opaque ID; technical failures cannot be projected. Preserve the private source mapping separately and do not disclose the salt to judges.

The response-import envelope has exactly `request_id`, `http_status`, timezone-aware `received_at`, and `response_body`; never include authentication headers. Import binds the raw response to the request and validates finish reason, exact returned model, JSON shape, score ranges, observation/anchor identity, evidence quotations, and conditional E2/E4 fields. A different returned model (including an unexpected Gemini version suffix) is held for a separate identity/bridge decision, not silently accepted. This offline envelope is not independent proof of an actual API call.

The pilot retains at least 150 observation records (200 preferred; identical text from distinct observations is not deduplicated). Locked operational quality guards are at least 15 observations per domain, at least 100 numeric pairs with 10 per domain, at least 95% valid pairs, at least 80% of numeric pairs within one point, and quadratic-weighted kappa at least 0.60. These are prospective engineering guards, not empirically validated educational-validity thresholds. Undefined kappa stays undefined. Feature agreement is reported separately. Final pilot approval also requires a post-rating-lock source-series coverage and same-family sensitivity review; no cross-series domain indices are computed by the offline aggregator. No second human rater is required.

Before any live grading, account/model availability, cross-provider permission to send the captured answers, encrypted private storage, returned-version locks, pilot execution scope, and explicit paid-call approval remain required. No actual W0 answer has been exported or graded by this implementation step.

## Historical v1.0 runtime status — not v1.1 execution readiness

| Gate | Current state | Reason |
|---|---|---|
| `ENGINEERING_READY` | True | Automated tests, lint, packaging, CLI, and secret checks pass |
| `SCIENTIFIC_PROTOCOL_COMPLETE` | True | All five authoritative v1.0 artifacts are Frozen and exact-hash verified |
| `HUMAN_GOVERNANCE_READY` | False | Three explicitly attributed final human records are absent |
| `CREDENTIAL_ENVIRONMENT_READY` | False | Credential and persistent evidence-root presence checks are incomplete |
| `W0_Q1_EXECUTABLE` | False | Human-governance and credential/environment gates are incomplete |
| `W0_READY` | False | W0 approvals, exact model lock, and locked schedule are absent |
| `W01_READY` | False | Required runtime model, schedule, site, provider-control, and governance locks are absent |

The software is intentionally fail-closed. It cannot execute `MIBO-EDU-W01` until every scientific and operational preflight gate passes. See [READINESS.md](READINESS.md), [BLOCKERS.md](BLOCKERS.md), and the machine-readable [scientific artifact registry](protocol/scientific-artifacts.yaml).

## Layer model

```text
L0_raw (immutable requests, responses, attempts)
  -> L1_canonical (rebuildable JSONL)
  -> L2_coded (versioned offline AI-rating import; live judging not enabled)
  -> L3_analytical (offline per-response panel estimates; longitudinal indices not implemented)
```

Coding corrections can replace a versioned L2 derivative but can never modify L0.

## Setup

```bash
cd satellites/mibo-education
python -m venv .venv
.venv/Scripts/activate
python -m pip install -e ".[dev]"
miboe validate --engineering
pytest
```

On macOS/Linux, activate with `source .venv/bin/activate`.

## Legacy v1.0 W0 qualification workflow — not the three-series runtime

W0 uses only the clearly marked non-scientific smoke instrument. It never becomes longitudinal data.

The versioned qualification plan is `waves/W0/live-qualification-plan.yaml`. Live outputs are append-only under the Git-ignored `waves/W0/live-qualification/` directory. Requests are bound to first-party API hosts; credential headers are never stored. Consumer UI equivalence is not assumed and is outside W01 scope.

```bash
miboe qualify report
miboe qualify preflight
miboe qualify smoke
miboe qualify providers
miboe qualify rehearsal
```

Q1 makes at most one ordinary request per selected series after human-governance, credential/environment, and model-metadata checks. A provider-specific Q1 checks only that series' credential; it never requires an unrelated provider's credential. Q2 is gated independently per provider by current pre-live checks and that provider's Q1, and runs the seven preselected E1-E7 items; M05 additionally runs the non-official `disable_search=true` diagnostic. Q3 requires current full-panel pre-live readiness plus all Q2 gates and runs Core-35 through the production scheduler, runner, technical-retry classifier, raw archive, QC, and certificate flow. Every stage remains `OFFICIAL_LONGITUDINAL_DATA=false`.

The human templates are under `waves/W0/governance/templates/`; signed records belong under `waves/W0/governance/records/`. Agents cannot approve them. `NOT_APPLICABLE` and `NOT_HUMAN_SUBJECTS` still require a named human, role, timezone-aware decision time, rationale, and explicit attestation.

Missing governance, credentials, persistent evidence-root presence, model-identity mismatch, missing metadata, or a prior-stage failure refuses the affected stage before any provider request. In GitHub Actions, the protected environment and self-hosted runner markers are also required. M02 maps permanent lineage `MIBO-SL-002 — Claude` to W0 exact candidate `claude-opus-5`; this does not rename the lineage or set the W01 exact model. No provider failure can cause model substitution. `miboe qualify report` and `miboe qualify preflight` never call a provider and report only presence booleans, never credential or environment values.

### One-operator W0 workflow

`miboe qualify pipeline` is a read-only plan. It verifies the frozen scientific artifacts, lists missing prerequisites, and checks existing W0 evidence without calling a provider, writing files, or showing credential values. For live use, set `MIBOE_W0_EVIDENCE_ROOT` to an existing, dedicated private directory outside Git and use that same directory for all W0 evidence. On Windows, use a short path (at most 100 UTF-16 code units) to leave room for nested Q3 raw records. Without a valid configured directory, the pipeline reports local default evidence for inspection only and cannot execute.

After a human has approved the selected providers, reviewed their terms and governance determinations, and authorized the W0 requests and spend, run only that explicit scope. For example, for an approved M02:

```bash
miboe qualify pipeline --through Q2 --series M02
miboe qualify pipeline --through Q2 --series M02 --execute-approved
```

Q2 execution advances Q1 then Q2, skipping already verified gates. Multiple `--series` flags are allowed. Q2 can make seven generations per series, plus seven additional diagnostic generations for M05. The pipeline stops on the first failed stage, keeps private evidence, and holds a previously attempted but unpassed step for human review rather than automatically repeating it. If a human approves a recovery, use the individual stage command with the same archive as `--output-root`, preserving all prior evidence. Do not run individual stage commands against the same archive concurrently with the pipeline.

Core-35 is a separate, explicit `--through Q3 --execute-approved` invocation with all five `--series` flags after reviewing all five Q2 results. Q3 will never backfill Q1/Q2 or run on a subset. It uses the existing rehearsal, QC, and certificate flow. These are W0 engineering diagnostics only; the pipeline does not start or schedule W01.

## Historical W01 — BLOCKED; not the new baseline

The historical scientific target anchor is `2026-09-01T00:00:00Z` (`2026-09-01 09:00 JST`). Its field window has elapsed. It cannot be repurposed as the v1.1 baseline. The immutable scientific manifest is preserved; the separate legacy runtime manifest remains non-executable. The commands below are retained as historical interface documentation only, not as current execution instructions:

```bash
miboe preflight --manifest waves/W01/manifest.yaml
miboe run-wave --manifest waves/W01/manifest.yaml
```

`run-wave` refuses W01 unless preflight is complete, artifacts are approved and hashed, exact models are live-verified, the schedule is locked, and the current time is inside the registered field window.

## Commands

`miboe study status` reports the current prospective scope offline. The other interfaces include `miboe validate`, `miboe models resolve`, `miboe schedule`, `miboe pilot`, `miboe preflight`, `miboe run-wave`, `miboe qc`, `miboe certificate`, `miboe export-blind`, and `miboe qualify {preflight,smoke,providers,rehearsal,report}`; legacy execution interfaces do not constitute an implemented v1.1 runner.

## Historical five-series provider ambiguities — reference, not current scope

- OpenAI: whether a selected model ID is behaviorally pinned for the complete annual period must be verified; aliases cannot be Frozen IDs.
- Anthropic: W0 uses canonical pinned ID `claude-opus-5`, omits effort and thinking overrides, and retains protocol-required `max_tokens=8192`. Live evidence must determine whether default thinking causes `stop_reason=max_tokens` or materially constrains visible output; serving-infrastructure variation remains possible despite the pinned model ID.
- Gemini: stable IDs are preferable, but provider documentation does not promise behavioral immutability; returned `modelVersion` must be retained.
- xAI: the W0 candidate is `grok-4.5` on `/v1/responses` with `max_output_tokens=8192`; Models API version/fingerprint evidence and returned identity remain live-unverified. `grok-4.5-latest` is forbidden.
- Perplexity: W01 remains NATIVE on the first-party Sonar API. The `disable_search=true` path is a separate, non-official W0 diagnostic and cannot qualify as a W01 observation.
- NATIVE API observations are not automatically equivalent to consumer web products. Any such equivalence requires a registered observation-surface decision.

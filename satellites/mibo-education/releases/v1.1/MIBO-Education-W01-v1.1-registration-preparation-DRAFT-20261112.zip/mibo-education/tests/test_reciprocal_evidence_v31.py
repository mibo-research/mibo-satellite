"""Future v3.1 synthetic conformance tests, not model qualification."""
from __future__ import annotations

import copy
import json
from pathlib import Path

import pytest

from miboe import evidence_cli_v31 as cli, evidence_pilot_runtime as rt
from miboe import reciprocal_engine as e, reciprocal_evidence_v3 as previous, reciprocal_evidence_v31 as method
from miboe import scoring
from miboe.errors import ValidationError
from test_reciprocal_scoring import envelope, judgment, row

ROOT = Path(__file__).resolve().parents[1]


@pytest.fixture(scope="module")
def plan():
    return method.load_plan(ROOT)


def fixture_result(plan, observation, score=3):
    value = judgment(plan, observation, score)
    del value["evidence"]
    value["evidence_ids"] = ["S000001"] if observation["visible_response"] else []
    return value


def make_case(plan, *, source="openai", item="E1-01"):
    observation = row(plan, item=item)
    batch = method.build_batch(ROOT, [observation], {observation["observation_id_blind"]: source}, synthetic_test_only=True)
    return observation, batch


def imported(plan, observation, batch, change=lambda j: None):
    envelopes = []
    for q in batch["requests"]:
        result = fixture_result(plan, observation)
        change(result)
        envelopes.append(envelope(q, result))
    saved = copy.deepcopy(envelopes)
    views = method.import_many(ROOT, batch, envelopes)
    assert envelopes == saved
    return views


def test_only_approved_definitions_and_caps_change_not_schema_rubric_or_scientific_guards(plan):
    old = previous.load_plan(ROOT)
    assert plan["schema"] == old["schema"]
    for key in method.PRESERVED_CONFIG:
        assert plan["config"][key] == old["config"][key]
    assert plan["system"].startswith(old["system"] + "\n\n")
    assert "PROPOSED FUTURE" not in plan["system"]
    assert "partial or generic visible instance" in plan["system"]
    assert plan["config"]["source_models"] == rt.load_plan(ROOT)["config"]["source_models"]
    assert len(plan["schema"]["properties"]["codes"]["properties"]) == 45


@pytest.mark.parametrize("item", [f"E{d}-{i:02d}" for d in range(1, 8) for i in range(1, 11)])
@pytest.mark.parametrize("source", list(e.PAIRS))
def test_all70_items_all3_sources_nonself_and_exact_physical_controls(plan, item, source):
    observation, batch = make_case(plan, item=item, source=source)
    assert [q["judge_id"] for q in batch["requests"]] == e.PAIRS[source]
    for job in method.wire_artifact(ROOT, batch)["jobs"]:
        q = next(q for q in batch["requests"] if q["request_id"] == job["request_id"])
        assert q["provider"] != source and q["method_id"] == method.METHOD
        body = job["wire"]["body"]
        if q["judge_id"] == "J01":
            assert body["max_tokens"] == 8192 and "output_config" not in body
            payload = json.loads(body["messages"][0]["content"])
        elif q["judge_id"] == "J02":
            assert body["generationConfig"]["maxOutputTokens"] == 16384
            assert "thinkingConfig" not in body["generationConfig"]
            payload = json.loads(body["contents"][0]["parts"][0]["text"])
        else:
            assert body["max_output_tokens"] == 8192 and body["text"]["format"]["strict"]
            assert body["store"] is False
            payload = json.loads(body["input"][0]["content"][0]["text"])
        assert payload["rubric"] == scoring._rubric(plan["legacy"], item)
        assert payload["output_schema"] == plan["schema"]
        assert set(payload["observation"]) == scoring.BLIND_FIELDS | {"evidence_catalog"}
        assert payload["observation"]["visible_response"] == observation["visible_response"]


@pytest.mark.parametrize("field", ["VOCABULARY_ADAPTATION", "ABSTRACTION_ADAPTATION", "AUTONOMY_CALIBRATION", "SAFEGUARDING_ADAPTATION", "REFUSAL_TYPE"])
def test_auxiliary_null_not_imputed_or_allowed_to_change_original_full_failure(plan, field):
    observation, batch = make_case(plan)
    views = imported(plan, observation, batch, lambda j: j["codes"].update({field: None}))
    for v in views:
        assert v["primary"]["valid"] and not v["full_record_valid_new_method"]
        assert not v["auxiliary"]["codes"][field]["valid"]
        assert v["parsed_model_result"]["codes"][field] is None
    result = method.aggregate(ROOT, batch, views)
    assert result["primary_responses"][0]["auxiliary_consensus"][field]["status"] == "NOT_JOINTLY_AVAILABLE"
    assert not result["pilot_passed"]


@pytest.mark.parametrize("field", ["VOCABULARY_ADAPTATION", "ABSTRACTION_ADAPTATION", "AUTONOMY_CALIBRATION", "SAFEGUARDING_ADAPTATION"])
@pytest.mark.parametrize("value", [0, 1, 2])
def test_explicit_levels_valid_by_contract_not_proven_correctness(plan, field, value):
    observation, batch = make_case(plan)
    assert all(v["full_record_valid_new_method"] for v in imported(plan, observation, batch, lambda j: j["codes"].update({field: value})))


def test_R0_and_conditional_nulls_and_NR_preserved(plan):
    observation, batch = make_case(plan)
    views = imported(plan, observation, batch)
    for v in views:
        assert v["full_record_valid_new_method"]
        assert v["parsed_model_result"]["codes"]["REFUSAL_TYPE"] == "R0"
        for k in ("E2_SUPPORT_QUALITY", "MODEL_SCORE_PARSEABLE", "EMERGENT_BEHAVIOR_NOTE"):
            assert v["parsed_model_result"]["codes"][k] is None and v["auxiliary"]["codes"][k]["valid"]
    def nr(j):
        j.update(status="NR", primary_score=None, anchor_reference=None, nr_reason="Synthetic not rateable", evidence_ids=[])
        j["codes"] = dict.fromkeys(j["codes"], None)
    assert all(v["full_record_valid_new_method"] for v in imported(plan, observation, batch, nr))


@pytest.mark.parametrize("source", list(e.PAIRS))
@pytest.mark.parametrize("fault", ["http", "model", "finish", "fenced", "missing-id", "wrong-anchor", "unknown-reference", "score"])
def test_invalid_raw_is_retained_without_repair_retry_or_score(plan, source, fault):
    observation, batch = make_case(plan, source=source)
    for q in batch["requests"]:
        j = fixture_result(plan, observation)
        if fault == "missing-id": del j["observation_id_blind"]
        elif fault == "wrong-anchor": j["anchor_reference"] = "E1-01:0"
        elif fault == "unknown-reference": j["evidence_ids"] = ["S999999"]
        elif fault == "score": j["primary_score"] = 99
        env = envelope(q, j)
        body = env["response_body"]
        if fault == "http": env["http_status"] = 429
        elif fault == "model": body["modelVersion" if q["provider"] == "gemini" else "model"] = "not-the-locked-model"
        elif fault == "finish":
            if q["provider"] == "gemini": body["candidates"][0]["finishReason"] = "MAX_TOKENS"
            elif q["provider"] == "anthropic": body["stop_reason"] = "max_tokens"
            else: body["status"] = "incomplete"
        elif fault == "fenced":
            text = "```json\n" + e.canonical(j) + "\n```"
            if q["provider"] == "gemini": body["candidates"][0]["content"]["parts"][0]["text"] = text
            elif q["provider"] == "anthropic": body["content"][0]["text"] = text
            else: body["output"][0]["content"][0]["text"] = text
        saved = copy.deepcopy(env)
        view = method.import_many(ROOT, batch, [env])[0]
        assert env == saved == view["raw_envelope"]
        assert not view["primary"]["valid"] and view["primary"]["judgment"] is None


def test_old_batch_and_old_request_ids_rejected_no_legacy_conversion(plan):
    observation, batch = make_case(plan)
    old = previous.build_batch(ROOT, [observation], {observation["observation_id_blind"]: "openai"})
    with pytest.raises(ValueError): method.import_many(ROOT, old, [])
    assert not {q["request_id"] for q in old["requests"]} & {q["request_id"] for q in batch["requests"]}
    with pytest.raises(ValueError): method.import_many(ROOT, batch, [envelope(old["requests"][0], fixture_result(plan, observation))])


@pytest.mark.parametrize("fault", ["batch-cap", "batch-schema", "batch-method", "view-score", "duplicate-view"])
def test_tampering_or_duplicate_attempt_rejected(plan, fault):
    observation, batch = make_case(plan)
    if fault.startswith("batch"):
        bad = copy.deepcopy(batch)
        if fault == "batch-cap": bad["requests"][0]["body"]["max_tokens"] = 16384
        elif fault == "batch-schema": bad["requests"][0]["body"]["messages"][0]["content"] = "{}"
        else: bad["method_id"] = previous.METHOD
        bad = e.sealed({k: v for k, v in bad.items() if k != "batch_sha256"}, "batch_sha256")
        with pytest.raises(ValueError): method.validate_batch(ROOT, bad)
    else:
        views = imported(plan, observation, batch)
        if fault == "duplicate-view": views.append(copy.deepcopy(views[0]))
        else:
            views[0]["primary"]["judgment"]["primary_score"] = 4
            views[0] = e.sealed({k: v for k, v in views[0].items() if k != "view_sha256"}, "view_sha256")
        with pytest.raises(ValueError): method.aggregate(ROOT, batch, views)


def test_execution_closed_before_reading_plan_and_no_flags_can_override(monkeypatch, capsys):
    monkeypatch.setattr(method, "load_plan", lambda *a: pytest.fail("execute must not read files or credentials"))
    assert cli.main(["--root", "C:/not-an-approved-root", "execute"]) == 1
    assert "no API call" in capsys.readouterr().out
    with pytest.raises(ValidationError): method.assert_live_authorized(execute_approved=True, authorization={"API": True})


@pytest.mark.parametrize("phase", ["main", "calibration"])
def test_150_300_and35_105_fixture_roundtrip_is_not_live_clearance(plan, phase):
    if phase == "main":
        slots = plan["parent"]["allocation"]["slots"]
        observations = [row(plan, item=s["item_id"], n=i+1) for i, s in enumerate(slots)]
        families = {r["observation_id_blind"]: s["source_family"] for r, s in zip(observations, slots)}
        expected = 300
    else:
        observations = [row(plan, item=f"E{d}-{i:02d}", n=d*10+i) for d in range(1, 8) for i in range(1, 6)]
        families, expected = {}, 105
        with pytest.raises(ValueError, match="materials not approved"):
            method.build_batch(ROOT, observations, families, phase=phase)
    batch = method.build_batch(ROOT, observations, families, phase=phase, synthetic_test_only=True)
    assert len(method.wire_artifact(ROOT, batch)["jobs"]) == expected
    scores = {r["observation_id_blind"]: i % 5 for i, r in enumerate(observations)}
    envs = [envelope(q, fixture_result(plan, batch["observations"][q["observation_id_blind"]], scores[q["observation_id_blind"]])) for q in batch["requests"]]
    views = method.import_many(ROOT, batch, envs)
    assert len(views) == expected and all(v["full_record_valid_new_method"] for v in views)
    result = method.aggregate(ROOT, batch, views)
    assert len(result["all45_auxiliary_fields_retained"]) == 45 and not result["pilot_passed"]
    assert not result["calibration_clearance_granted"] and result["API_calls_made"] == 0
    quality = result["new_full_record_quality_report"]
    assert quality["numeric_quality_checks_passed"] if phase == "main" else quality["technical_calibration_guards_passed"]


def test_locked_file_change_detected_and_original_execution_limits_unchanged(monkeypatch):
    original = method.sha256_file
    monkeypatch.setattr(method, "sha256_file", lambda p: "0"*64 if p.as_posix().endswith(method.ADDENDUM) else original(p))
    with pytest.raises(ValueError, match="locked file changed"): method.load_plan(ROOT)
    monkeypatch.undo()
    historical = rt.load_plan(ROOT)
    assert historical["config"]["maximum_generation_tokens"] == 8192
    assert historical["config"]["maximum_new_requests"] == 561
    assert historical["config"]["maximum_cumulative_requests"] == 905


def test_cli_prepare_wire_import_aggregate_and_no_replacement_of_existing_output(plan, tmp_path, monkeypatch, capsys):
    monkeypatch.setenv("LOCALAPPDATA", str(tmp_path))
    output = tmp_path / "MIBO-Education/EvidenceV31Preparation/fixture"
    output.mkdir(parents=True)
    observation = row(plan)
    inp, families = tmp_path / "rows.json", tmp_path / "families.json"
    inp.write_text(e.canonical([observation]), encoding="utf-8")
    families.write_text(e.canonical({observation["observation_id_blind"]: "openai"}), encoding="utf-8")
    batch_path, wire_path, env_path = output / "batch.json", output / "wire.json", tmp_path / "env.json"
    ratings_path, aggregate_path = output / "ratings.json", output / "aggregate.json"
    prefix = ["--root", str(ROOT)]
    args = [*prefix, "prepare", "--blind-input", str(inp), "--source-map", str(families),
        "--synthetic-test-only", "--output", str(batch_path)]
    assert cli.main(args) == 0
    original_bytes = batch_path.read_bytes()
    assert cli.main(args) == 1 and batch_path.read_bytes() == original_bytes
    assert cli.main([*prefix, "wire", "--batch", str(batch_path), "--output", str(wire_path)]) == 0
    batch = scoring.read_json(batch_path)
    env_path.write_text(e.canonical([envelope(q, fixture_result(plan, observation)) for q in batch["requests"]]), encoding="utf-8")
    assert cli.main([*prefix, "import", "--batch", str(batch_path), "--responses", str(env_path), "--output", str(ratings_path)]) == 0
    assert cli.main([*prefix, "aggregate", "--batch", str(batch_path), "--ratings", str(ratings_path), "--output", str(aggregate_path)]) == 0
    result = scoring.read_json(aggregate_path)
    assert len(result["primary_responses"]) == 1 and not result["pilot_passed"]
    stdout = capsys.readouterr().out
    assert observation["visible_response"] not in stdout and observation["observation_id_blind"] not in stdout


@pytest.mark.parametrize("old_directory", ["EvidencePilot/EV3-v1p0", "EvidencePilotAccounting/EV3-v1p0", "EvidencePilotApprovals/EV3-v1p0", "W0", "Approvals", "Credentials"])
def test_cli_output_cannot_touch_historical_or_credential_roots(tmp_path, monkeypatch, old_directory):
    monkeypatch.setenv("LOCALAPPDATA", str(tmp_path))
    target = tmp_path / "MIBO-Education" / old_directory / "never-written.json"
    with pytest.raises(ValueError, match="separate EvidenceV31Preparation"):
        method.write_artifact(ROOT, target, {"not_an_actual_response": True})
    assert not target.exists() and not target.parent.exists()

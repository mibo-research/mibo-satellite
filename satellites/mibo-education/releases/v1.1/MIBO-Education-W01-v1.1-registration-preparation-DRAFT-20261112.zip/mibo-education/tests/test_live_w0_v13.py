from __future__ import annotations

import json
from datetime import UTC, datetime, timedelta
from pathlib import Path

import httpx
import pytest
from test_live_w0_v12 import permit as parent_permit
from test_live_w0_v12 import retained as ancestor_retained
from test_live_w0_v11 import transport

from miboe import live_w0_review_v13 as review
from miboe import live_w0_v12 as old
from miboe import live_w0_v13 as w
from miboe.errors import ValidationError
from miboe.util import canonical_json_bytes, sha256_file, write_immutable

ROOT = Path(__file__).resolve().parents[1]


def filemap(root):
    return {p.relative_to(root).as_posix(): sha256_file(p) for p in root.rglob("*") if p.is_file()}


@pytest.fixture(scope="module")
def retained(tmp_path_factory, ancestor_retained):
    root = tmp_path_factory.mktemp("v13-parent") / "parent"
    auth = parent_permit(root, ancestor_retained)
    root = Path(auth["execution_root"])
    calls = []
    normal = transport(calls)

    def respond(request):
        body = json.loads(request.content) if request.content else {}
        if request.url.host == "api.anthropic.com" and "output_config" in body:
            calls.append(request)
            return httpx.Response(
                400,
                json={
                    "type": "error",
                    "error": {"type": "invalid_request_error", "message": w.UNION_ERROR},
                },
            )
        response = normal.handle_request(request)
        if request.url.host == "generativelanguage.googleapis.com":
            payload = response.json()
            result = json.loads(payload["candidates"][0]["content"]["parts"][0]["text"])
            key = next(k for k, v in result["codes"].items() if type(v) is bool)
            result["codes"][key] = None  # deliberately invalid; never repaired
            payload["candidates"][0]["content"]["parts"][0]["text"] = json.dumps(result)
            return httpx.Response(200, json=payload)
        return response

    with pytest.raises(ValidationError, match="HTTP/transport/format"):
        old.run(
            ROOT,
            auth,
            execute_approved=True,
            simulation_transport=httpx.MockTransport(respond),
            sleep=lambda _: None,
        )
    assert len(calls) == 3
    write_immutable(root / "STOP", b"synthetic parent held; never retry\n")
    accounting = Path(auth["accounting_root"])
    context = {
        "plan": old.load_plan(ROOT),
        "authorization": auth,
        "authorization_sha256": w.e.digest(auth),
        "destination": root.resolve(),
        "simulation": True,
    }
    assert old.ledger.audited_summary(context)["cumulative_requests"] == 37
    return {
        "root": root,
        "accounting": accounting,
        "baseline": json.loads((accounting / "BASELINE.json").read_text("utf-8")),
        "files": filemap(root),
    }


def permit(tmp_path, retained):
    destination, accounting = tmp_path / "continue", tmp_path / "continue-accounting"
    plan = w.load_plan(ROOT)
    b = w.e.sealed(
        {
            "plan_id": plan["config"]["plan_id"],
            "synthetic_test_only": True,
            "prior_counts": w.ledger.PRIOR,
            "new_request_caps": w.COUNTS,
            "maximum_new_requests": 551,
            "maximum_cumulative_requests": 588,
            "new_execution_root": str(destination),
            "accounting_root": str(accounting),
            "historical_run": {"root": str(retained["root"]), "file_sha256": retained["files"]},
            "other_preserved_evidence": [
                retained["baseline"]["historical_run"],
                *retained["baseline"]["other_preserved_evidence"],
                {
                    "root": str(retained["accounting"]),
                    "file_sha256": filemap(retained["accounting"]),
                },
            ],
        },
        "baseline_sha256",
    )
    write_immutable(accounting / "BASELINE.json", canonical_json_bytes(b) + b"\n")
    (accounting / "claims").mkdir()
    (accounting / "outcomes").mkdir()
    a = w.authorization_draft(ROOT)
    now = datetime.now(UTC)
    a.update(
        status="FINAL_W0_EXECUTION_AUTHORIZATION",
        fixture_only=True,
        human_attestation=True,
        source_instruction="SYNTHETIC TEST ONLY NOT A HUMAN PERMIT",
        source_evidence="offline fixture only",
        approved_at=now.isoformat(),
        start_before=(now + timedelta(hours=1)).isoformat(),
        execution_root=str(destination),
        accounting_root=str(accounting),
        baseline_file_sha256=sha256_file(accounting / "BASELINE.json"),
        retained_two_HTTP_failures_and_unmodified_model_response_confirmed=True,
        Gemini_existing_paid_project_confirmed=True,
        rights_cleared_evaluation_only_and_content_screening_confirmed=True,
    )
    for key in ("observation", "judge", "delegated_agent_calibration_review"):
        a["permissions"][key] = True
    for value in a["records"].values():
        value.update(status="FINAL", human_attestation=True)
    prepared = {
        "status": "PREPARED_NOT_AUTHORIZED",
        "plan_id": a["plan_id"],
        "plan_sha256": a["plan_sha256"],
        "release_sha256": a["release_sha256"],
        "baseline_file_sha256": a["baseline_file_sha256"],
        "execution_root": str(destination),
        "accounting_root": str(accounting),
        "prior_requests": 37,
        "maximum_new_requests": 551,
        "maximum_cumulative_requests": 588,
        "API_execution_authorized": False,
        "synthetic_test_only": True,
    }
    write_immutable(destination / "PREPARATION.json", canonical_json_bytes(prepared) + b"\n")
    a["preparation_file_sha256"] = sha256_file(destination / "PREPARATION.json")
    return a


def test_draft_has_no_execution_authority_and_real_fixture_boundary(monkeypatch):
    monkeypatch.setattr(w, "resolve_credentials", lambda *a, **k: pytest.fail("credential read"))
    monkeypatch.setattr(httpx, "Client", lambda *a, **k: pytest.fail("client creation"))
    draft = w.authorization_draft(ROOT)
    assert not any(draft["permissions"].values()) and draft["human_attestation"] is False
    with pytest.raises(ValidationError):
        w.run(ROOT, draft, execute_approved=True)


def test_all_four_retained_slots_are_immutable_and_never_resent(tmp_path, retained):
    a = permit(tmp_path, retained)
    ctx = w.authorize(ROOT, a, execute_approved=True, simulation=True)
    p = ctx["parent"]
    assert [v["valid"] for v in p["retained_ratings"]] == [False, False, True, False]
    assert [v["http_status"] for v in p["retained_envelopes"]] == [400, 200, 200, 400]
    assert len(p["missing_provenance"]) == 2
    assert p["invalid_model_response_provenance"]["logical_request_id"] == p["retained_ratings"][1]["request_id"]
    jobs = w.expected_jobs(ctx, p["batch"])
    assert len(jobs) == 101
    assert not set(p["retained_logical_request_ids"]) & {j["method_request_id"] for j in jobs}
    assert all(j["wire"]["method"] == "POST" for j in jobs)


@pytest.mark.parametrize(
    "fault",
    [
        "prior",
        "cap",
        "allocation",
        "metadata",
        "missing",
        "human",
        "agent",
        "publication",
        "W01",
        "old-release",
        "paid",
        "sharing",
    ],
)
def test_scope_changes_denied_before_any_IO(tmp_path, retained, fault):
    a = permit(tmp_path, retained)
    if fault == "prior":
        a["prior_requests"] = 0
    elif fault == "cap":
        a["maximum_cumulative_requests"] = 589
    elif fault == "allocation":
        a["maximum_requests"]["calibration"] = 105
    elif fault == "metadata":
        a["permissions"]["metadata"] = True
    elif fault == "missing":
        a["retained_two_HTTP_failures_and_unmodified_model_response_confirmed"] = False
    elif fault == "human":
        a["human_attestation"] = 1
    elif fault == "agent":
        a["actor_type"] = "AGENT"
    elif fault == "publication":
        a["permissions"]["publication"] = True
    elif fault == "W01":
        a["permissions"]["W01"] = True
    elif fault == "old-release":
        a["release_sha256"] = old.load_plan(ROOT)["lock"]["release_sha256"]
    elif fault == "paid":
        a["Gemini_existing_paid_project_confirmed"] = False
    elif fault == "sharing":
        a["rights_cleared_evaluation_only_and_content_screening_confirmed"] = False
    calls = []
    with pytest.raises(ValidationError):
        w.run(ROOT, a, execute_approved=True, simulation_transport=transport(calls))
    assert not calls and not (tmp_path / "continue/RUN_STARTED.json").exists()


def test_fixture_never_authorizes_real_HTTP(tmp_path, retained):
    with pytest.raises(ValidationError):
        w.run(ROOT, permit(tmp_path, retained), execute_approved=True)


def test_original_72_hour_clock_not_reset(tmp_path, retained):
    a = permit(tmp_path, retained)
    a["start_before"] = (w.stamp(a["approved_at"]) + timedelta(hours=168)).isoformat()
    started = w.stamp(
        json.loads((retained["root"] / "RUN_STARTED.json").read_text("utf-8"))["started_at"]
    )
    with pytest.raises(ValidationError, match="original W0 72-hour"):
        w.authorize(
            ROOT, a, execute_approved=True, simulation=True, now=started + timedelta(hours=73)
        )


def test_no_metadata_or_retained_slot_resend_or_premature_collection(tmp_path, retained):
    a = permit(tmp_path, retained)
    ctx = w.authorize(ROOT, a, execute_approved=True, simulation=True)
    calls = []
    session = w.Session(
        ctx,
        dict.fromkeys(w.KEY_NAMES, "fixture-only-key-not-real"),
        transport=transport(calls),
        sleep=lambda _: None,
    )
    try:
        for logical in ctx["parent"]["batch"]["requests"][:4]:
            attempted = w.judge_job(logical, "calibration")
            with pytest.raises(ValidationError, match="cannot be resent"):
                session.exchange(attempted)
        for job in (
            w.fixed_jobs(ctx["plan"], "metadata")[0],
            w.fixed_jobs(ctx["plan"], "collection")[0],
        ):
            with pytest.raises(ValidationError):
                session.exchange(job)
        assert calls == [] and session.ledger.summary()["cumulative_requests"] == 37
    finally:
        session.close()


def test_new_HTTP_failure_is_not_auto_converted_to_missing_or_retried(tmp_path, retained):
    a = permit(tmp_path, retained)
    calls = []
    with pytest.raises(ValidationError, match="HTTP/transport/format"):
        w.run(
            ROOT,
            a,
            execute_approved=True,
            simulation_transport=transport(calls, failure="http"),
            sleep=lambda _: None,
        )
    assert len(calls) == 1
    ctx = w.authorize(ROOT, a, execute_approved=True, simulation=True, continuation=True)
    assert w.ledger.audited_summary(ctx)["cumulative_requests"] == 38
    with pytest.raises(ValidationError):
        w.run(
            ROOT,
            a,
            execute_approved=True,
            simulation_transport=transport(calls),
            sleep=lambda _: None,
        )
    assert len(calls) == 1 and not (tmp_path / "continue/CALIBRATION_STAGE_FINISHED.json").exists()


def test_cumulative_caps_do_not_depend_on_mutable_summary():
    w.ledger.Ledger._caps(w.COUNTS)
    for phase in w.COUNTS:
        counts = dict(w.COUNTS)
        counts[phase] += 1
        with pytest.raises(ValidationError):
            w.ledger.Ledger._caps(counts)


def test_complete_551_request_continuation_preserves_two_failures_and_invalid_model_answer(tmp_path, retained):
    a = permit(tmp_path, retained)
    saved = filemap(retained["root"])
    calls = []
    stage = w.run(
        ROOT, a, execute_approved=True, simulation_transport=transport(calls), sleep=lambda _: None
    )
    assert len(calls) == 101 and stage["real_API_calls"] == 0
    assert stage["cumulative_accounting"]["cumulative_requests"] == 138
    directory = tmp_path / "continue"
    result = json.loads((directory / "calibration-result.json").read_text("utf-8"))
    assert len(result["ratings"]) == 105 and sum(r["valid"] for r in result["ratings"]) == 102
    invalid = [r for r in result["ratings"] if not r["valid"]]
    assert (
        len(invalid) == 3
        and all(v["judgment"] is None for v in invalid)
        and [v["raw_envelope"]["http_status"] for v in invalid] == [400, 200, 400]
    )
    quality = result["aggregation"]["quality_report"]
    assert quality["valid_rating_fraction"] == 102 / 105
    assert quality["technical_calibration_guards_passed"] is True
    with pytest.raises((OSError, ValueError)):
        review.continue_after_calibration(
            ROOT,
            a,
            execute_approved=True,
            simulation_transport=transport(calls),
            sleep=lambda _: None,
        )
    assert len(calls) == 101
    named = review.record_agent_review(
        ROOT,
        a,
        reviewer="synthetic AGENT",
        review_note="Fixture-only technical review; no real validity claim",
        simulation=True,
    )
    assert named["reviewer_type"] == "AGENT" and named["retained_technical_missing_count"] == 2
    assert named["retained_invalid_model_response_count"] == 1
    final = review.continue_after_calibration(
        ROOT, a, execute_approved=True, simulation_transport=transport(calls), sleep=lambda _: None
    )
    assert len(calls) == 551 and all(c.method == "POST" for c in calls)
    assert (
        final["counts"] == w.COUNTS and final["cumulative_accounting"]["cumulative_requests"] == 588
    )
    assert final["cumulative_accounting"]["cumulative_counts"] == {
        "metadata": 9,
        "smoke": 3,
        "qualification": 21,
        "calibration": 105,
        "collection": 150,
        "main": 300,
    }
    assert final["fresh_answers"] == 150 and final["main_ratings"] == 300
    assert final["retained_technical_missing"] == 2 and final["pilot_passed"] is False
    assert (
        final["real_API_calls"] == 0
        and not final["publication_authorized"]
        and not final["W01_authorized"]
    )
    assert filemap(retained["root"]) == saved
    ctx = w.authorize(ROOT, a, execute_approved=True, simulation=True, continuation=True)
    retained_ids = set(ctx["parent"]["retained_logical_request_ids"])
    for path in directory.glob("L0_raw/*/*/request.json"):
        job = json.loads(path.read_text("utf-8"))
        assert job.get("method_request_id") not in retained_ids
    with pytest.raises(ValidationError):
        review.continue_after_calibration(
            ROOT,
            a,
            execute_approved=True,
            simulation_transport=transport(calls),
            sleep=lambda _: None,
        )
    assert len(calls) == 551

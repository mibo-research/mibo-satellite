from __future__ import annotations
import copy
import json
from datetime import UTC, datetime, timedelta
from pathlib import Path
import httpx
import pytest
from test_live_w0_v15 import (
    retained as held55, permit as permit15, prior40, previous_retained,
    ancestor_retained, deterministic_synthetic_salt, alter_json_response,
)
from test_live_w0_v11 import transport
from miboe import live_w0_v15 as old, live_w0_review_v15 as old_review, live_w0_v16 as w
from miboe.errors import ValidationError
from miboe.util import canonical_json_bytes,sha256_file,write_immutable

ROOT = Path(__file__).resolve().parents[1]

def filemap(root,exclude=()):
    return {p.relative_to(root).as_posix():sha256_file(p) for p in root.rglob("*")
            if p.is_file() and p.relative_to(root).as_posix() not in exclude}

@pytest.fixture(scope="module")
def retained(tmp_path_factory,held55):
    a = permit15(tmp_path_factory.mktemp("v16-parent"),held55)
    calls, source_calls = [], []
    normal = transport(calls)
    def respond(request):
        body = json.loads(request.content)
        judge = any(k in body for k in ("system","instructions","systemInstruction"))
        if not judge:
            source_calls.append(request)
            if len(source_calls) == 126:
                calls.append(request)
                raise httpx.ReadTimeout("synthetic no response; not a real timeout")
        return normal.handle_request(request)
    mock = httpx.MockTransport(respond)
    old.run(ROOT,a,execute_approved=True,simulation_transport=mock,sleep=lambda _:None)
    old_review.record_agent_review(ROOT,a,reviewer="fixture AGENT",
        review_note="synthetic primary calibration technical review",simulation=True)
    with pytest.raises(ValidationError,match="HTTP/transport/format"):
        old_review.continue_after_calibration(ROOT,a,execute_approved=True,
            simulation_transport=mock,sleep=lambda _:None)
    assert len(calls) == 209 and len(source_calls) == 126
    path, accounting = Path(a["execution_root"]),Path(a["accounting_root"])
    write_immutable(path/"STOP",b"synthetic source transport failure; do not overwrite\n")
    base = json.loads((accounting/"BASELINE.json").read_text("utf-8"))
    review = json.loads((path/"calibration-agent-review.json").read_text("utf-8"))
    failed = old.fixed_jobs(old.load_plan(ROOT),"collection")[125]
    assert failed["provider"] == "anthropic" and failed["source"]["item_id"] == "E2-10"
    return {"root":path,"accounting":accounting,"baseline":base,"files":filemap(path),
        "governance":base["governance_carry_forward"],"failed_job":failed,
        "review":{"file_sha256":sha256_file(path/"calibration-agent-review.json"),
                  "review_sha256":review["review_sha256"]}}

def permit(tmp_path,retained):
    destination,accounting = tmp_path/"continue",tmp_path/"accounting"
    p = w.load_plan(ROOT)
    b = w.e.sealed({"plan_id":p["config"]["plan_id"],"synthetic_test_only":True,
        "prior_counts":w.ledger.PRIOR,"new_request_caps":w.COUNTS,
        "maximum_new_requests":325,"maximum_cumulative_requests":589,
        "new_execution_root":str(destination),"accounting_root":str(accounting),
        "historical_run":{"root":str(retained["root"]),"file_sha256":retained["files"]},
        "other_preserved_evidence":[retained["baseline"]["historical_run"],
            *retained["baseline"]["other_preserved_evidence"],
            {"root":str(retained["accounting"]),"file_sha256":filemap(retained["accounting"],("worker.lease",))}],
        "governance_carry_forward":retained["governance"],
        "authorized_retry_of_job_sha256":retained["failed_job"]["job_sha256"],
        "carried_calibration_review":retained["review"]},"baseline_sha256")
    write_immutable(accounting/"BASELINE.json",canonical_json_bytes(b)+b"\n")
    (accounting/"claims").mkdir()
    (accounting/"outcomes").mkdir()
    a = w.authorization_draft(ROOT)
    now = datetime.now(UTC)
    a.update(status="FINAL_W0_EXECUTION_AUTHORIZATION",fixture_only=True,human_attestation=True,
        source_instruction="SYNTHETIC FIXTURE NOT REAL AUTHORITY",source_evidence="offline fixture only",
        approved_at=now.isoformat(),start_before=(now+timedelta(hours=1)).isoformat(),
        execution_root=str(destination),accounting_root=str(accounting),
        baseline_file_sha256=sha256_file(accounting/"BASELINE.json"),
        authorized_retry_of_job_sha256=retained["failed_job"]["job_sha256"],
        governance={"status":"CARRIED_FORWARD_NO_NEW_SIGNATURE",
            "source_authorization_file_sha256":retained["governance"]["source_authorization_file_sha256"]})
    for flag in ("observation","judge","delegated_agent_calibration_review"):
        a["permissions"][flag] = True
    prepared = {"status":"PREPARED_NOT_AUTHORIZED","plan_id":a["plan_id"],
        "plan_sha256":a["plan_sha256"],"release_sha256":a["release_sha256"],
        "baseline_file_sha256":a["baseline_file_sha256"],"execution_root":str(destination),
        "accounting_root":str(accounting),"prior_requests":264,"maximum_new_requests":325,
        "maximum_cumulative_requests":589,"API_execution_authorized":False,"synthetic_test_only":True}
    write_immutable(destination/"PREPARATION.json",canonical_json_bytes(prepared)+b"\n")
    a["preparation_file_sha256"] = sha256_file(destination/"PREPARATION.json")
    return a

def test_draft_denies_before_key_or_client(monkeypatch):
    monkeypatch.setattr(w,"resolve_credentials",lambda *a,**k:pytest.fail("key read"))
    monkeypatch.setattr(httpx,"Client",lambda *a,**k:pytest.fail("client creation"))
    a = w.authorization_draft(ROOT)
    assert not any(a["permissions"].values()) and not a["human_attestation"] and "records" not in a
    with pytest.raises(ValidationError):
        w.run(ROOT,a,execute_approved=True)

def test_fixture_cannot_authorize_real_HTTP(tmp_path,retained):
    with pytest.raises(ValidationError):
        w.run(ROOT,permit(tmp_path,retained),execute_approved=True)

def test_exact125_carried_and_only_selected_retry_wire_identical(tmp_path,retained):
    a = permit(tmp_path,retained)
    ctx = w.authorize(ROOT,a,execute_approved=True,simulation=True)
    p = ctx["parent"]
    assert len(p["source_records"]) == 125 and len(p["remaining_source_jobs"]) == 25
    first = p["remaining_source_jobs"][0]
    assert first["wire"] == retained["failed_job"]["wire"]
    assert first["source"] == retained["failed_job"]["source"]
    assert first["job_sha256"] != retained["failed_job"]["job_sha256"]
    assert first["authorized_retry_of_job_sha256"] == retained["failed_job"]["job_sha256"]
    original = old.fixed_jobs(ctx["plan"],"collection")
    assert p["remaining_source_jobs"][1:] == original[126:]
    assert [x["valid"] for x in p["original22_legacy_ratings"]] == [
        False,False,True,False,True,True,False,False,False,True,True,True,True,False,True,True,False,True,False,False,True,True]
    assert p["calibration_result"]["aggregation"]["primary_quality_report"]["primary_calibration_guards_passed"]

@pytest.mark.parametrize("fault",["prior","cap","retry_count","retry_target","timeout","publication","W01","Core","human","release"])
def test_bad_scope_fails_before_HTTP(tmp_path,retained,fault):
    a = permit(tmp_path,retained)
    if fault == "prior": a["prior_requests"] = 263
    elif fault == "cap": a["maximum_cumulative_requests"] = 590
    elif fault == "retry_count": a["explicit_source_replay_limit"] = 2
    elif fault == "retry_target": a["authorized_retry_of_job_sha256"] = "wrong"
    elif fault == "timeout": a["transport_timeout_seconds"] = 0
    elif fault in ("publication","W01"): a["permissions"][fault] = True
    elif fault == "Core": a["Core_restart_authorized"] = True
    elif fault == "human": a["human_attestation"] = 1
    else: a["release_sha256"] = "wrong"
    calls = []
    with pytest.raises(ValidationError):
        w.run(ROOT,a,execute_approved=True,simulation_transport=transport(calls))
    assert not calls

def test_successful_old_sources_calibration_and_premature_main_cannot_send(tmp_path,retained):
    a = permit(tmp_path,retained)
    ctx = w.authorize(ROOT,a,execute_approved=True,simulation=True)
    calls = []
    session = w.Session(ctx,dict.fromkeys(w.KEY_NAMES,"fixture-only"),
        transport=transport(calls),sleep=lambda _:None)
    try:
        for job in old.fixed_jobs(ctx["plan"],"collection")[:126]:
            with pytest.raises(ValidationError):
                session.exchange(job)
        batch = json.loads((retained["root"]/"calibration-batch.json").read_text("utf-8"))
        for job in (old.fixed_jobs(ctx["plan"],"metadata")[0],
                    old.judge_job(batch["requests"][0],"main"),
                    old.judge_job(batch["requests"][0],"calibration"),
                    old.fixed_jobs(ctx["plan"],"collection")[126]):
            with pytest.raises(ValidationError):
                session.exchange(job)
        assert not calls and session.ledger.summary()["cumulative_requests"] == 264
    finally:
        session.close()

def test_read_timeout_is_classified_consumes_one_and_no_retry(tmp_path,retained):
    a,calls = permit(tmp_path,retained),[]
    def respond(request):
        calls.append(request)
        assert request.extensions["timeout"] == dict.fromkeys(("connect","read","write","pool"),600.0)
        raise httpx.ReadTimeout("fixture")
    with pytest.raises(ValidationError,match="HTTP/transport/format"):
        w.run(ROOT,a,execute_approved=True,simulation_transport=httpx.MockTransport(respond),sleep=lambda _:None)
    assert len(calls) == 1
    response = json.loads(next(Path(a["execution_root"]).glob("L0_raw/collection/*/response.json")).read_text("utf-8"))
    assert response["transport_error_class"] == "READ_TIMEOUT" and response["http_status"] == 0
    assert response["response_body"] is None and response["error_code"] == "TRANSPORT_FAILURE_NO_RETRY"
    outcome = json.loads((Path(a["accounting_root"])/"outcomes/000001.json").read_text("utf-8"))
    assert outcome["outcome_class"] == "TECHNICAL_FAILURE"
    with pytest.raises(ValidationError):
        w.run(ROOT,a,execute_approved=True,simulation_transport=transport(calls),sleep=lambda _:None)
    assert len(calls) == 1

def test_original_window_and_after_pacing_gate(tmp_path,retained,monkeypatch):
    a = permit(tmp_path,retained)
    ctx = w.authorize(ROOT,a,execute_approved=True,simulation=True)
    with pytest.raises(ValidationError,match="original W0 72-hour"):
        w.authorize(ROOT,a,execute_approved=True,simulation=True,now=ctx["started_at"]+timedelta(hours=73))
    calls = []
    session = w.Session(ctx,dict.fromkeys(w.KEY_NAMES,"fixture-only"),transport=transport(calls),sleep=lambda _:None)
    deadline = session.started+timedelta(hours=72)
    class Clock(datetime):
        current = deadline-timedelta(milliseconds=100)
        @classmethod
        def now(cls,tz=None): return cls.current
    def cross(_): Clock.current = deadline+timedelta(milliseconds=100)
    session.sleep,session.last_call = cross,w.time.monotonic()
    monkeypatch.setattr(w,"datetime",Clock)
    try:
        with pytest.raises(ValidationError,match="expired after pacing"):
            session.exchange(ctx["parent"]["remaining_source_jobs"][0])
        assert not calls and session.ledger.summary()["cumulative_requests"] == 264
    finally:
        session.close()

def test_new_caps_and_no_counter_reset():
    w.ledger.Ledger._caps(w.COUNTS)
    for phase in w.COUNTS:
        counts = dict(w.COUNTS)
        counts[phase] += 1
        with pytest.raises(ValidationError): w.ledger.Ledger._caps(counts)
    with pytest.raises(ValidationError): w.ledger.Ledger._caps({"collection":25,"main":299,"calibration":0})

def test_complete_325_no_new_calibration_preserves264_and_primary_auxiliary_separation(tmp_path,retained):
    a,calls = permit(tmp_path,retained),[]
    before = filemap(retained["root"])
    normal = transport(calls)
    def respond(request):
        assert request.extensions["timeout"]["read"] == 600.0
        response = normal.handle_request(request)
        body = json.loads(request.content)
        if any(k in body for k in ("system","instructions","systemInstruction")):
            provider = {"api.anthropic.com":"anthropic","api.openai.com":"openai","generativelanguage.googleapis.com":"gemini"}[request.url.host]
            return alter_json_response(response,provider,{"REFUSAL_TYPE":None})
        return response
    result = w.run(ROOT,a,execute_approved=True,simulation_transport=httpx.MockTransport(respond),sleep=lambda _:None)
    assert len(calls) == 325 and all(q.method == "POST" for q in calls)
    assert calls[0].content == canonical_json_bytes(retained["failed_job"]["wire"]["body"])
    assert result["counts"] == {"collection":25,"main":300}
    assert result["cumulative_accounting"]["cumulative_requests"] == 589
    assert result["cumulative_accounting"]["cumulative_counts"] == {
        "metadata":9,"smoke":3,"qualification":21,"calibration":105,"collection":151,"main":300}
    assert result["fresh_answers"] == 150 and result["explicit_failed_source_replays"] == 1
    assert not result["pilot_passed"] and not result["W01_authorized"] and result["real_API_calls"] == 0
    assert filemap(retained["root"]) == before
    directory = Path(a["execution_root"])
    assert len(list((directory/"collection-records").glob("*.json"))) == 25
    assert not (directory/"calibration-batch.json").exists()
    main = json.loads((directory/"main-result.json").read_text("utf-8"))
    assert len(main["ratings"]) == 300 and all(x["primary"]["valid"] for x in main["ratings"])
    assert not any(x["legacy_full_judgment_valid"] for x in main["ratings"])
    assert main["aggregation"]["primary_quality_report"]["primary_numeric_quality_checks_passed"]
    assert all(x["auxiliary_consensus"]["REFUSAL_TYPE"]["status"] == "NOT_JOINTLY_AVAILABLE"
               for x in main["aggregation"]["primary_responses"])
    with pytest.raises(ValidationError):
        w.run(ROOT,a,execute_approved=True,simulation_transport=transport(calls),sleep=lambda _:None)
    assert len(calls) == 325

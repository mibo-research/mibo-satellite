from __future__ import annotations

import copy
import json
from pathlib import Path

import pytest
from test_reciprocal_scoring import envelope, judgment, row
from miboe import reciprocal as r, reciprocal_engine as e, validity_v15 as v
from miboe.errors import ValidationError

ROOT = Path(__file__).resolve().parents[1]


@pytest.fixture
def case():
    plan = r.load_plan(ROOT)
    observation = row(plan)
    batch = r.build_batch(ROOT, [observation], {observation["observation_id_blind"]: "openai"})
    return plan, observation, batch


def views(case, modify=lambda j: None):
    plan, observation, batch = case
    envelopes = []
    for q in batch["requests"]:
        j = judgment(plan, observation)
        modify(j)
        envelopes.append(envelope(q, j))
    original = copy.deepcopy(envelopes)
    out = v.import_many(ROOT, batch, envelopes)
    assert envelopes == original
    assert [x["legacy_full_rating"] for x in out] == r.import_many(ROOT, batch, envelopes)
    return out


def test_full_valid_primary_pair_matches_frozen_result(case):
    out = views(case)
    assert all(x["primary"]["valid"] and x["legacy_full_judgment_valid"] for x in out)
    result = v.aggregate(ROOT, case[2], out)
    frozen = result["legacy_full_aggregation"]["responses"][0]
    for key in ("status", "numeric_pair", "panel_estimate", "valid_ratings"):
        assert result["primary_responses"][0][key] == frozen[key]
    assert len(result["all_auxiliary_fields_retained"]) == 45


def test_old_invalid_null_is_not_repaired_or_relabelled(case):
    def modify(j):
        j["codes"]["REFUSAL_TYPE"] = None
    out = views(case, modify)
    for view in out:
        assert view["primary"]["valid"] and not view["legacy_full_judgment_valid"]
        assert view["legacy_full_rating"]["valid"] is False
        assert view["legacy_full_rating"]["judgment"] is None
        assert view["parsed_result"]["codes"]["REFUSAL_TYPE"] is None
        state = view["auxiliary"]["codes"]["REFUSAL_TYPE"]
        assert state["raw_value"] is None and not state["valid"] and not state["available"]
        assert view["auxiliary"]["codes"]["REFUSAL_PRESENT"]["raw_value"] is False
        assert view["auxiliary"]["codes"]["REFUSAL_PRESENT"]["available"] is True
        assert view["auxiliary"]["codes"]["VOCABULARY_ADAPTATION"]["raw_value"] == 0
        assert view["auxiliary"]["codes"]["VOCABULARY_ADAPTATION"]["available"] is True
    combined = v.aggregate(ROOT, case[2], out)["primary_responses"][0]
    assert combined["status"] == "PANEL_ESTIMATE"
    assert combined["auxiliary_consensus"]["REFUSAL_TYPE"]["status"] == "NOT_JOINTLY_AVAILABLE"
    assert combined["auxiliary_consensus"]["REFUSAL_PRESENT"]["value"] is False


@pytest.mark.parametrize("fault", ["score", "anchor", "quote", "nr", "id"])
def test_primary_faults_are_not_excused_by_auxiliary_separation(case, fault):
    def modify(j):
        if fault == "score":
            j["primary_score"] = 99
        elif fault == "anchor":
            j["anchor_reference"] = "E1-01:0"
        elif fault == "quote":
            j["evidence"] = ["invented quote not in visible response"]
        elif fault == "nr":
            j.update(status="NR", primary_score=None, anchor_reference=None, nr_reason="")
        elif fault == "id":
            j["observation_id_blind"] = "B-" + "e" * 32
    for x in views(case, modify):
        assert not x["primary"]["valid"] and x["primary"]["judgment"] is None
        if fault == "id":
            assert all(not s["valid"] for s in x["auxiliary"]["codes"].values())
        else:
            assert x["auxiliary"]["codes"]["REFUSAL_PRESENT"]["valid"]


@pytest.mark.parametrize("fault", ["http", "model", "finish", "fenced", "duplicate", "not-object"])
def test_transport_and_json_failures_never_produce_a_score(case, fault):
    plan, observation, batch = case
    q = batch["requests"][0]
    raw = envelope(q, judgment(plan, observation))
    # The assigned J01 uses Anthropic for this source.
    assert q["provider"] == "anthropic"
    body = raw["response_body"]
    if fault == "http":
        raw["http_status"] = 400
    elif fault == "model":
        body["model"] = "unexpected"
    elif fault == "finish":
        body["stop_reason"] = "max_tokens"
    else:
        text = body["content"][0]["text"]
        body["content"][0]["text"] = {
            "fenced": "```json\n" + text + "\n```",
            "duplicate": '{"status":"NR","status":"RATEABLE"}',
            "not-object": "[]",
        }[fault]
    out = v.import_many(ROOT, batch, [raw])[0]
    assert not out["primary"]["valid"]
    assert out["primary"]["judgment"] is None
    assert not out["shared_identity_valid"]


def test_absent_auxiliary_is_explicit_not_filled(case):
    out = views(case, lambda j: j.pop("codes"))
    for x in out:
        assert x["primary"]["valid"] and not x["legacy_full_judgment_valid"]
        assert x["auxiliary"]["available_codes"] == 0
        assert len(x["auxiliary"]["codes"]) == 45
        assert all(not f["present"] and "raw_value" not in f for f in x["auxiliary"]["codes"].values())


def test_NR_remains_NR_and_mixed_pair_unresolved(case):
    def nr(j):
        j.update(status="NR", primary_score=None, anchor_reference=None, evidence=[], nr_reason="insufficient visible text")
    a, b = views(case, nr)
    assert a["primary"]["valid"] and a["primary"]["judgment"]["primary_score"] is None
    assert v.primary_pair({"J01": a, "J02": b})["status"] == "NR"
    b = views(case)[1]
    assert v.primary_pair({"J01": a, "J02": b})["status"] == "UNRESOLVED_RATEABILITY"


@pytest.mark.parametrize("domain", ["E2-01", "E4-01"])
def test_conditional_code_contracts_and_no_arithmetic_imputation(domain):
    plan = r.load_plan(ROOT)
    observation = row(plan, domain)
    batch = r.build_batch(ROOT, [observation], {observation["observation_id_blind"]: "openai"})
    def conflict(j):
        if domain.startswith("E2"):
            j["codes"]["E2_SUPPORT_QUALITY"] = None
        else:
            j["codes"].update(MODEL_SCORE_PARSEABLE=True, MODEL_ASSIGNED_ACCURACY_SCORE=1,
                MODEL_ASSIGNED_REASONING_SCORE=1, MODEL_ASSIGNED_EXPLANATION_SCORE=1, MODEL_ASSIGNED_TOTAL_SCORE=9)
    out = views((plan, observation, batch), conflict)
    key = "E2_SUPPORT_QUALITY" if domain.startswith("E2") else "MODEL_ASSIGNED_TOTAL_SCORE"
    assert all(x["primary"]["valid"] and not x["auxiliary"]["codes"][key]["valid"] for x in out)
    if domain.startswith("E4"):
        assert out[0]["auxiliary"]["codes"][key]["raw_value"] == 9


@pytest.mark.parametrize("conflict,keys", [
    ({"REFUSAL_PRESENT": False, "REFUSAL_TYPE": "R1"}, ["REFUSAL_PRESENT", "REFUSAL_TYPE"]),
    ({"SOURCE_FABRICATED": True, "SOURCE_FABRICATION_SUSPECTED": True}, ["SOURCE_FABRICATED", "SOURCE_FABRICATION_SUSPECTED"]),
    ({"EMERGENT_BEHAVIOR": True, "EMERGENT_BEHAVIOR_NOTE": None}, ["EMERGENT_BEHAVIOR_NOTE"]),
])
def test_auxiliary_conflicts_local_and_visible(case, conflict, keys):
    out = views(case, lambda j: j["codes"].update(conflict))
    for x in out:
        assert x["primary"]["valid"]
        assert all(not x["auxiliary"]["codes"][k]["valid"] for k in keys)


def test_accuracy_and_metadata_errors_do_not_rewrite_primary(case):
    out = views(case, lambda j: j.update(accuracy_status="ASSESSED", accuracy_code=None, identity_leakage="wrong"))
    assert all(x["primary"]["valid"] and not x["accuracy"]["accuracy_code"]["valid"] and not x["metadata"]["identity_leakage"]["valid"] for x in out)


def test_tampered_component_or_old_label_rejected(case):
    out = views(case)
    out[0]["primary"]["judgment"]["primary_score"] = 0
    out[0] = e.sealed({k:x for k,x in out[0].items() if k != "view_sha256"}, "view_sha256")
    with pytest.raises((ValueError, ValidationError)):
        v.aggregate(ROOT, case[2], out)

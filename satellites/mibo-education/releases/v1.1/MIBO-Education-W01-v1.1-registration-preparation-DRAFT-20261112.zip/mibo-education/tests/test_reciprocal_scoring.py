from __future__ import annotations

import ast
import json
from pathlib import Path

import pytest

from miboe import reciprocal as r
from miboe import reciprocal_engine as e
from miboe import scoring
from miboe.cli import main, parser

ROOT = Path(__file__).resolve().parents[1]


def row(plan, item="E1-01", n=1):
    return {
        "observation_id_blind": f"B-{n:032x}",
        "item_id": item,
        "exact_frozen_prompt": plan["legacy"]["items"][item].prompt,
        "visible_response": "合成工程試験専用の回答。実観測ではありません。",
    }


def judgment(plan, observation, score=3):
    properties = plan["legacy"]["schema"]["properties"]["codes"]["properties"]
    codes = {
        k: False if "boolean" in v["type"] else 0 if "integer" in v["type"] else None
        for k, v in properties.items()
    }
    codes.update(
        REFUSAL_TYPE="R0",
        EMERGENT_BEHAVIOR_NOTE=None,
        E2_SUPPORT_QUALITY=2 if observation["item_id"].startswith("E2-") else None,
        MODEL_SCORE_PARSEABLE=False if observation["item_id"].startswith("E4-") else None,
    )
    for key in codes:
        if key.startswith("MODEL_ASSIGNED_"):
            codes[key] = None
    return {
        "observation_id_blind": observation["observation_id_blind"],
        "item_id": observation["item_id"],
        "status": "RATEABLE",
        "primary_score": score,
        "accuracy_status": "UNVERIFIED",
        "accuracy_code": None,
        "codes": codes,
        "anchor_reference": f"{observation['item_id']}:{score}",
        "evidence": [observation["visible_response"][:20]],
        "nr_reason": None,
        "identity_leakage": False,
        "injection_attempt_observed": False,
    }


def envelope(request, result):
    text = e.canonical(result)
    model = request["requested_model"]
    if request["provider"] == "anthropic":
        body = {
            "model": model,
            "stop_reason": "end_turn",
            "content": [{"type": "text", "text": text}],
        }
    elif request["provider"] == "gemini":
        body = {
            "modelVersion": model,
            "candidates": [{"finishReason": "STOP", "content": {"parts": [{"text": text}]}}],
        }
    else:
        body = {
            "model": model,
            "status": "completed",
            "output": [
                {
                    "type": "message",
                    "role": "assistant",
                    "status": "completed",
                    "content": [{"type": "output_text", "text": text}],
                }
            ],
        }
    return {
        "request_id": request["request_id"],
        "http_status": 200,
        "received_at": "2026-11-07T12:00:00+09:00",
        "response_body": body,
    }


@pytest.fixture
def plan():
    return r.load_plan(ROOT)


@pytest.mark.parametrize("source,expected", list(e.PAIRS.items()))
def test_each_source_has_exactly_the_other_two_families(plan, source, expected):
    observation = row(plan)
    batch = r.build_batch(ROOT, [observation], {observation["observation_id_blind"]: source})
    assert [q["judge_id"] for q in batch["requests"]] == sorted(expected)
    assert all(q["provider"] != source for q in batch["requests"])
    assert len(batch["requests"]) == 2


def test_unknown_family_is_held_not_dropped_or_silently_routed(plan):
    observation = row(plan)
    with pytest.raises(ValueError, match="no approved reciprocal pair"):
        r.build_batch(ROOT, [observation], {observation["observation_id_blind"]: "perplexity"})


def test_routing_map_and_source_identity_never_enter_provider_body(plan):
    observation = row(plan)
    batch = r.build_batch(ROOT, [observation], {observation["observation_id_blind"]: "anthropic"})
    for request in batch["requests"]:
        body = request["body"]
        user = (
            body["contents"][0]["parts"][0]["text"]
            if request["provider"] == "gemini"
            else body["input"][0]["content"][0]["text"]
        )
        assert set(json.loads(user)["observation"]) == scoring.BLIND_FIELDS
        assert "private_source" not in user
        assert "anthropic" not in user
        assert "headers" not in request
        assert "tools" not in body
        if request["provider"] == "openai":
            assert body["store"] is False and body["stream"] is False
            assert body["text"]["format"]["strict"] is True
            assert "reasoning" not in body and "temperature" not in body


def test_calibration_is_full_common_bank_three_judges_and_no_expected_labels(plan):
    rows = r.calibration_rows(ROOT, salt="synthetic-calibration-salt-is-not-a-real-secret")
    batch = r.build_batch(ROOT, rows, {}, phase="calibration")
    assert len(rows) == 35 and len(batch["requests"]) == 105
    assert set(q["judge_id"] for q in batch["requests"]) == {"J01", "J02", "J03"}
    for request in batch["requests"]:
        assert "intended_anchor_level" not in e.canonical(request["body"])
        assert "case_id" not in e.canonical(request["body"])
        assert "CAL-E" not in e.canonical(request["body"])
    with pytest.raises(ValueError, match="intact"):
        r.build_batch(ROOT, rows[:-1], {}, phase="calibration")
    with pytest.raises(ValueError, match="not source-model"):
        r.build_batch(ROOT, rows, {rows[0]["observation_id_blind"]: "openai"}, phase="calibration")


@pytest.mark.parametrize("bad", ["identity", "finish", "http", "tool", "schema"])
def test_bad_openai_response_is_retained_invalid_without_repair(plan, bad):
    observation = row(plan)
    batch = r.build_batch(ROOT, [observation], {observation["observation_id_blind"]: "anthropic"})
    request = next(q for q in batch["requests"] if q["provider"] == "openai")
    response = envelope(request, judgment(plan, observation))
    if bad == "identity":
        response["response_body"]["model"] += "-unexpected-suffix"
    elif bad == "finish":
        response["response_body"]["status"] = "incomplete"
    elif bad == "http":
        response["http_status"] = 429
    elif bad == "tool":
        response["response_body"]["output"].append({"type": "function_call"})
    else:
        invalid = judgment(plan, observation)
        invalid["primary_score"] = True
        response = envelope(request, invalid)
    imported = r.import_many(ROOT, batch, [response])[0]
    assert imported["valid"] is False and imported["judgment"] is None
    assert imported["raw_envelope"] == response
    assert imported["error_code"] == "INVALID_FINISH_IDENTITY_OR_JUDGMENT"
    result = r.aggregate(ROOT, batch, [imported])
    assert result["responses"][0]["panel_estimate"] is None


def test_import_rejects_auth_headers_duplicate_attempts_and_tampered_batch(plan):
    observation = row(plan)
    batch = r.build_batch(ROOT, [observation], {observation["observation_id_blind"]: "openai"})
    response = envelope(batch["requests"][0], judgment(plan, observation))
    with pytest.raises(ValueError, match="duplicate"):
        r.import_many(ROOT, batch, [response, response])
    extra = {**response, "headers": {"authorization": "fixture-only"}}
    with pytest.raises(ValueError, match="allowlist"):
        r.import_many(ROOT, batch, [extra])
    batch["private_source_families_never_sent_to_judges"][observation["observation_id_blind"]] = (
        "gemini"
    )
    with pytest.raises(ValueError, match="hash mismatch"):
        r.import_many(ROOT, batch, [response])


def test_full_150_300_and_35_105_roundtrips_remain_synthetic_and_not_pilot_pass(plan):
    rows, sources = [], {}
    for n, slot in enumerate(plan["allocation"]["slots"], 1):
        observation = row(plan, slot["item_id"], n)
        rows.append(observation)
        sources[observation["observation_id_blind"]] = slot["source_family"]
    batch = r.build_batch(ROOT, rows, sources)
    assert len(batch["requests"]) == 300
    scores = {observation["observation_id_blind"]: n % 5 for n, observation in enumerate(rows)}
    responses = [
        envelope(
            q,
            judgment(
                plan,
                batch["observations"][q["observation_id_blind"]],
                scores[q["observation_id_blind"]],
            ),
        )
        for q in batch["requests"]
    ]
    imported = r.import_many(ROOT, batch, responses)
    assert all(i["valid"] for i in imported)
    result = r.aggregate(ROOT, batch, imported)
    assert result["quality_report"]["numeric_quality_checks_passed"] is True
    assert result["quality_report"]["pooled_two_rater_kappa"] is None
    assert result["pilot_passed"] is False
    assert result["human_validity_or_correctness_established"] is False
    assert result["cross_source_comparability_established"] is False
    assert result["scores_automatically_recalibrated"] is False
    common = r.calibration_rows(ROOT, salt="another-nonsecret-synthetic-calibration-salt")
    calibration = r.build_batch(ROOT, common, {}, phase="calibration")
    case_scores = {
        (c["item_id"], c["visible_response"]): c["intended_anchor_level_for_design_review_only"]
        for c in plan["bank"]["cases"]
    }
    responses = []
    for request in calibration["requests"]:
        observation = calibration["observations"][request["observation_id_blind"]]
        responses.append(
            envelope(
                request,
                judgment(
                    plan,
                    observation,
                    case_scores[observation["item_id"], observation["visible_response"]],
                ),
            )
        )
    ratings = r.import_many(ROOT, calibration, responses)
    assert len(ratings) == 105 and all(i["valid"] for i in ratings)
    report = r.aggregate(ROOT, calibration, ratings)
    assert report["quality_report"]["technical_calibration_guards_passed"] is True
    assert report["quality_report"]["common_calibration_clearance_granted"] is False
    assert report["pilot_passed"] is False


def test_constant_ratings_do_not_manufacture_kappa_or_calibration_success():
    metrics = e.agreement([[3, 3]] * 35)
    assert metrics["quadratic_weighted_kappa"] is None
    assert metrics["within_one_fraction"] == 1


def test_score_gap_missingness_and_NR_policy_preserved(plan):
    observation = row(plan)
    first, second = judgment(plan, observation, 1), judgment(plan, observation, 2)
    assert e.combine_pair({"J01": first, "J02": second})["panel_estimate"] == 1.5
    second["primary_score"] = 4
    assert e.combine_pair({"J01": first, "J02": second})["panel_estimate"] is None
    assert e.combine_pair({"J01": first, "J02": None})["panel_estimate"] is None
    first["status"] = second["status"] = "NR"
    first["primary_score"] = second["primary_score"] = None
    assert e.combine_pair({"J01": first, "J02": second})["status"] == "NR"


def test_reciprocal_cli_roundtrip_is_offline_and_prints_no_answer(tmp_path, plan, capsys):
    observation = row(plan)
    blind_input, mapping, output = (tmp_path / n for n in ("rows.jsonl", "map.json", "batch.json"))
    blind_input.write_text(e.canonical(observation) + "\n", encoding="utf-8")
    mapping.write_text(
        e.canonical({observation["observation_id_blind"]: "gemini"}), encoding="utf-8"
    )
    assert main(["reciprocal", "status", "--root", str(ROOT)]) == 0
    assert (
        main(
            [
                "reciprocal",
                "prepare",
                "--root",
                str(ROOT),
                "--blind-input",
                str(blind_input),
                "--source-map",
                str(mapping),
                "--output",
                str(output),
            ]
        )
        == 0
    )
    batch = scoring.read_json(output)
    response_path, ratings_path, aggregate_path = (
        tmp_path / n for n in ("responses.json", "ratings.json", "aggregate.json")
    )
    response_path.write_text(
        e.canonical([envelope(q, judgment(plan, observation)) for q in batch["requests"]]),
        encoding="utf-8",
    )
    assert (
        main(
            [
                "reciprocal",
                "import",
                "--root",
                str(ROOT),
                "--batch",
                str(output),
                "--responses",
                str(response_path),
                "--output",
                str(ratings_path),
            ]
        )
        == 0
    )
    assert (
        main(
            [
                "reciprocal",
                "aggregate",
                "--root",
                str(ROOT),
                "--batch",
                str(output),
                "--ratings",
                str(ratings_path),
                "--output",
                str(aggregate_path),
            ]
        )
        == 0
    )
    assert scoring.read_json(aggregate_path)["responses"][0]["panel_estimate"] == 3
    assert observation["visible_response"] not in capsys.readouterr().out
    with pytest.raises(SystemExit):
        parser().parse_args(["reciprocal", "execute"])


def test_legacy_lock_stays_valid_and_new_modules_have_no_network_or_key_lookup(plan):
    assert (
        plan["legacy"]["lock"]["lock_sha256"]
        == "802a4146dae3ccd5b10175a0790afee8e2ca8ef4b89964641d2b6a8d4ba0f101"
    )
    for filename in ("reciprocal.py", "reciprocal_engine.py"):
        tree = ast.parse((ROOT / "src/miboe" / filename).read_text(encoding="utf-8"))
        imports = [n.module or "" for n in ast.walk(tree) if isinstance(n, ast.ImportFrom)]
        imports += [a.name for n in ast.walk(tree) if isinstance(n, ast.Import) for a in n.names]
        assert not any(
            m.startswith(("os", "socket", "http", "urllib", "requests", "subprocess"))
            for m in imports
        )

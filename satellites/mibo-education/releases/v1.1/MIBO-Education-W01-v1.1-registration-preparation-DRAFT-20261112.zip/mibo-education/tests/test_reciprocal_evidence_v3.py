from __future__ import annotations
import copy
import json
from pathlib import Path
import pytest
from test_reciprocal_scoring import envelope, judgment, row
from miboe import reciprocal as old, reciprocal_engine as e, reciprocal_evidence_v3 as v3
from miboe import scoring, evidence_cli
from miboe.errors import ValidationError

ROOT = Path(__file__).resolve().parents[1]


@pytest.fixture
def case():
    p = old.load_plan(ROOT)
    observation = row(p)
    b = v3.build_batch(ROOT, [observation], {observation["observation_id_blind"]: "openai"})
    return p, observation, b


def candidate(p, observation, score=3):
    result = judgment(p, observation, score)
    del result["evidence"]
    result["evidence_ids"] = ["S000001"]
    return result


def import_case(case, change=lambda value: None):
    p, observation, batch = case
    envelopes = []
    for q in batch["requests"]:
        result = candidate(p, observation)
        change(result)
        envelopes.append(envelope(q, result))
    before = copy.deepcopy(envelopes)
    views = v3.import_many(ROOT, batch, envelopes)
    assert envelopes == before
    return views


def test_only_evidence_contract_changes_and_guards_match_parent(case):
    plan = v3.load_plan(ROOT)
    before = copy.deepcopy(case[0]["legacy"]["schema"])
    new = copy.deepcopy(plan["schema"])
    new["properties"]["evidence"] = before["properties"]["evidence"]
    del new["properties"]["evidence_ids"]
    new["required"] = ["evidence" if x == "evidence_ids" else x for x in new["required"]]
    assert new == before
    for k in ("judges", "source_pairs", "observations", "main_pilot_guards", "calibration", "aggregation"):
        assert e.digest(plan["config"][k]) == e.digest(case[0]["config"][k])


@pytest.mark.parametrize("source,pair", list(e.PAIRS.items()))
def test_nonself_routing_and_private_data_stay_out_of_requests(source, pair):
    p = old.load_plan(ROOT)
    observation = row(p)
    b = v3.build_batch(ROOT, [observation], {observation["observation_id_blind"]: source})
    assert [q["judge_id"] for q in b["requests"]] == pair
    assert all(q["provider"] != source for q in b["requests"])
    for q in b["requests"]:
        assert "private_source_families_never_sent_to_judges" not in e.canonical(q["body"])
        assert q["method_id"] == v3.METHOD


def test_projection_is_derived_and_raw_response_is_untouched(case):
    views = import_case(case)
    for view in views:
        assert view["primary"]["valid"] and view["full_record_valid_new_method"]
        assert view["parsed_model_result"]["evidence_ids"] == ["S000001"]
        assert "evidence" not in view["parsed_model_result"]
        assert view["internal_validation_projection"]["evidence"] == [case[1]["visible_response"]]
        assert view["source_reference_resolution"]["provenance"].startswith("DETERMINISTIC_SOURCE")
        assert not view["old_legacy_judgment_created_or_relabelled"]
        assert "raw_fields" not in view["primary"]


@pytest.mark.parametrize("bad", [["S999999"], [" S000001"], [False], [1], None, "S000001", ["S000001"]*7])
def test_invalid_reference_never_has_a_primary_score(case, bad):
    for v in import_case(case, lambda j: j.update(evidence_ids=bad)):
        assert not v["primary"]["valid"] and v["primary"]["judgment"] is None
        assert not v["full_record_valid_new_method"]
        assert v["parsed_model_result"]["evidence_ids"] == bad


def test_old_or_mixed_contract_rejected_without_conversion(case):
    for v in import_case(case, lambda j: j.update(evidence=["old quote"])):
        assert not v["primary"]["valid"] and v["source_reference_resolution"] is None
        assert v["parsed_model_result"]["evidence"] == ["old quote"]
    for v in import_case(case, lambda j: j.pop("evidence_ids")):
        assert not v["primary"]["valid"]
    old_batch = old.build_batch(ROOT, [case[1]], {case[1]["observation_id_blind"]: "openai"})
    with pytest.raises(ValueError): v3.import_many(ROOT, old_batch, [])
    with pytest.raises(ValueError): v3.import_many(ROOT, case[2], [envelope(old_batch["requests"][0], judgment(case[0], case[1]))])


@pytest.mark.parametrize("fault", ["score", "anchor", "id", "nr", "boolean-score"])
def test_primary_criteria_not_relaxed(case, fault):
    def change(j):
        if fault == "score": j["primary_score"] = 99
        if fault == "boolean-score": j["primary_score"] = True
        if fault == "anchor": j["anchor_reference"] = "E1-01:0"
        if fault == "id": j["observation_id_blind"] = "B-"+"e"*32
        if fault == "nr": j.update(status="NR", primary_score=None, anchor_reference=None, nr_reason="")
    assert all(not v["primary"]["valid"] for v in import_case(case, change))


def test_auxiliary_nulls_separate_without_null_to_zero_or_agreement(case):
    views = import_case(case, lambda j: j["codes"].update(REFUSAL_TYPE=None))
    for v in views:
        assert v["primary"]["valid"] and not v["full_record_valid_new_method"]
        assert v["auxiliary"]["codes"]["REFUSAL_TYPE"]["raw_value"] is None
        assert len(v["auxiliary"]["codes"]) == 45
    result = v3.aggregate(ROOT, case[2], views)
    assert result["primary_responses"][0]["auxiliary_consensus"]["REFUSAL_TYPE"]["status"] == "NOT_JOINTLY_AVAILABLE"
    assert result["primary_responses"][0]["panel_estimate"] == 3


@pytest.mark.parametrize("source", list(e.PAIRS))
@pytest.mark.parametrize("fault", ["http", "model", "finish", "fenced", "duplicate-json", "array"])
def test_transport_and_json_failures_preserve_raw_and_never_score(source, fault):
    p = old.load_plan(ROOT)
    observation = row(p)
    b = v3.build_batch(ROOT, [observation], {observation["observation_id_blind"]: source})
    for q in b["requests"]:
        result = candidate(p, observation)
        env = envelope(q, result)
        body = env["response_body"]
        if fault == "http": env["http_status"] = 429
        elif fault == "model": body["modelVersion" if q["provider"] == "gemini" else "model"] = "unexpected-model"
        elif fault == "finish":
            if q["provider"] == "anthropic": body["stop_reason"] = "max_tokens"
            elif q["provider"] == "gemini": body["candidates"][0]["finishReason"] = "MAX_TOKENS"
            else: body["status"] = "incomplete"
        else:
            text = {"fenced":"```json\n"+e.canonical(result)+"\n```", "duplicate-json":'{"status":"NR","status":"RATEABLE"}', "array":"[]"}[fault]
            if q["provider"] == "anthropic": body["content"][0]["text"] = text
            elif q["provider"] == "gemini": body["candidates"][0]["content"]["parts"][0]["text"] = text
            else: body["output"][0]["content"][0]["text"] = text
        before = copy.deepcopy(env)
        v = v3.import_many(ROOT, b, [env])[0]
        assert env == before and v["raw_envelope"] == before
        assert not v["primary"]["valid"] and v["primary"]["judgment"] is None


def test_batch_and_derived_view_tampering_rejected(case):
    b = copy.deepcopy(case[2])
    b["catalogs"][case[1]["observation_id_blind"]]["segments"][0]["text"] = "other"
    b = e.sealed({k:v for k,v in b.items() if k != "batch_sha256"}, "batch_sha256")
    with pytest.raises(ValueError): v3.validate_batch(ROOT, b)
    views = import_case(case)
    views[0]["primary"]["judgment"]["primary_score"] = 4
    views[0] = e.sealed({k:v for k,v in views[0].items() if k != "view_sha256"}, "view_sha256")
    with pytest.raises(ValueError): v3.aggregate(ROOT, case[2], views)


def test_duplicates_cross_batch_and_headers_rejected(case):
    q = case[2]["requests"][0]
    env = envelope(q, candidate(case[0], case[1]))
    with pytest.raises(ValueError): v3.import_many(ROOT, case[2], [env, env])
    env["headers"] = {"Authorization": "synthetic-never-a-real-key"}
    with pytest.raises(ValueError): v3.import_many(ROOT, case[2], [env])


def test_live_gate_closed_before_files_and_without_permit_flag(monkeypatch, capsys):
    monkeypatch.setattr(v3, "load_plan", lambda *a: pytest.fail("execute must not read plan or keys"))
    assert evidence_cli.main(["--root", "C:/not-a-real-project", "execute"]) == 1
    assert "no API call" in capsys.readouterr().out
    with pytest.raises(ValidationError): v3.assert_live_authorized(execute_approved=True, authorization={"API":True})


def test_wire_routes_and_native_enforcement_strength_unchanged():
    p = old.load_plan(ROOT)
    observations = [row(p, n=i+1) for i in range(3)]
    b = v3.build_batch(ROOT, observations, {r["observation_id_blind"]:s for r,s in zip(observations,e.PAIRS)})
    jobs = v3.wire_artifact(ROOT, b)["jobs"]
    assert len(jobs) == 6
    for j in jobs:
        body = j["wire"]["body"]
        assert "Authorization" not in e.canonical(body)
        if j["provider"] == "anthropic": assert "output_config" not in body and not j["binding"]["native_grammar_enforcement"]
        elif j["provider"] == "openai": assert body["store"] is False and body["text"]["format"]["strict"] is True
        else: assert "responseJsonSchema" in body["generationConfig"]
    assert not v3.status(ROOT)["API_calls_authorized"]


def test_long_lines_keep_original240_character_and_six_excerpt_limits():
    p = old.load_plan(ROOT)
    observation = row(p)
    observation["visible_response"] = "原"*601 + "\r\n終わり"
    b = v3.build_batch(ROOT, [observation], {observation["observation_id_blind"]: "openai"})
    catalog = b["catalogs"][observation["observation_id_blind"]]
    assert "".join(s["text"] for s in catalog["segments"]) == observation["visible_response"]
    assert all(len(s["text"]) <= 240 for s in catalog["segments"])
    views = v3.import_many(ROOT, b, [envelope(q, candidate(p, observation)) for q in b["requests"]])
    assert all(v["primary"]["valid"] and len(v["internal_validation_projection"]["evidence"][0]) == 240 for v in views)


def test_empty_completed_source_can_be_NR_without_invented_evidence():
    p = old.load_plan(ROOT)
    observation = row(p)
    observation["visible_response"] = ""
    b = v3.build_batch(ROOT, [observation], {observation["observation_id_blind"]: "openai"})
    result = candidate(p, observation)
    result.update(status="NR", primary_score=None, anchor_reference=None, nr_reason="No observable behavior in empty completed response", evidence_ids=[])
    views = v3.import_many(ROOT, b, [envelope(q, result) for q in b["requests"]])
    assert all(v["primary"]["valid"] for v in views)
    out = v3.aggregate(ROOT, b, views)
    assert out["primary_responses"][0]["status"] == "NR"
    assert out["primary_responses"][0]["panel_estimate"] is None


@pytest.mark.parametrize("phase", ["main", "calibration"])
def test_full_functional_pipeline_is_synthetic_not_model_qualification(phase):
    p = old.load_plan(ROOT)
    if phase == "main":
        observations = [row(p, item=s["item_id"], n=i+1) for i,s in enumerate(p["allocation"]["slots"])]
        families = {r["observation_id_blind"]: s["source_family"] for r,s in zip(observations,p["allocation"]["slots"])}
        expected = 300
    else:
        observations = old.calibration_rows(ROOT, salt="synthetic-evidence-v3-rehearsal-salt-000000")
        families, expected = {}, 105
    scores = {r["observation_id_blind"]: i%5 for i,r in enumerate(observations)}
    b = v3.build_batch(ROOT, observations, families, phase=phase)
    assert len(b["requests"]) == expected
    assert len(v3.wire_artifact(ROOT, b)["jobs"]) == expected
    envs = [envelope(q, candidate(p, b["observations"][q["observation_id_blind"]], scores[q["observation_id_blind"]])) for q in b["requests"]]
    views = v3.import_many(ROOT, b, envs)
    assert len(views) == expected and all(v["primary"]["valid"] for v in views)
    out = v3.aggregate(ROOT, b, views)
    report = out["primary_quality_report"]
    assert report["numeric_quality_checks_passed" if phase == "main" else "technical_calibration_guards_passed"]
    assert all(len(fields) == 45 for fields in out["auxiliary_coverage"].values())
    assert out["pilot_passed"] is False and out["calibration_clearance_granted"] is False
    assert out["engineering_only_not_independent_acceptance"] is True


def test_cli_prepare_wire_import_aggregate_and_private_destination(case, tmp_path, capsys):
    p, observation, _ = case
    def fixture(name, value):
        path = tmp_path/name
        path.write_text(e.canonical(value), encoding="utf-8")
        return str(path)
    rows = fixture("rows.json", [observation])
    families = fixture("families.json", {observation["observation_id_blind"]: "openai"})
    batch_path, wire_path, ratings_path, aggregate_path = [str(tmp_path/n) for n in ("batch.json", "wire.json", "ratings.json", "aggregate.json")]
    prefix = ["--root", str(ROOT)]
    assert evidence_cli.main(prefix+["status"]) == 0
    assert evidence_cli.main(prefix+["prepare", "--blind-input", rows, "--source-map", families, "--output", batch_path]) == 0
    batch = scoring.read_json(Path(batch_path))
    responses = fixture("responses.json", [envelope(q,candidate(p,observation)) for q in batch["requests"]])
    assert evidence_cli.main(prefix+["wire", "--batch", batch_path, "--output", wire_path]) == 0
    assert evidence_cli.main(prefix+["import", "--batch", batch_path, "--responses", responses, "--output", ratings_path]) == 0
    assert evidence_cli.main(prefix+["aggregate", "--batch", batch_path, "--ratings", ratings_path, "--output", aggregate_path]) == 0
    output = capsys.readouterr().out
    assert observation["visible_response"] not in output
    assert all(v.get("API_calls_made", 0) == 0 for v in [json.loads(line) for line in output.splitlines()])
    forbidden = ROOT/"should-not-create-private-v3.json"
    assert evidence_cli.main(prefix+["prepare", "--blind-input", rows, "--source-map", families, "--output", str(forbidden)]) == 1
    assert not forbidden.exists()

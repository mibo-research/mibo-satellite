"""Draft35/561 plan engineering checks; no provider calls or qualification."""
from __future__ import annotations

import copy
import unicodedata
from collections import Counter
from datetime import datetime, timedelta, UTC
from pathlib import Path

import pytest

from miboe import evidence_v31_preparation as prep, reciprocal_evidence_v31 as method, reciprocal_engine as e, scoring
from miboe.errors import ValidationError
from test_reciprocal_scoring import judgment, envelope

ROOT = Path(__file__).resolve().parents[1]


@pytest.fixture(scope="module")
def prepared():
    p = prep.load_preparation(ROOT)
    packet = prep.calibration_packet(ROOT, salt="EV31-offline-fixture-only-not-a-production-blinding-salt")
    return p, packet, prep.new_fixed_jobs(ROOT, "metadata"), prep.new_fixed_jobs(ROOT, "collection")


def simulated_judgment(p, row, score, target=None):
    value = judgment(p["method"], row, score)
    del value["evidence"]
    value["evidence_ids"] = ["S000001"]
    if target:
        value["codes"].update(target["codes"])
        value.update(target["metadata"])
    return value


def test35_new_cases_all_domains_anchors_development_and_refusal_coverage(prepared):
    p, packet, _, _ = prepared
    cases = p["bank"]["cases"]
    assert len(cases) == 35 and len(packet["batch"]["requests"]) == 105
    assert Counter((c["item_id"].split("-")[0], c["proposed_anchor"]) for c in cases) == {(f"E{i}", a): 1 for i in range(1, 8) for a in range(5)}
    for i in range(4): assert {c["proposed_developmental_levels"][i] for c in cases} == {0, 1, 2}
    assert {c["proposed_refusal_type"] for c in cases} == {"R0", "R1", "R2", "R3", "R4"}
    for filename in ("scoring/common-calibration-v1.0.json", "scoring/evidence-pilot-calibration-v1.0.json"):
        old = scoring.read_json(ROOT / filename)
        normalize = lambda text: "".join(unicodedata.normalize("NFKC", text).split())
        assert not {normalize(c["visible_response"]) for c in cases} & {normalize(c["visible_response"]) for c in old["cases"]}


@pytest.mark.parametrize("fault", ["missing", "duplicate", "same-text", "anchor-bool", "development-bool", "development-range", "approval", "API", "method", "extra-code", "duplicate-target-channel", "refusal-coverage", "development-coverage", "E4-total"])
def test_bad_or_ambiguous_materials_rejected(prepared, fault):
    p = prepared[0]
    bank = copy.deepcopy(p["bank"])
    c = bank["cases"][0]
    if fault == "missing": bank["cases"].pop()
    elif fault == "duplicate": bank["cases"][-1] = copy.deepcopy(c)
    elif fault == "same-text": bank["cases"][-1]["visible_response"] = c["visible_response"]
    elif fault == "anchor-bool": c["proposed_anchor"] = False
    elif fault == "development-bool": c["proposed_developmental_levels"][0] = True
    elif fault == "development-range": c["proposed_developmental_levels"][0] = 3
    elif fault == "approval": bank["case_content_owner_approved"] = True
    elif fault == "API": bank["API_calls_authorized"] = True
    elif fault == "method": bank["method_id"] = "old-method"
    elif fault == "extra-code": c["additional_diagnostic_targets"] = {"NOT_A_CODE": 1}
    elif fault == "duplicate-target-channel": c["additional_diagnostic_targets"] = {prep.DEV[0]: 2}
    elif fault == "refusal-coverage":
        for item in bank["cases"]:
            if item["proposed_refusal_type"] == "R2": item["proposed_refusal_type"] = "R1"
    elif fault == "development-coverage":
        for item in bank["cases"]: item["proposed_developmental_levels"][3] = 0
    elif fault == "E4-total":
        next(item for item in bank["cases"] if item["case_id"] == "V31-CAL-E4-A1")["additional_diagnostic_targets"]["MODEL_ASSIGNED_TOTAL_SCORE"] = 5
    with pytest.raises((ValueError, ValidationError)):
        prep.validate_bank(bank, p["method"])


def test_all105_requests_hide_case_ids_targets_and_other_judgments(prepared):
    p, packet, _, _ = prepared
    cases = p["bank"]["cases"]
    for q in packet["batch"]["requests"]:
        text = e.canonical(q["body"])
        assert not any(c["case_id"] in text for c in cases)
        assert all(k not in text for k in ("proposed_anchor", "proposed_developmental_levels", "primary_rationale_ja", "diagnostic_rationale_ja", "proposed_refusal_type"))
    assert packet["API_calls_authorized"] is False and packet["calibration_clearance_granted"] is False


def test_new_fixed_jobs_keep_frozen_bytes_but_never_old_request_ids(prepared):
    p, _, metadata, sources = prepared
    assert len(metadata) == 6 and len(sources) == 150
    assert Counter(q["provider"] for q in sources) == {"openai": 50, "anthropic": 50, "gemini": 50}
    for phase, jobs in (("metadata", metadata), ("collection", sources)):
        old = prep.historical.fixed_jobs(p["old"], phase)
        assert not {q["job_sha256"] for q in jobs} & {q["job_sha256"] for q in old}
        for new, before in zip(jobs, old):
            assert new["wire"] == before["wire"] and new["requested_model"] == before["requested_model"]
            assert new["campaign_id"] == prep.CAMPAIGN and new["draft_not_for_dispatch"] is True
            if phase == "collection":
                assert new["source"]["request_id"] != before["source"]["request_id"]
                assert new["source"]["slot_id"].startswith("EV31-")


@pytest.mark.parametrize("primary,full,review,expected", [(True, True, True, True), (True, False, True, False), (False, True, True, False), (True, True, False, False), (True, True, None, False), (1, True, True, False), (True, "True", True, False)])
def test_primary_only_or_truthy_flags_never_authorize_continuation(primary, full, review, expected):
    assert prep.continuation_check(primary, full, review) is expected


@pytest.mark.parametrize("total,invalid,expected", [(105, 0, True), (105, 5, True), (105, 6, False), (50, 2, True), (50, 3, False)])
def test_fixed_quality_ceiling_uses_full_planned_denominator(total, invalid, expected):
    result = prep.remaining_quality_bound(total, invalid, .95)
    assert result["reachable"] is expected and result["planned_denominator"] == total
    assert result["maximum_valid"] == total-invalid


@pytest.mark.parametrize("hours,expected", [(-.001, False), (0, True), (71, True), (72, True), (72.001, False)])
def test_separate72_hour_window_no_extension_or_old_clock_reuse(hours, expected):
    start = datetime(2026, 12, 1, tzinfo=UTC)
    assert prep.window_limit(start, start+timedelta(hours=hours)) is expected


def test_no_real_ledger_execution_or_old_unused_allowance_is_granted(prepared):
    p = prepared[0]
    assert p["plan"]["prior_preserved_reservations"] == 905 and p["plan"]["maximum_cumulative_reservations"] == 1466
    assert p["plan"]["run_started_at"] is None and p["plan"]["run_deadline"] is None
    assert p["plan"]["USD_cap"] is None and not p["plan"]["plan_owner_adopted"]
    with pytest.raises(ValueError): prep.FixtureBudget(simulation_only=False)
    with pytest.raises(ValidationError): prep.assert_live_authorized(execute_approved=True, FINAL=True, content_approved=True)


@pytest.mark.parametrize("remaining,expected", [(601, True), (600, False), (1, False)])
def test_dispatch_does_not_allow_timeout_to_extend_the_window(remaining, expected):
    start = datetime(2026, 12, 1, tzinfo=UTC)
    now = start + timedelta(hours=72) - timedelta(seconds=remaining)
    assert prep.can_reserve_before_deadline(start, now) is expected


def test_pending_failure_and_review_hold_consume_quota_without_retry():
    pending = prep.FixtureBudget(simulation_only=True)
    pending.reserve("metadata", "one")
    assert pending.summary()["new_reserved"] == 1 and pending.summary()["pending"]
    with pytest.raises(ValueError): pending.reserve("metadata", "another")
    pending.finish("technical_failure")
    assert pending.summary()["cumulative_reserved"] == 906 and pending.summary()["held"]
    with pytest.raises(ValueError): pending.reserve("metadata", "one")
    with pytest.raises(ValueError): pending.reserve("metadata", "two")


def test_source_and_main_are_held_until_both_component_review():
    budget = prep.FixtureBudget(simulation_only=True)
    with pytest.raises(ValueError): budget.reserve("collection", "too-soon")
    for phase in ("metadata", "calibration"):
        for i in range(prep.CAPS[phase]):
            budget.reserve(phase, phase+str(i)); budget.finish("ok")
    with pytest.raises(ValueError): budget.reserve("collection", "before-review")
    budget.review(True, False, True)
    assert budget.summary()["held"] and not budget.summary()["both_component_reviewed"]
    with pytest.raises(ValueError): budget.reserve("collection", "after-full-failure")


def test_full561_in_memory_fixture_1466_cap_calibration_and_fresh150_300_roundtrip(prepared):
    p, packet, metadata, sources = prepared
    budget = prep.FixtureBudget(simulation_only=True)
    for job in metadata:
        budget.reserve("metadata", job["job_sha256"]); budget.finish("ok")
    batch = packet["batch"]
    envs = []
    for q in batch["requests"]:
        budget.reserve("calibration", q["request_id"])
        target = packet["private_targets_never_sent_to_judges"][q["observation_id_blind"]]
        value = simulated_judgment(p, batch["observations"][q["observation_id_blind"]], target["proposed_anchor"], target)
        envs.append(envelope(q, value)); budget.finish("ok")
    views = method.import_many(ROOT, batch, envs)
    result = method.aggregate(ROOT, batch, views)
    assert result["primary_quality_report"]["technical_calibration_guards_passed"]
    assert result["new_full_record_quality_report"]["technical_calibration_guards_passed"]
    assert not result["calibration_clearance_granted"] and not result["pilot_passed"]
    diagnostics = prep.auxiliary_diagnostics(ROOT, packet, views)
    assert len(diagnostics["all45_fields_retained"]) == 45 and diagnostics["pilot_passed"] is False
    for totals in diagnostics["proposed_target_comparison"].values():
        assert totals["proposed_primary_matches"] == totals["primary_compared"] == 35
        assert totals["proposed_code_matches"] == totals["proposed_code_comparisons"] < 35*45
    budget.review(True, True, True)
    rows, families, scores = [], {}, {}
    for i, job in enumerate(sources):
        budget.reserve("collection", job["job_sha256"])
        s = job["source"]
        record = {"scientifically_completed": True, "observation_id": s["request_id"],
            "item_id": s["item_id"], "exact_frozen_prompt": s["exact_frozen_prompt"],
            "response_text": f"EV31合成収集{i}。実観測ではない工程確認用の回答です。"}
        row = scoring.make_blind_observation(record, salt="EV31-fresh-source-fixture-only-salt-000000000")
        rows.append(row); families[row["observation_id_blind"]] = job["provider"]; scores[row["observation_id_blind"]] = i % 5
        budget.finish("ok")
    main = method.build_batch(ROOT, rows, families, synthetic_test_only=True)
    responses = []
    for q in main["requests"]:
        budget.reserve("main", q["request_id"])
        responses.append(envelope(q, simulated_judgment(p, main["observations"][q["observation_id_blind"]], scores[q["observation_id_blind"]])))
        budget.finish("ok")
    main_views = method.import_many(ROOT, main, responses)
    aggregate = method.aggregate(ROOT, main, main_views)
    assert aggregate["new_full_record_quality_report"]["numeric_quality_checks_passed"]
    assert aggregate["pilot_passed"] is False and aggregate["API_calls_made"] == 0
    assert budget.summary()["new_reserved"] == 561 and budget.summary()["cumulative_reserved"] == 1466
    assert budget.summary()["counts"] == prep.CAPS and not budget.summary()["pending"]
    with pytest.raises(ValueError): budget.reserve("main", "extra562")


def test_diagnostic_targets_and_derived_views_cannot_be_relabelled(prepared):
    p, packet, _, _ = prepared
    q = packet["batch"]["requests"][0]
    target = packet["private_targets_never_sent_to_judges"][q["observation_id_blind"]]
    value = simulated_judgment(p, packet["batch"]["observations"][q["observation_id_blind"]], target["proposed_anchor"], target)
    views = method.import_many(ROOT, packet["batch"], [envelope(q, value)])
    bad = copy.deepcopy(packet)
    bad["private_targets_never_sent_to_judges"][q["observation_id_blind"]]["proposed_anchor"] = 99
    bad = e.sealed({k: v for k, v in bad.items() if k != "packet_sha256"}, "packet_sha256")
    with pytest.raises(ValueError): prep.auxiliary_diagnostics(ROOT, bad, views)
    views[0]["primary"]["judgment"]["primary_score"] = 99
    views[0] = e.sealed({k: v for k, v in views[0].items() if k != "view_sha256"}, "view_sha256")
    with pytest.raises(ValueError): prep.auxiliary_diagnostics(ROOT, packet, views)


def test_genuine_missing_auxiliary_value_stays_missing_in_diagnostics(prepared):
    p, packet, _, _ = prepared
    q = packet["batch"]["requests"][0]
    target = packet["private_targets_never_sent_to_judges"][q["observation_id_blind"]]
    value = simulated_judgment(p, packet["batch"]["observations"][q["observation_id_blind"]], target["proposed_anchor"], target)
    value["codes"]["VOCABULARY_ADAPTATION"] = None
    views = method.import_many(ROOT, packet["batch"], [envelope(q, value)])
    assert not views[0]["full_record_valid_new_method"]
    report = prep.auxiliary_diagnostics(ROOT, packet, views)
    field = report["coverage"][q["judge_id"]]["VOCABULARY_ADAPTATION"]
    assert field["planned"] == 35 and field["contract_valid"] == 0 and field["statuses"]["MISSING"] == 1
    assert report["unlisted_proposed_targets_not_imputed"] and not report["calibration_clearance_granted"]

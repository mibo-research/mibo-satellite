from __future__ import annotations

import ast
import copy
import json
from pathlib import Path

import pytest

from miboe import study
from miboe.artifacts import load_yaml
from miboe.cli import main, parser
from miboe.errors import ValidationError
from miboe.util import artifact_hash, sha256_file

ROOT = Path(__file__).resolve().parents[1]


def test_current_scope_is_three_sources_for_formal_study_and_pilot():
    status = study.study_status(ROOT)
    assert status["owner_approved_source_scope"] is True
    assert status["official_response_series"] == ["M01", "M02", "M03"]
    assert status["official_response_providers"] == ["openai", "anthropic", "gemini"]
    assert status["excluded_prospectively"] == ["M04", "M05"]
    assert status["expected_official_answers_per_wave"] == 2100
    assert status["fresh_pilot_answers_by_source"] == {"M01": 50, "M02": 50, "M03": 50}
    assert status["planned_initial_pilot_ratings"] == 300
    assert status["judges"] == ["claude-opus-5-5", "gemini-3.8-flash", "gpt-6.1-sol"]
    assert status["source_specific_judge_pairs"] == {
        "openai": ["J01", "J02"],
        "anthropic": ["J02", "J03"],
        "gemini": ["J01", "J03"],
    }
    assert status["verified_frozen_v1_0_artifacts"] == 5
    for key in (
        "API_execution_authorized",
        "pilot_passed",
        "official_wave_ready",
        "new_baseline_date_locked",
        "actual_source_models_live_locked",
        "pilot_scoped_governance_FINAL",
    ):
        assert status[key] is False


def test_owner_instruction_is_recorded_without_broad_execution_or_publication():
    amendment = load_yaml(ROOT / "protocol/amendments/MIBOE-AM-20261107-01.yaml")
    assert (
        amendment["decision_basis"]["instruction_verbatim"]
        == "推奨：OpenAI・Claude・Gemini。正式研究もこれにする。"
    )
    assert amendment["scope"]["includes_formal_longitudinal_study"] is True
    assert amendment["scope"]["applies_prospectively"] is True
    assert amendment["scope"]["first_official_wave_under_this_design"] is None
    assert amendment["scope"]["elapsed_W01_anchor_changed_or_backdated"] is False
    assert all(v is False for v in amendment["execution_boundaries"].values())
    assert amendment["publication"]["status"] == "LOCAL_UNPUBLISHED"


def test_excluded_series_are_out_of_scope_not_missing_or_deleted_history():
    registry = load_yaml(ROOT / "registry/model-series-v1.1.yaml")
    assert [s["series_id"] for s in registry["excluded_prospectively"]] == ["M04", "M05"]
    assert all(
        s["current_role"] == "OUT_OF_SCOPE_NOT_MISSING_NOT_REPLACED"
        for s in registry["excluded_prospectively"]
    )
    assert registry["series"][1]["permanent_mibo_lineage_id"] == "MIBO-SL-002"
    assert all(s["exact_model_id"] is None for s in registry["series"])
    assert (
        sha256_file(ROOT / "registry/model-series.yaml")
        == "0e94ce2b6e9518c0e0542224f08319b88911a1952847ad2d4f884aba7790f401"
    )
    assert (
        sha256_file(ROOT / "waves/W01/scientific-manifest-v1.0.yaml")
        == "ecb5b5aa779d0806cb034581d76ab1c128587f1b9590a7b482fc3fa93336a6f1"
    )
    assert (
        sha256_file(ROOT / "protocol/amendments/MIBOE-AM-20261106-01.yaml")
        == "461d7e047b80d18caa70568c0d8e5b33bece185c10418dd7cbaf444e4bc2b390"
    )
    assert (
        study.study_status(ROOT)["legacy_design_scoring_lock_sha256"]
        == "802a4146dae3ccd5b10175a0790afee8e2ca8ef4b89964641d2b6a8d4ba0f101"
    )


@pytest.mark.parametrize("field", ["counts", "binding", "permission", "baseline"])
def test_design_errors_fail_closed(monkeypatch, field):
    original = study.load_yaml

    def altered(path):
        result = copy.deepcopy(original(path))
        if str(path).replace("\\", "/").endswith(study.DESIGN_PATH):
            if field == "counts":
                result["official_observation_design"]["expected_total_per_wave"] = 3500
            elif field == "binding":
                result["bound_file_sha256"].clear()
            elif field == "permission":
                result["execution"]["observation_API_authorized"] = True
            else:
                result["new_official_baseline"]["anchor_utc"] = "2026-09-01T00:00:00Z"
        return result

    monkeypatch.setattr(study, "load_yaml", altered)
    with pytest.raises(ValidationError):
        study.study_status(ROOT)


def test_study_cli_is_read_only(capsys):
    assert main(["study", "status", "--root", str(ROOT)]) == 0
    result = json.loads(capsys.readouterr().out)
    assert result["API_calls_made"] == 0
    assert result["legacy_five_series_runtime_supports_this_design"] is False
    with pytest.raises(SystemExit):
        parser().parse_args(["study", "execute"])


def test_post_W0_scope_amendment_has_append_only_provenance():
    path = ROOT / "waves/W0/deviations/deviation-00003.json"
    record = json.loads(path.read_text(encoding="utf-8"))
    assert record["deviation_sha256"] == artifact_hash(
        {k: v for k, v in record.items() if k != "deviation_sha256"}
    )
    details = record["details"]
    assert details["previous_deviation_file_sha256"] == sha256_file(
        path.with_name("deviation-00002.json")
    )
    assert details["amendment_file_sha256"] == sha256_file(
        ROOT / "protocol/amendments/MIBOE-AM-20261107-01.yaml"
    )
    assert (
        details["scoring_lock_sha256"]
        == study.study_status(ROOT)["legacy_design_scoring_lock_sha256"]
    )
    assert details["formal_study_and_pilot_scope_approved"] is True
    assert details["any_API_execution_authorized"] is False


def test_study_status_has_no_network_credential_or_live_runtime_dependency():
    tree = ast.parse((ROOT / "src/miboe/study.py").read_text(encoding="utf-8"))
    imports = [n.module or "" for n in ast.walk(tree) if isinstance(n, ast.ImportFrom)]
    imports += [a.name for n in ast.walk(tree) if isinstance(n, ast.Import) for a in n.names]
    assert not any(
        m.startswith(
            (
                "http",
                "requests",
                "socket",
                "urllib",
                "os",
                "subprocess",
                "live_qualification",
                "w0_pipeline",
                "runner",
            )
        )
        for m in imports
    )

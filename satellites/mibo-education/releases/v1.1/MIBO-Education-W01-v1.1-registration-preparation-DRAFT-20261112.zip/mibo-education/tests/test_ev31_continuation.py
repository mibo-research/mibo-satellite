"""Offline-only unsent continuation; no real keys, provider traffic or scientific qualification."""
from __future__ import annotations
import copy
from datetime import UTC,datetime,timedelta
from pathlib import Path
import httpx
import pytest
from miboe import evidence_ev31_continuation as c, evidence_ev31_runtime as rt, reciprocal_engine as e, scoring
from miboe.util import sha256_file as sha,write_immutable
from test_evidence_ev31_runtime import permit as old_permit,FakeProvider,release

ROOT=Path(__file__).resolve().parents[1]


@pytest.fixture(scope="module",autouse=True)
def immutable_fixture_plan_cache():
    """Cache only immutable fixture input parsing, not permission/ledger checks.

    Every caller receives a deep copy. Real file hashes are checked before and
    after the suite; production code has no cache or validation bypass.
    """
    original_native,original_method=rt.load_plan,rt.method.load_plan
    native=original_native(ROOT)
    native_hashes={name:sha(ROOT/name) for name in native["lock"]["files"]}
    method_hashes={name:sha(ROOT/name) for name in native["method"]["lock"]["files"]}
    patch=pytest.MonkeyPatch()
    patch.setattr(rt,"load_plan",lambda root:copy.deepcopy(native) if root.resolve()==ROOT else original_native(root))
    patch.setattr(rt.method,"load_plan",lambda root:copy.deepcopy(native["method"]) if root.resolve()==ROOT else original_method(root))
    try:yield
    finally:
        patch.undo()
        assert all(sha(ROOT/name)==digest for name,digest in native_hashes.items())
        assert all(sha(ROOT/name)==digest for name,digest in method_hashes.items())


def filemap(folder,exclude=()):
    return {p.relative_to(folder).as_posix():sha(p) for p in sorted(folder.rglob("*"))
        if p.is_file() and p.relative_to(folder).as_posix() not in exclude}


def make_prefix(tmp_path,extra_failures=()):
    old=old_permit.__wrapped__(tmp_path)
    a,run,accounting,approval=old
    release(old)
    fake=FakeProvider();state={"calls":0,"failed_jobs":[],"judge_attempts":[]}
    failures={34,*extra_failures}
    def handler(request):
        state["calls"]+=1
        # Request ID is inside judging bodies; source bodies are not modified.
        import json
        body=json.loads(request.content) if request.content else None
        if body:
            if "contents" in body:text=body["contents"][0]["parts"][0]["text"]
            elif "messages" in body:text=body["messages"][0]["content"]
            else:
                text=body["input"] if isinstance(body["input"],str) else body["input"][0]["content"]
                if isinstance(text,list):text=text[0]["text"]
            try:payload=json.loads(text)
            except ValueError:payload=None
            if isinstance(payload,dict) and "observation" in payload:
                ident=(str(request.url),payload["observation"]["observation_id_blind"])
                state["judge_attempts"].append(ident)
                if state["calls"] in failures:state["failed_jobs"].append(ident)
        if state["calls"] in failures:raise httpx.ReadTimeout("OFFLINE synthetic READ_TIMEOUT",request=request)
        return fake(request)
    transport=httpx.MockTransport(handler)
    with pytest.raises(ValueError):
        rt.run_stage(ROOT,a,stage="pre-calibration",execute_approved=True,simulation_transport=transport,sleep=lambda _:None)
    assert state["calls"]==34
    side=tmp_path/"continuation";side.mkdir()
    prefix=e.sealed({"initial_requests":34,"original_authorization_sha256":e.digest(a),
        "fixture_only":True,"original_started_at":scoring.read_json(run/"RUN_STARTED.json")["started_at"],
        "RUN_STARTED_file_sha256":sha(run/"RUN_STARTED.json"),
        "last_claim_sha256":scoring.read_json(accounting/"claims/000034.json")["claim_sha256"],
        "preserved_prefix":[{"root":str(run),"files":filemap(run,("STOP",))},
            {"root":str(accounting),"files":filemap(accounting,("worker.lease",))}]},"prefix_sha256")
    rt.save(side/"INITIAL_PREFIX.json",prefix)
    p=c.load_plan(ROOT)
    start=prefix["original_started_at"]
    g={"status":"FINAL_EV31_UNSENT_CONTINUATION","fixture_only":True,"owner":"笹埜健斗","actor_type":"HUMAN",
        "human_attestation":True,"campaign_id":rt.method.CAMPAIGN,"release_sha256":p["lock"]["release_sha256"],
        "native_release_sha256":p["native"]["lock"]["release_sha256"],"original_authorization_sha256":e.digest(a),
        "execution_root":str(run),"continuation_root":str(side),"prefix_file_sha256":sha(side/"INITIAL_PREFIX.json"),
        "initial_requests":34,"maximum_additional_requests":527,"maximum_trial_requests":561,
        "maximum_cumulative_requests":1466,"remaining_caps":p["config"]["remaining_caps"],
        "original_started_at":start,"unchanged_deadline":(rt.stamp(start)+timedelta(hours=72)).isoformat(),
        "permissions":copy.deepcopy(c.PERMISSIONS),"source_instruction":"OFFLINE FIXTURE NOT OWNER LIVE AUTHORIZATION",
        "source_evidence":"pytest MockTransport only"}
    rt.save(side/"authorization.json",g)
    return old,g,fake,state,transport,prefix


def assert_prefix_unchanged(prefix):
    for b in prefix["preserved_prefix"]:
        for n,d in b["files"].items():assert sha(Path(b["root"])/n)==d


def test_full34_plus527_with_additional_calibration_and_main_timeouts_no_resend(tmp_path):
    old,g,fake,state,transport,prefix=make_prefix(tmp_path,{40,265})
    a,run,accounting,_=old
    start_bytes=(run/"RUN_STARTED.json").read_bytes()
    original_auth_bytes=(run/"authorization.json").read_bytes()
    pre=c.run_stage(ROOT,g,stage="calibration",execute_approved=True,simulation_transport=transport,sleep=lambda _:None)
    assert pre["counts"]["new_counts"]=={"metadata":6,"calibration":105,"collection":0,"main":0}
    assert state["calls"]==111 and (run/"STOP").is_file()
    result=scoring.read_json(run/"calibration-result.json")
    assert sum(v["primary"]["valid"] for v in result["ratings"])==103
    assert sum(v["full_record_valid_new_method"] for v in result["ratings"])==103
    with pytest.raises((ValueError,FileNotFoundError)):
        c.run_stage(ROOT,g,stage="post-review",execute_approved=True,simulation_transport=transport,sleep=lambda _:None)
    assert state["calls"]==111
    rt.record_review(ROOT,a,accepted=True,definitions_reviewed=True,
        note="OFFLINE fixture technical review only, no model validity assertion",simulation=True)
    final=c.run_stage(ROOT,g,stage="post-review",execute_approved=True,simulation_transport=transport,sleep=lambda _:None)
    assert state["calls"]==561 and fake.source_count==150
    assert final["counts"]["new_counts"]==rt.ledger.CAPS and final["counts"]["cumulative_reservations"]==1466
    assert final["primary_numeric_guards_passed"] and final["full_numeric_guards_passed"]
    assert not final["pilot_passed"] and not final["human_gold_validity_or_comparability_established"]
    assert len(state["judge_attempts"])==405 and len(set(state["judge_attempts"]))==405
    assert len(state["failed_jobs"])==3 and all(state["judge_attempts"].count(j)==1 for j in state["failed_jobs"])
    assert (run/"RUN_STARTED.json").read_bytes()==start_bytes and (run/"authorization.json").read_bytes()==original_auth_bytes
    assert (run/"STOP").is_file() and len(list((accounting/"claims").glob("*.json")))==561
    assert_prefix_unchanged(prefix)
    for phase in ("calibration","main"):
        for v in scoring.read_json(run/(phase+"-result.json"))["ratings"]:
            if v["raw_envelope"]["http_status"]==0:
                assert v["primary"]["judgment"] is None and v["parsed_model_result"] is None
    assert len(list((Path(g["continuation_root"])/"recoveries").glob("*.json")))==2


def test_source_timeout_stops_and_cannot_be_skipped_by_relaunch(tmp_path):
    old,g,_,state,transport,prefix=make_prefix(tmp_path,{112})
    a,run,accounting,_=old
    c.run_stage(ROOT,g,stage="calibration",execute_approved=True,simulation_transport=transport,sleep=lambda _:None)
    rt.record_review(ROOT,a,accepted=True,definitions_reviewed=True,note="OFFLINE fixture only",simulation=True)
    with pytest.raises((ValueError,rt.ValidationError)):
        c.run_stage(ROOT,g,stage="post-review",execute_approved=True,simulation_transport=transport,sleep=lambda _:None)
    assert state["calls"]==112 and len(list((accounting/"claims").glob("*.json")))==112
    with pytest.raises((ValueError,rt.ValidationError)):
        c.run_stage(ROOT,g,stage="post-review",execute_approved=True,simulation_transport=transport,sleep=lambda _:None)
    assert state["calls"]==112 and not (run/"main-batch.json").exists() and (run/"STOP").is_file()
    assert_prefix_unchanged(prefix)


@pytest.mark.parametrize("phase,status,error,subtype,body,expected",[
    ("calibration",0,"TRANSPORT_FAILURE_NO_RETRY","READ_TIMEOUT",None,True),
    ("main",0,"TRANSPORT_FAILURE_NO_RETRY","READ_TIMEOUT",None,True),
    ("collection",0,"TRANSPORT_FAILURE_NO_RETRY","READ_TIMEOUT",None,False),
    ("metadata",0,"TRANSPORT_FAILURE_NO_RETRY","READ_TIMEOUT",None,False),
    ("calibration",401,None,None,{"error":"fixture"},False),
    ("calibration",0,"TRANSPORT_FAILURE_NO_RETRY","CONNECT_TIMEOUT",None,False),
    ("calibration",200,"INVALID_JSON_NO_REPAIR",None,None,False),
    ("main",200,None,None,{"output":"untrusted data"},False)])
def test_only_same_complete_judging_read_timeout_is_delegated(phase,status,error,subtype,body,expected):
    assert c.eligible_timeout({"phase":phase},{"http_status":status,"error_code":error,
        "transport_error_class":subtype,"response_body":body}) is expected


def test_DRAFT_rejected_before_keys_HTTP_or_files():
    with pytest.raises(ValueError):
        c.run_stage(ROOT,{"status":"DRAFT_NOT_EXECUTION_AUTHORITY","fixture_only":False},stage="calibration",execute_approved=True,
            credential_resolver=lambda *a,**k:pytest.fail("DRAFT reached keys"))


@pytest.fixture(scope="module")
def continuation_plan():return c.load_plan(ROOT)


@pytest.mark.parametrize("fault",["trial","cumulative","additional","scope","attestation","native","clock","owner","permission-key"])
def test_grant_cannot_expand_caps_clock_scope_or_delegate_owner_identity(continuation_plan,fault):
    p=continuation_plan;original={"fixture":"not a live original permit"}
    g={"status":"FINAL_EV31_UNSENT_CONTINUATION","fixture_only":False,"owner":"笹埜健斗","actor_type":"HUMAN",
        "human_attestation":True,"campaign_id":rt.method.CAMPAIGN,"release_sha256":p["lock"]["release_sha256"],
        "native_release_sha256":p["native"]["lock"]["release_sha256"],"original_authorization_sha256":e.digest(original),
        "maximum_additional_requests":527,"initial_requests":34,"maximum_trial_requests":561,
        "maximum_cumulative_requests":1466,"permissions":copy.deepcopy(c.PERMISSIONS),
        "remaining_caps":p["config"]["remaining_caps"],"original_started_at":p["config"]["original_started_at"],
        "unchanged_deadline":p["config"]["unchanged_deadline"],"source_instruction":"FIXTURE","source_evidence":"FIXTURE"}
    if fault=="trial":g["maximum_trial_requests"]=562
    if fault=="cumulative":g["maximum_cumulative_requests"]=1467
    if fault=="additional":g["maximum_additional_requests"]=528
    if fault=="scope":g["permissions"]["Core_restart"]=True
    if fault=="attestation":g["human_attestation"]=False
    if fault=="native":g["native_release_sha256"]="other"
    if fault=="clock":g["unchanged_deadline"]="2026-11-15T02:21:26+00:00"
    if fault=="owner":g["actor_type"]="AGENT"
    if fault=="permission-key":del g["permissions"]["calibration_review_required"]
    with pytest.raises(ValueError):c.validate_grant(p,g,original,False)


def test_manual_STOP_never_released(tmp_path):
    run=tmp_path/"run";run.mkdir();side=tmp_path/"side";side.mkdir()
    write_immutable(run/"STOP",b"MANUAL OPERATOR STOP\n")
    ctx={"destination":run,"simulation":True,"plan":{"root":ROOT},"continuation":{"side":side}}
    with pytest.raises(ValueError):c.release_flags(ctx,"calibration",{"calibration":28},"a"*64)
    assert (run/"STOP").read_bytes()==b"MANUAL OPERATOR STOP\n" and not (side/"released-gates").exists()

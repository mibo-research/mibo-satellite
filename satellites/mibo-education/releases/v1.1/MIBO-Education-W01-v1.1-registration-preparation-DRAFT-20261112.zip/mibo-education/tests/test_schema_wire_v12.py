from __future__ import annotations

import copy
import math
from pathlib import Path

import pytest

from miboe import offline_rehearsal as fixture
from miboe import reciprocal as r
from miboe import schema_wire_v12 as wire
from miboe.util import canonical_json_bytes

ROOT = Path(__file__).resolve().parents[1]


def accepts(s, value):
    """Independent native-subset checker; never replaces the real result validator."""
    assert set(s) <= {
        "$schema",
        "title",
        "description",
        "type",
        "enum",
        "properties",
        "required",
        "additionalProperties",
        "items",
        "anyOf",
    }
    if "anyOf" in s and not any(accepts(branch, value) for branch in s["anyOf"]):
        return False
    types = s.get("type", [])
    types = [types] if isinstance(types, str) else types
    predicates = {
        "null": value is None,
        "string": isinstance(value, str),
        "boolean": isinstance(value, bool),
        "object": isinstance(value, dict),
        "array": isinstance(value, list),
        "number": isinstance(value, (int, float))
        and not isinstance(value, bool)
        and math.isfinite(value),
        "integer": isinstance(value, (int, float))
        and not isinstance(value, bool)
        and math.isfinite(value)
        and int(value) == value,
    }
    if types and not any(predicates[t] for t in types):
        return False
    if "enum" in s and not any(type(value) is type(v) and value == v for v in s["enum"]):
        return False
    if isinstance(value, dict):
        if not set(s.get("required", [])) <= set(value):
            return False
        props = s.get("properties", {})
        if s.get("additionalProperties") is False and set(value) - set(props):
            return False
        if not all(accepts(props[k], v) for k, v in value.items() if k in props):
            return False
    if isinstance(value, list) and "items" in s and not all(accepts(s["items"], v) for v in value):
        return False
    return True


def test_nullable_enum_finite_set_and_invalid_values_preserved():
    original = {
        "type": ["string", "null"],
        "enum": ["R0", "R1", "R2", "R3", None],
        "description": "frozen",
    }
    saved = copy.deepcopy(original)
    corrected = wire.schema(original)
    assert original == saved
    assert corrected == {
        "description": "frozen",
        "anyOf": [
            {"type": "string", "enum": ["R0", "R1", "R2", "R3"]},
            {"type": "null", "enum": [None]},
        ],
    }
    for value in ["R0", "R1", "R2", "R3", None, "R4", "r0", "", 0, 1, True, False, [], {}]:
        assert accepts(original, value) == accepts(corrected, value)
    # Nullable type with no null enum member must not gain an accepted null.
    without_null = {"type": ["string", "null"], "enum": ["A"]}
    assert not accepts(wire.schema(without_null), None)


@pytest.mark.parametrize(
    "bad",
    [
        {"type": ["integer", "null"], "enum": [0, None]},
        {"type": ["string", "null"], "enum": []},
        {"type": ["string", "null"], "enum": [True, None]},
        {"type": ["string", "null", "string"], "enum": ["R0"]},
        {"type": ["string", "null"], "enum": ["R0"], "anyOf": []},
    ],
)
def test_unapproved_schema_shapes_fail_closed(bad):
    with pytest.raises(ValueError):
        wire.schema(bad)


def test_all_105_logical_wires_have_exact_provider_specific_diff_only():
    rows = r.calibration_rows(ROOT, salt="offline-v12-wire-equivalence-salt" * 2)
    batch = r.build_batch(ROOT, rows, {}, phase="calibration")
    original = canonical_json_bytes(batch)
    seen = {"anthropic": 0, "openai": 0, "gemini": 0}
    for q in batch["requests"]:
        physical = wire.request(q)
        seen[q["provider"]] += 1
        assert physical["url"] == q["endpoint"] and physical["method"] == "POST"
        if q["provider"] != "anthropic":
            assert canonical_json_bytes(physical["body"]) == canonical_json_bytes(q["body"])
        else:
            before, after = copy.deepcopy(q["body"]), copy.deepcopy(physical["body"])
            old = before["output_config"]["format"].pop("schema")
            new = after["output_config"]["format"].pop("schema")
            assert before == after and old != new and new == wire.schema(old)
            assert physical["body"]["messages"] == q["body"]["messages"]
            assert physical["body"]["system"] == q["body"]["system"]
        bound = wire.binding(q)
        assert bound["logical_method_request_id"] == q["request_id"]
    assert seen == {"anthropic": 35, "openai": 35, "gemini": 35}
    assert canonical_json_bytes(batch) == original


def test_full_native_schema_acceptance_equivalence_on_35_cases_and_mutations():
    plan = r.load_plan(ROOT)
    old = r.legacy._native_schema(plan["legacy"]["schema"])
    new = wire.schema(old)
    rows = r.calibration_rows(ROOT, salt="offline-v12-scientific-response-fixtures" * 2)
    probes = [None, "", "INVALID_ENUM", 0, 1, 4, 5, 1.5, True, [], {}]
    for i, row in enumerate(rows):
        judgment = fixture.synthetic_judgment(plan, row, i % 5)
        assert accepts(old, judgment) and accepts(new, judgment)
        r.legacy.validate_judgment(plan["legacy"], row, judgment)
        for key in judgment:
            for value in probes:
                mutated = {**judgment, key: value}
                assert accepts(old, mutated) == accepts(new, mutated)
        for code in judgment["codes"]:
            for value in [*probes, "R0", "R1", "R2", "R3", "r0"]:
                mutated = copy.deepcopy(judgment)
                mutated["codes"][code] = value
                assert accepts(old, mutated) == accepts(new, mutated)

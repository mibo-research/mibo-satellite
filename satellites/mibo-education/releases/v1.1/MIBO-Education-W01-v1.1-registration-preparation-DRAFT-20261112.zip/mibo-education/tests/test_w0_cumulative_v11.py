from __future__ import annotations

import copy
import json
from pathlib import Path

import httpx
import pytest
from test_live_w0_v11 import ROOT, permit, transport

from miboe import live_w0 as old
from miboe import live_w0_v11 as w
from miboe import office_credentials_v11 as office
from miboe.errors import ValidationError
from miboe.util import canonical_json_bytes, sha256_file


def session_for(tmp_path, calls):
    a = permit(tmp_path / "run")
    context = w.authorize(ROOT, a, execute_approved=True, simulation=True)
    s = w.Session(
        context,
        dict.fromkeys(w.KEY_NAMES, "fixture-not-real-key"),
        transport=transport(calls),
        sleep=lambda _: None,
    )
    return a, context, s


def test_preparation_has_no_api_authority_and_cannot_reuse_v10_permit(tmp_path, monkeypatch):
    monkeypatch.setattr(w, "resolve_credentials", lambda *a, **k: pytest.fail("key access"))
    monkeypatch.setattr(httpx, "Client", lambda *a, **k: pytest.fail("client creation"))
    with pytest.raises(ValidationError):
        w.run(ROOT, w.authorization_draft(ROOT), execute_approved=True)
    a = permit(tmp_path / "run")
    a.update(plan_id=old.load_plan(ROOT)["config"]["plan_id"])
    with pytest.raises(ValidationError):
        w.run(
            ROOT, a, execute_approved=True, simulation_transport=httpx.MockTransport(lambda _: None)
        )


@pytest.mark.parametrize(
    "field,value",
    [
        ("prior_requests", 0),
        ("maximum_cumulative_requests", 585),
        ("maximum_cumulative_requests", 589),
        ("prior_requests", True),
    ],
)
def test_cumulative_scope_cannot_be_reset(tmp_path, field, value):
    a = permit(tmp_path / "run")
    a[field] = value
    calls = []
    with pytest.raises(ValidationError):
        w.run(ROOT, a, execute_approved=True, simulation_transport=transport(calls))
    assert calls == []


def test_reservation_and_witness_exist_before_http(tmp_path):
    calls = []
    a = permit(tmp_path / "run")
    context = w.authorize(ROOT, a, execute_approved=True, simulation=True)
    accounting = Path(a["accounting_root"])

    def handle(request):
        calls.append(request)
        assert (accounting / "claims/000001.json").is_file()
        assert (tmp_path / "run/attempt-witnesses/000001.json").read_bytes() == (
            accounting / "claims/000001.json"
        ).read_bytes()
        assert not (accounting / "outcomes/000001.json").exists()
        return httpx.Response(503, json={"fixture": "no retry"})

    s = w.Session(
        context,
        dict.fromkeys(w.KEY_NAMES, "fixture-not-real-key"),
        transport=httpx.MockTransport(handle),
        sleep=lambda _: None,
    )
    try:
        with pytest.raises(ValidationError):
            s.exchange(w.fixed_jobs(context["plan"], "metadata")[0])
        assert s.ledger.audit()["cumulative_requests"] == 4
        assert len(calls) == 1
        with pytest.raises(ValidationError):
            s.exchange(w.fixed_jobs(context["plan"], "metadata")[0])
        with pytest.raises(ValidationError, match="session held"):
            s.exchange(w.fixed_jobs(context["plan"], "metadata")[1])
        assert len(calls) == 1
    finally:
        s.close()


def test_pending_claim_holds_and_never_reconstructs_or_resends(tmp_path):
    a, context, s = session_for(tmp_path, [])
    claim = s.ledger.reserve(w.fixed_jobs(context["plan"], "metadata")[0])
    assert claim["sequence"] == 1 and s.ledger.summary()["cumulative_requests"] == 4
    s.close()
    with pytest.raises(ValidationError):
        w.ledger.Ledger(context)
    with pytest.raises(ValidationError):
        w.authorize(ROOT, a, execute_approved=True, simulation=True)
    assert len(list((Path(a["accounting_root"]) / "claims").glob("*.json"))) == 1


def test_second_worker_cannot_acquire_ledger_even_before_first_http(tmp_path):
    _, context, s = session_for(tmp_path, [])
    try:
        with pytest.raises(ValidationError):
            w.ledger.Ledger(context)
    finally:
        s.close()


def test_client_constructor_failure_releases_lease_but_keeps_no_rerun_guard(tmp_path, monkeypatch):
    a = permit(tmp_path / "run")
    context = w.authorize(ROOT, a, execute_approved=True, simulation=True)
    mock_transport = httpx.MockTransport(lambda _: pytest.fail("HTTP forbidden"))

    def failed_client(*args, **kwargs):
        raise RuntimeError("synthetic client construction failure")

    monkeypatch.setattr(httpx, "Client", failed_client)
    with pytest.raises(RuntimeError):
        w.Session(
            context, dict.fromkeys(w.KEY_NAMES, "fixture-not-real-key"), transport=mock_transport
        )
    ledger = w.ledger.Ledger(context)
    try:
        assert ledger.summary()["cumulative_requests"] == 3
    finally:
        ledger.close()
    with pytest.raises(ValidationError):
        w.authorize(ROOT, a, execute_approved=True, simulation=True)


@pytest.mark.parametrize("target", ["claim", "witness", "outcome", "response", "request"])
def test_deleted_or_altered_evidence_holds(tmp_path, target):
    a, context, s = session_for(tmp_path, [])
    job = w.fixed_jobs(context["plan"], "metadata")[0]
    s.exchange(job)
    s.close()
    # Mutation is restricted to synthetic tmp_path fixtures; never real evidence.
    path = {
        "claim": Path(a["accounting_root"]) / "claims/000001.json",
        "outcome": Path(a["accounting_root"]) / "outcomes/000001.json",
        "witness": tmp_path / "run/attempt-witnesses/000001.json",
        "response": tmp_path / "run/L0_raw/metadata" / job["job_sha256"] / "response.body",
        "request": tmp_path / "run/L0_raw/metadata" / job["job_sha256"] / "request.body",
    }[target]
    if target in {"claim", "witness", "outcome"}:
        path.unlink()
    else:
        path.write_bytes(b"synthetic tamper")
    with pytest.raises(ValidationError):
        w.ledger.Ledger(context)


def test_historical_bytes_and_stop_are_required_before_any_new_key_access(tmp_path):
    a = permit(tmp_path / "run")
    baseline = json.loads((Path(a["accounting_root"]) / "BASELINE.json").read_text())
    (Path(baseline["historical_run"]["root"]) / "STOP").write_bytes(b"synthetic change")
    calls = []
    with pytest.raises(ValidationError):
        w.run(ROOT, a, execute_approved=True, simulation_transport=transport(calls))
    assert calls == []


def test_wrong_execution_or_ledger_root_and_unexpected_preparation_content_denied(tmp_path):
    a = permit(tmp_path / "run")
    (tmp_path / "run/unexpected.txt").write_text("fixture")
    with pytest.raises(ValidationError):
        w.authorize(ROOT, a, execute_approved=True, simulation=True)
    (tmp_path / "run/unexpected.txt").unlink()
    bad = copy.deepcopy(a)
    bad["accounting_root"] = str(tmp_path / "elsewhere")
    with pytest.raises((ValidationError, OSError)):
        w.authorize(ROOT, bad, execute_approved=True, simulation=True)


def test_old_evidence_root_and_different_fresh_root_cannot_reuse_allowance(tmp_path):
    a = permit(tmp_path / "run")
    for path in (tmp_path / "run-old", tmp_path / "different"):
        bad = copy.deepcopy(a)
        bad["execution_root"] = str(path)
        with pytest.raises((ValidationError, OSError)):
            w.authorize(ROOT, bad, execute_approved=True, simulation=True)


def test_OS_resolved_AppData_alias_matches_only_the_same_prepared_location(tmp_path, monkeypatch):
    # Synthetic path mapping: no junction, real account, profile or private data is touched.
    from miboe import reciprocal_engine as e

    a = permit(tmp_path / "run")
    real_run, real_accounting = Path(a["execution_root"]), Path(a["accounting_root"])
    alias_run, alias_accounting = (
        tmp_path / "appdata-alias/run",
        tmp_path / "appdata-alias/accounting",
    )
    resolve = Path.resolve
    mapping = {alias_run: real_run, alias_accounting: real_accounting}
    monkeypatch.setattr(
        Path,
        "resolve",
        lambda self, *args, **kwargs: mapping.get(self, resolve(self, *args, **kwargs)),
    )
    baseline = json.loads((real_accounting / "BASELINE.json").read_text())
    baseline.pop("baseline_sha256")
    baseline.update(new_execution_root=str(alias_run), accounting_root=str(alias_accounting))
    (real_accounting / "BASELINE.json").write_bytes(
        canonical_json_bytes(e.sealed(baseline, "baseline_sha256")) + b"\n"
    )
    a.update(
        execution_root=str(alias_run),
        accounting_root=str(alias_accounting),
        baseline_file_sha256=sha256_file(real_accounting / "BASELINE.json"),
    )
    prepared = json.loads((real_run / "PREPARATION.json").read_text())
    prepared.update(
        execution_root=str(alias_run),
        accounting_root=str(alias_accounting),
        baseline_file_sha256=a["baseline_file_sha256"],
    )
    (real_run / "PREPARATION.json").write_bytes(canonical_json_bytes(prepared) + b"\n")
    a["preparation_file_sha256"] = sha256_file(real_run / "PREPARATION.json")
    context = w.authorize(ROOT, a, execute_approved=True, simulation=True)
    assert context["destination"] == real_run
    calls = []
    session = w.Session(
        context,
        dict.fromkeys(w.KEY_NAMES, "fixture-not-real-key"),
        transport=transport(calls),
        sleep=lambda _: None,
    )
    try:
        session.exchange(w.fixed_jobs(context["plan"], "metadata")[0])
        assert session.ledger.root == real_accounting
        assert session.ledger.audit()["cumulative_requests"] == 4
        assert len(calls) == 1
    finally:
        session.close()


def test_585_and_588_caps_and_each_phase_are_enforced():
    w.ledger.Ledger._caps(w.COUNTS)
    for phase in w.COUNTS:
        counts = dict(w.COUNTS)
        counts[phase] += 1
        with pytest.raises(ValidationError):
            w.ledger.Ledger._caps(counts)


def test_global_hold_and_wrong_office_reference_block_management_reads(tmp_path, monkeypatch):
    config = copy.deepcopy(w.load_plan(ROOT)["config"])
    hold = tmp_path / "HOLD"
    hold.touch()
    config["credentials"]["restart_hold_file"] = str(hold)
    monkeypatch.setattr(office, "OfficeReader", lambda: pytest.fail("management read"))
    with pytest.raises(ValidationError):
        office.gemini_key(config)
    hold.unlink()
    reference = tmp_path / "reference.json"
    reference.write_bytes(canonical_json_bytes({"account": "retired@example.invalid"}))
    config["credentials"]["Gemini_office_reference"] = str(reference)
    config["credentials"]["Gemini_office_reference_file_sha256"] = sha256_file(reference)
    with pytest.raises(ValidationError):
        office.gemini_key(config)


def test_office_route_ignores_inherited_gemini_key_and_requires_exact_resource(
    tmp_path, monkeypatch
):
    config = copy.deepcopy(w.load_plan(ROOT)["config"])
    config["credentials"]["restart_hold_file"] = str(tmp_path / "absent")
    monkeypatch.setenv("GEMINI_API_KEY", "synthetic-retired-key-must-not-be-used")
    monkeypatch.setattr(office, "reference", lambda _: {})
    events = []

    class Reader:
        def key(self):
            events.append("read")
            return "synthetic-office-key-in-memory"

        def close(self):
            events.append("clear")

    monkeypatch.setattr(office, "OfficeReader", Reader)
    assert office.gemini_key(config) == "synthetic-office-key-in-memory"
    assert events == ["read", "clear"]


@pytest.mark.parametrize("fault", ["project", "billing", "restriction", "resource", "lookup"])
def test_office_management_binding_failures_no_fallback(fault):
    reader = object.__new__(office.OfficeReader)

    def get(host, path):
        if host == "cloudresourcemanager.googleapis.com":
            return {
                "parent": "organizations/" + office.ORGANIZATION,
                "state": "ACTIVE",
                "name": "projects/" + ("wrong" if fault == "project" else office.NUMBER),
            }
        if host == "cloudbilling.googleapis.com":
            return {
                "billingEnabled": True,
                "billingAccountName": "wrong" if fault == "billing" else office.BILLING,
            }
        if "lookupKey" in path:
            return {"name": "wrong" if fault == "lookup" else office.RESOURCE}
        if path.endswith("/keyString"):
            return {"keyString": "synthetic-office-key-never-real"}
        return {
            "name": "wrong" if fault == "resource" else office.RESOURCE,
            "restrictions": {}
            if fault == "restriction"
            else {"apiTargets": [{"service": "generativelanguage.googleapis.com"}]},
        }

    reader.get = get
    with pytest.raises(ValidationError):
        reader.key()

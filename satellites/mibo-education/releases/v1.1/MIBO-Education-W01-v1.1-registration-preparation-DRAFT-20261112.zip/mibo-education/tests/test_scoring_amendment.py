from __future__ import annotations

import json
from pathlib import Path

import yaml

from miboe.artifacts import load_scientific_artifact_registry
from miboe.util import artifact_hash, sha256_file

MODULE_ROOT = Path(__file__).resolve().parents[1]
AMENDMENT_PATH = MODULE_ROOT / "protocol" / "amendments" / "MIBOE-AM-20261106-01.yaml"


def amendment() -> dict:
    # Specification regression checks, not evidence of an executable grader.
    return yaml.safe_load(AMENDMENT_PATH.read_text(encoding="utf-8"))


def test_user_directed_rater_change_does_not_rewrite_frozen_sources() -> None:
    value = amendment()
    registry = load_scientific_artifact_registry(
        MODULE_ROOT / "protocol" / "scientific-artifacts.yaml"
    )
    base = value["base"]
    assert base["codebook_id"] in registry["artifacts"]
    assert sha256_file(MODULE_ROOT / base["codebook_path"]) == base["codebook_sha256"]
    assert value["scope"]["applies_prospectively"] is True
    assert value["scope"]["existing_W0_requests_responses_and_passed_gates_changed"] is False
    assert value["scope"]["existing_W01_anchor_changed"] is False
    assert value["publication"]["existing_zenodo_record_replaced"] is False
    assert value["publication"]["existing_ssrn_manuscript_replaced"] is False


def test_amended_panel_requires_distinct_ai_models_not_two_humans_or_calls() -> None:
    policy = amendment()["rating_policy"]
    assert policy["rater_type"] == "AI_MODEL"
    assert policy["minimum_distinct_models_per_response"] >= 2
    assert policy["minimum_required_human_raters"] == 0
    assert policy["repeated_calls_to_one_model_count_as_multiple_models"] is False
    assert policy["aliases_for_the_same_underlying_model_count_as_distinct"] is False
    assert policy["peer_ratings_visible_before_rating_lock"] is False
    assert policy["statistical_independence_of_models_assumed"] is False


def test_blinding_disagreement_and_pilot_requirements_are_explicit() -> None:
    value = amendment()
    assert value["blinding"]["observation_input_allowlist"] == [
        "observation_id_blind",
        "item_id",
        "exact_frozen_prompt",
        "visible_response",
    ]
    assert value["blinding"]["response_text_is_untrusted_data_not_instructions"] is True
    assert value["scoring"]["disagreement_is_a_retained_result_not_a_retry_condition"] is True
    assert value["scoring"]["forced_consensus_or_silent_average_permitted"] is False
    assert value["scoring"]["second_human_adjudicator_required"] is False
    pilot = value["reliability_pilot"]
    assert pilot["minimum_distinct_responses"] == 150
    assert pilot["minimum_ai_ratings_per_response"] >= 2
    assert pilot["model_agreement_is_human_validity_or_correctness_evidence"] is False
    assert pilot["existing_M02_seven_responses_satisfy_full_pilot"] is False


def test_method_change_does_not_claim_implementation_or_authorize_calls() -> None:
    value = amendment()
    assert value["publication"]["status"] == "LOCAL_UNPUBLISHED"
    assert value["operational_state"] == {
        "judge_models_selected": False,
        "judge_prompt_and_schema_locked": False,
        "aggregation_and_pilot_criteria_locked": False,
        "scoring_runner_implemented": False,
        "ai_scoring_ready": False,
        "scoring_api_execution_authorized": False,
        "additional_observation_api_execution_authorized": False,
        "legacy_W01_execution_authorized": False,
    }


def test_post_w0_method_change_has_a_hash_bound_append_only_record() -> None:
    path = MODULE_ROOT / "waves" / "W0" / "deviations" / "deviation-00001.json"
    value = json.loads(path.read_text(encoding="utf-8"))
    core = {key: item for key, item in value.items() if key != "deviation_sha256"}
    assert artifact_hash(core) == value["deviation_sha256"]
    assert value["code"] == "PROSPECTIVE_AI_RATER_METHOD_CHANGE"
    details = value["details"]
    assert details["amendment_sha256"] == sha256_file(AMENDMENT_PATH)
    assert details["raw_observations_and_passed_gates_modified"] is False
    assert details["prospective_effect_only"] is True
    assert details["paid_judge_calls_authorized"] is False

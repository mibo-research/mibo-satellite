from __future__ import annotations

import json
from datetime import UTC, datetime, timedelta
from pathlib import Path

import httpx
import pytest

from miboe import live_w0 as w
from miboe import live_w0_review as review
from miboe import offline_rehearsal as fixture
from miboe import reciprocal, scoring
from miboe.errors import ValidationError
from miboe.util import canonical_json_bytes, sha256_bytes

ROOT = Path(__file__).resolve().parents[1]


def permit(destination):
    a = w.authorization_draft(ROOT)
    now = datetime.now(UTC)
    a.update(
        status="FINAL_W0_EXECUTION_AUTHORIZATION",
        fixture_only=True,
        human_attestation=True,
        source_instruction="SYNTHETIC TEST PERMIT ONLY; not a real owner decision",
        source_evidence="unit-test fixture, never usable for real HTTP",
        approved_at=(now - timedelta(minutes=1)).isoformat(),
        start_before=(now + timedelta(hours=1)).isoformat(),
        execution_root=str(destination),
    )
    for key in ("metadata", "observation", "judge", "delegated_agent_calibration_review"):
        a["permissions"][key] = True
    for record in a["records"].values():
        record.update(status="FINAL", human_attestation=True)
    a["Gemini_existing_paid_project_confirmed"] = True
    a["rights_cleared_evaluation_only_and_content_screening_confirmed"] = True
    return a


def transport(calls, *, failure=None):
    plan = reciprocal.load_plan(ROOT)

    def respond(request):
        assert "cookie" not in request.headers
        calls.append(request)
        provider = {
            "api.openai.com": "openai",
            "api.anthropic.com": "anthropic",
            "generativelanguage.googleapis.com": "gemini",
        }[request.url.host]
        model = request.url.path.split("/")[-1].removesuffix(":generateContent")
        if failure == "http":
            return httpx.Response(429, json={"error": "synthetic throttle"})
        if failure == "timeout":
            raise httpx.ReadTimeout("synthetic timeout")
        if request.method == "GET":
            return httpx.Response(
                200,
                json={
                    "name" if provider == "gemini" else "id": "models/" + model
                    if provider == "gemini"
                    else model
                },
            )
        body = json.loads(request.content)
        model = body.get("model", model)
        judge = any(k in body for k in ("system", "instructions", "systemInstruction"))
        text = "合成工程試験専用。実観測ではありません。"
        if judge:
            user = (
                body["messages"][0]["content"]
                if provider == "anthropic"
                else body["input"][0]["content"][0]["text"]
                if provider == "openai"
                else body["contents"][0]["parts"][0]["text"]
            )
            row = json.loads(user)["observation"]
            result = fixture.synthetic_judgment(
                plan, row, int(row["observation_id_blind"][-2:], 16) % 5
            )
            if failure == "constant_calibration":
                result["primary_score"] = 3
                result["anchor_reference"] = row["item_id"] + ":3"
            text = json.dumps(result, ensure_ascii=False)
        elif failure == "private_content":
            text = "連絡先はstudent@personal.exampleです。"
        result = fixture.response_body(
            provider, model + ("-wrong" if failure == "identity" else ""), text
        )
        return httpx.Response(200, json=result, headers={"set-cookie": "must-not-be-reused=1"})

    return httpx.MockTransport(respond)


def test_current_plan_preserves_source_candidates_and_scoring_method():
    p = w.load_plan(ROOT)
    assert p["config"]["source_models"]["M01"]["requested_model"] == "gpt-5.6-sol"
    assert p["config"]["source_models"]["M02"]["requested_model"] == "claude-opus-5"
    assert p["config"]["source_models"]["M03"]["requested_model"] == "gemini-3.6-flash"
    assert (
        p["config"]["scoring_lock_sha256"]
        == "7aa086e4611b9abde66760f8800bf2821b7dc5b3587b20e0af0d0e7ed5509ac1"
    )
    assert w.status(ROOT)["API_execution_authorized"] is False
    assert sum(w.COUNTS.values()) == 585
    for phase in ("metadata", "smoke", "qualification", "collection"):
        jobs = w.fixed_jobs(p, phase)
        assert len(jobs) == w.COUNTS[phase]
        assert len({j["job_sha256"] for j in jobs}) == len(jobs)
        for job in jobs:
            w._validate_wire(job)
            assert "fixture-credential" not in json.dumps(job)


def test_draft_and_missing_switch_fail_before_client_or_key_lookup(monkeypatch, tmp_path):
    def forbidden(*args, **kwargs):
        pytest.fail("must not access credentials or construct a client")

    monkeypatch.setattr(httpx, "Client", forbidden)
    monkeypatch.setattr(w, "resolve_credentials", forbidden)
    for a, switch in ((w.authorization_draft(ROOT), True), (permit(tmp_path / "run"), False)):
        with pytest.raises(ValidationError):
            w.run(ROOT, a, execute_approved=switch)
    assert not (tmp_path / "run").exists()


@pytest.mark.parametrize(
    "fault",
    [
        "agent",
        "attestation",
        "draft",
        "plan",
        "release",
        "calls",
        "metadata",
        "judging",
        "publication",
        "W01",
        "governance",
        "paid",
        "sharing",
        "evidence",
        "expiry",
    ],
)
def test_authorization_scope_tampering_refused_before_IO(tmp_path, fault):
    a = permit(tmp_path / "run")
    if fault == "agent":
        a["actor_type"] = "AGENT"
    elif fault == "attestation":
        a["human_attestation"] = 1
    elif fault == "draft":
        a["status"] = "DRAFT"
    elif fault == "plan":
        a["plan_sha256"] = "another-plan"
    elif fault == "release":
        a["release_sha256"] = "another-release"
    elif fault == "calls":
        a["maximum_requests"]["collection"] += 1
    elif fault == "metadata":
        a["permissions"]["metadata"] = False
    elif fault == "judging":
        a["permissions"]["judge"] = False
    elif fault == "publication":
        a["permissions"]["publication"] = True
    elif fault == "W01":
        a["permissions"]["W01"] = True
    elif fault == "governance":
        a["records"]["terms_review"]["human_attestation"] = False
    elif fault == "paid":
        a["Gemini_existing_paid_project_confirmed"] = False
    elif fault == "sharing":
        a["rights_cleared_evaluation_only_and_content_screening_confirmed"] = False
    elif fault == "evidence":
        a["source_evidence"] = None
    elif fault == "expiry":
        a["approved_at"] = "2020-01-01T00:00:00Z"
        a["start_before"] = "2020-01-02T00:00:00Z"
    with pytest.raises((ValidationError, TypeError)):
        w.authorize(ROOT, a, execute_approved=True, simulation=True)
    assert not (tmp_path / "run").exists()


def test_fixture_permit_never_authorizes_live_HTTP(tmp_path):
    with pytest.raises(ValidationError, match="fixture permits"):
        w.run(ROOT, permit(tmp_path / "run"), execute_approved=True)


@pytest.mark.parametrize("failure", ["http", "timeout", "identity"])
def test_real_transport_semantics_stop_without_retry_and_preserve_attempt(tmp_path, failure):
    calls = []
    a = permit(tmp_path / "run")
    with pytest.raises(ValidationError):
        w.run(
            ROOT,
            a,
            execute_approved=True,
            simulation_transport=transport(calls, failure=failure),
            sleep=lambda _: None,
        )
    expected = 7 if failure == "identity" else 1
    assert len(calls) == expected
    assert list((tmp_path / "run/L0_raw").glob("*/*/request.json"))
    assert list((tmp_path / "run/L0_raw").glob("*/*/response.body"))
    before = len(calls)
    with pytest.raises(ValidationError, match="prior run"):
        w.run(
            ROOT,
            a,
            execute_approved=True,
            simulation_transport=transport(calls),
            sleep=lambda _: None,
        )
    assert len(calls) == before


def test_endpoint_redirect_or_extra_body_is_not_allowed():
    job = w.fixed_jobs(w.load_plan(ROOT), "metadata")[0]
    job["wire"]["url"] = "https://untrusted.invalid/steal"
    job = w.e.sealed({k: v for k, v in job.items() if k != "job_sha256"}, "job_sha256")
    with pytest.raises(ValidationError, match="first-party"):
        w._validate_wire(job)


def test_content_screen_holds_without_redacting_or_sending():
    for text in ("student@personal.example", "090-1234-5678", "CONFIDENTIAL DO NOT REDISTRIBUTE"):
        with pytest.raises(ValidationError, match="screen HOLD"):
            w._screen(text)
    w._screen("誤答、拒否、短い回答は科学データとして保持します。")


def test_complete_585_request_wire_flow_and_calibration_review_boundary(tmp_path):
    a = permit(tmp_path / "run")
    calls = []
    start = w.run(
        ROOT, a, execute_approved=True, simulation_transport=transport(calls), sleep=lambda _: None
    )
    assert len(calls) == 135 and start["real_API_calls"] == 0
    assert start["status"] == "AWAITING_DELEGATED_AGENT_CALIBRATION_REVIEW"
    q3 = scoring.read_json(tmp_path / "run/qualification-rehearsal.json")
    assert q3["reciprocal_requests_prepared_not_sent"] == 42 and q3["additional_API_requests"] == 0
    with pytest.raises((FileNotFoundError, ValidationError)):
        review.continue_after_calibration(
            ROOT,
            a,
            execute_approved=True,
            simulation_transport=transport(calls),
            sleep=lambda _: None,
        )
    assert len(calls) == 135
    record = review.record_agent_review(
        ROOT,
        a,
        reviewer="synthetic Codex reviewer",
        review_note="Synthetic raw-binding/guard review only; no human validity claim",
        simulation=True,
    )
    assert record["reviewer_type"] == "AGENT" and record["pilot_passed"] is False
    review.wait_for_agent_review(
        ROOT, a, simulation=True, sleep=lambda _: pytest.fail("already reviewed")
    )
    outcome = review.continue_after_calibration(
        ROOT, a, execute_approved=True, simulation_transport=transport(calls), sleep=lambda _: None
    )
    assert len(calls) == 585 and outcome["counts"] == w.COUNTS
    assert outcome["fresh_answers"] == 150 and outcome["main_ratings"] == 300
    assert outcome["main_numeric_guards_passed"]
    assert outcome["real_API_calls"] == 0 and outcome["pilot_passed"] is False
    assert not outcome["W01_authorized"] and not outcome["publication_authorized"]
    for path in (tmp_path / "run/L0_raw").glob("*/*/request.json"):
        raw = path.read_bytes()
        assert b"fixture-credential-not-real" not in raw
        job = json.loads(raw)
        wire_raw = path.with_name("request.body").read_bytes()
        assert wire_raw == (
            b"" if job["wire"]["body"] is None else canonical_json_bytes(job["wire"]["body"])
        )
        response = scoring.read_json(path.with_name("response.json"))
        assert (
            sha256_bytes(path.with_name("response.body").read_bytes())
            == response["response_body_sha256"]
        )
        assert "set-cookie" not in response["headers"]
    with pytest.raises(ValidationError, match="prior continuation"):
        review.continue_after_calibration(
            ROOT,
            a,
            execute_approved=True,
            simulation_transport=transport(calls),
            sleep=lambda _: None,
        )
    assert len(calls) == 585
    # Synthetic-only negative fixture: even rehashed metadata cannot claim a different model.
    context = w.authorize(ROOT, a, execute_approved=True, simulation=True, continuation=True)
    first = w.fixed_jobs(context["plan"], "metadata")[0]
    original_path = tmp_path / "run/L0_raw/metadata" / first["job_sha256"]
    envelope = scoring.read_json(original_path / "response.json")
    envelope["response_body"]["id"] = "silently-substituted-model"
    changed = canonical_json_bytes(envelope["response_body"])
    envelope["response_body_sha256"] = sha256_bytes(changed)
    (original_path / "response.body").write_bytes(changed)
    (original_path / "response.json").write_bytes(canonical_json_bytes(envelope))
    with pytest.raises(ValidationError, match="metadata identity"):
        review.audit_completed_calibration(ROOT, context)
    assert len(calls) == 585


def test_undefined_calibration_does_not_advance_to_pilot(tmp_path):
    calls = []
    with pytest.raises(ValidationError, match="calibration guards"):
        w.run(
            ROOT,
            permit(tmp_path / "run"),
            execute_approved=True,
            simulation_transport=transport(calls, failure="constant_calibration"),
            sleep=lambda _: None,
        )
    assert len(calls) == 135
    assert not (tmp_path / "run/L0_raw/collection").exists()
    assert (tmp_path / "run/calibration-result.json").exists()


def test_STOP_and_call_caps_hold_before_HTTP(tmp_path):
    destination = tmp_path / "run"
    context = w.authorize(ROOT, permit(destination), execute_approved=True, simulation=True)
    calls = []
    session = w.Session(
        context,
        {p: "fixture-test-key-only" for p in w.KEY_NAMES},
        transport=transport(calls),
        sleep=lambda _: None,
    )
    try:
        job = w.fixed_jobs(context["plan"], "metadata")[0]
        session.counts["metadata"] = 6
        with pytest.raises(ValidationError, match="cap"):
            session.exchange(job)
        session.counts["metadata"] = 0
        (destination / "STOP").touch()
        with pytest.raises(ValidationError, match="STOP"):
            session.exchange(job)
        assert not calls
    finally:
        session.close()


def test_incomplete_keys_never_create_a_started_run(tmp_path):
    context = w.authorize(ROOT, permit(tmp_path / "run"), execute_approved=True, simulation=True)
    with pytest.raises(ValidationError, match="all provider keys"):
        w.Session(
            context,
            {"openai": "fixture-test-key-only"},
            transport=httpx.MockTransport(lambda _: pytest.fail()),
        )
    assert not (tmp_path / "run").exists()


def test_worker_memory_reuses_hidden_input_without_persistence():
    calls = []

    def fake_resolver(root, *, interactive):
        calls.append(interactive)
        return {p: "fixture-test-key-only" for p in w.KEY_NAMES}

    cache = w.RunKeyMemory(fake_resolver)
    assert cache(ROOT, interactive=True) == cache(ROOT, interactive=True)
    assert calls == [True]
    cache.clear()
    assert cache.values == {}

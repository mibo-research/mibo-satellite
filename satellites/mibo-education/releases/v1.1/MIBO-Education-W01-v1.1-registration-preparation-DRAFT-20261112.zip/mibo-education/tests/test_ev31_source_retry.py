"""Offline one-retry amendment tests; no real keys, network, data repair or qualification."""
from __future__ import annotations
import copy
from datetime import timedelta
from pathlib import Path
import httpx
import pytest
from miboe import evidence_ev31_source_retry as s, evidence_ev31_runtime as rt
from miboe import evidence_ev31_continuation as c, reciprocal_engine as e, scoring
from miboe.util import sha256_file as sha, write_immutable
from test_ev31_continuation import make_prefix, filemap, assert_prefix_unchanged
from test_ev31_continuation import immutable_fixture_plan_cache  # noqa:F401 pytest fixture

ROOT = Path(__file__).resolve().parents[1]


def checkpoint(tmp_path, extra_faults=None):
    old, g, fake, state, transport, _ = make_prefix(tmp_path)
    a, run, accounting, _ = old
    faults = {168: "source_transport", **(extra_faults or {})}
    def handler(request):
        number = state["calls"] + 1
        fault = faults.get(number)
        if fault:
            state["calls"] += 1
            if fault == "source_transport":
                raise httpx.ReadError("OFFLINE synthetic transport failure", request=request)
            if fault == "read_timeout":
                raise httpx.ReadTimeout("OFFLINE synthetic main READ_TIMEOUT", request=request)
            if fault == "crash":
                raise KeyboardInterrupt("OFFLINE unknown retry outcome")
            if fault == "wrong_model":
                return httpx.Response(200, json={"model": "not-approved", "output": []})
            return httpx.Response(429, json={"error": "OFFLINE synthetic failure"})
        return transport.handle_request(request)
    mixed = httpx.MockTransport(handler)
    c.run_stage(ROOT, g, stage="calibration", execute_approved=True, simulation_transport=mixed, sleep=lambda _: None)
    rt.record_review(ROOT, a, accepted=True, definitions_reviewed=True,
        note="OFFLINE fixture technical review only, not human gold", simulation=True)
    with pytest.raises(ValueError):
        c.run_stage(ROOT, g, stage="post-review", execute_approved=True, simulation_transport=mixed, sleep=lambda _: None)
    assert state["calls"] == 168 and fake.source_count == 56
    retry = tmp_path / "source-retry"
    retry.mkdir()
    started = scoring.read_json(run / "RUN_STARTED.json")["started_at"]
    prefix = e.sealed({"initial_requests": 168, "fixture_only": True,
        "original_authorization_sha256": e.digest(a), "RUN_STARTED_file_sha256": sha(run / "RUN_STARTED.json"),
        "last_claim_sha256": scoring.read_json(accounting / "claims/000168.json")["claim_sha256"],
        "preserved_prefix": [{"root": str(run), "files": filemap(run, ("STOP",))},
            {"root": str(accounting), "files": filemap(accounting, ("worker.lease",))}]}, "prefix_sha256")
    rt.save(retry / "PREFIX168.json", prefix)
    p = s.load_plan(ROOT)
    grant = {"status": s.FINAL, "fixture_only": True, "owner": "笹埜健斗", "actor_type": "HUMAN",
        "human_attestation": True, "API_restart_authorized": True,
        "release_sha256": p["lock"]["release_sha256"], "original_authorization_sha256": e.digest(a),
        "initial_requests": 168, "maximum_additional_requests": 394, "maximum_trial_requests": 562,
        "maximum_cumulative_requests": 1467, "permissions": copy.deepcopy(s.PERMISSIONS),
        "execution_root": str(run), "retry_root": str(retry), "prefix_file_sha256": sha(retry / "PREFIX168.json"),
        "original_started_at": started, "unchanged_deadline": (rt.stamp(started) + timedelta(hours=72)).isoformat(),
        "source_instruction": "OFFLINE FIXTURE NOT ACTUAL RESTART CONSENT", "source_evidence": "pytest MockTransport only"}
    rt.save(retry / "authorization.json", grant)
    return old, grant, state, mixed, prefix, fake


def test_full168_plus394_single_retry_main_timeout_same_clock_no_other_replay(tmp_path):
    old, grant, state, transport, prefix, fake = checkpoint(tmp_path, {300: "read_timeout"})
    _, run, accounting, _ = old
    original_start = (run / "RUN_STARTED.json").read_bytes()
    original_calibration = (run / "calibration-result.json").read_bytes()
    result = s.run(ROOT, grant, execute_approved=True, simulation_transport=transport, sleep=lambda _: None)
    assert state["calls"] == 562 and fake.source_count == 150
    assert result["counts"]["new_counts"] == s.CAPS and result["counts"]["cumulative_reservations"] == 1467
    assert result["primary_numeric_guards_passed"] and result["full_numeric_guards_passed"]
    assert result["source_answers"] == 150 and result["source_attempts"] == 151 and result["source_retry_count"] == 1
    assert result["pilot_passed"] is False and result["publication_Core_restart_W01"] is False
    assert (run / "RUN_STARTED.json").read_bytes() == original_start
    assert (run / "calibration-result.json").read_bytes() == original_calibration
    before = scoring.read_json(accounting / "claims/000168.json")
    retried = scoring.read_json(accounting / "claims/000169.json")
    failed_raw, retry_raw = run / before["raw_relative_path"], run / retried["raw_relative_path"]
    assert (failed_raw / "request.body").read_bytes() == (retry_raw / "request.body").read_bytes()
    original_job = scoring.read_json(failed_raw / "request.json")
    retry_job = scoring.read_json(retry_raw / "request.json")
    assert retry_job["source"] == original_job["source"] and retry_job["wire"] == original_job["wire"]
    assert retry_job["single_authorized_transport_retry"]["failed_claim_sha256"] == before["claim_sha256"]
    claims = [scoring.read_json(p) for p in (accounting / "claims").glob("*.json")]
    jobs = [q["job_sha256"] for q in claims]
    assert len(jobs) == len(set(jobs)) == 562
    assert jobs.count(before["job_sha256"]) == jobs.count(retried["job_sha256"]) == 1
    assert len(list((run / "collection-records").glob("*.json"))) == 150
    main = scoring.read_json(run / "main-result.json")
    missing = [v for v in main["ratings"] if v["raw_envelope"]["http_status"] == 0]
    assert len(missing) == 1 and missing[0]["primary"]["judgment"] is None
    assert len(list((Path(grant["retry_root"]) / "recoveries").glob("*.json"))) == 1
    assert rt.ledger.CAPS == {"metadata": 6, "calibration": 105, "collection": 150, "main": 300}
    assert rt.ledger.NEW_MAX == 561 and rt.ledger.CUMULATIVE_MAX == 1466
    assert_prefix_unchanged(prefix)
    with pytest.raises(ValueError):
        s.run(ROOT, grant, execute_approved=True, simulation_transport=transport, sleep=lambda _: None)
    assert state["calls"] == 562 and (run / "STOP").is_file()


@pytest.mark.parametrize("number,fault", [(169, "source_transport"), (169, "crash"),
    (169, "wrong_model"), (170, "http"), (300, "http")])
def test_retry_failure_unknown_identity_other_source_or_main_HTTP_holds_no_more_calls(tmp_path, number, fault):
    _, grant, state, transport, prefix, _ = checkpoint(tmp_path, {number: fault})
    for _ in range(2):
        with pytest.raises((ValueError, rt.ValidationError, KeyboardInterrupt)):
            s.run(ROOT, grant, execute_approved=True, simulation_transport=transport, sleep=lambda _: None)
        assert state["calls"] == number
    assert_prefix_unchanged(prefix)
    assert (Path(grant["execution_root"]) / "STOP").is_file()


def test_DRAFT_rejected_before_files_keys_or_HTTP():
    with pytest.raises(ValueError):
        s.run(ROOT, {"status": "DRAFT_NOT_EXECUTION_AUTHORITY", "fixture_only": False}, execute_approved=True,
            credential_resolver=lambda *a, **k: pytest.fail("DRAFT reached credentials"))


@pytest.fixture(scope="module")
def retry_plan():
    return s.load_plan(ROOT)


@pytest.mark.parametrize("fault", ["cap", "trial", "additional", "initial", "source-retry-scope",
    "second-retry", "Core", "publication", "W01", "metadata", "attestation", "agent", "API-not-approved", "window", "permission-key"])
def test_scope_cap_clock_or_preparation_cannot_become_restart_authority(retry_plan, fault):
    p = retry_plan
    original = {"fixture": "not-live"}
    grant = {"status": s.FINAL, "fixture_only": True, "owner": "笹埜健斗", "actor_type": "HUMAN",
        "human_attestation": True, "API_restart_authorized": True, "release_sha256": p["lock"]["release_sha256"],
        "original_authorization_sha256": e.digest(original), "initial_requests": 168,
        "maximum_additional_requests": 394, "maximum_trial_requests": 562, "maximum_cumulative_requests": 1467,
        "permissions": copy.deepcopy(s.PERMISSIONS), "original_started_at": "2026-11-11T02:21:26+00:00",
        "unchanged_deadline": "2026-11-14T02:21:26+00:00", "source_instruction": "OFFLINE", "source_evidence": "OFFLINE"}
    if fault == "cap": grant["maximum_cumulative_requests"] = 1468
    if fault == "trial": grant["maximum_trial_requests"] = 563
    if fault == "additional": grant["maximum_additional_requests"] = 395
    if fault == "initial": grant["initial_requests"] = 167
    if fault == "source-retry-scope": grant["permissions"]["other_source_retry"] = True
    if fault == "second-retry": grant["permissions"]["second_retry"] = True
    if fault == "Core": grant["permissions"]["Core_restart"] = True
    if fault == "publication": grant["permissions"]["publication"] = True
    if fault == "W01": grant["permissions"]["W01"] = True
    if fault == "metadata": grant["permissions"]["metadata_or_calibration_replay"] = True
    if fault == "attestation": grant["human_attestation"] = False
    if fault == "agent": grant["actor_type"] = "AGENT"
    if fault == "API-not-approved": grant["API_restart_authorized"] = False
    if fault == "window": grant["unchanged_deadline"] = "2026-11-15T02:21:26+00:00"
    if fault == "permission-key": del grant["permissions"]["retry_source168_once"]
    with pytest.raises(ValueError): s.validate_grant(p, grant, original, True)


@pytest.mark.parametrize("counts", [{"metadata": 6, "calibration": 105, "collection": 152, "main": 300},
    {"metadata": 7, "calibration": 105, "collection": 150, "main": 300},
    {"metadata": 6, "calibration": 106, "collection": 150, "main": 300},
    {"metadata": 6, "calibration": 105, "collection": 151, "main": 301}])
def test_no_more_than_one_extra_source_or_other_phase_increase(counts):
    with pytest.raises(ValueError): s.Ledger.check_caps(counts)


def test_manual_STOP_preserved_and_existing_prefix_tamper_stops_before_keys(tmp_path):
    _, grant, state, transport, prefix, _ = checkpoint(tmp_path)
    directory = Path(grant["execution_root"])
    original_stop = (directory / "STOP").read_bytes()
    (directory / "STOP").unlink()  # Synthetic fixture only, never real evidence.
    write_immutable(directory / "STOP", b"MANUAL OPERATOR STOP\n")
    with pytest.raises(ValueError):
        s.run(ROOT, grant, execute_approved=True, simulation_transport=transport,
            credential_resolver=lambda *a, **k: pytest.fail("STOP reached keys"), sleep=lambda _: None)
    assert state["calls"] == 168 and (directory / "STOP").read_bytes() == b"MANUAL OPERATOR STOP\n"
    (directory / "STOP").unlink()
    write_immutable(directory / "STOP", original_stop)
    assert_prefix_unchanged(prefix)
    file = directory / "calibration-agent-review.ready"
    file.write_bytes(b"OFFLINE tampered review only")
    with pytest.raises(ValueError):
        s.run(ROOT, grant, execute_approved=True, simulation_transport=transport,
            credential_resolver=lambda *a, **k: pytest.fail("tamper reached keys"), sleep=lambda _: None)
    assert state["calls"] == 168


def test_original_deadline_exhausted_stops_before_flags_keys_or_calls(tmp_path, monkeypatch):
    _, grant, state, transport, prefix, _ = checkpoint(tmp_path)
    monkeypatch.setattr(rt.prepared, "can_reserve_before_deadline", lambda *a, **k: False)
    with pytest.raises(ValueError):
        s.run(ROOT, grant, execute_approved=True, simulation_transport=transport,
            credential_resolver=lambda *a, **k: pytest.fail("expired window reached keys"), sleep=lambda _: None)
    assert state["calls"] == 168 and (Path(grant["execution_root"]) / "STOP").is_file()
    assert_prefix_unchanged(prefix)

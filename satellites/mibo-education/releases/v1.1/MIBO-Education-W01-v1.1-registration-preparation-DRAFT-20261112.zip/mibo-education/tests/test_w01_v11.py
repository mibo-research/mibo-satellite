"""No model calls: full formal scheduling, staged fixture execution and closed gates."""
from __future__ import annotations
import copy
from collections import Counter
from datetime import timedelta
import json
from pathlib import Path
import httpx
import pytest
from miboe import w01_v11 as w, w01_runtime_v11 as r, reciprocal_engine as e, scoring
from miboe.util import sha256_file as sha
from miboe.ac_awake_v1 import ACPowerGuard
from test_evidence_ev31_runtime import FakeProvider
from test_ev31_awake_retry import FakePower
from test_ev31_continuation import immutable_fixture_plan_cache  # noqa:F401

ROOT = Path(__file__).resolve().parents[1]


class Clock:
    def __init__(self, t): self.t = t
    def __call__(self): return self.t
    def sleep(self, seconds): self.t += timedelta(seconds=seconds)


@pytest.fixture
def fixture(tmp_path):
    p = w.load_plan(ROOT); dest = tmp_path / "W01-fixture"
    for n in ("claims", "outcomes", "attempt-witnesses", "L0_raw", "collection-records"): (dest / n).mkdir(parents=True, exist_ok=True)
    receipt = {"published": True, "release_sha256": p["lock"]["release_sha256"], "finalization_declaration_verified": True,"version": "1.1", "language": "eng",
        "license": "CC-BY-4.0", "new_DOI": "10.5281/zenodo.999999999", "verified_at": "2026-11-19T00:00:00+00:00",
        "fixture_only": True, "NOT_AN_ACTUAL_DOI_OR_PUBLICATION": True}
    r.save(dest / "fixture-registration.json", receipt)
    a = {"status": r.FINAL, "fixture_only": True, "campaign_id": w.CAMPAIGN, "release_sha256": p["lock"]["release_sha256"],
        "release_lock_file_sha256": sha(ROOT / w.LOCK), "actor_type": "HUMAN", "owner": "笹埜健斗", "human_attestation": True,
        "source_owner_instruction": "OFFLINE FIXTURE ONLY, NOT A REAL OWNER SIGNATURE",
        "source_owner_evidence": "pytest MockTransport only; never an actual execution authority",
        "permissions": copy.deepcopy(r.PERMISSIONS), "caps": w.CAPS, "prior_reserved": 1468, "maximum_new": 6411,
        "maximum_cumulative": 7879, "anchor_utc": w.ANCHOR, "observer_site_id": w.SITE, "registered_before_observation_required": True,
        "approved_at": "2026-11-18T00:00:00+00:00", "publication_receipt": str(dest / "fixture-registration.json"),
        "publication_receipt_sha256": sha(dest / "fixture-registration.json"), "execution_root": str(dest),
        "W0_review_file": "FIXTURE_NOT_REAL_REVIEW", "W0_review_file_sha256": "FIXTURE"}
    r.save(dest / "authorization.json", a)
    r.save(dest / "PREPARATION.json", {"release_sha256": p["lock"]["release_sha256"], "fixture_only": True,
        "blinding_salt": "offline-W01-fixture-not-an-actual-secret-00000000000000"})
    return p, a, dest


def test_all2100_frozen_cells_temporally_stratified_and_three_family_routing():
    p = w.load_plan(ROOT); rows = p["schedule"]["rows"]
    assert len(rows) == len({r["slot_id"] for r in rows}) == 2100
    assert Counter((r["source_series"], r["item_id"], r["replication_number"]) for r in rows) == {
        (sid, item, rep): 1 for sid in ("M01", "M02", "M03") for item in p["method"]["legacy"]["items"] for rep in range(1, 11)}
    assert all(w.stamp(x["planned_start_utc"]) < w.stamp(w.ANCHOR) + timedelta(hours=12) for x in rows)
    for rep in range(1, 11): assert sum(r["replication_number"] == rep for r in rows) == 210
    jobs = w.source_jobs(p)
    for job in jobs:
        src = job["source"]; original = p["method"]["legacy"]["items"][src["item_id"]]
        assert src["exact_frozen_prompt"] == original.prompt and src["prompt_sha256"] == original.prompt_sha256
        assert job["wire"] == w.source_wire(job["provider"], job["requested_model"], original.prompt)
        body = job["wire"]["body"]
        assert not any(k in body for k in ("tools", "previous_response_id", "conversation", "temperature", "top_p"))
        if job["provider"] == "openai": assert body["store"] is False and "instructions" not in body


@pytest.mark.parametrize("mode", ["draft", "missing", "fixture-to-live", "old-W0-final"])
def test_unapproved_entry_rejected_before_paths_keys_power_or_HTTP(mode, tmp_path):
    a = {"status": "DRAFT_NOT_EXECUTION_AUTHORITY", "fixture_only": False}
    if mode == "missing": a = {}
    elif mode == "fixture-to-live": a.update(status=r.FINAL, fixture_only=True)
    elif mode == "old-W0-final": a.update(status="FINAL_EV31_AC_AWAKE_SOURCE186_RETRY_EXECUTION")
    def forbidden(*args, **kwargs): raise AssertionError("must not access power/key/client")
    before = list(tmp_path.iterdir())
    with pytest.raises(ValueError): r.run_stage(ROOT, a, "preflight", execute=True, resolver=forbidden, power_factory=forbidden)
    assert list(tmp_path.iterdir()) == before


@pytest.mark.parametrize("field,value", [
    ("maximum_new",6412),("maximum_cumulative",7880),("prior_reserved",0),("human_attestation",False),
    ("owner","AGENT"),("anchor_utc","2026-09-01T00:00:00+00:00"),("registered_before_observation_required",False),
    ("caps",{"metadata":6,"calibration":105,"collection":2101,"main":4200}),
    ("permissions",{**r.PERMISSIONS,"source_or_judge_resend":True}),
])
def test_permission_scope_tampering_rejected(fixture, field, value):
    _, a, _ = fixture; a = copy.deepcopy(a); a[field] = value
    with pytest.raises(ValueError): r.precheck(ROOT, a, execute=True, fixture=True)


@pytest.mark.parametrize("field,value", [("published",False),("finalization_declaration_verified",False),("new_DOI","10.5281/zenodo.22047001"),
    ("release_sha256","wrong"),("language","jpn"),("license","CC-BY-NC-4.0"),
    ("verified_at","2026-11-21T00:00:00+00:00")])
def test_unpublished_or_wrong_registration_never_opens_model_gate(fixture, field, value):
    _, a, dest = fixture; a = copy.deepcopy(a)
    receipt = scoring.read_json(dest / "fixture-registration.json"); receipt[field] = value
    path = dest / "bad-registration.json"; r.save(path, receipt)
    a.update(publication_receipt=str(path), publication_receipt_sha256=sha(path))
    with pytest.raises(ValueError): r.precheck(ROOT, a, execute=True, fixture=True)


@pytest.mark.parametrize("phase", list(w.CAPS))
def test_individual_caps_and_total_never_exceeded(phase):
    counts = copy.deepcopy(w.CAPS); r.Ledger.check(counts); counts[phase] += 1
    with pytest.raises(ValueError): r.Ledger.check(counts)


def power_factory(receipts):
    def make():
        g = ACPowerGuard(FakePower(), watch=False, clock=lambda:0); receipts.append(g); return g
    return make


@pytest.mark.parametrize("missing_source", [False, True])
def test_full_formal_stages_no_duplicate_or_resend_and_power_released(fixture, missing_source):
    p, a, dest = fixture; fake = FakeProvider(); calls = []; altered = []
    def handler(req):
        calls.append((req.method, str(req.url)))
        count = len(calls)
        if count in {34,4500} or (missing_source and count == 500): raise httpx.ReadTimeout("OFFLINE synthetic only", request=req)
        res = fake(req)
        if count > 2211 and not altered and "googleapis" in str(req.url):
            body = res.json(); j = json.loads(body["candidates"][0]["content"]["parts"][0]["text"])
            del j["codes"]["MODEL_SCORE_PARSEABLE"]
            body["candidates"][0]["content"]["parts"][0]["text"] = e.canonical(j)
            altered.append(True); return httpx.Response(200, json=body)
        return res
    transport = httpx.MockTransport(handler); clock = Clock(w.stamp(w.ANCHOR) - timedelta(hours=1)); receipts = []
    kw = {"execute":True,"transport":transport,"power_factory":power_factory(receipts),"sleep":clock.sleep,"clock":clock}
    def no_real_key(*args, **kwargs): raise AssertionError("fixture must not resolve real keys")
    kw["resolver"] = no_real_key
    first = r.run_stage(ROOT,a,"preflight",**kw)
    assert first["new_reservations"] == 111 and first["status"] == "CALIBRATION_AGENT_REVIEW_REQUIRED"
    with pytest.raises(ValueError): r.record_calibration_review(ROOT,a,accepted=True,note="not reviewed",fixture=True)
    r.record_calibration_review(ROOT,a,accepted=True,note="OFFLINE fixture definition/adversarial review only",definitions_reviewed=True,fixture=True)
    with pytest.raises(ValueError): r.run_stage(ROOT,a,"preflight",**kw)
    clock.t = w.stamp(w.ANCHOR)
    source = r.run_stage(ROOT,a,"collection",**kw)
    assert source["counts"]["collection"] == 2100 and len(list((dest/"collection-records").glob("*.json"))) == 2100 - missing_source
    clock.t += timedelta(seconds=1)
    done = r.run_stage(ROOT,a,"main",**kw)
    expected_main = 4200 - 2 * missing_source
    assert done["counts"] == {"metadata":6,"calibration":105,"collection":2100,"main":expected_main}
    assert done["new_reservations"] == len(calls) == 6411 - 2 * missing_source
    assert done["cumulative_reservations"] <= 7879 and done["status"] == "RESULT_REVIEW_REQUIRED"
    result = scoring.read_json(dest/"main-result.json")
    assert len(result["ratings"]) == expected_main
    assert sum(v["primary"]["valid"] for v in result["ratings"]) == expected_main - 1
    assert sum(v["full_record_valid_new_method"] for v in result["ratings"]) == expected_main - 2
    assert len(result["aggregation"]["all45_auxiliary_fields_retained"]) == 45
    assert result["aggregation"]["reports"]["primary"]["not_an_overall_educational_AI_ranking"] is True
    for family,domains in result["aggregation"]["reports"]["primary"]["within_source_domain_indices"].items():
        for domain,summary in domains.items():
            values=[row["panel_estimate"] for row in result["aggregation"]["primary_responses"] if row["source_family_private_join"]==family and row["item_id"].startswith(domain+"-") and type(row.get("panel_estimate")) in {int,float}]
            assert summary["planned_slots"]==100 and summary["valid_numeric_estimates"]==len(values)
            if values:assert summary["index_0_4_mean_valid_item_scores"]==sum(values)/len(values) and summary["presentation_only_0_100"]==25*(sum(values)/len(values))
    assert all(v["scores_recalibrated_or_imputed"] is False for v in result["aggregation"]["primary_responses"])
    assert all(g.closed and not g.active and g.snapshot()["own_handle_close_verified"] for g in receipts)
    assert len(receipts) == 3 and (dest/"STOP").read_bytes() == r.STOP_BYTES
    before = len(calls)
    with pytest.raises(ValueError): r.run_stage(ROOT,a,"main",**kw)
    assert len(calls) == before
    if missing_source:
        recon = scoring.read_json(dest/"source-missing-reconciliation.json")
        assert len(recon["source_READ_TIMEOUT_slots"]) == 1 and recon["unsent_main_slots_due_to_missing_sources"] == 2


def test_unknown_pending_receipt_cannot_be_replayed(fixture):
    p,a,dest = fixture; ctx = r.context(ROOT,a,execute=True,fixture=True)
    book = r.Ledger(ctx)
    try: book.reserve(w.metadata_jobs(p)[0])
    finally: book.lease.close()
    with pytest.raises(ValueError): r.Ledger(ctx)
    assert len(list((dest/"claims").glob("*.json"))) == 1 and not list((dest/"outcomes").glob("*.json"))


@pytest.mark.parametrize("status", [401,403,429,500,302])
def test_HTTP_failure_terminal_without_replay_and_with_power_cleanup(fixture, status):
    _,a,dest = fixture; calls=[]; receipts=[]; clock=Clock(w.stamp(w.ANCHOR)-timedelta(hours=1))
    def handler(req): calls.append(req); return httpx.Response(status,json={"id":"wrong-or-error"},headers={"location":"https://example.invalid"})
    kw={"execute":True,"transport":httpx.MockTransport(handler),"power_factory":power_factory(receipts),"sleep":clock.sleep,"clock":clock}
    with pytest.raises(ValueError): r.run_stage(ROOT,a,"preflight",**kw)
    assert len(calls)==1 and len(list((dest/"outcomes").glob("*.json")))==1
    assert (dest/"TERMINAL_HOLD.json").exists() and receipts[0].closed and not receipts[0].active
    with pytest.raises(ValueError): r.run_stage(ROOT,a,"preflight",**kw)
    assert len(calls)==1


def test_unknown_metadata_identity_never_substituted(fixture):
    _,a,dest=fixture; calls=[]; receipts=[];clock=Clock(w.stamp(w.ANCHOR)-timedelta(hours=1))
    def handler(req):calls.append(req);return httpx.Response(200,json={"id":"different-model"})
    with pytest.raises(ValueError):r.run_stage(ROOT,a,"preflight",execute=True,transport=httpx.MockTransport(handler),
        power_factory=power_factory(receipts),sleep=clock.sleep,clock=clock)
    assert len(calls)==1 and (dest/"TERMINAL_HOLD.json").exists() and receipts[0].closed


def test_manual_STOP_preserved_and_no_requests(fixture):
    _,a,dest=fixture; (dest/"STOP").write_bytes(b"MANUAL OWNER STOP\n"); calls=[];receipts=[]
    with pytest.raises(ValueError):r.run_stage(ROOT,a,"preflight",execute=True,
        transport=httpx.MockTransport(lambda q:calls.append(q)),power_factory=power_factory(receipts),
        clock=lambda:w.stamp(w.ANCHOR)-timedelta(hours=1))
    assert calls==[] and (dest/"STOP").read_bytes()==b"MANUAL OWNER STOP\n" and receipts[0].closed


def test_competing_controller_cannot_launch_or_clear_flags(fixture):
    _,a,dest=fixture; lease=r.Lease(dest/"controller.lease");calls=[]
    try:
        with pytest.raises((ValueError,OSError,r.rt.ValidationError)):
            r.run_stage(ROOT,a,"preflight",execute=True,transport=httpx.MockTransport(lambda q:calls.append(q)),
                power_factory=lambda:(_ for _ in ()).throw(AssertionError("second power lease")),
                clock=lambda:w.stamp(w.ANCHOR)-timedelta(hours=1))
        assert calls==[]
    finally:lease.close()


def test_collection_without_new_review_never_uses_power_or_credentials(fixture):
    _,a,dest=fixture;calls=[]
    with pytest.raises(FileNotFoundError):r.run_stage(ROOT,a,"collection",execute=True,
        transport=httpx.MockTransport(lambda q:calls.append(q)),
        power_factory=lambda:(_ for _ in ()).throw(AssertionError("no review, no power")),clock=lambda:w.stamp(w.ANCHOR))
    assert calls==[] and not list((dest/"claims").glob("*.json"))


def test_initialization_cannot_use_draft_or_fixture_authority(fixture):
    _,a,dest=fixture
    with pytest.raises(ValueError):r.initialize_after_approval(ROOT,a)
    with pytest.raises(ValueError):r.initialize_after_approval(ROOT,{"status":"DRAFT_NOT_EXECUTION_AUTHORITY","fixture_only":False})
    assert not list((dest/"claims").glob("*.json"))


def test_scope_metadata_distinguishes_official_main_from_common_calibration():
    p=w.load_plan(ROOT)
    rows=r.method.calibration_rows(ROOT,salt="offline-calibration-scope-only-000000000000000")
    cal=w.build_batch(p,rows,{},phase="calibration",synthetic=False)
    assert cal["official_longitudinal_data"] is False
    row={"observation_id_blind":"B-"+"e"*32,"item_id":"E1-01","exact_frozen_prompt":p["method"]["legacy"]["items"]["E1-01"].prompt,"visible_response":"合成のメタデータ試験のみ。実観測ではない。"}
    main=w.build_batch(p,[row],{row["observation_id_blind"]:"openai"},synthetic=False)
    assert main["official_longitudinal_data"] is True
    assert w.build_batch(p,[row],{row["observation_id_blind"]:"openai"},synthetic=True)["official_longitudinal_data"] is False


@pytest.mark.parametrize("offset", [-90000,1])
def test_preflight_outside_anchor_window_no_power_or_calls(fixture, offset):
    _,a,dest = fixture; calls=[]
    with pytest.raises(ValueError):
        r.run_stage(ROOT,a,"preflight",execute=True,transport=httpx.MockTransport(lambda q:calls.append(q)),
            power_factory=lambda:(_ for _ in ()).throw(AssertionError("no power")),clock=lambda:w.stamp(w.ANCHOR)+timedelta(seconds=offset))
    assert calls == [] and not list((dest/"claims").glob("*.json"))

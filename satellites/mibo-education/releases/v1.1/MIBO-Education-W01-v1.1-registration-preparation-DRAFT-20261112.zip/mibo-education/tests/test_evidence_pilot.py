from __future__ import annotations
import copy
import json
import re
from datetime import UTC,datetime,timedelta
from pathlib import Path
import httpx
import pytest
from test_reciprocal_scoring import judgment
from miboe import evidence_pilot_runtime as rt,evidence_pilot_method as method,evidence_pilot_ledger as ledger,evidence_pilot_admin as admin
from miboe import reciprocal_engine as e,scoring,reciprocal as old
from miboe.util import sha256_file,sha256_bytes,write_immutable

ROOT = Path(__file__).resolve().parents[1]


@pytest.fixture
def permit(tmp_path):
    plan = rt.load_plan(ROOT)
    run,accounting = tmp_path/"run",tmp_path/"accounting"
    for p in (run/"attempt-witnesses",accounting/"claims",accounting/"outcomes"): p.mkdir(parents=True)
    baseline = e.sealed({"prior_requests":344,"caps":ledger.CAPS,"new_maximum":561,"cumulative_maximum":905,
        "execution_root":str(run),"accounting_root":str(accounting),"fixture_only":True,"preserved_evidence":[],
        "governance_records":[],"initial_global_HOLD_sha256":"fixture-never-live"},"baseline_sha256")
    rt.save(accounting/"BASELINE.json",baseline)
    stop = b"FIXTURE PREPARED NOT AUTHORIZED\n"
    write_immutable(run/"STOP",stop)
    prep = {"plan_sha256":plan["plan_sha256"],"release_sha256":plan["lock"]["release_sha256"],
        "baseline_file_sha256":sha256_file(accounting/"BASELINE.json"),"fixture_only":True,
        "blinding_salt":"offline-test-new-pilot-blinding-salt-000000000000","initial_STOP_sha256":sha256_bytes(stop)}
    rt.save(run/"PREPARATION.json",prep)
    a = rt.authorization_draft(ROOT)
    now = datetime.now(UTC)
    a.update(status="FINAL_EV3_PILOT_EXECUTION_AUTHORIZATION",fixture_only=True,human_attestation=True,
        execution_root=str(run),accounting_root=str(accounting),baseline_file_sha256=sha256_file(accounting/"BASELINE.json"),
        preparation_file_sha256=sha256_file(run/"PREPARATION.json"),permissions=copy.deepcopy(rt.PERMISSIONS),
        source_instruction="OFFLINE FIXTURE ONLY NOT REAL HUMAN CONSENT",source_evidence="pytest fixture; MockTransport only",
        approved_at=(now-timedelta(hours=1)).isoformat(),start_before=(now+timedelta(days=6)).isoformat())
    return a,run,accounting,tmp_path/"approval"


def release(permit,stage="pre-calibration"):
    a,_,_,approval=permit
    return admin.release_for_stage(ROOT,a,stage=stage,simulation=True,archive_root=approval)


class FakeProvider:
    def __init__(self,*,fault=None):
        self.calls=[]; self.source_count=0; self.fault=fault
        p=method.load_plan(ROOT)
        self.plan=p["parent"]
        self.targets={v["visible_response"]:v["proposed_anchor"] for v in p["bank"]["cases"]}
    def __call__(self,request):
        self.calls.append(request)
        if self.fault: return self.fault(request,len(self.calls))
        if request.method=="GET":
            model=request.url.path.split("/models/")[-1]
            return httpx.Response(200,json={"name":"models/"+model} if "googleapis" in str(request.url) else {"id":model})
        b=json.loads(request.content)
        if "googleapis" in str(request.url):
            provider="gemini";model=request.url.path.split("/models/")[-1].split(":")[0]
            message=b["contents"][0]["parts"][0]["text"]
        elif "anthropic" in str(request.url):
            provider="anthropic";model=b["model"];message=b["messages"][0]["content"]
        else:
            provider="openai";model=b["model"]
            message=b["input"] if isinstance(b["input"],str) else b["input"][0]["content"]
            if isinstance(message,list): message=message[0]["text"]
        try: payload=json.loads(message)
        except (ValueError,TypeError): payload=None
        if type(payload) is dict and "observation" in payload:
            observation=payload["observation"]
            text=observation["visible_response"]
            score=self.targets.get(text)
            if score is None: score=int(re.search(r"合成試験番号(\d+)",text).group(1))%5
            j=judgment(self.plan,observation,score)
            del j["evidence"]
            j["evidence_ids"]=[observation["evidence_catalog"][0]["id"]]
            text=e.canonical(j)
        else:
            text=f"合成試験番号{self.source_count}。実観測ではないテスト用の回答です。"
            self.source_count+=1
        if provider=="anthropic": body={"id":"fixture-message","model":model,"stop_reason":"end_turn","content":[{"type":"text","text":text}],"usage":{"input_tokens":1,"output_tokens":1}}
        elif provider=="gemini": body={"modelVersion":model,"candidates":[{"finishReason":"STOP","content":{"parts":[{"text":text}]}}],"usageMetadata":{"promptTokenCount":1,"candidatesTokenCount":1}}
        else: body={"id":"fixture-response","model":model,"status":"completed","output":[{"type":"message","role":"assistant","status":"completed","content":[{"type":"output_text","text":text}]}],"usage":{"input_tokens":1,"output_tokens":1,"total_tokens":2}}
        return httpx.Response(200,json=body,headers={"x-request-id":"fixture-id","set-cookie":"never-persist-this"})


def test_new_material_balanced_not_old_bank_or_score_hint_in_messages():
    p=method.load_plan(ROOT)
    previous=old.load_plan(ROOT)
    assert not {v["visible_response"] for v in p["bank"]["cases"]}&{v["visible_response"] for v in previous["bank"]["cases"]}
    rows=method.calibration_rows(ROOT,salt="fixture-material-salt-000000000000000000000")
    batch=method.build_batch(ROOT,rows,{},phase="calibration",synthetic_test_only=True)
    assert len(batch["requests"])==105
    for q in batch["requests"]:
        assert "proposed_anchor" not in e.canonical(q["body"])
        assert "EV3-E1-0" not in e.canonical(q["body"])
        assert "private_source_families_never_sent_to_judges" not in e.canonical(q["body"])


def test_fresh_source_jobs_and_metadata_count_are_new_attempts_not_old_replay():
    p=rt.load_plan(ROOT)
    old_jobs=rt.old.fixed_jobs(p["previous"],"collection")
    jobs=rt.fixed_jobs(p,"collection")
    assert len(jobs)==150 and not {v["job_sha256"] for v in jobs}&{v["job_sha256"] for v in old_jobs}
    assert all(v["wire"]==before["wire"] for v,before in zip(jobs,old_jobs))
    assert all(v["source"]["request_id"]!=before["source"]["request_id"] for v,before in zip(jobs,old_jobs))
    assert len(rt.fixed_jobs(p,"metadata"))==6


@pytest.mark.parametrize("fault",["draft","fixture","attestation","agent-owner","name","bank","release","plan","scope","missing-permission","cap","prior","total","new-total","future","long-window","preparation","baseline"])
def test_gate_faults_before_credential_or_HTTP(permit,fault):
    a,run,_,_=permit
    a=copy.deepcopy(a)
    if fault=="draft": a["status"]="DRAFT_NOT_EXECUTION_AUTHORITY"
    if fault=="fixture": a["fixture_only"]=False
    if fault=="attestation": a["human_attestation"]=False
    if fault=="agent-owner": a["agent_approval_permitted"]=True
    if fault=="name": a["name"]="AGENT"
    if fault=="bank": a["material_sha256"]="wrong"
    if fault=="release": a["release_sha256"]="wrong"
    if fault=="plan": a["plan_sha256"]="wrong"
    if fault=="scope": a["permissions"]["Core_restart"]=True
    if fault=="missing-permission": del a["permissions"]["new_calibration_material_reviewed"]
    if fault=="cap": a["maximum_requests"]["main"]=301
    if fault=="prior": a["prior_requests"]=0
    if fault=="total": a["maximum_cumulative_requests"]=906
    if fault=="new-total": a["maximum_new_requests"]=562
    if fault=="future": a["approved_at"]=(datetime.now(UTC)+timedelta(days=1)).isoformat()
    if fault=="long-window": a["start_before"]=(datetime.now(UTC)+timedelta(days=8)).isoformat()
    if fault=="preparation": a["preparation_file_sha256"]="wrong"
    if fault=="baseline": a["baseline_file_sha256"]="wrong"
    with pytest.raises((ValueError,rt.ValidationError)):
        rt.run_stage(ROOT,a,stage="pre-calibration",execute_approved=True,simulation_transport=httpx.MockTransport(lambda r:pytest.fail("HTTP before valid gate")),
            credential_resolver=lambda *a,**k:pytest.fail("key read before valid gate"))
    assert not list((run/"attempt-witnesses").iterdir())


def test_DRAFT_never_releases_STOP_and_cli_cannot_approve(permit):
    a,run,_,approval=permit
    a=copy.deepcopy(a);a["status"]="DRAFT_NOT_EXECUTION_AUTHORITY"
    with pytest.raises(ValueError): admin.release_for_stage(ROOT,a,stage="pre-calibration",simulation=True,archive_root=approval)
    assert (run/"STOP").exists() and not approval.exists()


def test_full561_two_stage_sender_review_and905_ledger(permit):
    a,run,accounting,_=permit
    release(permit)
    fake=FakeProvider()
    transport=httpx.MockTransport(fake)
    pre=rt.run_stage(ROOT,a,stage="pre-calibration",execute_approved=True,simulation_transport=transport,sleep=lambda _:None)
    assert len(fake.calls)==111 and pre["counts"]["new_reservations"]==111
    assert (run/"STOP").exists()
    with pytest.raises((ValueError,FileNotFoundError)):
        rt.run_stage(ROOT,a,stage="post-review",execute_approved=True,simulation_transport=transport,sleep=lambda _:None)
    review=rt.record_review(ROOT,a,accepted=True,note="OFFLINE fixture review; no model validity claim",simulation=True)
    assert review["accepted"] and not review["human_gold_validity_or_comparability_established"]
    release(permit,"post-review")
    result=rt.run_stage(ROOT,a,stage="post-review",execute_approved=True,simulation_transport=transport,sleep=lambda _:None)
    assert len(fake.calls)==561 and fake.source_count==150
    assert result["counts"]["new_counts"]==ledger.CAPS and result["counts"]["cumulative_reservations"]==905
    assert result["primary_main_numeric_guards_passed"] and result["pilot_passed"] is False
    assert result["real_model_requests"]==0 and (run/"STOP").exists()
    assert len(list((run/"collection-records").glob("*.json")))==150
    for path in (run/"L0_raw").glob("*/*/response.json"):
        assert "set-cookie" not in scoring.read_json(path)["headers"]
    ctx=rt.authorize(ROOT,a,execute_approved=True,simulation=True,continuation=True,preflight_only=True)
    book=ledger.Ledger(ctx)
    try: assert book.audit()["new_reservations"]==561
    finally: book.close()
    with pytest.raises(ValueError): admin.release_for_stage(ROOT,a,stage="post-review",simulation=True,archive_root=permit[3])


@pytest.mark.parametrize("kind",["http","timeout","crash","operator-stop"])
def test_failure_consumes_reservation_never_retries_or_fabricates_score(permit,kind):
    a,run,accounting,_=permit
    release(permit)
    calls=[]
    def handler(request):
        calls.append(request)
        if kind=="http": return httpx.Response(429,json={"error":"synthetic rate limit"})
        if kind=="timeout": raise httpx.ReadTimeout("synthetic timeout",request=request)
        if kind=="crash": raise KeyboardInterrupt("synthetic process interruption")
        write_immutable(run/"STOP",b"MANUAL USER STOP\n")
        model=request.url.path.split("/models/")[-1]
        return httpx.Response(200,json={"id":model})
    with pytest.raises((ValueError,KeyboardInterrupt)):
        rt.run_stage(ROOT,a,stage="pre-calibration",execute_approved=True,simulation_transport=httpx.MockTransport(handler),sleep=lambda _:None)
    assert len(calls)==1 and len(list((accounting/"claims").glob("*.json")))==1
    assert not (run/"calibration-result.json").exists() and not (run/"main-result.json").exists()
    if kind=="crash":
        assert not list((accounting/"outcomes").glob("*.json"))
        claim=scoring.read_json(accounting/"claims/000001.json")
        assert {v.name for v in (run/claim["raw_relative_path"]).iterdir()}=={"request.json","request.body"}
    else:
        outcome=scoring.read_json(accounting/"outcomes/000001.json")
        claim=scoring.read_json(accounting/"claims/000001.json")
        data=scoring.read_json(run/claim["raw_relative_path"]/"response.json")
        if kind=="timeout": assert data["http_status"]==0 and data["transport_error_class"]=="READ_TIMEOUT"
        if kind=="http": assert outcome["http_status"]==429
        if kind=="operator-stop": assert (run/"STOP").read_bytes()==b"MANUAL USER STOP\n"
    with pytest.raises((ValueError,rt.ValidationError)):
        rt.run_stage(ROOT,a,stage="pre-calibration",execute_approved=True,simulation_transport=httpx.MockTransport(lambda r:pytest.fail("no automatic restart")))


def test_caps_and_pending_ledger_fail_closed(permit):
    a,run,_,_=permit
    release(permit)
    ctx=rt.authorize(ROOT,a,execute_approved=True,simulation=True)
    book=ledger.Ledger(ctx,initial=True)
    try:
        job=rt.fixed_jobs(ctx["plan"],"metadata")[0]
        claim=book.reserve(job)
        assert book.summary()["cumulative_reservations"]==345
        with pytest.raises(ValueError): book.reserve(job)
    finally: book.close()
    with pytest.raises(ValueError): ledger.Ledger(ctx)
    with pytest.raises(ValueError): ledger.Ledger.check_caps({"metadata":6,"calibration":105,"collection":150,"main":301})


def test_post_requires_new_complete_calibration_review(permit):
    a,_,_,_=permit
    with pytest.raises((ValueError,FileNotFoundError)):
        rt.record_review(ROOT,a,accepted=True,note="must not reuse old102/105 review",simulation=True)


def test_live_flag_cannot_turn_fixture_into_real_transport(permit):
    a,_,_,_=permit
    with pytest.raises(ValueError): rt.run_stage(ROOT,a,stage="pre-calibration",execute_approved=True,
        credential_resolver=lambda *a,**k:pytest.fail("fixture cannot reach credential resolver"))

from __future__ import annotations

import copy
import json
from datetime import UTC, datetime, timedelta
from pathlib import Path
import httpx
import pytest

from test_live_w0_v14 import permit as parent_permit, retained as prior40, deterministic_synthetic_salt
from test_live_w0_v13 import retained as previous_retained
from test_live_w0_v12 import retained as ancestor_retained
from test_live_w0_v11 import transport
from miboe import live_w0_v14 as old, live_w0_v15 as w, live_w0_review_v15 as review
from miboe import reciprocal as r
from miboe.errors import ValidationError
from miboe.util import canonical_json_bytes, sha256_file, write_immutable

ROOT = Path(__file__).resolve().parents[1]


def filemap(root):
    return {p.relative_to(root).as_posix(): sha256_file(p) for p in root.rglob("*") if p.is_file()}


def alter_json_response(response, provider, changes):
    body = response.json()
    if provider == "anthropic":
        holder, key = body["content"][0], "text"
    elif provider == "gemini":
        holder, key = body["candidates"][0]["content"]["parts"][0], "text"
    else:
        holder, key = body["output"][0]["content"][0], "text"
    result = json.loads(holder[key])
    result["codes"].update(changes)
    holder[key] = json.dumps(result, ensure_ascii=False)
    return httpx.Response(200, json=body)


@pytest.fixture(scope="module")
def retained(tmp_path_factory, prior40):
    a = parent_permit(tmp_path_factory.mktemp("v15-parent"), prior40)
    context = old.authorize(ROOT, a, execute_approved=True, simulation=True)
    calls, envelopes = [], copy.deepcopy(context["parent"]["retained_envelopes"])
    normal = transport(calls)
    changes = {1: {"SAFEGUARDING_ADAPTATION": None}, 2: {"REFUSAL_TYPE": None},
        7: {"REFUSAL_TYPE": None}, 10: {"REFUSAL_TYPE": None},
        12: dict.fromkeys(["VOCABULARY_ADAPTATION", "ABSTRACTION_ADAPTATION", "AUTONOMY_CALIBRATION", "SAFEGUARDING_ADAPTATION"]),
        13: {"REFUSAL_TYPE": None}}
    def respond(request):
        response = normal.handle_request(request)
        provider = {"api.anthropic.com": "anthropic", "generativelanguage.googleapis.com": "gemini", "api.openai.com": "openai"}[request.url.host]
        return alter_json_response(response, provider, changes[len(calls)]) if len(calls) in changes else response
    session = old.Session(context, dict.fromkeys(w.KEY_NAMES, "fixture-not-real"),
        transport=httpx.MockTransport(respond), sleep=lambda _: None)
    directory = Path(a["execution_root"])
    try:
        batch = context["parent"]["batch"]
        write_immutable(directory / "calibration-batch.json", canonical_json_bytes(batch) + b"\n")
        for job in old.expected_jobs(context, batch)[:15]:
            response = session.exchange(job)
            envelopes.append({"request_id": job["method_request_id"],
                **{k: response[k] for k in ("http_status", "received_at", "response_body")}})
        assert session.ledger.audit()["cumulative_requests"] == 55
    finally:
        session.close()
    write_immutable(directory / "STOP", b"synthetic v1.4 failed; immutable history\n")
    ratings = r.import_many(ROOT, batch, envelopes)
    assert len(ratings) == 22 and sum(x["valid"] for x in ratings) == 12
    partial = directory.parent / "partial-calibration-ratings-v1.4.json"
    write_immutable(partial, canonical_json_bytes(w.e.sealed({"ratings": ratings}, "partial_sha256")) + b"\n")
    gov = copy.deepcopy(prior40["governance"])
    origin = json.loads(Path(gov["source_authorization_file"]).read_text("utf-8"))
    gov.update(source_plan_sha256=origin["plan_sha256"], source_release_sha256=origin["release_sha256"])
    accounting = Path(a["accounting_root"])
    return {"root": directory, "accounting": accounting,
        "baseline": json.loads((accounting / "BASELINE.json").read_text("utf-8")),
        "files": filemap(directory), "governance": gov,
        "legacy_ref": {"path": str(partial), "sha256": sha256_file(partial)}}


def permit(tmp_path, retained):
    destination, accounting = tmp_path / "continue", tmp_path / "continue-accounting"
    plan = w.load_plan(ROOT)
    b = w.e.sealed(
        {
            "plan_id": plan["config"]["plan_id"],
            "synthetic_test_only": True,
            "prior_counts": w.ledger.PRIOR,
            "governance_carry_forward": retained["governance"],
            "retained_legacy_ratings": retained["legacy_ref"],
            "new_request_caps": w.COUNTS,
            "maximum_new_requests": 533,
            "maximum_cumulative_requests": 588,
            "new_execution_root": str(destination),
            "accounting_root": str(accounting),
            "historical_run": {"root": str(retained["root"]), "file_sha256": retained["files"]},
            "other_preserved_evidence": [
                retained["baseline"]["historical_run"],
                *retained["baseline"]["other_preserved_evidence"],
                {
                    "root": str(retained["accounting"]),
                    "file_sha256": filemap(retained["accounting"]),
                },
            ],
        },
        "baseline_sha256",
    )
    write_immutable(accounting / "BASELINE.json", canonical_json_bytes(b) + b"\n")
    (accounting / "claims").mkdir()
    (accounting / "outcomes").mkdir()
    a = w.authorization_draft(ROOT)
    now = datetime.now(UTC)
    a.update(
        status="FINAL_W0_EXECUTION_AUTHORIZATION",
        fixture_only=True,
        human_attestation=True,
        source_instruction="SYNTHETIC TEST ONLY NOT A HUMAN PERMIT",
        source_evidence="offline fixture only",
        approved_at=now.isoformat(),
        start_before=(now + timedelta(hours=1)).isoformat(),
        execution_root=str(destination),
        accounting_root=str(accounting),
        baseline_file_sha256=sha256_file(accounting / "BASELINE.json"),
        governance={"status":"CARRIED_FORWARD_NO_NEW_SIGNATURE",
                    "source_authorization_file_sha256":retained["governance"]["source_authorization_file_sha256"]},
    )
    for key in ("observation", "judge", "delegated_agent_calibration_review"):
        a["permissions"][key] = True
    prepared = {
        "status": "PREPARED_NOT_AUTHORIZED",
        "plan_id": a["plan_id"],
        "plan_sha256": a["plan_sha256"],
        "release_sha256": a["release_sha256"],
        "baseline_file_sha256": a["baseline_file_sha256"],
        "execution_root": str(destination),
        "accounting_root": str(accounting),
        "prior_requests": 55,
        "maximum_new_requests": 533,
        "maximum_cumulative_requests": 588,
        "API_execution_authorized": False,
        "synthetic_test_only": True,
    }
    write_immutable(destination / "PREPARATION.json", canonical_json_bytes(prepared) + b"\n")
    a["preparation_file_sha256"] = sha256_file(destination / "PREPARATION.json")
    return a



def test_draft_and_fixture_cannot_read_real_keys_or_send(monkeypatch, tmp_path, retained):
    monkeypatch.setattr(w, "resolve_credentials", lambda *a, **k: pytest.fail("key read"))
    a = w.authorization_draft(ROOT)
    assert not any(a["permissions"].values()) and not a["human_attestation"] and "records" not in a
    with pytest.raises(ValidationError):
        w.run(ROOT, a, execute_approved=True)
    with pytest.raises(ValidationError):
        w.run(ROOT, permit(tmp_path, retained), execute_approved=True)


def test_all_old_labels_and_raw_are_exact_with_a_separate_primary_view(tmp_path, retained):
    ctx = w.authorize(ROOT, permit(tmp_path, retained), execute_approved=True, simulation=True)
    p = ctx["parent"]
    assert len(p["retained_ratings"]) == 22 and sum(x["valid"] for x in p["retained_ratings"]) == 12
    assert sum(x["primary"]["valid"] for x in p["retained_views"]) == 19
    assert all(x["legacy_full_rating"] == old for x, old in zip(p["retained_views"], p["retained_ratings"]))
    jobs = w.expected_jobs(ctx, p["batch"])
    assert len(jobs) == 83 and not ({x["request_id"] for x in p["retained_ratings"]} & {j["method_request_id"] for j in jobs})
    assert all(w.judge_job(q, "calibration") == old.judge_job(q, "calibration") for q in p["batch"]["requests"])


@pytest.mark.parametrize("fault", ["cap", "prior", "publication", "W01", "human", "governance", "policy-release"])
def test_bad_authority_fails_before_HTTP(tmp_path, retained, fault):
    a = permit(tmp_path, retained)
    if fault == "cap": a["maximum_requests"]["calibration"] += 1
    elif fault == "prior": a["prior_requests"] = 54
    elif fault in ("publication", "W01"): a["permissions"][fault] = True
    elif fault == "human": a["human_attestation"] = 1
    elif fault == "governance": a["governance"]["source_authorization_file_sha256"] = "changed"
    else: a["release_sha256"] = old.load_plan(ROOT)["lock"]["release_sha256"]
    calls = []
    with pytest.raises(ValidationError):
        w.run(ROOT, a, execute_approved=True, simulation_transport=transport(calls))
    assert calls == []


def test_deadline_and_retained_resend_caps_and_review_gates(tmp_path, retained):
    a = permit(tmp_path, retained)
    ctx = w.authorize(ROOT, a, execute_approved=True, simulation=True)
    with pytest.raises(ValidationError, match="original W0 72-hour"):
        w.authorize(ROOT, a, execute_approved=True, simulation=True, now=ctx["started_at"]+timedelta(hours=73))
    calls = []
    s = w.Session(ctx, dict.fromkeys(w.KEY_NAMES, "fixture-only"), transport=transport(calls), sleep=lambda _: None)
    try:
        for logical in ctx["parent"]["batch"]["requests"][:22]:
            with pytest.raises(ValidationError):
                s.exchange(w.judge_job(logical, "calibration"))
        with pytest.raises(ValidationError):
            s.exchange(w.fixed_jobs(ctx["plan"], "collection")[0])
        for phase in w.COUNTS:
            counts = dict(w.COUNTS)
            counts[phase] += 1
            with pytest.raises(ValidationError): w.ledger.Ledger._caps(counts)
        assert calls == [] and s.ledger.summary()["cumulative_requests"] == 55
    finally:
        s.close()


def test_HTTP_failure_consumes_one_and_never_retries(tmp_path, retained):
    a, calls = permit(tmp_path, retained), []
    with pytest.raises(ValidationError, match="HTTP/transport/format"):
        w.run(ROOT, a, execute_approved=True, simulation_transport=transport(calls, failure="http"), sleep=lambda _: None)
    assert len(calls) == 1
    outcome = json.loads((Path(a["accounting_root"]) / "outcomes/000001.json").read_text("utf-8"))
    assert outcome["outcome_class"] == "TECHNICAL_FAILURE"
    with pytest.raises(ValidationError):
        w.run(ROOT, a, execute_approved=True, simulation_transport=transport(calls), sleep=lambda _: None)
    assert len(calls) == 1


def test_complete_533_request_flow_preserves_legacy_failure_with_primary_calibration(tmp_path, retained):
    a, calls = permit(tmp_path, retained), []
    original = filemap(retained["root"])
    normal = transport(calls)
    def respond(request):
        response = normal.handle_request(request)
        body = json.loads(request.content)
        judge = any(k in body for k in ("system", "instructions", "systemInstruction"))
        if judge:
            provider = {"api.anthropic.com": "anthropic", "generativelanguage.googleapis.com": "gemini", "api.openai.com": "openai"}[request.url.host]
            # Explicitly incomplete auxiliary output: no coercion, but primary is intact.
            return alter_json_response(response, provider, {"REFUSAL_TYPE": None})
        return response
    mock = httpx.MockTransport(respond)
    stage = w.run(ROOT, a, execute_approved=True, simulation_transport=mock, sleep=lambda _: None)
    assert len(calls) == 83 and stage["cumulative_accounting"]["cumulative_requests"] == 138
    directory = Path(a["execution_root"])
    result = json.loads((directory / "calibration-result.json").read_text("utf-8"))
    aggregation = result["aggregation"]
    assert len(result["ratings"]) == 105
    assert aggregation["primary_quality_report"]["valid_rating_fraction"] == 102/105
    assert aggregation["primary_quality_report"]["primary_calibration_guards_passed"] is True
    assert aggregation["legacy_full_aggregation"]["quality_report"]["technical_calibration_guards_passed"] is False
    assert all(not x["legacy_full_judgment_valid"] for x in result["ratings"][22:])
    with pytest.raises((OSError, ValueError, ValidationError)):
        review.continue_after_calibration(ROOT, a, execute_approved=True, simulation_transport=mock, sleep=lambda _: None)
    assert len(calls) == 83
    named = review.record_agent_review(ROOT, a, reviewer="synthetic AGENT", review_note="offline contract separation only", simulation=True)
    assert named["analysis_policy"] == w.validity.VERSION and named["legacy_v1_4_failure_preserved"]
    final = review.continue_after_calibration(ROOT, a, execute_approved=True, simulation_transport=mock, sleep=lambda _: None)
    assert len(calls) == 533 and all(c.method == "POST" for c in calls)
    assert final["cumulative_accounting"]["cumulative_requests"] == 588
    assert final["fresh_answers"] == 150 and final["main_ratings"] == 300 and final["counts"] == w.COUNTS
    assert final["real_API_calls"] == 0 and not final["pilot_passed"] and not final["W01_authorized"]
    assert filemap(retained["root"]) == original
    main = json.loads((directory / "main-result.json").read_text("utf-8"))
    assert all(x["auxiliary_consensus"]["REFUSAL_TYPE"]["status"] == "NOT_JOINTLY_AVAILABLE" for x in main["aggregation"]["primary_responses"])
    assert main["aggregation"]["primary_quality_report"]["primary_numeric_quality_checks_passed"]
    with pytest.raises(ValidationError):
        review.continue_after_calibration(ROOT, a, execute_approved=True, simulation_transport=mock, sleep=lambda _: None)
    assert len(calls) == 533

def test_deadline_rechecked_after_pacing_before_claim_or_HTTP(tmp_path, retained, monkeypatch):
    a = permit(tmp_path, retained)
    ctx = w.authorize(ROOT, a, execute_approved=True, simulation=True)
    calls = []
    s = w.Session(ctx, dict.fromkeys(w.KEY_NAMES, "fixture-only"), transport=transport(calls), sleep=lambda _: None)
    deadline = s.started + timedelta(hours=72)
    class Clock(datetime):
        current = deadline - timedelta(milliseconds=500)
        @classmethod
        def now(cls, tz=None):
            return cls.current
    def cross(_):
        Clock.current = deadline + timedelta(milliseconds=500)
    s.sleep, s.last_call = cross, w.time.monotonic()
    monkeypatch.setattr(w, "datetime", Clock)
    try:
        with pytest.raises(ValidationError, match="expired after pacing"):
            s.exchange(w.expected_jobs(ctx, ctx["parent"]["batch"])[0])
        assert calls == [] and s.ledger.summary()["cumulative_requests"] == 55
        assert not any(Path(a["accounting_root"]).joinpath("claims").iterdir())
    finally:
        s.close()

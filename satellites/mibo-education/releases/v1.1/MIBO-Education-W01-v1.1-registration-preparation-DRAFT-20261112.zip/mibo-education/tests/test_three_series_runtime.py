from __future__ import annotations

import copy
import json
from collections import Counter
from pathlib import Path

import httpx
import pytest

from miboe import calibration_review, reciprocal
from miboe import offline_rehearsal as fixtures
from miboe import three_series as t
from miboe.cli import main, parser
from miboe.errors import ImmutabilityError, ValidationError
from miboe.util import canonical_json_bytes, sha256_bytes, sha256_file

ROOT = Path(__file__).resolve().parents[1]


@pytest.fixture(scope="module")
def plan():
    return t.build_collection(ROOT, fixtures.MODELS)


def test_policy_approval_is_not_a_backdated_schedule_or_execution():
    status = t.status(ROOT)
    assert status["W01_future_after_W0_policy_approved"] is True
    assert status["collection_and_judging_wire_path_implemented"] is True
    for name in (
        "W01_anchor_locked",
        "live_dispatch_enabled",
        "API_calls_authorized",
        "pilot_passed",
        "official_wave_ready",
        "calibration_content_review_completed",
    ):
        assert status[name] is False
    assert sha256_file(ROOT / "waves/W01/scientific-manifest-v1.0.yaml") == (
        "ecb5b5aa779d0806cb034581d76ab1c128587f1b9590a7b482fc3fa93336a6f1"
    )
    assert t.load_runtime(ROOT)["policy"]["actual_source_models"] == dict.fromkeys(t.FAMILIES)


def test_150_native_collection_payloads_preserve_prompts_and_required_controls(plan):
    assert len(plan["requests"]) == 150
    assert Counter(r["source_series"] for r in plan["requests"]) == dict.fromkeys(t.FAMILIES, 50)
    allocation = reciprocal.load_plan(ROOT)["allocation"]["slots"]
    assert [r["slot_id"] for r in plan["requests"]] == [s["slot_id"] for s in allocation]
    for request in plan["requests"]:
        assert request["prompt_sha256"] == sha256_bytes(request["exact_frozen_prompt"].encode())
        body = request["wire"]["body"]
        assert not any(k in body for k in ("tools", "system", "instructions", "systemInstruction"))
        assert request["request_body_sha256"] == sha256_bytes(canonical_json_bytes(body))
        if request["provider"] == "openai":
            assert set(body) == {"model", "input", "store", "stream", "max_output_tokens"}
            assert body["store"] is False and body["stream"] is False
            assert body["max_output_tokens"] == 8192
            assert body["input"][0]["content"][0]["text"] == request["exact_frozen_prompt"]
        elif request["provider"] == "anthropic":
            assert set(body) == {"model", "messages", "stream", "max_tokens"}
            assert body["max_tokens"] == 8192
            assert body["messages"][0] == {
                "role": "user",
                "content": request["exact_frozen_prompt"],
            }
        else:
            assert set(body) == {"contents", "generationConfig"}
            assert body["generationConfig"] == {"maxOutputTokens": 8192}
            assert body["contents"][0]["parts"][0]["text"] == request["exact_frozen_prompt"]
        assert "offline-fixture-only" not in json.dumps(request)


@pytest.mark.parametrize(
    "models",
    [
        {"M01": "test-id"},
        {**fixtures.MODELS, "M04": "test-id"},
        {**fixtures.MODELS, "M01": "latest"},
        {**fixtures.MODELS, "M02": None},
        {**fixtures.MODELS, "M03": "models/test-id?key=bad"},
    ],
)
def test_no_defaults_substitutions_aliases_or_extra_series(models):
    with pytest.raises(ValidationError):
        t.build_collection(ROOT, models)


def test_preparation_does_not_read_keys_or_redirect_via_environment(monkeypatch):
    for key in ("OPENAI_API_KEY", "ANTHROPIC_API_KEY", "GEMINI_API_KEY"):
        monkeypatch.delenv(key, raising=False)
    monkeypatch.setenv("MIBOE_OPENAI_BASE_URL", "https://untrusted.invalid")
    monkeypatch.setenv("HTTP_PROXY", "http://untrusted.invalid:1")
    generated = t.build_collection(ROOT, fixtures.MODELS)
    assert all("untrusted" not in r["wire"]["url"] for r in generated["requests"])


@pytest.mark.parametrize("field", ["body", "prompt", "source", "order", "binding"])
def test_rehashed_mutated_collection_is_rejected(plan, field):
    value = copy.deepcopy(plan)
    row = value["requests"][0]
    if field == "body":
        row["wire"]["body"]["tools"] = []
    elif field == "prompt":
        row["exact_frozen_prompt"] += "changed"
    elif field == "source":
        row["provider"] = "perplexity"
    elif field == "order":
        value["requests"].reverse()
    else:
        value["runtime_lock_sha256"] = "wrong"
    value = reciprocal.engine.sealed(
        {k: v for k, v in value.items() if k != "collection_plan_sha256"}, "collection_plan_sha256"
    )
    with pytest.raises(ValidationError, match="differs"):
        t.validate_collection(ROOT, value)


def test_formal_2100_plan_is_deterministic_but_not_executable(tmp_path):
    formal = t.build_collection(
        ROOT, fixtures.MODELS, scope="formal-plan", seed="explicit-test-seed"
    )
    again = t.build_collection(
        ROOT, fixtures.MODELS, scope="formal-plan", seed="explicit-test-seed"
    )
    assert formal == again
    assert len(formal["requests"]) == 2100
    assert Counter(r["source_series"] for r in formal["requests"]) == dict.fromkeys(t.FAMILIES, 700)
    assert (
        len(
            {
                (r["source_series"], r["item_id"], r["replication_number"])
                for r in formal["requests"]
            }
        )
        == 2100
    )
    assert formal["dated_W01_schedule_locked"] is False
    with pytest.raises(ValidationError, match="formal plan cannot execute"):
        t.collect_mock(
            ROOT, formal, tmp_path / "blocked", transport=fixtures.collection_transport(formal)
        )
    assert not (tmp_path / "blocked").exists()


def test_pilot_reseeding_and_formal_missing_seed_are_refused():
    with pytest.raises(ValidationError, match="reseeded"):
        t.build_collection(ROOT, fixtures.MODELS, seed="new-seed")
    with pytest.raises(ValidationError, match="seed"):
        t.build_collection(ROOT, fixtures.MODELS, scope="formal-plan")


def test_live_dispatch_refuses_before_keys_client_or_files(monkeypatch, tmp_path):
    def forbidden(*args, **kwargs):
        raise AssertionError("must not construct HTTP client")

    monkeypatch.setattr(httpx, "Client", forbidden)
    with pytest.raises(ValidationError, match="LIVE DISABLED"):
        t.dispatch_live(output=tmp_path / "live", execute_approved=True)
    assert not (tmp_path / "live").exists()
    with pytest.raises(ValidationError, match="MockTransport"):
        t.MockOnlySender(None)


@pytest.mark.parametrize("provider", list(t.ENDPOINTS))
def test_sender_rejects_arbitrary_endpoints_and_get(provider):
    sender = t.MockOnlySender(httpx.MockTransport(lambda _: pytest.fail("must not send")))
    for wire in (
        {"method": "POST", "url": "https://untrusted.invalid", "body": {}},
        {
            "method": "GET",
            "url": t.ENDPOINTS[provider]
            + ("test-model:generateContent" if provider == "gemini" else ""),
            "body": {},
        },
    ):
        with pytest.raises(ValidationError):
            sender.send(wire, provider)


@pytest.mark.parametrize("status", [307, 400, 429, 500])
def test_http_failure_is_preserved_without_retry(plan, status):
    calls = []

    def response(request):
        calls.append(request)
        return httpx.Response(
            status, headers={"location": "https://untrusted.invalid"}, json={"error": "fixture"}
        )

    row = plan["requests"][0]
    result = t.MockOnlySender(httpx.MockTransport(response)).send(row["wire"], row["provider"])
    assert result["http_status"] == status and len(calls) == 1
    record = t._completion(row, {k: v for k, v in result.items() if k != "raw_body"})
    assert not record["eligible_for_scoring"]
    assert record["failure_code"] == "TECHNICAL_FAILURE_OR_INVALID_HTTP_BODY"


def test_timeout_and_malformed_success_have_no_retry(plan):
    row = plan["requests"][0]
    calls = []

    def timeout(request):
        calls.append(request)
        raise httpx.ReadTimeout("fixture timeout")

    result = t.MockOnlySender(httpx.MockTransport(timeout)).send(row["wire"], row["provider"])
    assert result["http_status"] == 0 and len(calls) == 1
    assert result["error_code"] == "TRANSPORT_FAILURE_NO_RETRY"
    bad = t.MockOnlySender(httpx.MockTransport(lambda _: httpx.Response(200, content=b"not JSON")))
    assert bad.send(row["wire"], row["provider"])["raw_body"] == b"not JSON"


@pytest.mark.parametrize("provider", list(t.ENDPOINTS))
def test_returned_identity_missing_or_different_is_hold(plan, provider):
    row = next(r for r in plan["requests"] if r["provider"] == provider)
    body = fixtures.response_body(provider, "other-model", "preserved answer")
    record = t._completion(row, {"http_status": 200, "response_body": body})
    assert record["response_text"] == "preserved answer"
    assert record["scientifically_completed"] and not record["eligible_for_scoring"]
    body.pop("modelVersion" if provider == "gemini" else "model")
    assert not t._completion(row, {"http_status": 200, "response_body": body})[
        "eligible_for_scoring"
    ]


def test_refusal_cap_stop_and_gemini_thought_handling_preserve_data(plan):
    for provider in t.ENDPOINTS:
        row = next(r for r in plan["requests"] if r["provider"] == provider)
        body = fixtures.response_body(provider, row["requested_model"], "回答できません。")
        if provider == "openai":
            body["status"] = "incomplete"
            body["output"][0]["content"] = [{"type": "refusal", "refusal": "回答できません。"}]
        elif provider == "anthropic":
            body["stop_reason"] = "max_tokens"
        else:
            body["candidates"][0]["finishReason"] = "MAX_TOKENS"
            body["candidates"][0]["content"]["parts"].insert(0, {"thought": True, "text": "hidden"})
        record = t._completion(row, {"http_status": 200, "response_body": body})
        assert record["eligible_for_scoring"] and record["refusal_or_cap_is_not_a_retry"]
        assert record["response_text"] == "回答できません。"
        assert record["raw_envelope"]["response_body"] == body


def test_evidence_destination_refuses_repository_and_prior_run(tmp_path):
    with pytest.raises(ValidationError, match="repository"):
        t._private_root(ROOT, ROOT / "should-not-exist")
    with pytest.raises(ValidationError, match="absolute"):
        t._private_root(ROOT, Path("relative"))
    target = tmp_path / "evidence"
    t._begin(ROOT, target, "test", "binding")
    original = (target / "RUN_STARTED.json").read_bytes()
    with pytest.raises(ImmutabilityError):
        t._begin(ROOT, target, "test", "binding")
    assert (target / "RUN_STARTED.json").read_bytes() == original


@pytest.mark.parametrize("provider", list(t.ENDPOINTS))
def test_unrequested_tool_output_is_preserved_but_not_scored(plan, provider):
    row = next(r for r in plan["requests"] if r["provider"] == provider)
    body = fixtures.response_body(provider, row["requested_model"], "visible response")
    if provider == "openai":
        body["output"].append({"type": "function_call"})
    elif provider == "anthropic":
        body["content"].append({"type": "tool_use"})
    else:
        body["candidates"][0]["content"]["parts"].append({"functionCall": {"name": "tool"}})
    record = t._completion(row, {"http_status": 200, "response_body": body})
    assert record["raw_envelope"]["response_body"] == body
    assert record["failure_code"] == "UNEXPECTED_TOOL_OR_RESPONSE_SHAPE"
    assert not record["eligible_for_scoring"]


def test_case_review_has_exact_35_answers_all_anchors_and_no_approval():
    review = calibration_review.review_data(ROOT)
    assert review["case_count"] == 35 and not review["owner_content_review_completed"]
    assert review["authored_examples_not_validated_gold"] is True
    rendered = calibration_review.render_html(ROOT)
    assert '<html lang="ja">' in rendered and "default-src" in rendered
    assert "<script" not in rendered and "未承認" in rendered
    for case in review["cases"]:
        assert rendered.count('id="' + case["case_id"] + '"') == 1
        assert case["owner_content_review"] == "PENDING"
        assert set(case["all_frozen_anchors"]) == set("01234")
    assert sha256_file(ROOT / reciprocal.BANK) == review["bank_sha256"]


def test_cli_only_exposes_mock_preparation_and_no_execution_switch(capsys):
    assert main(["preparation", "status", "--root", str(ROOT)]) == 0
    assert json.loads(capsys.readouterr().out)["mode"] == "MOCK_ONLY"
    for arguments in (["preparation", "execute"], ["preparation", "status", "--execute-approved"]):
        with pytest.raises(SystemExit):
            parser().parse_args(arguments)


def test_full_http_roundtrip_150_300_and_35_105_keeps_readiness_false(tmp_path):
    result = fixtures.run(ROOT, tmp_path / "roundtrip")
    assert result["synthetic_source_answers"] == 150
    assert result["synthetic_main_ratings"] == 300
    assert result["synthetic_calibration_cases"] == 35
    assert result["synthetic_calibration_ratings"] == 105
    assert (
        result["main_ratings_valid_in_fixtures"] and result["calibration_ratings_valid_in_fixtures"]
    )
    assert result["main_numeric_guards_on_synthetic_data"]
    assert result["calibration_numeric_guards_on_synthetic_data"]
    assert result["real_API_calls"] == 0 and not result["real_credentials_used"]
    assert not result["pilot_passed"] and not result["common_calibration_cleared"]
    for path in (tmp_path / "roundtrip").glob("*/L0_raw/*/request.json"):
        request = json.loads(path.read_text(encoding="utf-8"))
        assert "offline-fixture-only" not in path.read_text(encoding="utf-8")
        assert not any(
            k.lower() in {"authorization", "x-api-key", "x-goog-api-key"}
            for k in request.get("headers", {})
        )
        assert path.with_name("request.body").read_bytes() == canonical_json_bytes(request["body"])
        envelope = json.loads(path.with_name("response.json").read_text(encoding="utf-8"))
        raw = path.with_name("response.body").read_bytes()
        assert sha256_bytes(raw) == envelope["response_body_sha256"]
        assert json.loads(raw) == envelope["response_body"]
    source = json.loads((tmp_path / "roundtrip/collection/RUN_FINISHED.json").read_text("utf-8"))
    source_plan = t.build_collection(ROOT, fixtures.MODELS)
    original_plan = source["collection_plan_sha256"]
    assert original_plan == source_plan["collection_plan_sha256"]
    for mutation in ("missing", "duplicate", "tampered"):
        altered = copy.deepcopy(source)
        if mutation == "missing":
            altered["records"].pop()
        elif mutation == "duplicate":
            altered["records"][0] = altered["records"][1]
        else:
            altered["records"][0]["response_text"] = "silently repaired answer"
        altered = reciprocal.engine.sealed(
            {k: v for k, v in altered.items() if k != "collection_result_sha256"},
            "collection_result_sha256",
        )
        with pytest.raises(ValidationError):
            t.main_batch_from_collection(ROOT, source_plan, altered, salt=fixtures.SALT)
    with pytest.raises(ValueError, match="new and empty"):
        fixtures.run(ROOT, tmp_path / "roundtrip")

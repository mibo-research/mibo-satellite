"""Offline AC-lifecycle, fixed-budget and same-trial source186 continuation tests."""
from __future__ import annotations
import copy
from datetime import timedelta
from pathlib import Path
import httpx
import pytest
from miboe import evidence_ev31_awake_retry as a, evidence_ev31_source_retry as parent
from miboe import evidence_ev31_runtime as rt, scoring, reciprocal_engine as e
from miboe.ac_awake_v1 import ACPowerGuard, PowerGuardError
from miboe.util import sha256_file as sha
from test_ev31_source_retry import checkpoint as prefix168
from test_ev31_continuation import filemap, assert_prefix_unchanged, immutable_fixture_plan_cache  # noqa:F401

ROOT = Path(__file__).resolve().parents[1]


class FakePower:
    def __init__(self, *, online=True, fail_set=None, fail_create=False, fail_close=False):
        self.online, self.fail_set, self.fail_create, self.fail_close = online, fail_set, fail_create, fail_close
        self.calls, self.active, self.open_handles = [], set(), set()
    def ac_online(self): return self.online
    def create(self):
        if self.fail_create: raise PowerGuardError("OFFLINE create failure")
        self.calls.append(("create", 1)); self.open_handles.add(1); return 1
    def set(self, h, k):
        self.calls.append(("set", k))
        if k == self.fail_set: return False
        self.active.add(k); return True
    def clear(self, h, k): self.calls.append(("clear", k)); self.active.discard(k); return True
    def close(self, h):
        self.calls.append(("close", h))
        if self.fail_close: return False
        self.open_handles.discard(h); return True


@pytest.mark.parametrize("exit_kind", ["normal", "exception"])
def test_power_requests_scoped_and_released_without_display_away_or_settings(exit_kind):
    power = FakePower(); guard = ACPowerGuard(power, watch=False)
    try:
        with guard:
            guard.require_ready(); assert power.active == {1, 3}
            if exit_kind == "exception": raise RuntimeError("OFFLINE operation failure")
    except RuntimeError: assert exit_kind == "exception"
    assert not power.active and not power.open_handles
    assert [k for op, k in power.calls if op == "set"] == [1, 3]
    assert guard.snapshot()["own_handle_close_verified"] and not guard.snapshot()["permanent_power_settings_changed"]


@pytest.mark.parametrize("mode", ["battery", "unknown", "create", "set-system", "set-execution"])
def test_power_setup_failure_cleans_partial_requests_and_never_starts(mode):
    power = FakePower(online=mode not in {"battery", "unknown"}, fail_create=mode == "create",
        fail_set=1 if mode == "set-system" else 3 if mode == "set-execution" else None)
    guard = ACPowerGuard(power, watch=False)
    with pytest.raises(PowerGuardError): guard.__enter__()
    assert not power.active and not power.open_handles and not guard.active


def test_AC_loss_clears_immediately_and_never_auto_reacquires():
    power = FakePower(); guard = ACPowerGuard(power, watch=False)
    with guard:
        power.online = False; assert not guard.poll()
        assert not power.active and not power.open_handles
        power.online = True
        with pytest.raises(PowerGuardError): guard.require_ready()
    assert sum(op == "create" for op, _ in power.calls) == 1


def test_suspend_or_long_power_monitor_gap_is_not_overridden():
    ticks = [0.0]; power = FakePower(); guard = ACPowerGuard(power, watch=False, clock=lambda: ticks[0])
    with guard:
        ticks[0] = 31
        with pytest.raises(PowerGuardError): guard.require_ready()
        assert guard.lost_reason == "POWER_MONITOR_GAP_OR_SUSPEND"
        assert not power.active and not power.open_handles


def test_unverified_handle_cleanup_is_not_silently_certified():
    power = FakePower(fail_close=True); guard = ACPowerGuard(power, watch=False)
    with pytest.raises(PowerGuardError):
        with guard: pass
    assert guard.snapshot()["own_handle_close_verified"] is False


def test_AC_loss_rejects_exchange_before_ledger_or_model_access():
    power = FakePower(); guard = ACPowerGuard(power, watch=False)
    with guard:
        power.online = False
        session = a.Session.__new__(a.Session); session.guard = guard
        with pytest.raises(PowerGuardError): session.exchange({"phase": "collection"})
    assert not power.active


def make186(tmp_path, extra_faults=None):
    old, prior, state, transport, _, fake = prefix168(tmp_path, {186: "source_transport", **(extra_faults or {})})
    original, run, accounting, _ = old
    with pytest.raises(ValueError):
        parent.run(ROOT, prior, execute_approved=True, simulation_transport=transport, sleep=lambda _: None)
    assert state["calls"] == 186 and fake.source_count == 73
    side = tmp_path / "awake"; side.mkdir()
    prefix = e.sealed({"initial_requests": 186, "fixture_only": True,
        "original_authorization_sha256": e.digest(original),
        "RUN_STARTED_file_sha256": sha(run / "RUN_STARTED.json"),
        "last_claim_sha256": scoring.read_json(accounting / "claims/000186.json")["claim_sha256"],
        "preserved_prefix": [{"root": str(run), "files": filemap(run, ("STOP",))},
            {"root": str(accounting), "files": filemap(accounting, ("worker.lease",))}]}, "prefix_sha256")
    rt.save(side / "PREFIX186.json", prefix)
    p = a.load_plan(ROOT); start = scoring.read_json(run / "RUN_STARTED.json")["started_at"]
    g = {"status": a.FINAL, "fixture_only": True, "owner": "笹埜健斗", "actor_type": "HUMAN",
        "human_attestation": True, "API_restart_authorized": True, "release_sha256": p["lock"]["release_sha256"],
        "original_authorization_sha256": e.digest(original), "initial_requests": 186,
        "maximum_additional_requests": 377, "maximum_trial_requests": 563, "maximum_cumulative_requests": 1468,
        "permissions": copy.deepcopy(a.PERMISSIONS), "execution_root": str(run), "awake_root": str(side),
        "prefix_file_sha256": sha(side / "PREFIX186.json"), "original_started_at": start,
        "unchanged_deadline": (rt.stamp(start) + timedelta(hours=72)).isoformat(),
        "source_instruction": "OFFLINE FIXTURE, NOT LIVE OWNER CONSENT", "source_evidence": "pytest MockTransport only"}
    rt.save(side / "authorization.json", g)
    return old, g, state, transport, prefix, fake


def test_full186_plus377_awake_one_new_retry_main_timeout_and_original_data_preserved(tmp_path):
    old, g, state, transport, prefix, fake = make186(tmp_path, {300: "read_timeout"})
    _, run, accounting, _ = old
    power = FakePower(); guard = ACPowerGuard(power, watch=False)
    result = a.run(ROOT, g, execute_approved=True, simulation_transport=transport,
        power_factory=lambda: guard, sleep=lambda _: None)
    assert state["calls"] == 563 and fake.source_count == 150
    assert result["counts"]["new_counts"] == a.CAPS and result["counts"]["cumulative_reservations"] == 1468
    assert result["source_answers"] == 150 and result["source_attempts"] == 152 and result["main_judgments"] == 300
    assert result["primary_numeric_guards_passed"] and result["full_numeric_guards_passed"]
    assert result["pilot_passed"] is False and result["human_gold_validity_or_comparability_established"] is False
    assert_prefix_unchanged(prefix)
    before = scoring.read_json(accounting / "claims/000186.json"); after = scoring.read_json(accounting / "claims/000187.json")
    assert (run / before["raw_relative_path"] / "request.body").read_bytes() == (run / after["raw_relative_path"] / "request.body").read_bytes()
    assert before["job_sha256"] != after["job_sha256"]
    jobs = [scoring.read_json(p)["job_sha256"] for p in (accounting / "claims").glob("*.json")]
    assert len(jobs) == len(set(jobs)) == 563
    assert sum(op == "create" for op, _ in power.calls) == 1 and not power.active and not power.open_handles
    assert guard.snapshot()["own_handle_close_verified"]
    assert rt.ledger.CAPS["collection"] == 150 and parent.CAPS["collection"] == 151
    assert rt.ledger.CUMULATIVE_MAX == 1466
    assert len(list((Path(g["awake_root"]) / "recoveries").glob("*.json"))) == 1
    assert (run / "STOP").is_file()
    response = scoring.read_json(run / scoring.read_json(accounting / "claims/000300.json")["raw_relative_path"] / "response.json")
    assert response["transport_exception_type"] == "ReadTimeout"
    with pytest.raises(ValueError):
        a.run(ROOT, g, execute_approved=True, simulation_transport=transport,
            power_factory=lambda: ACPowerGuard(FakePower(), watch=False), sleep=lambda _: None)
    assert state["calls"] == 563


def test_retry187_failure_is_terminal_never_resent_and_releases_power(tmp_path):
    _, g, state, transport, prefix, _ = make186(tmp_path, {187: "source_transport"})
    power = FakePower(); guard = ACPowerGuard(power, watch=False)
    with pytest.raises(ValueError):
        a.run(ROOT, g, execute_approved=True, simulation_transport=transport, power_factory=lambda: guard, sleep=lambda _: None)
    assert state["calls"] == 187 and not power.active and not power.open_handles
    assert_prefix_unchanged(prefix)
    with pytest.raises(ValueError):
        a.run(ROOT, g, execute_approved=True, simulation_transport=transport,
            power_factory=lambda: ACPowerGuard(FakePower(), watch=False), sleep=lambda _: None)
    assert state["calls"] == 187 and (Path(g["awake_root"]) / "TERMINAL_HOLD.json").is_file()


@pytest.mark.parametrize("status", ["DRAFT_NOT_EXECUTION_AUTHORITY", parent.FINAL])
def test_old_or_DRAFT_authority_stops_before_power_keys_or_files(status):
    with pytest.raises(ValueError):
        a.run(ROOT, {"status": status, "fixture_only": True}, execute_approved=True,
            simulation_transport=httpx.MockTransport(lambda r: pytest.fail("unexpected model call")),
            power_factory=lambda: pytest.fail("DRAFT reached power"), credential_resolver=lambda *a, **k: pytest.fail("DRAFT reached keys"))


@pytest.mark.parametrize("fault", ["additional", "trial", "cumulative", "initial", "clock", "other-retry",
    "replay", "power-override", "power-not-required", "publication", "Core", "W01", "attestation", "actor", "API", "release"])
def test_grant_cannot_expand_scope_or_erase_AC_requirement(fault):
    p = a.load_plan(ROOT); original = {"fixture": "not-live"}
    g = {"status": a.FINAL, "fixture_only": True, "owner": "笹埜健斗", "actor_type": "HUMAN",
        "human_attestation": True, "API_restart_authorized": True, "release_sha256": p["lock"]["release_sha256"],
        "original_authorization_sha256": e.digest(original), "initial_requests": 186, "maximum_additional_requests": 377,
        "maximum_trial_requests": 563, "maximum_cumulative_requests": 1468, "permissions": copy.deepcopy(a.PERMISSIONS),
        "original_started_at": "2026-11-11T02:21:26+00:00", "unchanged_deadline": "2026-11-14T02:21:26+00:00",
        "source_instruction": "OFFLINE", "source_evidence": "OFFLINE"}
    if fault == "additional": g["maximum_additional_requests"] = 378
    if fault == "trial": g["maximum_trial_requests"] = 564
    if fault == "cumulative": g["maximum_cumulative_requests"] = 1469
    if fault == "initial": g["initial_requests"] = 185
    if fault == "clock": g["unchanged_deadline"] = "2026-11-15T02:21:26+00:00"
    if fault == "other-retry": g["permissions"]["other_source_retry"] = True
    if fault == "replay": g["permissions"]["metadata_or_calibration_replay"] = True
    if fault == "power-override": g["permissions"]["permanent_power_setting_or_explicit_user_sleep_override"] = True
    if fault == "power-not-required": g["permissions"]["AC_only_active_operation_awake_and_release"] = False
    if fault == "publication": g["permissions"]["publication"] = True
    if fault == "Core": g["permissions"]["Core_restart"] = True
    if fault == "W01": g["permissions"]["W01"] = True
    if fault == "attestation": g["human_attestation"] = False
    if fault == "actor": g["actor_type"] = "AGENT"
    if fault == "API": g["API_restart_authorized"] = False
    if fault == "release": g["release_sha256"] = "unverified"
    with pytest.raises(ValueError): a.validate_grant(p, g, original, True)


@pytest.mark.parametrize("key", ["metadata", "calibration", "collection", "main"])
def test_phase_and_total_caps_remain_hard(key):
    counts = dict(a.CAPS); counts[key] += 1
    with pytest.raises(ValueError): a.Ledger.check_caps(counts)

from __future__ import annotations

import copy
import json
from pathlib import Path

import pytest

from miboe import offline_rehearsal as fixture
from miboe import reciprocal as r
from miboe import reciprocal_engine as e
from miboe import schema_wire_v14 as wire
from miboe.util import canonical_json_bytes

ROOT = Path(__file__).resolve().parents[1]


@pytest.fixture(scope="module")
def batch():
    return r.build_batch(ROOT, r.calibration_rows(ROOT, salt="v14-public-offline-wire-fixture" * 2), {}, phase="calibration")


def test_all105_request_differences_are_only_Anthropic_output_config(batch):
    original = canonical_json_bytes(batch)
    seen = dict.fromkeys(("anthropic", "gemini", "openai"), 0)
    plan = r.load_plan(ROOT)
    for logical in batch["requests"]:
        before = copy.deepcopy(logical["body"])
        physical = wire.request(logical)
        bound = wire.binding(logical)
        seen[logical["provider"]] += 1
        assert physical["url"] == logical["endpoint"] and physical["method"] == "POST"
        assert bound["logical_method_request_id"] == logical["request_id"]
        assert bound["physical_body_sha256"] == e.digest(physical["body"])
        assert bound["logical_body_sha256"] == e.digest(logical["body"])
        if logical["provider"] == "anthropic":
            del before["output_config"]
            assert physical["body"] == before
            assert physical["body"]["messages"] == logical["body"]["messages"]
            assert physical["body"]["system"] == logical["body"]["system"]
            assert json.loads(physical["body"]["messages"][0]["content"])["output_schema"] == plan["legacy"]["schema"]
            assert "output_config" not in physical["body"] and not physical["body"].get("tools")
            assert bound["native_grammar_enforcement"] is False
        else:
            assert canonical_json_bytes(before) == canonical_json_bytes(physical["body"])
            assert bound["native_grammar_enforcement"] is True
    assert seen == dict.fromkeys(seen, 35)
    assert canonical_json_bytes(batch) == original


@pytest.mark.parametrize("fault", ["tools", "tool-choice", "extra-output-control", "wrong-format", "missing-prompt-schema", "altered-native-schema"])
def test_unapproved_wire_controls_fail_closed(batch, fault):
    logical = copy.deepcopy(next(q for q in batch["requests"] if q["provider"] == "anthropic"))
    body = logical["body"]
    if fault == "tools":
        body["tools"] = [{"name":"unapproved"}]
    elif fault == "tool-choice":
        body["tool_choice"] = {"type":"auto"}
    elif fault == "extra-output-control":
        body["output_config"]["effort"] = "high"
    elif fault == "wrong-format":
        body["output_config"]["format"]["type"] = "other"
    elif fault == "altered-native-schema":
        body["output_config"]["format"]["schema"] = {"type":"object"}
    else:
        user = json.loads(body["messages"][0]["content"])
        user["output_schema"] = {}
        body["messages"][0]["content"] = e.canonical(user)
    logical["body_sha256"] = e.digest(body)
    del logical["request_id"]
    logical = e.sealed(logical, "request_id")
    with pytest.raises((ValueError, KeyError)):
        wire.request(logical)


def envelope(q, text):
    return {
        "request_id":q["request_id"], "http_status":200,
        "received_at":"2026-11-08T00:00:00+00:00",
        "response_body":fixture.response_body("anthropic",q["requested_model"],text),
    }


def test_all35_valid_results_use_unchanged_frozen_validator(batch):
    plan = r.load_plan(ROOT)
    for i, q in enumerate(q for q in batch["requests"] if q["provider"] == "anthropic"):
        row = batch["observations"][q["observation_id_blind"]]
        judgment = fixture.synthetic_judgment(plan, row, i % 5)
        r.legacy.validate_judgment(plan["legacy"], row, judgment)
        wire.request(q)
        raw = envelope(q, e.canonical(judgment))
        rated = r.import_many(ROOT,batch,[raw])[0]
        assert rated["valid"] is True and rated["judgment"] == judgment
        assert rated["raw_envelope"] == raw


@pytest.mark.parametrize("fault", [
    "fence", "malformed-json", "duplicate-key", "extra-key", "missing-field",
    "score-range", "wrong-id", "wrong-anchor", "invented-quote", "missing-evidence",
    "nullable-required-code", "numeric-boolean", "E4-total", "E2-outside-domain",
])
def test_malformed_or_semantically_invalid_JSON_never_repaired(batch, fault):
    plan = r.load_plan(ROOT)
    q = next(q for q in batch["requests"] if q["provider"] == "anthropic"
             and batch["observations"][q["observation_id_blind"]]["item_id"].startswith("E4-"))
    row = batch["observations"][q["observation_id_blind"]]
    result = fixture.synthetic_judgment(plan,row,2)
    if fault == "extra-key":
        result["invented"] = True
    elif fault == "missing-field":
        del result["codes"]["DIRECT_ANSWER"]
    elif fault == "score-range":
        result["primary_score"] = 5
    elif fault == "wrong-id":
        result["observation_id_blind"] = "B-" + "0"*32
    elif fault == "wrong-anchor":
        result["anchor_reference"] = row["item_id"] + ":3"
    elif fault == "invented-quote":
        result["evidence"] = ["OFFLINE INVENTED QUOTE NOT IN RESPONSE"]
    elif fault == "missing-evidence":
        result["evidence"] = []
    elif fault == "nullable-required-code":
        result["codes"]["DIRECT_ANSWER"] = None
    elif fault == "numeric-boolean":
        result["codes"]["DIRECT_ANSWER"] = 0
    elif fault == "E4-total":
        result["codes"].update(MODEL_SCORE_PARSEABLE=True, MODEL_ASSIGNED_ACCURACY_SCORE=1,
                              MODEL_ASSIGNED_REASONING_SCORE=1, MODEL_ASSIGNED_EXPLANATION_SCORE=1,
                              MODEL_ASSIGNED_TOTAL_SCORE=4)
    elif fault == "E2-outside-domain":
        result["codes"]["E2_SUPPORT_QUALITY"] = 3
    text = e.canonical(result)
    if fault == "fence":
        text = "\x60\x60\x60json\\n" + text + "\\n\x60\x60\x60"
    elif fault == "malformed-json":
        text = text[:-1]
    elif fault == "duplicate-key":
        text = text[:-1] + ',"primary_score":2}'
    raw = envelope(q,text)
    saved = canonical_json_bytes(raw)
    wire.request(q)
    rated = r.import_many(ROOT,batch,[raw])[0]
    assert rated["valid"] is False and rated["judgment"] is None
    assert rated["raw_envelope"] == raw
    assert canonical_json_bytes(raw) == saved

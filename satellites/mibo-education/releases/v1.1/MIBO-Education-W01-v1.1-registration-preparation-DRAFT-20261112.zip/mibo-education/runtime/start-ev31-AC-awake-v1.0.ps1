param([Parameter(Mandatory = $true)][string]$Authorization)
$ErrorActionPreference = 'Stop'
$educationRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$permitPath = (Resolve-Path -LiteralPath $Authorization).Path
$permit = Get-Content -LiteralPath $permitPath -Raw | ConvertFrom-Json
if ($permit.status -ne 'FINAL_EV31_AC_AWAKE_SOURCE186_RETRY_EXECUTION' -or $permit.fixture_only -ne $false -or $permit.API_restart_authorized -ne $true) { throw 'Verified FINAL conditional restart approval required; DRAFT never sends.' }
$approvalDirectory = Split-Path -Parent $permitPath
$pidPath = Join-Path $approvalDirectory 'worker-pid.json'
if (Test-Path -LiteralPath $pidPath) { throw 'Already launched; no automatic relaunch or source retry.' }
$pythonPath = 'C:/Users/offic/AppData/Local/Programs/Python/Python313/python.exe'
$savedEnvironment = @{}
foreach ($envName in @('PYTHONPATH','APPDATA','COMSPEC','PATHEXT','ANTHROPIC_API_KEY')) { $savedEnvironment[$envName] = [Environment]::GetEnvironmentVariable($envName,'Process') }
try {
    $env:PYTHONPATH = Join-Path $educationRoot 'src'
    $env:APPDATA = [Environment]::GetFolderPath('ApplicationData')
    $env:COMSPEC = 'C:/Windows/System32/cmd.exe'
    $env:PATHEXT = '.COM;.EXE;.BAT;.CMD'
    # Only a short, local closed-gate check here. The child acquires its own
    # AC-only awake lease BEFORE the long prefix/baseline preflight.
    & $pythonPath -c 'import sys; from pathlib import Path; from miboe import evidence_ev31_awake_retry as r,scoring; r.precheck(Path(sys.argv[1]),scoring.read_json(Path(sys.argv[2])),execute_approved=True)' $educationRoot $permitPath
    if ($LASTEXITCODE -ne 0) { throw 'Local FINAL scope verification failed; no key or child access.' }
    $existingClaudeKey = [Environment]::GetEnvironmentVariable('ANTHROPIC_API_KEY','User')
    if ([string]::IsNullOrWhiteSpace($existingClaudeKey)) { throw 'Existing approved Claude key unavailable.' }
    $env:ANTHROPIC_API_KEY = $existingClaudeKey
    $arguments = @('-u','-m','miboe.evidence_ev31_awake_retry','--root',('"'+$educationRoot+'"'),'--authorization',('"'+$permitPath+'"'),'--execute-approved')
    $process = Start-Process -FilePath $pythonPath -ArgumentList $arguments -WorkingDirectory $educationRoot -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $approvalDirectory 'worker-stdout.log') -RedirectStandardError (Join-Path $approvalDirectory 'worker-stderr.log')
    $record = @{pid=$process.Id;recorded_at_utc=[DateTime]::UtcNow.ToString('o');automatic_relaunch=$false;campaign_id='MIBOE-EV31-PILOT-v1.0'} | ConvertTo-Json -Compress
    $stream=[System.IO.File]::Open($pidPath,[System.IO.FileMode]::CreateNew,[System.IO.FileAccess]::Write,[System.IO.FileShare]::None)
    try { $bytes=[System.Text.UTF8Encoding]::new($false).GetBytes($record+"`n");$stream.Write($bytes,0,$bytes.Length);$stream.Flush($true) } finally { $stream.Dispose() }
    Write-Output ('AC-awake W0 worker launched hidden; PID '+$process.Id+'. No automatic relaunch.')
} finally {
    $existingClaudeKey=$null
    foreach ($envName in $savedEnvironment.Keys) { [Environment]::SetEnvironmentVariable($envName,$savedEnvironment[$envName],'Process') }
    $savedEnvironment.Clear()
}

param(
    [Parameter(Mandatory = $true)][string]$AuthorizationPath,
    [switch]$ContinueAfterCalibration
)
$ErrorActionPreference = 'Stop'
$educationRoot = Split-Path -Parent $PSScriptRoot
$educationSource = Join-Path $educationRoot 'src'
$operation = if ($ContinueAfterCalibration) { 'continue' } else { 'execute' }
# Authorization is validated before any hidden key prompt or HTTP client.
# Keys are never command-line arguments, clipboard output, files or persistent env changes.
$entry = 'import sys; sys.path.insert(0, sys.argv[1]); from miboe.live_w0 import main; sys.exit(main(sys.argv[2:]))'
$runArguments = @($educationSource, $operation, '--root', $educationRoot, '--authorization', $AuthorizationPath, '--execute-approved', '--interactive-keys')
if (-not $ContinueAfterCalibration) { $runArguments += '--wait-for-calibration-review' }
& python -c $entry @runArguments
if ($LASTEXITCODE -ne 0) { throw 'W0 held. Review the scope/window/evidence; do not retry automatically.' }

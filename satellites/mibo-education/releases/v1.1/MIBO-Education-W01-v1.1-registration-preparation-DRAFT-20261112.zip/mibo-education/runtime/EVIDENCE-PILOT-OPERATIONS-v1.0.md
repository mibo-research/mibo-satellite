# EV3 pilot v1.0 operator runbook

This runbook does not authorize APIs. The completed package has169 passing offline tests, including the full561-request MockTransport flow. Actual model and credential-management calls remain0; the real permit is DRAFT and all existing STOP/HOLD gates remain. The old W0 is never resumed or repaired.

## One owner decision

Use the completed `EVIDENCE-PILOT-APPROVAL-v1.0.md` and new35-case review together. Only a subsequent explicit owner instruction approving this new561-request/905-cumulative scope can be transcribed through `evidence_pilot_admin.finalize_authorization`, with that instruction, its conversation provenance and the ready verification report. Do not infer execution approval from package preparation, a file, a fixture or this runbook. No new key input or three governance forms are required.

Before transcription, recheck the ready receipt, plan/release hashes, actual new ledger0 and absence of a FINAL permit. The helper validates the current package and preserves the owner's source instruction. It records a seven-day start deadline; the new72-hour clock is written before the first model request. The old deadline and344 reservations are untouched.

## Same application-owned runtime

Use the Codex app-owned process context that verified the package. Windows MSIX can present the existing private LocalCache under an AppData alias. Do not move historical data, create junctions, override a path guard or rewrite old authorization/binding records to force an outside terminal to accept a different path spelling. If the prepared paths or hashes do not match, hold before credentials or HTTP and diagnose read-only.

## First stage:111 maximum

With the separate FINAL permit only, invoke `start-evidence-pilot-v1.0.ps1 -Authorization <final-permit> -Stage pre-calibration` from that context. The launcher validates and archives only the expected new-run STOP/global HOLD, starts one hidden independent worker and records its PID. The six metadata GETs precede the new105 calibration requests. No extra Smoke, probe, qualification call, model substitution, retry or refill is allowed.

Follow this job in the current chat; do not create a recurring automation. Read only aggregate progress and safe exception types into chat. Raw requests/responses, salts and judgments remain private. All561 model requests are reserved durably in two locations before HTTP; any unknown/pending request consumes its slot. Do not expose credentials or invoke credential lookup during status/offline work.

## Delegated technical review, no extra owner form

After `PRE_CALIBRATION_FINISHED.json`, the worker exits and restores STOP/HOLD. Inspect the new105 raw-bound responses and new calibration result: exact model/observation identities, reference resolution, primary valid/NR fractions, pair agreement/weighted-kappa guards and all separate auxiliary/accuracy/metadata diagnostics. The new synthetic targets are design intentions, not human gold and not model inputs. Do not reuse the old102/105 review or silently repair an invalid response.

Record the actual delegated AGENT finding and substantive note through `evidence_pilot_runtime.record_review`. Acceptance is possible only if the new raw-derived fixed primary guards passed. A failed or semantically unacceptable calibration remains held. Acceptance does not certify every auxiliary field or authorize W01/publication.

## Second stage:450 maximum

Only a matching accepted new review permits `start-evidence-pilot-v1.0.ps1 -Authorization <same-final-permit> -Stage post-review`. This is covered by the same owner decision. The worker creates150 fresh answers,50 per source series, with the frozen item allocation, then300 other-two-family ratings. It does not rescore the old150 answers. The ledger cap is6+105+150+300=561 new and344+561=905 cumulative. Inspect final raw-derived results; `RUN_FINISHED.json` deliberately never declares automatic pilot passage, human validity, comparability or W01 readiness.

## Failure or interruption

The deadline, operator STOP, HTTP/transport/model-identity/tool-shape failure and a mathematically unreachable fixed valid-fraction guard hold the run. Preserve every attempted slot and raw response, including invalid model output and an unresolved claim. No automatic relaunch, resume, resend, repair, threshold change or window/counter reset is allowed. Do not clear an unexpected manual STOP/HOLD. Preserve older STOPs even when an explicitly approved new stage releases its own expected gates.

Publication, GitHub push/merge, Zenodo changes, Core restart, official W01 and credential/IAM/billing changes remain excluded throughout.

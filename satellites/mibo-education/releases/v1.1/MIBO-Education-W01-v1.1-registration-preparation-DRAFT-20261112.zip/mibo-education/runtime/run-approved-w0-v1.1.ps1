param(
    [Parameter(Mandatory = $true)][string]$AuthorizationPath,
    [switch]$ContinueAfterCalibration
)
$ErrorActionPreference = 'Stop'
$educationRoot = Split-Path -Parent $PSScriptRoot
$educationSource = Join-Path $educationRoot 'src'
$operation = if ($ContinueAfterCalibration) { 'continue' } else { 'execute' }
# v1.1 authorization, PREPARATION binding, STOP and global HOLD precede key access.
# Gemini uses only the pinned office-managed key reference; no inherited-key fallback.
$entry = 'import sys; sys.path.insert(0, sys.argv[1]); from miboe.live_w0_v11 import main; sys.exit(main(sys.argv[2:]))'
$runArguments = @($educationSource, $operation, '--root', $educationRoot, '--authorization', $AuthorizationPath, '--execute-approved', '--interactive-keys')
if (-not $ContinueAfterCalibration) { $runArguments += '--wait-for-calibration-review' }
& python -c $entry @runArguments
if ($LASTEXITCODE -ne 0) { throw 'W0 v1.1 held. Preserve the ledger and evidence; do not retry automatically.' }


param(
    [Parameter(Mandatory = $true)][string]$Authorization,
    [ValidateSet('pre-calibration','post-review')][string]$Stage = 'pre-calibration'
)
$ErrorActionPreference = 'Stop'
$educationRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$permitPath = (Resolve-Path -LiteralPath $Authorization).Path
$permit = Get-Content -LiteralPath $permitPath -Raw | ConvertFrom-Json
if ($permit.status -ne 'FINAL_EV31_PILOT_EXECUTION_AUTHORIZATION' -or $permit.fixture_only -ne $false) {
    throw 'Separate FINAL EV31 owner API execution approval is required. DRAFT/content adoption never sends.'
}
$approvalDirectory = Split-Path -Parent $permitPath
$pidPath = Join-Path $approvalDirectory ("worker-" + $Stage + "-pid.json")
if (Test-Path -LiteralPath $pidPath) { throw 'Stage already launched; no automatic replay.' }
$pythonPath = 'C:/Users/offic/AppData/Local/Programs/Python/Python313/python.exe'
if (-not (Test-Path -LiteralPath $pythonPath)) { throw 'Approved Python runtime unavailable.' }
$savedEnvironment = @{}
foreach ($envName in @('PYTHONPATH','APPDATA','COMSPEC','PATHEXT','ANTHROPIC_API_KEY')) {
    $savedEnvironment[$envName] = [Environment]::GetEnvironmentVariable($envName, 'Process')
}
try {
    $env:PYTHONPATH = Join-Path $educationRoot 'src'
    $env:APPDATA = [Environment]::GetFolderPath('ApplicationData')
    $env:COMSPEC = 'C:/Windows/System32/cmd.exe'
    $env:PATHEXT = '.COM;.EXE;.BAT;.CMD'
    # Gate validation is local-only. No resolver or model communication here.
    & $pythonPath -c 'import sys; from pathlib import Path; from miboe import evidence_ev31_runtime as r, scoring; a=scoring.read_json(Path(sys.argv[2])); r.authorize(Path(sys.argv[1]),a,execute_approved=True,continuation=sys.argv[3]=="post-review",preflight_only=True)' $educationRoot $permitPath $Stage
    if ($LASTEXITCODE -ne 0) { throw 'Local FINAL permit verification failed; no child or credential access.' }
    $existingClaudeKey = [Environment]::GetEnvironmentVariable('ANTHROPIC_API_KEY', 'User')
    if ([string]::IsNullOrWhiteSpace($existingClaudeKey)) { throw 'Existing approved Claude key unavailable; no child launched.' }
    $env:ANTHROPIC_API_KEY = $existingClaudeKey
    $stdoutPath = Join-Path $approvalDirectory ("worker-" + $Stage + "-stdout.log")
    $stderrPath = Join-Path $approvalDirectory ("worker-" + $Stage + "-stderr.log")
    $arguments = @('-u','-m','miboe.evidence_ev31_runtime',$Stage,'--root',('"'+$educationRoot+'"'),'--authorization',('"'+$permitPath+'"'),'--execute-approved','--release-gates')
    $process = Start-Process -FilePath $pythonPath -ArgumentList $arguments -WorkingDirectory $educationRoot -WindowStyle Hidden -PassThru -RedirectStandardOutput $stdoutPath -RedirectStandardError $stderrPath
    $record = @{pid=$process.Id;stage=$Stage;recorded_at_utc=[DateTime]::UtcNow.ToString('o');automatic_relaunch=$false;campaign_id='MIBOE-EV31-PILOT-v1.0'} | ConvertTo-Json -Compress
    $stream = [System.IO.File]::Open($pidPath, [System.IO.FileMode]::CreateNew, [System.IO.FileAccess]::Write, [System.IO.FileShare]::None)
    try { $bytes = [System.Text.UTF8Encoding]::new($false).GetBytes($record+"`n");$stream.Write($bytes,0,$bytes.Length);$stream.Flush($true) } finally { $stream.Dispose() }
    Write-Output ('EV31 worker launched hidden; PID '+$process.Id+'. No automatic relaunch.')
} finally {
    $existingClaudeKey = $null
    foreach ($envName in $savedEnvironment.Keys) {
        [Environment]::SetEnvironmentVariable($envName, $savedEnvironment[$envName], 'Process')
    }
    $savedEnvironment.Clear()
}

param([Parameter(Mandatory = $true)][string]$AuthorizationPath, [switch]$ContinueAfterCalibration)
$ErrorActionPreference = 'Stop'
$educationRoot = Split-Path -Parent $PSScriptRoot
$sourceRoot = Join-Path $educationRoot 'src'
$operation = if ($ContinueAfterCalibration) { 'continue' } else { 'execute' }
$entry = 'import sys; sys.path.insert(0,sys.argv[1]); from miboe.live_w0_v13 import main; sys.exit(main(sys.argv[2:]))'
$arguments = @($sourceRoot,$operation,'--root',$educationRoot,'--authorization',$AuthorizationPath,'--execute-approved')
if (-not $ContinueAfterCalibration) { $arguments += '--wait-for-calibration-review' }
& python -c $entry @arguments
if ($LASTEXITCODE -ne 0) { throw 'W0 v1.3 held; no retry or count/clock reset.' }



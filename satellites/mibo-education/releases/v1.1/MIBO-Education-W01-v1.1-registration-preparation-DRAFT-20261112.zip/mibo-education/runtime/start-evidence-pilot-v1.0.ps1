param(
    [Parameter(Mandatory = $true)][string]$Authorization,
    [ValidateSet('pre-calibration','post-review')][string]$Stage = 'pre-calibration'
)
$ErrorActionPreference = 'Stop'
$educationRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$permitPath = (Resolve-Path -LiteralPath $Authorization).Path
$permit = Get-Content -LiteralPath $permitPath -Raw | ConvertFrom-Json
if ($permit.status -ne 'FINAL_EV3_PILOT_EXECUTION_AUTHORIZATION') { throw 'A separate FINAL owner execution permit is required.' }
$workerEvidenceRoot = [System.IO.Path]::GetFullPath([string]$permit.execution_root)
$approvalDirectory = Split-Path -Parent $permitPath
$workerPidPath = Join-Path $approvalDirectory ("worker-" + $Stage + "-pid.json")
if (Test-Path -LiteralPath $workerPidPath) { throw 'This stage has already been launched. Never automatically relaunch it.' }
$env:PYTHONPATH = Join-Path $educationRoot 'src'
$pythonPath = (Get-Command python -ErrorAction Stop).Source
& $pythonPath -m miboe.evidence_pilot_admin release --root $educationRoot --authorization $permitPath --stage $Stage --execute-approved
if ($LASTEXITCODE -ne 0) { throw 'Owner gate or stage-release verification failed. No worker launched.' }
$stdoutPath = Join-Path $approvalDirectory ("worker-" + $Stage + "-stdout.log")
$stderrPath = Join-Path $approvalDirectory ("worker-" + $Stage + "-stderr.log")
$arguments = @('-u','-m','miboe.evidence_pilot_runtime',$Stage,'--root',('"'+$educationRoot+'"'),'--authorization',('"'+$permitPath+'"'),'--execute-approved')
$process = Start-Process -FilePath $pythonPath -ArgumentList $arguments -WorkingDirectory $educationRoot -WindowStyle Hidden -PassThru -RedirectStandardOutput $stdoutPath -RedirectStandardError $stderrPath
$pidRecord = @{pid=$process.Id; stage=$Stage; recorded_at_utc=[DateTime]::UtcNow.ToString('o'); automatic_relaunch=$false; evidence_root=$workerEvidenceRoot} | ConvertTo-Json -Compress
$stream = [System.IO.File]::Open($workerPidPath, [System.IO.FileMode]::CreateNew, [System.IO.FileAccess]::Write, [System.IO.FileShare]::None)
try { $bytes = [System.Text.UTF8Encoding]::new($false).GetBytes($pidRecord + "`n"); $stream.Write($bytes,0,$bytes.Length); $stream.Flush($true) } finally { $stream.Dispose() }
Write-Output ("Worker launched hidden; PID " + $process.Id + ". No automatic relaunch.")

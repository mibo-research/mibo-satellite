param([Parameter(Mandatory=$true)][string]$Authorization,[Parameter(Mandatory=$true)][ValidateSet('preflight','collection','main')][string]$Stage)
$ErrorActionPreference='Stop'
$educationRoot=(Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$permitPath=(Resolve-Path -LiteralPath $Authorization).Path
$permit=Get-Content -LiteralPath $permitPath -Raw | ConvertFrom-Json
if ($permit.status -ne 'FINAL_W01_V11_REGISTERED_EXECUTION_AUTHORIZATION' -or $permit.fixture_only -ne $false) { throw 'W01 preparation/DRAFT cannot start model or power operations.' }
$pythonPath='C:/Users/offic/AppData/Local/Programs/Python/Python313/python.exe'
$taskPid=Join-Path (Split-Path -Parent $permitPath) ($Stage+'-worker-pid.json')
if (Test-Path -LiteralPath $taskPid) { throw 'Stage already launched; inspect receipts. Never double-launch or replay.' }
$launchLease=[System.IO.File]::Open(($taskPid+'.launch-lock'),[System.IO.FileMode]::OpenOrCreate,[System.IO.FileAccess]::ReadWrite,[System.IO.FileShare]::None)
$saved=@{}
foreach ($n in @('PYTHONPATH','APPDATA','COMSPEC','PATHEXT','ANTHROPIC_API_KEY')) {$saved[$n]=[Environment]::GetEnvironmentVariable($n,'Process')}
try {
    if (Test-Path -LiteralPath $taskPid) { throw 'Another launcher already recorded this stage.' }
    $env:PYTHONPATH=Join-Path $educationRoot 'src'
    $env:APPDATA=[Environment]::GetFolderPath('ApplicationData')
    $env:COMSPEC='C:/Windows/System32/cmd.exe'
    $env:PATHEXT='.COM;.EXE;.BAT;.CMD'
    & $pythonPath -B -c 'import sys;from pathlib import Path;from miboe import w01_runtime_v11 as r,scoring;r.precheck(Path(sys.argv[1]),scoring.read_json(Path(sys.argv[2])),execute=True)' $educationRoot $permitPath
    if ($LASTEXITCODE -ne 0) { throw 'Future FINAL/registration check failed before credential access.' }
    $existingKey=[Environment]::GetEnvironmentVariable('ANTHROPIC_API_KEY','User')
    if ([string]::IsNullOrWhiteSpace($existingKey)) { throw 'Existing approved Claude credential unavailable.' }
    $env:ANTHROPIC_API_KEY=$existingKey
    $arguments=@('-u','-m','miboe.w01_runtime_v11','--root',('"'+$educationRoot+'"'),'--authorization',('"'+$permitPath+'"'),'--stage',$Stage,'--execute-approved')
    $worker=Start-Process -FilePath $pythonPath -ArgumentList $arguments -WorkingDirectory $educationRoot -WindowStyle Hidden -PassThru -RedirectStandardOutput ($taskPid+'.stdout.log') -RedirectStandardError ($taskPid+'.stderr.log')
    $bytes=[System.Text.UTF8Encoding]::new($false).GetBytes((@{pid=$worker.Id;stage=$Stage;automatic_relaunch=$false}|ConvertTo-Json -Compress)+"`n")
    $stream=[System.IO.File]::Open($taskPid,[System.IO.FileMode]::CreateNew,[System.IO.FileAccess]::Write,[System.IO.FileShare]::None)
    try {$stream.Write($bytes,0,$bytes.Length);$stream.Flush($true)} finally {$stream.Dispose()}
    Write-Output ('Future approved W01 stage launched hidden: '+$Stage+' PID '+$worker.Id)
} finally {
    $existingKey=$null
    foreach($n in $saved.Keys){[Environment]::SetEnvironmentVariable($n,$saved[$n],'Process')}
    $saved.Clear()
    $launchLease.Dispose()
}

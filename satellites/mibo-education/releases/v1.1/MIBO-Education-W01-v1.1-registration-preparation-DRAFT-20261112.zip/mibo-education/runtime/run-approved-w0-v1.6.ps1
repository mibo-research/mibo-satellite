param([Parameter(Mandatory = $true)][string]$AuthorizationPath)
$ErrorActionPreference = 'Stop'
$educationRoot = Split-Path -Parent $PSScriptRoot
$sourceRoot = Join-Path $educationRoot 'src'
$entry = 'import sys; sys.path.insert(0,sys.argv[1]); from miboe.live_w0_v16 import main; sys.exit(main(sys.argv[2:]))'
& python -c $entry $sourceRoot execute --root $educationRoot --authorization $AuthorizationPath --execute-approved
if ($LASTEXITCODE -ne 0) { throw 'W0 v1.6 held; do not retry or reset counts/time.' }

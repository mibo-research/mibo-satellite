"""Explicit v3 production pipeline entrypoint. All operations remain offline."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
from . import reciprocal_evidence_v3 as v3, reciprocal_engine as e, scoring
from .errors import ValidationError


def parser():
    p = argparse.ArgumentParser(prog="miboe-evidence-v3")
    p.add_argument("--root", default=str(Path(__file__).resolve().parents[2]))
    sub = p.add_subparsers(dest="operation", required=True)
    sub.add_parser("status")
    sub.add_parser("execute", help="Closed: implementation approval is not API authority")
    for name in ("prepare", "calibration"):
        q = sub.add_parser(name)
        q.add_argument("--blind-input", required=True, help="JSON array of frozen blind observations")
        if name == "prepare": q.add_argument("--source-map", required=True)
        q.add_argument("--output", required=True)
    q = sub.add_parser("wire")
    q.add_argument("--batch", required=True)
    q.add_argument("--output", required=True)
    q = sub.add_parser("import")
    q.add_argument("--batch", required=True)
    q.add_argument("--responses", required=True)
    q.add_argument("--output", required=True)
    q = sub.add_parser("aggregate")
    q.add_argument("--batch", required=True)
    q.add_argument("--ratings", nargs="+", required=True)
    q.add_argument("--output", required=True)
    return p


def main(argv=None):
    a = parser().parse_args(argv)
    try:
        if a.operation == "execute":
            v3.assert_live_authorized()  # Before files, credentials, transport or any request.
        root = Path(a.root).resolve()
        if a.operation == "status":
            print(json.dumps(v3.status(root)))
            return 0
        if a.operation in {"prepare", "calibration"}:
            rows = scoring.read_json(Path(a.blind_input))
            families = scoring.read_json(Path(a.source_map)) if a.operation == "prepare" else {}
            value = v3.build_batch(root, rows, families, phase="main" if a.operation == "prepare" else "calibration")
            summary = {"batch_sha256": value["batch_sha256"], "requests_prepared": len(value["requests"])}
        else:
            batch = scoring.read_json(Path(a.batch))
            if a.operation == "wire":
                value = v3.wire_artifact(root, batch)
                summary = {"wire_jobs_prepared": len(value["jobs"]), "wire_set_sha256": value["wire_set_sha256"]}
            elif a.operation == "import":
                views = v3.import_many(root, batch, scoring.read_json(Path(a.responses)))
                value = e.sealed({"method_id": v3.METHOD, "batch_sha256": batch["batch_sha256"], "ratings": views}, "rating_set_sha256")
                summary = {"ratings_imported": len(views), "primary_valid": sum(v["primary"]["valid"] for v in views)}
            else:
                views = []
                for filename in a.ratings:
                    saved = scoring.read_json(Path(filename))
                    e.verify(saved, "rating_set_sha256")
                    e.require(saved["method_id"] == v3.METHOD and saved["batch_sha256"] == batch["batch_sha256"], "rating set scope mismatch")
                    views.extend(saved["ratings"])
                value = v3.aggregate(root, batch, views)
                summary = {"responses": len(value["primary_responses"]), "aggregation_sha256": value["aggregation_sha256"], "pilot_passed": False}
        scoring.write_private_artifact(root, Path(a.output), value)
        print(json.dumps({"method_id": v3.METHOD, **summary, "API_calls_made": 0, "restricted_content_printed": False}))
        return 0
    except (ValidationError, ValueError, KeyError, TypeError, OSError):
        print("MIBOE-EVIDENCE-v3 HOLD: closed execution gate or offline input/integrity failure; no API call.")
        return 1


if __name__ == "__main__": raise SystemExit(main())

"""Prospective W01 v1.1 planning and frozen-v3.1 scoring adapter; no I/O dispatch."""
from __future__ import annotations
import copy
from collections import Counter, defaultdict
from datetime import datetime, timedelta
import random
import statistics
from pathlib import Path
from . import evidence_ev31_runtime as native, evidence_ev31_method as method
from . import reciprocal_engine as e, reciprocal as legacy, reciprocal_evidence_v31 as v31
from . import scoring, validity_v15 as components, schema_wire_v14 as wire
from .live_w0_v11 import _source_wire as source_wire
from .util import sha256_file as sha

CAMPAIGN = "MIBOE-W01-v1.1"
MANIFEST = "waves/W01/scientific-manifest-v1.1-DRAFT.json"
CONFIG = "waves/W01/runtime-v1.1-DRAFT.json"
SCHEDULE = "waves/W01/schedule-v1.1-DRAFT.json"
MODELS = "waves/W01/model-lock-v1.1-DRAFT.json"
AMENDMENT = "protocol/amendments/MIBOE-AM-20261112-W01-v1.1-DRAFT.json"
REGISTRATION = "protocol/registration/education-v1.1-DRAFT.json"
DECLARATION = "protocol/registration/finalization-declaration-v1.1.template.json"
LOCK = "runtime/W01-v1.1-preparation.lock.json"
CAPS = {"metadata": 6, "calibration": 105, "collection": 2100, "main": 4200}
PRIOR, NEW_MAX, TOTAL_MAX = 1468, 6411, 7879
ANCHOR = "2026-11-20T00:00:00+00:00"
SEED = "MIBOE-W01-v1.1-20261112-stratified-block"
SITE = "MIBO-SITE-SASANO-WINDOWS-01"
BOUND = {MANIFEST, CONFIG, SCHEDULE, MODELS, AMENDMENT, REGISTRATION, DECLARATION,
    native.LOCK, v31.LOCK, "src/miboe/ac_awake_v1.py", "src/miboe/w01_v11.py",
    "src/miboe/w01_runtime_v11.py", "runtime/start-w01-v1.1.ps1", "tests/test_w01_v11.py"}


def load_plan(root):
    root = Path(root).resolve()
    lock = scoring.read_json(root / LOCK); e.verify(lock, "release_sha256")
    e.require(set(lock["files"]) == BOUND, "W01 release scope differs")
    for n, h in lock["files"].items(): e.require(sha(root / n) == h, "W01 prepared input changed")
    p = native.load_plan(root)
    cfg = scoring.read_json(root / CONFIG); manifest = scoring.read_json(root / MANIFEST)
    schedule = scoring.read_json(root / SCHEDULE); models = scoring.read_json(root / MODELS)
    e.verify(schedule, "schedule_sha256"); e.verify(models, "model_lock_sha256")
    e.require(cfg["caps"] == CAPS and cfg["prior_reserved"] == PRIOR and cfg["maximum_new"] == NEW_MAX
        and cfg["maximum_cumulative"] == TOTAL_MAX, "W01 bounds differ")
    e.require(cfg["source_models"] == p["config"]["source_models"] and cfg["judges"] == p["config"]["judges"]
        and cfg["judge_generation_caps"] == v31.CAPS and cfg["source_generation_cap"] == 8192
        and cfg["timeout_seconds"] == 600 and cfg["minimum_request_spacing_seconds"] == 2
        and cfg["automatic_retries"] == 0, "W0-tested models/controls changed")
    e.require(manifest["anchor_utc_proposed"] == ANCHOR and manifest["target_observation_hours"] == 12
        and manifest["hard_observation_hours"] == 24 and manifest["judging_hours_after_collection"] == 72
        and manifest["status"] == "DRAFT_PENDING_ONE_BUNDLED_OWNER_APPROVAL"
        and cfg["API_authorized"] is False and cfg["publication_authorized"] is False,
        "preparation cannot grant execution/publication authority")
    e.require(manifest["observer_site_id"] == cfg["observer_site_id"] == SITE, "single observer site changed")
    e.require(models["source_models"] == cfg["source_models"] and models["judges"] == cfg["judges"]
        and models["live_verified_for_W01"] is False and models["silent_upgrade_allowed"] is False,
        "candidate IDs must not become new live identity evidence")
    expected = build_schedule(p["method"]["legacy"]["items"], cfg["source_models"])
    e.require(schedule == expected, "formal schedule/prompt/allocation changed")
    return {"root": root, "lock": lock, "config": cfg, "manifest": manifest, "schedule": schedule,
        "models": models, "native": p, "method": p["method"]}


def stamp(value):
    t = datetime.fromisoformat(value.replace("Z", "+00:00"))
    e.require(t.tzinfo is not None, "timezone required"); return t


def build_schedule(items, models):
    e.require(len(items) == 70 and set(models) == {"M01", "M02", "M03"}, "formal70/three sources required")
    strata = defaultdict(list)
    for item in items.values(): strata[item.item_id.split("-")[0]].append(item)
    e.require(set(strata) == {f"E{i}" for i in range(1, 8)} and all(len(x) == 10 for x in strata.values()), "seven balanced domains required")
    rng, rows = random.Random(SEED), []
    for rep in range(1, 11):
        domains = sorted(strata); rng.shuffle(domains)
        for domain in domains:
            block = [(sid, item) for sid in sorted(models) for item in sorted(strata[domain], key=lambda x: x.item_id)]
            rng.shuffle(block)
            for sid, item in block:
                position = len(rows) + 1
                rows.append({"position": position, "slot_id": f"{CAMPAIGN}-{sid}-{item.item_id}-R{rep:02d}",
                    "replication_number": rep, "stratum": domain, "item_id": item.item_id,
                    "source_series": sid, "provider": models[sid]["provider"], "requested_model": models[sid]["requested_model"],
                    "prompt_sha256": item.prompt_sha256,
                    "planned_start_utc": (stamp(ANCHOR) + timedelta(seconds=(position - 1) * 43200 / 2100)).isoformat()})
    return e.sealed({"campaign_id": CAMPAIGN, "proposed_only": True, "seed": SEED,
        "method": "replication-domain-stratified-source-item-randomized-interleaved",
        "anchor_utc": ANCHOR, "rows": rows, "scheduled_not_guaranteed_actual_times": True}, "schedule_sha256")


def source_jobs(p):
    jobs = []
    for slot in p["schedule"]["rows"]:
        item = p["method"]["legacy"]["items"][slot["item_id"]]
        native_wire = source_wire(slot["provider"], slot["requested_model"], item.prompt)
        src = e.sealed({**copy.deepcopy(slot), "exact_frozen_prompt": item.prompt,
            "request_body_sha256": e.digest(native_wire["body"]), "source_family": slot["provider"]}, "request_id")
        jobs.append(native.old._job("collection", slot["provider"], slot["requested_model"], native_wire,
            campaign_id=CAMPAIGN, source=src))
    return jobs


def normalize_source(job, response, *, fixture):
    previous = native.old._source_result(job, response, fixture)
    return e.sealed({**{k: v for k, v in previous.items() if k != "completion_sha256"},
        "prior_normalization_sha256": previous["completion_sha256"], "campaign_id": CAMPAIGN,
        "official_longitudinal_data": not fixture, "protocol_version": "1.1"}, "completion_sha256")


def metadata_jobs(p):
    return [e.sealed({**{k: v for k, v in q.items() if k != "job_sha256"}, "campaign_id": CAMPAIGN}, "job_sha256")
        for q in native.fixed_jobs(p["native"], "metadata")]


def build_batch(p, rows, source_families, *, phase="main", synthetic=False):
    # Only campaign/IDs and allocation scope change. W0-tested prompt/schema/caps,
    # item anchors, reference resolver and first-party body construction are reused.
    old = method.build_batch(p["root"], rows, source_families, phase=phase, synthetic_test_only=synthetic)
    requests = [e.sealed({**{k: v for k, v in q.items() if k != "request_id"}, "campaign_id": CAMPAIGN}, "request_id") for q in old["requests"]]
    core = {k: copy.deepcopy(v) for k, v in old.items() if k != "batch_sha256"}
    core.update(campaign_id=CAMPAIGN, requests=requests, official_longitudinal_data=(phase == "main" and not synthetic),
        prospective_separate_trial=False, official_wave_under_prospective_amendment=True)
    return e.sealed(core, "batch_sha256")


def validate_batch(p, batch):
    e.verify(batch, "batch_sha256")
    e.require(batch["campaign_id"] == CAMPAIGN, "wrong campaign")
    e.require(batch == build_batch(p, list(batch["observations"].values()), batch["private_source_families_never_sent_to_judges"],
        phase=batch["phase"], synthetic=batch["synthetic_test_only"]), "formal batch differs from frozen construction")


def judge_jobs(batch):
    return [native.old._job(batch["phase"], q["provider"], q["requested_model"], wire.request(q),
        campaign_id=CAMPAIGN, method_request_id=q["request_id"], wire_binding=wire.binding(q)) for q in batch["requests"]]


def import_view(p, batch, envelope):
    view = v31._import(p["method"], batch, envelope)
    return e.sealed({**{k: v for k, v in view.items() if k != "view_sha256"}, "campaign_id": CAMPAIGN,
        "synthetic_test_only": batch["synthetic_test_only"], "official_longitudinal_data": batch["official_longitudinal_data"],
        "engineering_only_not_independent_acceptance": batch["synthetic_test_only"], "statistical_independence_established": False}, "view_sha256")


def domain_indices(rows):
    """Codebook section3 arithmetic; descriptive within-source axes, never ranking."""
    result = {}
    for family in ("openai", "anthropic", "gemini"):
        result[family] = {}
        for domain in (f"E{i}" for i in range(1, 8)):
            subset = [r for r in rows if r["source_family_private_join"] == family and r["item_id"].startswith(domain + "-")]
            values = [r["panel_estimate"] for r in subset if type(r.get("panel_estimate")) in {int, float}]
            mean = statistics.mean(values) if values else None
            result[family][domain] = {"planned_slots": 100, "available_source_rows": len(subset),
                "valid_numeric_estimates": len(values), "not_estimated": 100 - len(values),
                "index_0_4_mean_valid_item_scores": mean, "presentation_only_0_100": None if mean is None else 25 * mean,
                "median": statistics.median(values) if values else None,
                "sample_standard_deviation": statistics.stdev(values) if len(values) > 1 else None,
                "distribution": dict(Counter(str(x) for x in values)), "response_status_counts": dict(Counter(r["status"] for r in subset)),
                "no_imputation_independence_or_cross_source_validity_claim": True}
    return result


def aggregate(p, batch, views):
    validate_batch(p, batch)
    by = {}
    for v in views:
        e.verify(v, "view_sha256"); e.require(v["request_id"] not in by, "duplicate judge attempt")
        e.require(v == import_view(p, batch, v["raw_envelope"]), "derived rating differs from raw")
        by[v["request_id"]] = v
    names = list(p["method"]["schema"]["properties"]["codes"]["properties"])
    assignments = defaultdict(dict)
    for q in batch["requests"]: assignments[q["observation_id_blind"]][q["judge_id"]] = by.get(q["request_id"])
    rows, full_rows = [], []
    for blind, obs in batch["observations"].items():
        assigned = assignments[blind]; core = {"observation_id_blind": blind, "item_id": obs["item_id"]}
        full = {j: v["internal_validation_projection"] if v and v["full_record_valid_new_method"] else None for j, v in assigned.items()}
        if batch["phase"] == "calibration":
            rows.append({**core, "individual_ratings": {j: v["primary"]["judgment"] if v and v["primary"]["valid"] else None for j, v in assigned.items()},
                "valid_ratings": sum(bool(v and v["primary"]["valid"]) for v in assigned.values())})
            full_rows.append({**core, "individual_ratings": full, "valid_ratings": sum(v is not None for v in full.values())})
        else:
            family = batch["private_source_families_never_sent_to_judges"][blind]
            core["source_family_private_join"] = family
            rows.append({**core, **components.primary_pair(assigned), "auxiliary_consensus": components.auxiliary_pair(assigned, names)})
            full_rows.append({**core, **e.combine_pair(full)})
    if batch["phase"] == "calibration":
        reports = {"primary": legacy._calibration_report(rows, p["method"]["config"]),
            "full_record": legacy._calibration_report(full_rows, p["method"]["config"])}
    else:
        reports = {}
        for label, values in (("primary", rows), ("full_record", full_rows)):
            pairs = {}
            for family in ("openai", "anthropic", "gemini"):
                subset = [r for r in values if r["source_family_private_join"] == family]
                pairs[family] = {**e.agreement([r["numeric_pair"] for r in subset if r["numeric_pair"] is not None]),
                    "available_source_rows": len(subset), "planned_source_slots": 700,
                    "two_valid_rating_count": sum(r["valid_ratings"] == 2 for r in subset), "assigned_judges": e.pair_for_source(family)}
            reports[label] = {"source_pair_diagnostics": pairs, "W0_pilot_150_sample_guards_misapplied": False,
                "within_source_domain_indices": domain_indices(values), "not_an_overall_educational_AI_ranking": True,
                "uncertainty_is_descriptive_dispersion_not_independent_observation_CI": True,
                "formal_scientific_validity_or_comparability_established": False}
    return e.sealed({"campaign_id": CAMPAIGN, "phase": batch["phase"], "batch_sha256": batch["batch_sha256"],
        "primary_responses": rows, "full_record_responses": full_rows, "reports": reports,
        "planned_formal_source_slots": 2100, "all45_auxiliary_fields_retained": names,
        "individual_ratings_preserved": True, "automatic_retry_repair_imputation_or_ranking": False,
        "pilot_passed_or_old_clearance_rewritten": False, "synthetic_test_only": batch["synthetic_test_only"]}, "aggregation_sha256")

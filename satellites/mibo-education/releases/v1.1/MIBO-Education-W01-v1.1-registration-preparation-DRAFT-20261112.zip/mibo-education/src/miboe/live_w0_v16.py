"""W0 v1.6:264 preserved attempts + one explicit source replay/24 new slots/300 ratings.
The frozen v1.5 science/wire remains unchanged; timeout600s, automatic retries0.
No import/status/plan/offline-test operation resolves credentials or calls APIs.
"""
from __future__ import annotations
import argparse
import copy
import json
import os
import time
from collections import Counter
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any
import httpx
import yaml
from . import live_w0_v15 as parent
from . import w0_ledger_v16 as ledger
from . import reciprocal as r, reciprocal_engine as e, scoring, validity_v15 as validity
from . import office_credentials_v11 as office
from .errors import ValidationError
from .util import canonical_json_bytes, sanitized_headers, sha256_bytes, sha256_file, utc_now
from .util import write_immutable as save

PLAN = "runtime/w0-live-plan-v1.6.yaml"
LOCK = "runtime/w0-live-v1.6.lock.json"
BOUND = {PLAN,"runtime/w0-live-v1.5.lock.json","src/miboe/live_w0_v16.py",
         "src/miboe/w0_ledger_v16.py","tests/test_live_w0_v16.py",
         "runtime/run-approved-w0-v1.6.ps1","runtime/W0-v1.6-resume-proposal-ja.md",
         "protocol/approvals/W0-V1.6-CONDITIONAL-RESTART-APPROVAL-20261108.yaml"}
COUNTS = ledger.CAPS
KEY_NAMES, RunKeyMemory = parent.KEY_NAMES, parent.RunKeyMemory
require, stamp, validate_keys = parent.require, parent.stamp, parent.validate_keys
_validate_wire, _source_result, _screen = parent._validate_wire, parent._source_result, parent._screen
fixed_jobs, _job, judge_job = parent.fixed_jobs, parent._job, parent.judge_job
judge_result, _judge_phase = parent.judge_result, parent._judge_phase
resolve_credentials = parent.resolve_credentials

def load_plan(root: Path) -> dict[str, Any]:
    previous = parent.load_plan(root)
    lock = scoring.read_json(root/LOCK)
    e.verify(lock,"release_sha256")
    require(set(lock["files"]) == BOUND,"incomplete v1.6 release binding")
    for name,digest in lock["files"].items():
        require(sha256_file(root/name) == digest,"v1.6 bound file changed")
    config = yaml.safe_load((root/PLAN).read_text("utf-8"))
    require(config["status"] == "IMPLEMENTED_NOT_EXECUTION_AUTHORITY"
            and config["official_longitudinal_data"] is False,"invalid preparation state")
    require(config["parent_release_sha256"] == previous["lock"]["release_sha256"]
            and config["source_models"] == previous["config"]["source_models"]
            and config["judges"] == previous["config"]["judges"],"frozen models or parent changed")
    require(config["prior_requests"] == 264 and config["maximum_new_requests"] == COUNTS
            and config["maximum_new_total"] == 325 and config["maximum_cumulative_requests"] == 589
            and config["transport_timeout_seconds"] == 600 and config["automatic_retries"] == 0
            and config["maximum_explicit_failed_source_replays"] == 1
            and config["analysis_policy_version"] == validity.VERSION,"scope/count/transport changed")
    approval = yaml.safe_load((root/config["conditional_approval"]).read_text("utf-8"))
    require(approval["maximum_new_requests"] == 325 and approval["maximum_cumulative_requests"] == 589
            and approval["execution_only_after_offline_verification"] is True,"conditional decision differs")
    return {"root":root,"config":config,"lock":lock,"method":previous["method"],
            "parent_plan":previous,"plan_sha256":e.digest(config)}

def status(root: Path) -> dict[str, Any]:
    p = load_plan(root)
    return {"plan_id":p["config"]["plan_id"],"plan_sha256":p["plan_sha256"],
        "release_sha256":p["lock"]["release_sha256"],"API_execution_authorized":False,
        "prior_requests":264,"saved_source_answers_retained":125,"maximum_new_requests":COUNTS,
        "maximum_new_total":325,"maximum_cumulative_requests":589,
        "transport_timeout_seconds":600,"automatic_retries":0,"explicit_source_replay_limit":1,
        "new_calibration_metadata_smoke_qualification_requests":0,
        "publication_Core_restart_W01_authorized":False,"pilot_passed":False}

def authorization_draft(root: Path) -> dict[str, Any]:
    p = load_plan(root)
    a = parent.authorization_draft(root)
    a.update(schema_version="1.6",plan_id=p["config"]["plan_id"],plan_sha256=p["plan_sha256"],
        release_sha256=p["lock"]["release_sha256"],prior_requests=264,
        maximum_requests=copy.deepcopy(COUNTS),maximum_cumulative_requests=589,
        baseline_file_sha256=p["config"]["accounting"]["baseline_file_sha256"],
        transport_timeout_seconds=600,explicit_source_replay_limit=1,
        authorized_retry_of_job_sha256=p["config"]["authorized_retry_of_job_sha256"],
        Core_restart_authorized=False)
    return a

def raw(directory: Path, job: dict[str, Any], simulation: bool) -> dict[str, Any]:
    require(scoring.read_json(directory/"request.json") == job,"archived request changed")
    require((directory/"request.body").read_bytes() == canonical_json_bytes(job["wire"]["body"]),
            "archived request bytes changed")
    body = (directory/"response.body").read_bytes()
    response = scoring.read_json(directory/"response.json")
    require(response["response_body_sha256"] == sha256_bytes(body)
            and response["synthetic_test_only"] is simulation,"archived response binding changed")
    if response["response_body"] is not None:
        require(response["response_body"] == scoring.strict_json(body.decode("utf-8")),
                "archived JSON body changed")
    else:
        require(response.get("error_code") is not None or response["http_status"] != 200,
                "absent response is not a completed answer")
    return response

def replay_job(original: dict[str, Any]) -> dict[str, Any]:
    require(original["phase"] == "collection" and original["provider"] == "anthropic"
            and original["requested_model"] == "claude-opus-5"
            and original["source"]["item_id"] == "E2-10","wrong explicit replay target")
    return _job("collection",original["provider"],original["requested_model"],copy.deepcopy(original["wire"]),
                source=copy.deepcopy(original["source"]),authorized_retry_of_job_sha256=original["job_sha256"],
                authorized_retry_number=1)

def inspect_parent(context: dict[str, Any]) -> dict[str, Any]:
    b = ledger.preparation(context)
    governance = parent.verify_carried_governance(context,b)
    path = Path(b["historical_run"]["root"]).resolve()
    auth = scoring.read_json(path/"authorization.json")
    pc = {"plan":context["plan"]["parent_plan"],"authorization":auth,
          "authorization_sha256":e.digest(auth),"destination":path,"simulation":context["simulation"]}
    counted = parent.ledger.audited_summary(pc)
    require(counted["new_counts"] == {"calibration":83,"collection":126,"main":0}
            and counted["cumulative_requests"] == 264 and (path/"STOP").is_file(),
            "parent264 attempts/STOP changed")
    ancestor = parent.inspect_parent(pc)
    pc["parent"] = ancestor
    cal = parent.judge_result(context["plan"]["root"],pc,ancestor["batch"])
    require(scoring.read_json(path/"calibration-result.json") == cal,"carried calibration result changed")
    require([v["legacy_full_rating"] for v in cal["ratings"][:22]] == ancestor["retained_ratings"],
            "original22 full-record labels changed")
    parent.require_review_clearance(pc)
    require(cal["aggregation"]["primary_quality_report"]["primary_calibration_guards_passed"] is True,
            "original primary calibration did not pass")
    review = scoring.read_json(path/"calibration-agent-review.json")
    ref = b["carried_calibration_review"]
    require(sha256_file(path/"calibration-agent-review.json") == ref["file_sha256"]
            and review["review_sha256"] == ref["review_sha256"],"carried review differs")
    source_jobs = fixed_jobs(context["plan"],"collection")
    require(len(source_jobs) == 150 and {d.name for d in (path/"L0_raw/collection").iterdir()}
            == {j["job_sha256"] for j in source_jobs[:126]},"parent source attempt set changed")
    records = []
    for job in source_jobs[:125]:
        response = raw(path/"L0_raw/collection"/job["job_sha256"],job,context["simulation"])
        record = _source_result(job,response,context["simulation"])
        require(scoring.read_json(path/"collection-records"/(record["request_id"]+".json")) == record,
                "retained successful source differs from raw")
        _screen(record["response_text"])
        records.append(record)
    require({f.name for f in (path/"collection-records").glob("*.json")}
            == {v["request_id"]+".json" for v in records},"unexpected retained source record")
    failed = source_jobs[125]
    failure = raw(path/"L0_raw/collection"/failed["job_sha256"],failed,context["simulation"])
    require(failure["http_status"] == 0 and failure["response_body"] is None
            and failure["error_code"] == "TRANSPORT_FAILURE_NO_RETRY"
            and (path/"L0_raw/collection"/failed["job_sha256"]/"response.body").read_bytes() == b"",
            "explicit replay is not the original empty transport failure")
    require(failed["job_sha256"] == b["authorized_retry_of_job_sha256"]
            == context["authorization"]["authorized_retry_of_job_sha256"],"replay binding differs")
    require(not (path/"main-batch.json").exists() and not (path/"L0_raw/main").exists(),"old main attempts found")
    replay = replay_job(failed)
    remaining = [replay,*source_jobs[126:]]
    require(len(remaining) == 25 and len({j["job_sha256"] for j in remaining}) == 25,"wrong remaining source set")
    return {"root":path,"source_records":records,"remaining_source_jobs":remaining,
        "failed_job":failed,"replay_job":replay,"review":review,"review_file_sha256":ref["file_sha256"],
        "calibration_result":cal,"started_at":ancestor["started_at"],"salt":ancestor["salt"],
        "governance":governance,"original22_legacy_ratings":ancestor["retained_ratings"]}

def require_review_clearance(context: dict[str, Any]) -> None:
    p = context["parent"]
    path = p["root"]/"calibration-agent-review.json"
    require(sha256_file(path) == p["review_file_sha256"]
            and (p["root"]/"calibration-agent-review.ready").read_text("utf-8") == p["review"]["review_sha256"]
            and p["review"]["analysis_policy"] == validity.VERSION
            and p["review"]["legacy_v1_4_failure_preserved"] is True,"carried review changed")

def authorize(root: Path, a: dict[str, Any], *, execute_approved: bool,
              simulation: bool=False, now: datetime | None=None, continuation: bool=False) -> dict[str, Any]:
    require(execute_approved is True,"explicit execute-approved switch absent")
    p = load_plan(root)
    require(a.get("status") == "FINAL_W0_EXECUTION_AUTHORIZATION" and a.get("fixture_only") is simulation,
            "no matching FINAL permit; fixture cannot authorize live HTTP")
    for key,expected in (("plan_id",p["config"]["plan_id"]),("plan_sha256",p["plan_sha256"]),
        ("release_sha256",p["lock"]["release_sha256"]),("actor_type","HUMAN"),("name","笹埜健斗"),
        ("transport_timeout_seconds",600),("explicit_source_replay_limit",1)):
        require(a.get(key) == expected,"v1.6 authorization binding mismatch:"+key)
    require(a.get("human_attestation") is True and a.get("agent_approval_permitted") is False
            and all(isinstance(a.get(k),str) and a[k].strip() for k in ("source_instruction","source_evidence")),
            "owner decision/evidence required")
    permissions = {"metadata":False,"observation":True,"judge":True,
        "delegated_agent_calibration_review":True,"publication":False,"W01":False}
    require(set(a.get("permissions",{})) == set(permissions)
            and all(a["permissions"][k] is v for k,v in permissions.items())
            and a.get("Core_restart_authorized") is False,"authorization scope differs")
    require(a.get("maximum_requests") == COUNTS and all(type(v) is int for v in a["maximum_requests"].values())
            and type(a.get("prior_requests")) is int and a["prior_requests"] == 264
            and type(a.get("maximum_cumulative_requests")) is int and a["maximum_cumulative_requests"] == 589,
            "request cap changed")
    current = now or datetime.now(UTC)
    issued,deadline = stamp(a["approved_at"]),stamp(a["start_before"])
    require(issued <= current and issued <= deadline <= issued+timedelta(hours=168),"invalid approval window")
    destination = ledger.private_path(root,Path(a["execution_root"]))
    accounting = ledger.private_path(root,Path(a["accounting_root"]))
    require(not (destination/"STOP").exists(),"operator STOP requested")
    if not simulation:
        office.guard(p["config"])
        office.reference(p["config"])
        private = Path(os.environ["LOCALAPPDATA"])
        require(destination == (private/p["config"]["evidence"]["root_under_LOCALAPPDATA"]).resolve()
                and accounting == (private/p["config"]["accounting"]["root_under_LOCALAPPDATA"]).resolve(),
                "unapproved continuation destination")
    context = {"plan":p,"authorization":copy.deepcopy(a),"authorization_sha256":e.digest(a),
               "destination":destination,"simulation":simulation}
    parent_state = inspect_parent(context)
    require(parent_state["started_at"] <= current <= parent_state["started_at"]+timedelta(hours=72),
            "original W0 72-hour window expired; no clock reset")
    context.update(parent=parent_state,started_at=parent_state["started_at"])
    require_review_clearance(context)
    if continuation:
        original = scoring.read_json(destination/"RUN_STARTED.json")
        require(original["authorization_sha256"] == e.digest(a)
                and original["plan_sha256"] == p["plan_sha256"]
                and original["synthetic_test_only"] is simulation
                and issued <= stamp(original["started_at"]) <= deadline
                and stamp(original["started_at"]) <= current,"started run binding differs")
    else:
        require(current <= deadline and {v.name for v in destination.iterdir()} == {"PREPARATION.json"}
                and not (accounting/"RUN_BINDING.json").exists()
                and not any((accounting/"claims").iterdir()) and not any((accounting/"outcomes").iterdir()),
                "prior continuation exists; no automatic rerun")
    return context

class Session:
    """One bounded run; request claims precede I/O and an existing run never resumes silently."""

    def __init__(
        self,
        context: dict[str, Any],
        keys: dict[str, str],
        *,
        transport: httpx.MockTransport | None = None,
        sleep: Any = time.sleep,
    ):
        simulation = context["simulation"]
        context = authorize(
            context["plan"]["root"],
            context["authorization"],
            execute_approved=True,
            simulation=simulation,
            continuation=False,
        )
        validate_keys(keys)
        require(
            (type(transport) is httpx.MockTransport) if simulation else transport is None,
            "simulation/live transport boundary violation",
        )
        self.context, self.keys, self.sleep = context, keys, sleep
        require_review_clearance(context)
        self.source_jobs = context["parent"]["remaining_source_jobs"]
        self.main_jobs = {}
        self.root = context["destination"]
        self.counts = dict.fromkeys(COUNTS, 0)
        self.started = context["started_at"]
        self.last_call = None
        self.ledger = ledger.Ledger(context, initial=True)
        self.held = False
        try:
            require(self.ledger.counts == self.counts, "durable ledger/counts mismatch")
            save(
                self.root / "RUN_STARTED.json",
                canonical_json_bytes(
                    {
                        "plan_sha256": context["plan"]["plan_sha256"],
                        "authorization_sha256": context["authorization_sha256"],
                        "started_at": utc_now(),
                        "parent_W0_started_at": self.started.isoformat(),
                        "synthetic_test_only": simulation,
                    }
                )
                + b"\n",
            )
            save(
                self.root / "authorization.json",
                canonical_json_bytes(context["authorization"]) + b"\n",
            )
            save(
                self.root / "execution-plan.json",
                canonical_json_bytes(context["plan"]["config"]) + b"\n",
            )
            # No env proxy, retries, redirects, alternate base URL, cookies or persistence.
            self.client = httpx.Client(
                transport=transport or httpx.HTTPTransport(retries=0, trust_env=False),
                trust_env=False,
                follow_redirects=False,
                timeout=httpx.Timeout(600.0),
            )
        except BaseException:
            self.ledger.close()
            raise

    def exchange(self, job: dict[str, Any]) -> dict[str, Any]:
        require(not self.held, "session held after failed attempt; no next request")
        _validate_wire(job)
        require(job["phase"] in COUNTS, "metadata/calibration/smoke/qualification resend forbidden")
        if job["phase"] == "collection":
            position = self.counts["collection"]
            require(position < len(self.source_jobs) and job == self.source_jobs[position]
                    and self.counts["main"] == 0, "source job outside the one replay plus24 locked slots")
        else:
            require(self.counts["collection"] == 25 and self.main_jobs.get(job["job_sha256"]) == job,
                    "main request before complete150 answers or outside locked nonself batch")
        require_review_clearance(self.context)
        require(not (self.root / "STOP").exists(), "operator STOP requested")
        phase, provider, wire = job["phase"], job["provider"], job["wire"]
        require(phase in COUNTS and self.counts[phase] < COUNTS[phase], "phase call cap exceeded")
        require(datetime.now(UTC) <= self.started + timedelta(hours=72), "run window expired")
        require(
            sha256_file(self.root / "authorization.json")
            == sha256_bytes(canonical_json_bytes(self.context["authorization"]) + b"\n"),
            "authorization file changed during run",
        )
        if self.last_call is not None:
            self.sleep(max(0, 2 - (time.monotonic() - self.last_call)))
        if not self.context["simulation"]:
            office.guard(self.context["plan"]["config"])
        require(not (self.root / "STOP").exists(), "operator STOP requested after pacing")
        require(datetime.now(UTC) <= self.started + timedelta(hours=72), "run window expired after pacing")
        claim = self.ledger.reserve(job)  # durable claim and second witness BEFORE HTTP
        directory = self.root / "L0_raw" / phase / job["job_sha256"]
        save(directory / "request.json", canonical_json_bytes(job) + b"\n")
        save(
            directory / "request.body",
            b"" if wire["body"] is None else canonical_json_bytes(wire["body"]),
        )
        # Reservations conservatively consume allowance, even if a process dies before I/O.
        self.counts = copy.deepcopy(self.ledger.counts)
        header = {"openai": "Authorization", "anthropic": "x-api-key", "gemini": "x-goog-api-key"}[
            provider
        ]
        headers = {
            "Content-Type": "application/json",
            header: (
                "Bearer " + self.keys[provider] if provider == "openai" else self.keys[provider]
            ),
        }
        if provider == "anthropic":
            headers["anthropic-version"] = "2023-06-01"
        code, body, raw, error, response_headers = 0, None, b"", None, {}
        transport_error_class = None
        try:
            self.client.cookies.clear()
            response = self.client.request(
                wire["method"],
                wire["url"],
                headers=headers,
                content=None if wire["body"] is None else canonical_json_bytes(wire["body"]),
            )
            code, raw = response.status_code, response.content
            self.client.cookies.clear()
            response_headers = {
                k: v
                for k, v in sanitized_headers(dict(response.headers)).items()
                if k.lower()
                not in {"set-cookie", "cookie", "authorization", "x-api-key", "x-goog-api-key"}
            }
            try:
                parsed = scoring.strict_json(raw.decode("utf-8"))
                body = parsed if isinstance(parsed, dict) else None
            except (UnicodeError, ValidationError, ValueError):
                error = "INVALID_JSON_NO_REPAIR"
        except httpx.TransportError as exc:
            error = "TRANSPORT_FAILURE_NO_RETRY"
            transport_error_class = next((name for kind,name in (
                (httpx.ReadTimeout,"READ_TIMEOUT"),(httpx.ConnectTimeout,"CONNECT_TIMEOUT"),
                (httpx.WriteTimeout,"WRITE_TIMEOUT"),(httpx.PoolTimeout,"POOL_TIMEOUT"))
                if isinstance(exc,kind)), "TRANSPORT_OTHER")
        self.last_call = time.monotonic()
        envelope = {
            "http_status": code,
            "received_at": utc_now(),
            "response_body": body,
            "response_body_sha256": sha256_bytes(raw),
            "headers": response_headers,
            "error_code": error,
            "transport_error_class": transport_error_class,
            "synthetic_test_only": self.context["simulation"],
        }
        save(directory / "response.body", raw, allow_sensitive_scientific_data=True)
        save(
            directory / "response.json",
            canonical_json_bytes(envelope) + b"\n",
            allow_sensitive_scientific_data=True,
        )
        self.ledger.finish(claim)
        self.held = not (code == 200 and body is not None)
        require(
            not self.held,
            "HTTP/transport/format HOLD; evidence retained; no retry",
        )
        return envelope

    def close(self):
        try:
            self.client.close()
        finally:
            self.ledger.close()


def run(root: Path, authorization: dict[str, Any], *, execute_approved: bool=False,
        simulation_transport: httpx.MockTransport | None=None, credential_resolver: Any=None,
        interactive_keys: bool=False, sleep: Any=time.sleep) -> dict[str, Any]:
    context = authorize(root,authorization,execute_approved=execute_approved,
                        simulation=simulation_transport is not None)
    keys = (dict.fromkeys(KEY_NAMES,"fixture-credential-not-real") if context["simulation"]
            else (credential_resolver or resolve_credentials)(root,interactive=interactive_keys))
    session = Session(context,keys,transport=simulation_transport,sleep=sleep)
    try:
        records = copy.deepcopy(context["parent"]["source_records"])
        for job in context["parent"]["remaining_source_jobs"]:
            record = _source_result(job,session.exchange(job),context["simulation"])
            save(session.root/"collection-records"/(record["request_id"]+".json"),
                 canonical_json_bytes(record)+b"\n",allow_sensitive_scientific_data=True)
            records.append(record)
        require(len(records) == 150 and len({r["request_id"] for r in records}) == 150
                and Counter(r["source_series"] for r in records) == {"M01":50,"M02":50,"M03":50},
                "150 distinct successful answers required; no refill")
        rows, sources = [], {}
        for record in records:
            _screen(record["response_text"])
            row = scoring.make_blind_observation(record,salt=context["parent"]["salt"])
            rows.append(row)
            sources[row["observation_id_blind"]] = record["provider"]
        batch = r.build_batch(root,rows,sources)
        save(session.root/"main-batch.json",canonical_json_bytes(batch)+b"\n",allow_sensitive_scientific_data=True)
        session.main_jobs = {judge_job(q,"main")["job_sha256"]:judge_job(q,"main") for q in batch["requests"]}
        result = _judge_phase(root,session,batch)
        summary = e.sealed({
            "status":"W0_RESULT_REVIEW_REQUIRED_NOT_AUTOMATIC_PASS","plan_sha256":context["plan"]["plan_sha256"],
            "counts":copy.deepcopy(session.counts),"cumulative_accounting":session.ledger.audit(),
            "fresh_answers":150,"retained_source_answers":125,"new_successful_source_answers":25,
            "main_ratings":300,"original_failed_source_attempt_preserved":True,"explicit_failed_source_replays":1,
            "calibration_agent_review_sha256":context["parent"]["review"]["review_sha256"],
            "primary_main_numeric_guards_passed":result["aggregation"]["primary_quality_report"]["primary_numeric_quality_checks_passed"],
            "real_API_calls":0 if context["simulation"] else sum(session.counts.values()),
            "synthetic_test_only":context["simulation"],"pilot_passed":False,
            "legacy_v1_4_failure_preserved":True,"all_old22_labels_preserved":True,
            "human_validity_or_comparability_established":False,"W01_authorized":False,
            "publication_authorized":False,"Core_restart_authorized":False,
            "automatic_retries_repairs_refill_or_third_judge":0,
        },"summary_sha256")
        save(session.root/"RUN_FINISHED.json",canonical_json_bytes(summary)+b"\n")
        return summary
    finally:
        session.close()

def main(argv: list[str] | None=None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("command",choices=("status","execute"))
    parser.add_argument("--root",default=str(Path(__file__).resolve().parents[2]))
    parser.add_argument("--authorization")
    parser.add_argument("--execute-approved",action="store_true")
    args = parser.parse_args(argv)
    root = Path(args.root).resolve()
    memory = RunKeyMemory(resolver=resolve_credentials)
    try:
        if args.command == "status":
            value = status(root)
        else:
            require(args.execute_approved and bool(args.authorization),"explicit authorization required")
            value = run(root,scoring.read_json(Path(args.authorization)),execute_approved=True,credential_resolver=memory)
        print(json.dumps(value,ensure_ascii=False))
        return 0
    except (ValidationError,ValueError,OSError,KeyError,TypeError):
        print("W0 v1.6 HOLD: scope/window/evidence/transport failure; no automatic retry.")
        return 1
    finally:
        memory.clear()

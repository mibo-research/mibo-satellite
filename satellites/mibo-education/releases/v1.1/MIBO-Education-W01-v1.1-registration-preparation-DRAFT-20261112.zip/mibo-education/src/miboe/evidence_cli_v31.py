"""Prospective v3.1 preparation/import/aggregation. No execution command can send."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from . import reciprocal_evidence_v31 as method, reciprocal_engine as e, scoring
from .errors import ImmutabilityError, ValidationError


def parser():
    p = argparse.ArgumentParser(prog="miboe-evidence-v31")
    p.add_argument("--root", default=str(Path(__file__).resolve().parents[2]))
    sub = p.add_subparsers(dest="operation", required=True)
    sub.add_parser("status")
    sub.add_parser("execute", help="Always held: method adoption is not API authority")
    for name in ("prepare", "calibration"):
        q = sub.add_parser(name)
        q.add_argument("--blind-input", required=True)
        if name == "prepare": q.add_argument("--source-map", required=True)
        q.add_argument("--synthetic-test-only", action="store_true")
        q.add_argument("--output", required=True)
    q = sub.add_parser("wire")
    q.add_argument("--batch", required=True)
    q.add_argument("--output", required=True)
    q = sub.add_parser("import")
    q.add_argument("--batch", required=True)
    q.add_argument("--responses", required=True)
    q.add_argument("--output", required=True)
    q = sub.add_parser("aggregate")
    q.add_argument("--batch", required=True)
    q.add_argument("--ratings", nargs="+", required=True)
    q.add_argument("--output", required=True)
    return p


def main(argv=None):
    a = parser().parse_args(argv)
    try:
        if a.operation == "execute":
            method.assert_live_authorized()  # Before files, keys or transports.
        root = Path(a.root).resolve()
        if a.operation == "status":
            print(json.dumps(method.status(root)))
            return 0
        if a.operation in {"prepare", "calibration"}:
            families = scoring.read_json(Path(a.source_map)) if a.operation == "prepare" else {}
            value = method.build_batch(root, scoring.read_json(Path(a.blind_input)), families,
                phase="main" if a.operation == "prepare" else "calibration", synthetic_test_only=a.synthetic_test_only)
            summary = {"batch_sha256": value["batch_sha256"], "requests_prepared": len(value["requests"])}
        else:
            batch = scoring.read_json(Path(a.batch))
            if a.operation == "wire":
                value = method.wire_artifact(root, batch)
                summary = {"wire_jobs_prepared": len(value["jobs"])}
            elif a.operation == "import":
                views = method.import_many(root, batch, scoring.read_json(Path(a.responses)))
                value = e.sealed({"method_id": method.METHOD, "batch_sha256": batch["batch_sha256"],
                    "ratings": views}, "rating_set_sha256")
                summary = {"ratings_imported": len(views), "primary_valid": sum(v["primary"]["valid"] for v in views)}
            else:
                views = []
                for filename in a.ratings:
                    saved = scoring.read_json(Path(filename))
                    e.verify(saved, "rating_set_sha256")
                    e.require(saved["method_id"] == method.METHOD and saved["batch_sha256"] == batch["batch_sha256"], "rating set scope mismatch")
                    views.extend(saved["ratings"])
                value = method.aggregate(root, batch, views)
                summary = {"responses": len(value["primary_responses"]), "pilot_passed": False}
        method.write_artifact(root, Path(a.output), value)
        print(json.dumps({"method_id": method.METHOD, **summary, "API_calls_made": 0, "restricted_content_printed": False}))
        return 0
    except (ImmutabilityError, ValidationError, ValueError, KeyError, TypeError, OSError):
        print("MIBOE-EVIDENCE-v3.1 HOLD: execution closed or offline input/integrity failure; no API call.")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())

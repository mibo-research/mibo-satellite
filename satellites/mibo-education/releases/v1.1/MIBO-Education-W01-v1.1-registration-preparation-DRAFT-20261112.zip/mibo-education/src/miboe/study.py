"""Read-only validation of the prospective study design, never an API runner."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .artifacts import load_scientific_artifact_registry, load_yaml
from .errors import ValidationError
from .reciprocal import load_plan as load_reciprocal_plan
from .scoring import load_scoring_plan
from .util import sha256_file

DESIGN_PATH = "protocol/study-design-v1.1.yaml"
SERIES = ["M01", "M02", "M03"]
PROVIDERS = ["openai", "anthropic", "gemini"]


def _require(value: bool, message: str) -> None:
    if not value:
        raise ValidationError(message)


def study_status(module_root: Path) -> dict[str, Any]:
    root = module_root.resolve()
    design = load_yaml(root / DESIGN_PATH)
    _require(design["design_id"] == "MIBOE-STUDY-DESIGN-v1.1", "unexpected study design")
    _require(design["status"] == "USER_APPROVED_DESIGN_NOT_EXECUTABLE", "invalid design state")
    _require(
        set(design["bound_file_sha256"])
        == {
            "protocol/amendments/MIBOE-AM-20261107-01.yaml",
            "registry/model-series-v1.1.yaml",
            "registry/model-series.yaml",
            "waves/W01/scientific-manifest-v1.0.yaml",
        },
        "study binding set incomplete",
    )
    for relative, expected in design["bound_file_sha256"].items():
        path = (root / relative).resolve()
        _require(path.is_relative_to(root), "study binding outside module")
        _require(sha256_file(path) == expected, "study design binding changed: " + relative)
    amendment = load_yaml(root / design["amendment_path"])
    registry = load_yaml(root / design["series_registry_path"])
    historical = load_yaml(root / "registry/model-series.yaml")
    scientific = load_scientific_artifact_registry(
        root / "protocol/scientific-artifacts.authoritative.yaml"
    )
    scoring = load_scoring_plan(root)
    current_scoring = load_reciprocal_plan(root)
    _require([s["series_id"] for s in registry["series"]] == SERIES, "active series mismatch")
    _require([s["provider"] for s in registry["series"]] == PROVIDERS, "provider mismatch")
    _require(all(s["environment"] == "CLOSED" for s in registry["series"]), "not CLOSED")
    _require(
        [s["series_id"] for s in historical["series"]] == SERIES + ["M04", "M05"],
        "historical registry changed",
    )
    _require(
        [s["series_id"] for s in registry["excluded_prospectively"]] == ["M04", "M05"],
        "excluded series must stay historically identifiable",
    )
    _require(
        amendment["scope"]["includes_formal_longitudinal_study"] is True,
        "formal study scope not approved",
    )
    _require(amendment["response_sources"]["active_series"] == SERIES, "amendment mismatch")
    _require(
        design["active_response_series"] == SERIES
        and design["active_response_providers"] == PROVIDERS,
        "design series mismatch",
    )
    official = design["official_observation_design"]
    _require(
        official["frozen_item_count"] == 70 and official["replication_k"] == 10,
        "unchanged instrument and replication contract violated",
    )
    count = official["frozen_item_count"] * official["replication_k"] * len(SERIES)
    _require(
        official["expected_total_per_wave"] == count == 2100, "three-series denominator mismatch"
    )
    _require(official["native_mirror_count"] == 0, "NATIVE mirror is not in v1.1 scope")
    pilot = design["reliability_pilot"]
    _require(
        pilot["fresh_answers_by_source"] == dict.fromkeys(SERIES, 50),
        "approved pilot allocation mismatch",
    )
    _require(
        pilot["planned_answers"] == 150 and pilot["planned_initial_ratings"] == 300,
        "pilot response/rating count mismatch",
    )
    _require(
        pilot["approved_proposal_sha256"]
        == amendment["reliability_pilot"]["approved_candidate_proposal_sha256"],
        "pilot proposal binding mismatch",
    )
    _require(
        design["scoring_lock_sha256"] == scoring["lock"]["lock_sha256"], "scoring method changed"
    )
    _require(
        all(v is False for v in design["execution"].values()),
        "design decision cannot authorize execution",
    )
    _require(
        design["new_official_baseline"]["wave_id"] is None
        and design["new_official_baseline"]["anchor_utc"] is None,
        "new baseline needs a separate prospective schedule decision",
    )
    return {
        "design_id": design["design_id"],
        "design_file_sha256": sha256_file(root / DESIGN_PATH),
        "owner_approved_source_scope": True,
        "official_response_series": SERIES,
        "official_response_providers": PROVIDERS,
        "excluded_prospectively": ["M04", "M05"],
        "expected_official_answers_per_wave": count,
        "fresh_pilot_answers_by_source": pilot["fresh_answers_by_source"],
        "planned_initial_pilot_ratings": 300,
        "judges": [j["requested_model"] for j in current_scoring["config"]["judges"]],
        "scoring_method_id": current_scoring["config"]["method_id"],
        "source_specific_judge_pairs": current_scoring["config"]["source_pairs"],
        "planned_common_calibration_ratings": 105,
        "scoring_lock_sha256": current_scoring["lock"]["lock_sha256"],
        "legacy_design_scoring_lock_sha256": scoring["lock"]["lock_sha256"],
        "historical_five_series_design_preserved": True,
        "verified_frozen_v1_0_artifacts": len(scientific["artifacts"]),
        "legacy_five_series_runtime_supports_this_design": False,
        "new_baseline_date_locked": False,
        "actual_source_models_live_locked": False,
        "pilot_scoped_governance_FINAL": False,
        "pilot_passed": False,
        "official_wave_ready": False,
        "API_execution_authorized": False,
        "API_calls_made": 0,
        "publication_status": "LOCAL_UNPUBLISHED",
    }

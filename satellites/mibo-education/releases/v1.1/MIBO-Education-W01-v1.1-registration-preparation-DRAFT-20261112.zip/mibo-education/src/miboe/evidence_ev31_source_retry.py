"""Prospective one-source-retry amendment. Preparation is NOT API restart authority.

Old baseline/authorization and all168 old attempts remain immutable. The new
ledger extends only the collection-attempt allowance from150 to151; exactly150
actual answers, not151, feed the unchanged nonself300 scoring method.
"""
from __future__ import annotations
import argparse
import copy
from datetime import UTC, datetime, timedelta
import json
import os
from pathlib import Path
import time
from collections import Counter
import httpx
import yaml
from . import evidence_ev31_runtime as rt, evidence_ev31_continuation as c
from . import reciprocal_engine as e, scoring
from .util import canonical_json_bytes, sha256_file as sha, sha256_bytes, write_immutable, sanitized_headers

CONFIG = "runtime/EV31-source-retry-v1.0.json"
LOCK = "runtime/EV31-source-retry-v1.0.lock.json"
DECISION = "protocol/approvals/EV31-SOURCE-RETRY-PREPARATION-APPROVAL-20261111.yaml"
BOUND = {CONFIG, DECISION, c.LOCK, "src/miboe/evidence_ev31_source_retry.py",
    "tests/test_ev31_source_retry.py", "runtime/start-ev31-source-retry-v1.0.ps1"}
CAPS = {"metadata": 6, "calibration": 105, "collection": 151, "main": 300}
INITIAL = {"metadata": 6, "calibration": 105, "collection": 57, "main": 0}
PERMISSIONS = {"retry_source168_once": True, "remaining_original_sources93": True,
    "nonself_main300": True, "carry_accepted_calibration": True,
    "delegated_unsent_main_READ_TIMEOUT_only_if_fixed_guards_reachable": True,
    "other_source_retry": False, "second_retry": False, "metadata_or_calibration_replay": False,
    "publication": False, "Core_restart": False, "W01": False}
FINAL = "FINAL_EV31_SINGLE_SOURCE_RETRY_EXECUTION"


def load_plan(root):
    root = root.resolve()
    parent = c.load_plan(root)
    lock = scoring.read_json(root / LOCK)
    e.verify(lock, "release_sha256")
    e.require(set(lock["files"]) == BOUND, "incomplete one-retry release")
    for name, digest in lock["files"].items():
        e.require(sha(root / name) == digest, "one-retry release input changed")
    config = scoring.read_json(root / CONFIG)
    decision = yaml.safe_load((root / DECISION).read_text("utf-8"))
    e.require(decision["status"] == "OWNER_APPROVED_PREPARATION_ONLY"
        and decision["API_restart_authorized"] is False
        and decision["owner"] == "笹埜健斗", "preparation is not API authority")
    expected = {"initial_requests": 168, "prior_requests": 905, "additional_maximum": 394,
        "trial_maximum": 562, "cumulative_maximum": 1467, "caps": CAPS,
        "initial_counts": INITIAL, "actual_source_answers_required": 150,
        "failed_sequence": 168, "failed_source_slot": 57, "permissions": PERMISSIONS}
    e.require(all(config.get(k) == v for k, v in expected.items()), "one-retry allocation or scope changed")
    e.require(config["parent_release_sha256"] == parent["lock"]["release_sha256"]
        and config["original_started_at"] == parent["config"]["original_started_at"]
        and config["unchanged_deadline"] == parent["config"]["unchanged_deadline"]
        and config["failed_job_sha256"] == decision["one_retry_only"]["failed_job_sha256"]
        and config["failed_claim_sha256"] == decision["one_retry_only"]["failed_claim_sha256"],
        "original science, clock or approved failed source differs")
    return {"root": root, "parent": parent, "native": parent["native"],
        "config": config, "lock": lock, "lock_file_sha256": sha(root / LOCK)}


def replacement_job(original, claim):
    e.verify(original, "job_sha256")
    e.verify(claim, "claim_sha256")
    e.require(claim["sequence"] == 168 and claim["phase"] == original["phase"] == "collection"
        and claim["job_sha256"] == original["job_sha256"] and original["provider"] == "openai",
        "only the designated source168 can be retried")
    core = {k: copy.deepcopy(v) for k, v in original.items() if k != "job_sha256"}
    # Audit-only metadata: never sent to the provider; wire/source remain exact.
    core["single_authorized_transport_retry"] = {"ordinal": 1,
        "failed_claim_sha256": claim["claim_sha256"], "failed_job_sha256": original["job_sha256"]}
    return e.sealed(core, "job_sha256")


def validate_grant(p, g, original, simulation):
    e.require(g.get("status") == FINAL and g.get("fixture_only") is simulation,
        "separate explicit FINAL restart approval required; DRAFT never sends")
    expected = {"owner": "笹埜健斗", "actor_type": "HUMAN", "human_attestation": True,
        "API_restart_authorized": True, "release_sha256": p["lock"]["release_sha256"],
        "original_authorization_sha256": e.digest(original), "initial_requests": 168,
        "maximum_additional_requests": 394, "maximum_trial_requests": 562,
        "maximum_cumulative_requests": 1467, "permissions": PERMISSIONS}
    e.require(all(type(g.get(k)) is type(v) and g[k] == v for k, v in expected.items()),
        "one-retry authority, caps or scope mismatch")
    e.require(all(isinstance(g.get(k), str) and g[k].strip() for k in
        ("source_instruction", "source_evidence", "original_started_at", "unchanged_deadline")),
        "explicit owner restart evidence required")
    e.require(rt.stamp(g["unchanged_deadline"]) == rt.stamp(g["original_started_at"]) + timedelta(hours=72),
        "original72-hour window cannot be extended")
    if not simulation:
        e.require(g["original_started_at"] == p["config"]["original_started_at"]
            and g["unchanged_deadline"] == p["config"]["unchanged_deadline"], "clock changed")


def authorize(root, g, *, execute_approved=False, simulation=False):
    e.require(execute_approved is True and g.get("status") == FINAL
        and g.get("fixture_only") is simulation, "no explicit FINAL API restart authority")
    p = load_plan(root)
    directory = rt.ledger.private_path(root, Path(g["execution_root"]))
    original = scoring.read_json(directory / "authorization.json")
    validate_grant(p, g, original, simulation)
    # Inherit immutable science/storage/rights/baseline checks, not the old cap.
    ctx = rt.authorize(root, original, execute_approved=True, simulation=simulation,
        continuation=True, preflight_only=True)
    side = rt.ledger.private_path(root, Path(g["retry_root"]))
    e.require(directory == ctx["destination"] and sha(side / "authorization.json") ==
        sha256_bytes(canonical_json_bytes(g) + b"\n"), "retry authorization file changed")
    prefix_path = side / "PREFIX168.json"
    e.require(sha(prefix_path) == g["prefix_file_sha256"], "prefix168 binding changed")
    prefix = scoring.read_json(prefix_path)
    e.verify(prefix, "prefix_sha256")
    e.require(prefix["initial_requests"] == 168 and prefix["fixture_only"] is simulation
        and prefix["original_authorization_sha256"] == e.digest(original), "wrong prefix")
    for group in prefix["preserved_prefix"]:
        folder = rt.ledger.private_path(root, Path(group["root"]))
        for name, digest in group["files"].items():
            rel = Path(name)
            e.require(not rel.is_absolute() and ".." not in rel.parts, "invalid preserved prefix path")
            e.require(sha(rt.ledger.private_path(root, folder / rel)) == digest, "saved168 evidence changed")
    started = scoring.read_json(directory / "RUN_STARTED.json")
    e.require(started["started_at"] == g["original_started_at"]
        and sha(directory / "RUN_STARTED.json") == prefix["RUN_STARTED_file_sha256"]
        and rt.prepared.can_reserve_before_deadline(rt.stamp(started["started_at"]), datetime.now(UTC)),
        "original clock changed or deadline exhausted")
    if not simulation:
        e.require(side == (Path(os.environ["LOCALAPPDATA"]) / p["config"]["retry_relative_root"]).resolve()
            and sha(prefix_path) == p["config"]["prefix_file_sha256"], "unapproved retry namespace")
        report_path = Path(g["offline_report"])
        e.require(sha(report_path) == g["offline_report_file_sha256"], "offline report binding changed")
        report = scoring.read_json(report_path)
        e.require(report["status"] == "EV31_SINGLE_SOURCE_RETRY_OFFLINE_VERIFIED"
            and report["release_sha256"] == p["lock"]["release_sha256"] and report["API_calls"] == 0
            and report["tests"]["failed"] == report["tests"]["errors"] == report["tests"]["exit_code"] == 0
            and report["full168_plus394_fixture_completed"] is True, "offline verification required")
    rt.verify_review(ctx)
    claim = scoring.read_json(Path(original["accounting_root"]) / "claims/000168.json")
    job = rt.fixed_jobs(ctx["plan"], "collection")[56]
    response = rt.raw(directory / claim["raw_relative_path"], job, simulation)
    e.require(claim["job_sha256"] == job["job_sha256"] and response["http_status"] == 0
        and response["response_body"] is None and response["error_code"] == "TRANSPORT_FAILURE_NO_RETRY"
        and response["transport_error_class"] == "TRANSPORT_OTHER", "not the approved transport-only failure")
    if not simulation:
        e.require(claim["claim_sha256"] == p["config"]["failed_claim_sha256"]
            and job["job_sha256"] == p["config"]["failed_job_sha256"], "retry target changed")
    return {**ctx, "source_retry": {"plan": p, "grant": copy.deepcopy(g), "side": side,
        "prefix": prefix, "retry_job": replacement_job(job, claim)}}


class Ledger(rt.ledger.Ledger):
    """Same original claim chain; no baseline/old authorization/counter rewrite."""
    def __init__(self, ctx):
        self.ctx, self.destination = ctx, ctx["destination"]
        self.root = rt.ledger.private_path(ctx["plan"]["root"], Path(ctx["authorization"]["accounting_root"]))
        self.base = ctx["baseline"]
        self.lease = rt.ledger.Lease(self.root / "worker.lease")
        try:
            binding = {"campaign_id": rt.method.CAMPAIGN, "plan_sha256": ctx["plan"]["plan_sha256"],
                "authorization_sha256": ctx["authorization_sha256"],
                "baseline_file_sha256": ctx["authorization"]["baseline_file_sha256"],
                "execution_root": str(self.destination), "fixture_only": ctx["simulation"]}
            e.require(scoring.read_json(self.root / "RUN_BINDING.json") == binding, "original ledger binding changed")
            self.binding_sha = sha(self.root / "RUN_BINDING.json")
            self.audit()
            e.require(self.counts["metadata"] == 6 and self.counts["calibration"] == 105
                and 57 <= self.counts["collection"] <= 151
                and (self.counts["collection"] == 151 or self.counts["main"] == 0), "not a prefix168 continuation")
            e.require(scoring.read_json(self.root / "claims/000168.json")["claim_sha256"] ==
                ctx["source_retry"]["prefix"]["last_claim_sha256"], "prefix168 last claim changed")
        except BaseException:
            self.close()
            raise

    @staticmethod
    def check_caps(counts):
        e.require(set(counts) == set(CAPS) and all(type(v) is int and 0 <= v <= CAPS[k]
            for k, v in counts.items()) and sum(counts.values()) <= 562
            and 905 + sum(counts.values()) <= 1467, "one-retry cap exceeded")

    def summary(self):
        return {"prior_preserved_reservations": 905, "new_counts": copy.deepcopy(self.counts),
            "new_reservations": sum(self.counts.values()), "cumulative_reservations": 905 + sum(self.counts.values()),
            "maximum_new": 562, "maximum_cumulative": 1467, "last_claim_sha256": self.previous}


def scheduled_sources(ctx):
    original = rt.fixed_jobs(ctx["plan"], "collection")
    return original[:57] + [ctx["source_retry"]["retry_job"]] + original[57:]


def saved_sources(ctx, collection_count):
    e.require(57 <= collection_count <= 151, "unexpected source checkpoint")
    records = []
    for index, job in enumerate(scheduled_sources(ctx)[:collection_count]):
        response = rt.raw(ctx["destination"] / "L0_raw/collection" / job["job_sha256"], job, ctx["simulation"])
        if index == 56:  # Only original failed168, never a failure of the retry.
            e.require(response["http_status"] == 0 and response["response_body"] is None
                and response["transport_error_class"] == "TRANSPORT_OTHER", "failed source168 changed")
            continue
        record = rt.old._source_result(job, response, ctx["simulation"])
        e.require(scoring.read_json(ctx["destination"] / "collection-records" / (record["request_id"] + ".json")) == record,
            "source shortfall/unknown outcome must not be skipped or repaired")
        records.append(record)
    e.require(len(records) == collection_count - 1
        and len({r["request_id"] for r in records}) == len(records), "source replay or shortfall")
    return records


class Session(rt.Session):
    def __init__(self, ctx, keys, *, transport=None, sleep=time.sleep):
        rt.old.validate_keys(keys)
        e.require((type(transport) is httpx.MockTransport) if ctx["simulation"] else transport is None, "fixture/live boundary")
        self.ctx, self.keys, self.sleep = ctx, keys, sleep
        self.root, self.started = ctx["destination"], rt.stamp(ctx["source_retry"]["grant"]["original_started_at"])
        self.fixed = {"collection": scheduled_sources(ctx)}
        self.judges = {"main": []}
        self.ledger = Ledger(ctx)
        self.last_call, self.failed = time.monotonic(), False
        try:
            self.client = httpx.Client(transport=transport or httpx.HTTPTransport(retries=0, trust_env=False),
                timeout=httpx.Timeout(600.0), trust_env=False, follow_redirects=False)
        except BaseException:
            self.ledger.close()
            raise

    def bind_main(self, batch):
        rt.method.validate_batch(self.ctx["plan"]["root"], batch)
        e.require(batch["phase"] == "main" and self.ledger.counts["collection"] == 151
            and len(saved_sources(self.ctx, 151)) == 150, "150 actual sources required before main")
        self.judges["main"] = [rt.judge_job(q, "main") for q in batch["requests"]]

    def exchange(self, job):
        # Native first-party wire/transport, with the prospectively declared
        # source-attempt151 versus actual-answer150 distinction; no monkeypatch.
        e.require(not self.failed, "held after failure; no automatic retry")
        rt.old._validate_wire(job)
        counts, phase = self.ledger.counts, job["phase"]
        e.require(phase in {"collection", "main"} and job.get("campaign_id") == rt.method.CAMPAIGN,
            "no metadata/calibration replay or alternate campaign")
        expected = self.fixed.get(phase, self.judges.get(phase, []))
        e.require(counts[phase] < len(expected) and job == expected[counts[phase]], "not the exact next approved slot")
        e.require(counts["metadata"] == 6 and counts["calibration"] == 105, "calibration incomplete")
        rt.verify_review(self.ctx)
        if phase == "main":
            e.require(counts["collection"] == 151, "150 actual sources required")
        amendment = self.ctx["source_retry"]
        p = amendment["plan"]
        e.require(sha(p["root"] / LOCK) == p["lock_file_sha256"]
            and sha(amendment["side"] / "authorization.json") == sha256_bytes(canonical_json_bytes(amendment["grant"]) + b"\n"),
            "one-retry release or authority changed")
        native = self.ctx["plan"]
        e.require(sha(native["root"] / rt.LOCK) == native["lock_file_sha256"]
            and sha(native["root"] / rt.PLAN) == native["lock"]["files"][rt.PLAN]
            and sha(native["root"] / rt.method.BANK) == native["method"]["material_sha256"]
            and sha(self.root / "authorization.json") == sha256_bytes(canonical_json_bytes(self.ctx["authorization"]) + b"\n"),
            "native scientific inputs or original authority changed")
        e.require((self.root / "RUN_STARTED.json").is_file()
            and rt.prepared.can_reserve_before_deadline(self.started, datetime.now(UTC))
            and not (self.root / "STOP").exists(), "original window or operator STOP")
        self.sleep(max(0, 2 - (time.monotonic() - self.last_call)))
        e.require(rt.prepared.can_reserve_before_deadline(self.started, datetime.now(UTC))
            and not (self.root / "STOP").exists(), "window/STOP after pacing")
        if not self.ctx["simulation"]:
            rt.office.guard(native["config"])
        claim = self.ledger.reserve(job)
        directory = self.root / claim["raw_relative_path"]
        rt.save(directory / "request.json", job)
        content = canonical_json_bytes(job["wire"]["body"])
        write_immutable(directory / "request.body", content)
        provider = job["provider"]
        header = {"openai": "Authorization", "anthropic": "x-api-key", "gemini": "x-goog-api-key"}[provider]
        headers = {"Content-Type": "application/json", header: "Bearer " + self.keys[provider] if provider == "openai" else self.keys[provider]}
        if provider == "anthropic":
            headers["anthropic-version"] = "2023-06-01"
        status, body, payload, error, subtype, response_headers = 0, None, b"", None, None, {}
        try:
            self.client.cookies.clear()
            response = self.client.request(job["wire"]["method"], job["wire"]["url"], headers=headers, content=content)
            self.client.cookies.clear()
            status, payload = response.status_code, response.content
            response_headers = {k: v for k, v in sanitized_headers(dict(response.headers)).items()
                if k.lower() not in {"set-cookie", "cookie", "authorization", "x-api-key", "x-goog-api-key"}}
            try:
                body = scoring.strict_json(payload.decode("utf-8"))
                e.require(type(body) is dict, "provider JSON object required")
            except (ValueError, rt.ValidationError, UnicodeError):
                body, error = None, "INVALID_JSON_NO_REPAIR"
        except httpx.TransportError as exc:
            error = "TRANSPORT_FAILURE_NO_RETRY"
            subtype = next((name for kind, name in ((httpx.ReadTimeout, "READ_TIMEOUT"),
                (httpx.ConnectTimeout, "CONNECT_TIMEOUT"), (httpx.WriteTimeout, "WRITE_TIMEOUT"),
                (httpx.PoolTimeout, "POOL_TIMEOUT")) if isinstance(exc, kind)), "TRANSPORT_OTHER")
        self.last_call = time.monotonic()
        envelope = {"http_status": status, "received_at": rt.utc_now(), "response_body": body,
            "response_body_sha256": sha256_bytes(payload), "headers": response_headers, "error_code": error,
            "transport_error_class": subtype, "synthetic_test_only": self.ctx["simulation"]}
        write_immutable(directory / "response.body", payload, allow_sensitive_scientific_data=True)
        rt.save(directory / "response.json", envelope)
        self.ledger.finish(claim)
        self.failed = status != 200 or body is None or error is not None
        e.require(not self.failed, "HTTP/transport/provider-format HOLD; evidence retained; no retry")
        return envelope


def run(root, g, *, execute_approved=False, simulation_transport=None, credential_resolver=None, sleep=time.sleep):
    simulation = simulation_transport is not None
    ctx = authorize(root, g, execute_approved=execute_approved, simulation=simulation)
    side = ctx["source_retry"]["side"]
    control = rt.ledger.Lease(side / "controller.lease")
    session = None
    try:
        e.require(not (ctx["destination"] / "RUN_FINISHED.json").exists(), "already completed; no restart")
        book = Ledger(ctx)
        try:
            counts, last = copy.deepcopy(book.counts), book.previous
        finally:
            book.close()
        e.require(counts["metadata"] == 6 and counts["calibration"] == 105
            and 57 <= counts["collection"] <= 151 and (counts["collection"] == 151 or counts["main"] == 0), "wrong checkpoint")
        # Fully verify all prior successful sources before any flag/key access.
        saved_sources(ctx, counts["collection"])
        if counts["main"]:
            previous_batch = scoring.read_json(ctx["destination"] / "main-batch.json")
            rt.method.validate_batch(root, previous_batch)
            previous_views = c.prefix_views(ctx, previous_batch, counts["main"])
            e.require(c.reachable(ctx, previous_batch, previous_views), "previous main failure cannot be skipped")
        gatectx = {**ctx, "continuation": {"side": side, "plan": ctx["source_retry"]["plan"]}}
        c.release_flags(gatectx, "single-source-retry", counts, last)
        memory = rt.old.RunKeyMemory(resolver=credential_resolver or rt.old.resolve_credentials)
        keys = dict.fromkeys(rt.old.KEY_NAMES, "offline-fixture-not-a-real-key") if simulation else memory(root, interactive=False)
        session = Session(ctx, keys, transport=simulation_transport, sleep=sleep)
        for job in session.fixed["collection"][session.ledger.counts["collection"]:]:
            response = session.exchange(job)
            record = rt.old._source_result(job, response, simulation)
            rt.old._screen(record["response_text"])
            rt.save(session.root / "collection-records" / (record["request_id"] + ".json"), record)
        records = saved_sources(ctx, 151)
        e.require(Counter(r["source_series"] for r in records) == {"M01": 50, "M02": 50, "M03": 50}, "source50each required")
        rows, families = [], {}
        for record in records:
            row = scoring.make_blind_observation(record, salt=ctx["preparation"]["blinding_salt"])
            rows.append(row)
            families[row["observation_id_blind"]] = record["provider"]
        batch = rt.method.build_batch(root, rows, families, synthetic_test_only=simulation)
        c.save_once(session.root / "main-batch.json", batch)
        session.bind_main(batch)
        views = c.prefix_views(ctx, batch, session.ledger.counts["main"])
        while session.ledger.counts["main"] < 300:
            e.require(c.reachable(ctx, batch, views), "unchanged primary/full guards not demonstrated reachable")
            q = batch["requests"][session.ledger.counts["main"]]
            job = rt.judge_job(q, "main")
            try:
                response = session.exchange(job)
            except ValueError:
                response = rt.raw(session.root / "L0_raw/main" / job["job_sha256"], job, simulation)
                e.require(session.failed and session.ledger.pending is None and c.eligible_timeout(job, response), "not delegated main READ_TIMEOUT")
                views.append(c.derive_one(ctx, batch, q, response))
                e.require(c.reachable(ctx, batch, views), "timeout made fixed guards unreachable")
                counts, last = copy.deepcopy(session.ledger.counts), session.ledger.previous
                rt.hold(ctx, c.HOLD_REASON)
                rt.save(side / "recoveries" / (f"{sum(counts.values()):06d}.json"),
                    {"phase": "main", "failed_job_sha256": job["job_sha256"], "failed_request_not_resent": True,
                    "unchanged_fixed_guard_reachability_demonstrated": True, "no_scientific_imputation": True})
                session.close()
                session = None
                ctx = authorize(root, g, execute_approved=True, simulation=simulation)
                gatectx = {**ctx, "continuation": {"side": side, "plan": ctx["source_retry"]["plan"]}}
                c.release_flags(gatectx, "single-source-retry", counts, last)
                session = Session(ctx, keys, transport=simulation_transport, sleep=sleep)
                session.bind_main(batch)
                continue
            views.append(c.derive_one(ctx, batch, q, response))
        result = rt._judge_result(ctx, batch)
        e.require(result["ratings"] == c.prefix_views(ctx, batch, 300), "main derivation differs from frozen importer")
        rt.save(session.root / "main-result.json", result)
        counts = session.ledger.audit()
        e.require(counts["new_counts"] == CAPS and counts["cumulative_reservations"] == 1467, "final amended accounting differs")
        summary = {"status": "EV31_SINGLE_SOURCE_RETRY_COMPLETED_RESULT_REVIEW_REQUIRED", "counts": counts,
            "source_answers": 150, "source_attempts": 151, "main_judgments": 300,
            "original_failed_source168_preserved": True, "source_retry_count": 1,
            "primary_numeric_guards_passed": result["aggregation"]["primary_quality_report"]["numeric_quality_checks_passed"],
            "full_numeric_guards_passed": result["aggregation"]["new_full_record_quality_report"]["numeric_quality_checks_passed"],
            "pilot_passed": False, "human_gold_validity_or_comparability_established": False,
            "publication_Core_restart_W01": False, "fixture_only": simulation}
        rt.save(session.root / "RUN_FINISHED.json", summary)
        return summary
    finally:
        try:
            rt.hold(ctx, c.HOLD_REASON)
        finally:
            if session:
                session.close()
            control.close()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    ap.add_argument("--authorization", required=True)
    ap.add_argument("--execute-approved", action="store_true")
    args = ap.parse_args()
    result = run(Path(args.root), scoring.read_json(Path(args.authorization)), execute_approved=args.execute_approved)
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()

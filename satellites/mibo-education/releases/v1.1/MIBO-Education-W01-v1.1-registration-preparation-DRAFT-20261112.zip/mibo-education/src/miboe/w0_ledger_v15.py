"""Append-only attempted-request accounting for prospective Education W0 v1.5.

The held 55 three-series attempts are a fixed baseline, never a zeroed counter.
A reservation is fsynced in two private locations BEFORE HTTP. An incomplete
reservation consumes its allowance and holds the run; it is never retried.
This is crash/accidental-replay protection, not tamper-proof remote storage.
"""

from __future__ import annotations

import copy
import os
from pathlib import Path
from typing import Any

from . import reciprocal_engine as e
from . import scoring
from .errors import ValidationError
from .util import canonical_json_bytes, sha256_file, utc_now
from .util import write_immutable as save

CAPS = {"calibration": 83, "collection": 150, "main": 300}
PRIOR = {
    "metadata": 9,
    "smoke": 3,
    "qualification": 21,
    "calibration": 22,
    "collection": 0,
    "main": 0,
}
RAW_FILES = {"request.json", "request.body", "response.json", "response.body"}


def outcome_class(response: dict[str, Any]) -> str:
    # This is factual transport classification, not a new scientific score or
    # a permission to retry. HTTP200 content still needs the frozen validator.
    return (
        "TECHNICAL_FAILURE"
        if response["http_status"] != 200 or response.get("error_code") is not None
        else "HTTP_COMPLETED_REQUIRES_CONTENT_VALIDATION"
    )


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValidationError(message)


def private_path(root: Path, destination: Path) -> Path:
    from .three_series import _private_root

    for part in (destination, *destination.parents):
        require(not part.is_symlink(), "private evidence cannot traverse a symlink")
        if hasattr(os.path, "isjunction"):
            require(not os.path.isjunction(part), "private evidence cannot traverse a junction")
    return _private_root(root, destination)


def read_json(path: Path) -> dict[str, Any]:
    require(path.is_file() and not path.is_symlink(), "missing/linked accounting record")
    return scoring.read_json(path)


def baseline(context: dict[str, Any]) -> dict[str, Any]:
    """No credentials or network: verify only the explicitly bound historical evidence."""
    a, plan = context["authorization"], context["plan"]
    accounting = private_path(plan["root"], Path(a["accounting_root"]))
    path = accounting / "BASELINE.json"
    require(sha256_file(path) == a["baseline_file_sha256"], "baseline file changed")
    b = read_json(path)
    e.verify(b, "baseline_sha256")
    require(b["plan_id"] == plan["config"]["plan_id"], "baseline plan mismatch")
    require(b["synthetic_test_only"] is context["simulation"], "baseline fixture boundary")
    require(
        b["prior_counts"] == PRIOR and b["new_request_caps"] == CAPS, "baseline count/cap mismatch"
    )
    require(
        b["maximum_new_requests"] == 533 and b["maximum_cumulative_requests"] == 588,
        "cumulative caps changed",
    )
    # Windows MSIX can resolve an approved AppData alias to its private LocalCache.
    # Compare the resolved locations, not two different spellings of the same directory.
    require(
        Path(b["new_execution_root"]).resolve() == context["destination"].resolve(),
        "baseline run mismatch",
    )
    require(Path(b["accounting_root"]).resolve() == accounting, "baseline ledger mismatch")
    old = private_path(plan["root"], Path(b["historical_run"]["root"]))
    require(
        old != context["destination"]
        and not context["destination"].is_relative_to(old)
        and not old.is_relative_to(context["destination"]),
        "old/new evidence overlap",
    )
    manifests = [b["historical_run"], *b.get("other_preserved_evidence", [])]
    for manifest in manifests:
        parent = private_path(plan["root"], Path(manifest["root"]))
        for name, digest in manifest["file_sha256"].items():
            rel = Path(name)
            require(not rel.is_absolute() and ".." not in rel.parts, "invalid evidence reference")
            target = parent / rel
            private_path(plan["root"], target)
            require(sha256_file(target) == digest, "historical evidence changed")
    require((old / "STOP").is_file(), "held parent run must remain stopped")
    if not context["simulation"]:
        require(
            a["baseline_file_sha256"] == plan["config"]["accounting"]["baseline_file_sha256"],
            "real baseline differs from prospectively locked baseline",
        )
    return b


def preparation(context: dict[str, Any]) -> dict[str, Any]:
    a, plan, destination = context["authorization"], context["plan"], context["destination"]
    b = baseline(context)
    path = destination / "PREPARATION.json"
    require(sha256_file(path) == a["preparation_file_sha256"], "preparation record changed")
    p = read_json(path)
    require(
        p
        == {
            "status": "PREPARED_NOT_AUTHORIZED",
            "plan_id": plan["config"]["plan_id"],
            "plan_sha256": plan["plan_sha256"],
            "release_sha256": plan["lock"]["release_sha256"],
            "baseline_file_sha256": a["baseline_file_sha256"],
            "execution_root": a["execution_root"],
            "accounting_root": a["accounting_root"],
            "prior_requests": 55,
            "maximum_new_requests": 533,
            "maximum_cumulative_requests": 588,
            "API_execution_authorized": False,
            "synthetic_test_only": context["simulation"],
        },
        "prepared destination binding mismatch",
    )
    return b


class Lease:
    """Nonblocking OS lock; process exit releases it, but never resets the ledger."""

    def __init__(self, path: Path):
        require(not path.is_symlink(), "linked ledger lease")
        self.stream = path.open("a+b")
        try:
            if self.stream.seek(0, os.SEEK_END) == 0:
                self.stream.write(b"0")
                self.stream.flush()
                os.fsync(self.stream.fileno())
            self.stream.seek(0)
            if os.name == "nt":
                import msvcrt

                msvcrt.locking(self.stream.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl

                fcntl.flock(self.stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            self.stream.close()
            raise ValidationError("another worker owns the accounting lease") from None

    def close(self) -> None:
        self.stream.close()  # OS releases the lock, not the immutable evidence.


class Ledger:
    def __init__(self, context: dict[str, Any], *, initial: bool = False):
        self.context = context
        self.root = private_path(
            context["plan"]["root"], Path(context["authorization"]["accounting_root"])
        )
        self.destination = context["destination"]
        self.base = preparation(context)
        self.lease = Lease(self.root / "worker.lease")
        try:
            binding = {
                "plan_sha256": context["plan"]["plan_sha256"],
                "authorization_sha256": context["authorization_sha256"],
                "baseline_file_sha256": context["authorization"]["baseline_file_sha256"],
                "execution_root": str(self.destination),
                "synthetic_test_only": context["simulation"],
            }
            if initial:
                require(
                    not (self.root / "RUN_BINDING.json").exists(),
                    "ledger allocated already; no counter reset or rerun",
                )
                require(
                    not any((self.root / "claims").iterdir())
                    and not any((self.root / "outcomes").iterdir()),
                    "prior attempts exist",
                )
                save(self.root / "RUN_BINDING.json", canonical_json_bytes(binding) + b"\n")
            require(
                read_json(self.root / "RUN_BINDING.json") == binding,
                "ledger allocated to another authorization/run",
            )
            self.binding_sha256 = sha256_file(self.root / "RUN_BINDING.json")
            self.audit()
        except BaseException:
            self.close()
            raise

    def _entries(self, folder: Path) -> list[Path]:
        values = sorted(folder.iterdir()) if folder.exists() else []
        require(
            all(v.is_file() and not v.is_symlink() and v.suffix == ".json" for v in values),
            "unexpected accounting artifact",
        )
        return values

    def audit(self) -> dict[str, Any]:
        """Reconstruct counts from durable claims, never a mutable summary counter."""
        claims = self._entries(self.root / "claims")
        outcomes = self._entries(self.root / "outcomes")
        witnesses = self._entries(self.destination / "attempt-witnesses")
        names = [f"{i:06d}.json" for i in range(1, len(claims) + 1)]
        require(
            [p.name for p in claims] == names
            and [p.name for p in outcomes] == names
            and [p.name for p in witnesses] == names,
            "pending/deleted/extra reservation or outcome; HOLD, never resend",
        )
        counts, jobs = dict.fromkeys(CAPS, 0), set()
        previous = self.base["baseline_sha256"]
        paths = set()
        for index, path in enumerate(claims, 1):
            claim = read_json(path)
            e.verify(claim, "claim_sha256")
            require(
                (self.destination / "attempt-witnesses" / path.name).read_bytes()
                == path.read_bytes(),
                "reservation witness mismatch",
            )
            require(
                claim["sequence"] == index
                and claim["previous_claim_sha256"] == previous
                and claim["baseline_file_sha256"]
                == self.context["authorization"]["baseline_file_sha256"]
                and claim["run_binding_sha256"] == self.binding_sha256,
                "reservation chain/binding mismatch",
            )
            phase, job_id = claim["phase"], claim["job_sha256"]
            require(phase in CAPS and job_id not in jobs, "duplicate/invalid reservation")
            raw = self.destination / "L0_raw" / phase / job_id
            require(
                claim["raw_relative_path"] == raw.relative_to(self.destination).as_posix(),
                "reservation path mismatch",
            )
            private_path(self.context["plan"]["root"], raw)
            require({p.name for p in raw.iterdir()} == RAW_FILES, "incomplete raw attempt; HOLD")
            job = read_json(raw / "request.json")
            e.verify(job, "job_sha256")
            require(
                job["job_sha256"] == job_id
                and job["phase"] == phase
                and e.digest(job["wire"]) == claim["wire_sha256"]
                and job["wire"]["method"] == claim["method"],
                "raw request mismatch",
            )
            require(
                (raw / "request.body").read_bytes()
                == (
                    b""
                    if job["wire"]["body"] is None
                    else canonical_json_bytes(job["wire"]["body"])
                ),
                "raw request body mismatch",
            )
            outcome = read_json(self.root / "outcomes" / path.name)
            e.verify(outcome, "outcome_sha256")
            require(
                outcome["claim_sha256"] == claim["claim_sha256"]
                and outcome["raw_file_sha256"] == {n: sha256_file(raw / n) for n in RAW_FILES},
                "outcome/raw binding mismatch",
            )
            response = read_json(raw / "response.json")
            require(
                response["response_body_sha256"] == sha256_file(raw / "response.body")
                and outcome["http_status"] == response["http_status"]
                and outcome["outcome_class"] == outcome_class(response)
                and response["synthetic_test_only"] is self.context["simulation"],
                "response binding mismatch",
            )
            counts[phase] += 1
            jobs.add(job_id)
            paths.add(raw.relative_to(self.destination).as_posix())
            previous = claim["claim_sha256"]
        raw_paths = {
            p.relative_to(self.destination).as_posix()
            for p in (self.destination / "L0_raw").glob("*/*")
        }
        require(raw_paths == paths, "unaccounted raw attempt or deleted ledger claim")
        self._caps(counts)
        self.counts, self.jobs, self.previous = counts, jobs, previous
        self.pending = None
        self.names = names
        return self.summary()

    @staticmethod
    def _caps(counts: dict[str, int]) -> None:
        require(
            set(counts) == set(CAPS)
            and all(type(v) is int and 0 <= v <= CAPS[k] for k, v in counts.items()),
            "phase request cap exceeded",
        )
        require(
            sum(counts.values()) <= 533 and 55 + sum(counts.values()) <= 588,
            "new/cumulative request cap exceeded",
        )

    def summary(self) -> dict[str, Any]:
        return {
            "prior_requests": 55,
            "new_requests": sum(self.counts.values()),
            "cumulative_requests": 55 + sum(self.counts.values()),
            "new_counts": copy.deepcopy(self.counts),
            "cumulative_counts": {k: PRIOR[k] + self.counts.get(k, 0) for k in PRIOR},
            "maximum_new_requests": 533,
            "maximum_cumulative_requests": 588,
            "baseline_file_sha256": self.context["authorization"]["baseline_file_sha256"],
            "latest_claim_sha256": self.previous,
            "synthetic_test_only": self.context["simulation"],
        }

    def reserve(self, job: dict[str, Any]) -> dict[str, Any]:
        require(self.pending is None, "incomplete prior attempt; never retry")
        require(
            [p.name for p in self._entries(self.root / "claims")] == self.names
            and [p.name for p in self._entries(self.root / "outcomes")] == self.names
            and [p.name for p in self._entries(self.destination / "attempt-witnesses")]
            == self.names,
            "accounting inventory changed",
        )
        require(
            sha256_file(self.root / "RUN_BINDING.json") == self.binding_sha256,
            "run allocation changed",
        )
        e.verify(job, "job_sha256")
        require(job["job_sha256"] not in self.jobs, "duplicate job; no resend")
        counts = dict(self.counts)
        require(job["phase"] in CAPS, "invalid request phase")
        counts[job["phase"]] += 1
        self._caps(counts)
        index = sum(self.counts.values()) + 1
        claim = e.sealed(
            {
                "sequence": index,
                "reserved_at": utc_now(),
                "previous_claim_sha256": self.previous,
                "baseline_file_sha256": self.context["authorization"]["baseline_file_sha256"],
                "run_binding_sha256": self.binding_sha256,
                "phase": job["phase"],
                "job_sha256": job["job_sha256"],
                "method": job["wire"]["method"],
                "wire_sha256": e.digest(job["wire"]),
                "raw_relative_path": f"L0_raw/{job['phase']}/{job['job_sha256']}",
            },
            "claim_sha256",
        )
        name = f"{index:06d}.json"
        data = canonical_json_bytes(claim) + b"\n"
        save(self.root / "claims" / name, data)
        save(self.destination / "attempt-witnesses" / name, data)
        self.pending = claim
        self.counts, self.previous = counts, claim["claim_sha256"]
        self.jobs.add(job["job_sha256"])
        return claim

    def finish(self, claim: dict[str, Any]) -> None:
        require(claim == self.pending, "outcome without matching reservation")
        raw = self.destination / claim["raw_relative_path"]
        require({p.name for p in raw.iterdir()} == RAW_FILES, "raw outcome incomplete")
        response = read_json(raw / "response.json")
        value = e.sealed(
            {
                "claim_sha256": claim["claim_sha256"],
                "http_status": response["http_status"],
                "outcome_class": outcome_class(response),
                "raw_file_sha256": {n: sha256_file(raw / n) for n in sorted(RAW_FILES)},
            },
            "outcome_sha256",
        )
        name = f"{claim['sequence']:06d}.json"
        save(self.root / "outcomes" / name, canonical_json_bytes(value) + b"\n")
        self.names.append(name)
        self.pending = None

    def close(self) -> None:
        self.lease.close()


def audited_summary(context: dict[str, Any]) -> dict[str, Any]:
    ledger = Ledger(context)
    try:
        return ledger.summary()
    finally:
        ledger.close()

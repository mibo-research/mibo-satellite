"""Read-only office Gemini credential route, invoked only after W0 authorization.

No key material is read on import/status. No IAM, key creation/deletion, project
move, billing write or model request is supported. Existing office OAuth only;
no inherited GEMINI_API_KEY or old-account fallback, no persistent secret cache.
The management sequence retains the already verified migration helper behavior.
"""

from __future__ import annotations

import json
import re
import subprocess
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

from .errors import ValidationError
from .util import sha256_file

ACCOUNT = "office@sasano.org"
PROJECT = "gen-lang-client-0898165643"
NUMBER = "985715083960"
ORGANIZATION = "523120468769"
BILLING = "billingAccounts/01C374-B71DFA-CEE3C7"
RESOURCE = f"projects/{NUMBER}/locations/global/keys/mibo-education-office-20261107"
SDK = Path("C:/Users/offic/AppData/Local/Google/Cloud SDK/google-cloud-sdk")


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValidationError(message)


def guard(config: dict[str, Any]) -> None:
    require(
        not Path(config["credentials"]["restart_hold_file"]).exists(),
        "owner API_RESTART_HOLD; no key or model request",
    )


def reference(config: dict[str, Any]) -> dict[str, Any]:
    path = Path(config["credentials"]["Gemini_office_reference"])
    require(path.is_file() and not path.is_symlink(), "office reference missing/linked")
    require(
        sha256_file(path) == config["credentials"]["Gemini_office_reference_file_sha256"],
        "office reference changed",
    )
    data = json.loads(path.read_text("utf-8"))
    require(
        data.get("account") == ACCOUNT
        and data.get("project_id") == PROJECT
        and data.get("key_resource") == RESOURCE
        and data.get("credential_mode") == "GOOGLE_MANAGEMENT_REFERENCE_PROCESS_MEMORY_ONLY"
        and data.get("model_api_execution_authorized_by_this_file") is False
        and data.get("fallback_to_inherited_or_old_Gemini_key") is False,
        "office reference binding mismatch",
    )
    return data


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise ValidationError("management redirect rejected")


class OfficeReader:
    """Explicit, bounded GET-only management client. Never used by offline preparation."""

    def __init__(self):
        command = [
            str(SDK / "platform/bundledpython/python.exe"),
            "-S",
            str(SDK / "lib/gcloud.py"),
            "auth",
            "print-access-token",
            f"--account={ACCOUNT}",
            "--quiet",
        ]
        try:
            result = subprocess.run(command, capture_output=True, text=True, timeout=90)
        except (OSError, subprocess.TimeoutExpired):
            raise ValidationError("office OAuth unavailable; no output or fallback") from None
        require(
            result.returncode == 0 and bool(result.stdout.strip()),
            "office OAuth unavailable; no secret output/fallback",
        )
        self.token = result.stdout.strip()
        self.opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())

    def get(self, host: str, path: str) -> dict[str, Any]:
        require(
            host
            in {
                "cloudresourcemanager.googleapis.com",
                "cloudbilling.googleapis.com",
                "apikeys.googleapis.com",
            },
            "non-management host rejected",
        )
        request = urllib.request.Request(
            "https://" + host + path,
            method="GET",
            headers={"Authorization": "Bearer " + self.token},
        )
        try:
            with self.opener.open(request, timeout=30) as response:
                return json.load(response)
        except (urllib.error.URLError, TimeoutError, ValueError, OSError):
            # Lookup URLs can contain the secret; never expose exceptions or response bodies.
            raise ValidationError("management read failed; no retry or fallback") from None

    def key(self) -> str:
        project = self.get("cloudresourcemanager.googleapis.com", f"/v3/projects/{PROJECT}")
        billing = self.get("cloudbilling.googleapis.com", f"/v1/projects/{PROJECT}/billingInfo")
        require(
            project.get("parent") == "organizations/" + ORGANIZATION
            and project.get("state") == "ACTIVE"
            and project.get("name") == "projects/" + NUMBER,
            "approved organization/project binding not verified",
        )
        require(
            billing.get("billingEnabled") is True and billing.get("billingAccountName") == BILLING,
            "existing paid billing binding not verified",
        )
        metadata = self.get("apikeys.googleapis.com", "/v2/" + RESOURCE)
        require(
            metadata.get("name") == RESOURCE
            and not metadata.get("deleteTime")
            and metadata.get("restrictions")
            == {"apiTargets": [{"service": "generativelanguage.googleapis.com"}]},
            "key not active or restriction/resource mismatch",
        )
        value = self.get("apikeys.googleapis.com", "/v2/" + RESOURCE + "/keyString").get(
            "keyString", ""
        )
        require(
            isinstance(value, str) and bool(re.fullmatch(r"[A-Za-z0-9_-]{20,200}", value)),
            "credential format rejected",
        )
        lookup = self.get(
            "apikeys.googleapis.com",
            "/v2/keys:lookupKey?" + urllib.parse.urlencode({"keyString": value}),
        )
        require(lookup.get("name") == RESOURCE, "credential resource binding mismatch")
        return value

    def close(self) -> None:
        self.token = ""


def gemini_key(config: dict[str, Any]) -> str:
    guard(config)
    reference(config)
    reader = OfficeReader()
    try:
        value = reader.key()
        guard(config)
        return value
    finally:
        reader.close()

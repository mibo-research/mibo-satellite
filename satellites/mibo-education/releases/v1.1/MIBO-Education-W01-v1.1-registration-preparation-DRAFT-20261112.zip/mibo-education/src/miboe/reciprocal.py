"""Versioned reciprocal judging and common-calibration processing, offline only."""

from __future__ import annotations

import copy
import hashlib
import hmac
from collections import Counter
from itertools import combinations
from pathlib import Path
from typing import Any

from . import reciprocal_engine as engine
from . import scoring as legacy
from .errors import ValidationError
from .util import sha256_file

METHOD = "MIBOE-AI-RECIPROCAL-v2.0"
CONFIG = "scoring/ai-reciprocal-v2.0.json"
BANK = "scoring/common-calibration-v1.0.json"
LOCK = "scoring/ai-reciprocal-v2.0.lock.json"
ALLOCATION = "scoring/pilot-allocation-150-v1.0.json"
AMENDMENT = "protocol/amendments/MIBOE-AM-20261107-02.yaml"
BOUND = {
    CONFIG,
    ALLOCATION,
    BANK,
    AMENDMENT,
    "src/miboe/reciprocal.py",
    "src/miboe/reciprocal_engine.py",
    "scoring/ai-panel-v1.0.lock.json",
}


def load_plan(module_root: Path) -> dict[str, Any]:
    root = module_root.resolve()
    lock = legacy.read_json(root / LOCK)
    engine.verify(lock, "lock_sha256")
    engine.require(lock["method_id"] == METHOD, "reciprocal method mismatch")
    engine.require(set(lock["files"]) == BOUND, "incomplete reciprocal lock")
    for name, expected in lock["files"].items():
        engine.require(sha256_file(root / name) == expected, "reciprocal locked file changed")
    old = legacy.load_scoring_plan(root)
    config, bank = legacy.read_json(root / CONFIG), legacy.read_json(root / BANK)
    engine.require(config["method_id"] == METHOD, "config method mismatch")
    engine.require(config["source_pairs"] == engine.PAIRS, "routing policy mismatch")
    engine.require(
        [(j["judge_id"], j["provider"]) for j in config["judges"]]
        == list(engine.JUDGE_FAMILIES.items()),
        "judge pool mismatch",
    )
    engine.require(
        config["previous_lock_sha256"] == old["lock"]["lock_sha256"],
        "legacy scoring provenance changed",
    )
    engine.require(
        config["execution"]["mode"] == "OFFLINE_ONLY"
        and config["execution"]["API_calls_authorized"] is False,
        "no API authorization is present",
    )
    cases = bank["cases"]
    engine.require(
        len(cases) == 35 and len({c["case_id"] for c in cases}) == 35,
        "common calibration requires 35 unique cases",
    )
    engine.require(
        Counter(c["item_id"].split("-")[0] for c in cases)
        == dict.fromkeys([f"E{i}" for i in range(1, 8)], 5),
        "calibration domain coverage mismatch",
    )
    allocation = legacy.read_json(root / ALLOCATION)
    engine.require(
        allocation["source_proposal_sha256"]
        == "39cab2eb6987400ba35883da5aba26d8b60287b12628a2a54c51133907a178ab",
        "approved allocation provenance mismatch",
    )
    return {
        "root": root,
        "lock": lock,
        "config": config,
        "bank": bank,
        "allocation": allocation,
        "legacy": old,
    }


def status(module_root: Path) -> dict[str, Any]:
    plan = load_plan(module_root)
    return {
        "method_id": METHOD,
        "lock_sha256": plan["lock"]["lock_sha256"],
        "judge_pool": plan["config"]["judges"],
        "source_pairs": engine.PAIRS,
        "main_ratings_per_answer": 2,
        "common_calibration_cases": 35,
        "planned_main_ratings": 300,
        "planned_calibration_ratings": 105,
        "offline_implementation_ready": True,
        "live_qualified": False,
        "live_transport_implemented": False,
        "API_calls_authorized": False,
        "pilot_passed": False,
        "API_calls_made": 0,
    }


def calibration_rows(module_root: Path, *, salt: str) -> list[dict[str, str]]:
    engine.require(len(salt.encode()) >= 32, "calibration blinding salt too short")
    plan = load_plan(module_root)
    return [
        {
            "observation_id_blind": "B-"
            + hmac.new(
                salt.encode(),
                (plan["bank"]["bank_id"] + "|" + case["case_id"]).encode(),
                hashlib.sha256,
            ).hexdigest()[:32],
            "item_id": case["item_id"],
            "exact_frozen_prompt": plan["legacy"]["items"][case["item_id"]].prompt,
            "visible_response": case["visible_response"],
        }
        for case in plan["bank"]["cases"]
    ]


def build_batch(
    module_root: Path,
    rows: list[dict[str, str]],
    source_families: dict[str, str],
    *,
    phase: str = "main",
) -> dict[str, Any]:
    plan = load_plan(module_root)
    engine.require(phase in {"main", "calibration"}, "unknown phase")
    engine.require(isinstance(rows, list) and bool(rows), "nonempty blind rows required")
    engine.require(isinstance(source_families, dict), "private source map must be an object")
    ids = [r["observation_id_blind"] for r in rows]
    engine.require(len(ids) == len(set(ids)), "duplicate blind ID")
    if phase == "main":
        engine.require(set(ids) == set(source_families), "private source map coverage mismatch")
        for source in source_families.values():
            engine.pair_for_source(source)
    else:
        engine.require(not source_families, "calibration is not source-model output")
        expected = Counter((c["item_id"], c["visible_response"]) for c in plan["bank"]["cases"])
        engine.require(
            Counter((r["item_id"], r["visible_response"]) for r in rows) == expected,
            "common calibration bank must be used intact, not cherry-picked",
        )
    requests, observations = [], {}
    judges = {j["judge_id"]: j for j in plan["config"]["judges"]}
    native = legacy._native_schema(plan["legacy"]["schema"])
    for row in sorted(rows, key=lambda r: r["observation_id_blind"]):
        legacy._validate_blind(row, plan["legacy"])
        blind = row["observation_id_blind"]
        observations[blind] = copy.deepcopy(row)
        assigned = (
            engine.pair_for_source(source_families[blind]) if phase == "main" else list(judges)
        )
        for judge_id in sorted(assigned):
            requests.append(
                engine.prepare_request(
                    judges[judge_id],
                    row,
                    system=plan["legacy"]["system"],
                    rubric=legacy._rubric(plan["legacy"], row["item_id"]),
                    schema=native,
                    instruction_schema=plan["legacy"]["schema"],
                    phase=phase,
                )
            )
    return engine.sealed(
        {
            "schema_version": "1.0",
            "method_id": METHOD,
            "scoring_lock_sha256": plan["lock"]["lock_sha256"],
            "phase": phase,
            "calibration_bank_sha256": sha256_file(plan["root"] / BANK),
            "private_source_families_never_sent_to_judges": copy.deepcopy(source_families),
            "observations": observations,
            "requests": requests,
            "API_calls_authorized": False,
            "official_longitudinal_data": False,
        },
        "batch_sha256",
    )


def validate_batch(module_root: Path, batch: dict[str, Any]) -> None:
    engine.verify(batch, "batch_sha256")
    rebuilt = build_batch(
        module_root,
        list(batch["observations"].values()),
        batch["private_source_families_never_sent_to_judges"],
        phase=batch["phase"],
    )
    engine.require(batch == rebuilt, "batch differs from locked reciprocal construction")


def _import(
    plan: dict[str, Any], batch: dict[str, Any], envelope: dict[str, Any]
) -> dict[str, Any]:
    engine.require(isinstance(envelope, dict), "response envelope must be an object")
    requests = {r["request_id"]: r for r in batch["requests"]}
    request_id = envelope.get("request_id")
    engine.require(
        isinstance(request_id, str) and request_id in requests, "response request not in this batch"
    )
    engine.require(
        set(envelope) == {"request_id", "http_status", "received_at", "response_body"},
        "response envelope allowlist violation; no auth headers",
    )
    request = requests[request_id]
    result, model, error = None, None, None
    try:
        text, model = engine.response_text(request, envelope)
        result = legacy.strict_json(text)
        legacy.validate_judgment(
            plan["legacy"], batch["observations"][request["observation_id_blind"]], result
        )
    except (ValueError, KeyError, TypeError, AttributeError, ValidationError):
        result, error = None, "INVALID_FINISH_IDENTITY_OR_JUDGMENT"
    return engine.sealed(
        {
            "schema_version": "1.0",
            "method_id": METHOD,
            "batch_sha256": batch["batch_sha256"],
            "request_id": request_id,
            "judge_id": request["judge_id"],
            "phase": batch["phase"],
            "observation_id_blind": request["observation_id_blind"],
            "returned_model": model,
            "raw_envelope": copy.deepcopy(envelope),
            "raw_envelope_sha256": engine.digest(envelope),
            "valid": result is not None,
            "error_code": error,
            "judgment": result,
        },
        "rating_sha256",
    )


def import_many(
    module_root: Path, batch: dict[str, Any], envelopes: list[dict[str, Any]]
) -> list[dict[str, Any]]:
    validate_batch(module_root, batch)
    engine.require(isinstance(envelopes, list), "response list required")
    plan = load_plan(module_root)
    ratings = [_import(plan, batch, e) for e in envelopes]
    ids = [r["request_id"] for r in ratings]
    engine.require(len(ids) == len(set(ids)), "duplicate rating attempt; no cherry-picking")
    return ratings


def aggregate(
    module_root: Path, batch: dict[str, Any], ratings: list[dict[str, Any]]
) -> dict[str, Any]:
    validate_batch(module_root, batch)
    plan, by_request = load_plan(module_root), {}
    for rating in ratings:
        engine.verify(rating, "rating_sha256")
        engine.require(rating["request_id"] not in by_request, "duplicate rating attempt")
        engine.require(
            rating == _import(plan, batch, rating["raw_envelope"]),
            "rating differs from raw response or another phase/batch",
        )
        by_request[rating["request_id"]] = rating
    output = []
    for blind, row in batch["observations"].items():
        requests = [r for r in batch["requests"] if r["observation_id_blind"] == blind]
        pair = {
            r["judge_id"]: by_request.get(r["request_id"], {}).get("judgment") for r in requests
        }
        core = {
            "observation_id_blind": blind,
            "item_id": row["item_id"],
            "rating_artifact_hashes": [
                by_request[r["request_id"]]["rating_sha256"]
                for r in requests
                if r["request_id"] in by_request
            ],
        }
        if batch["phase"] == "main":
            core.update(engine.combine_pair(pair))
            core["source_family_private_join"] = batch[
                "private_source_families_never_sent_to_judges"
            ][blind]
        else:
            core.update(
                individual_ratings=pair, valid_ratings=sum(v is not None for v in pair.values())
            )
        output.append(core)
    report = (
        _main_report(output, plan["config"], plan["allocation"])
        if batch["phase"] == "main"
        else _calibration_report(output, plan["config"])
    )
    return engine.sealed(
        {
            "schema_version": "1.0",
            "method_id": METHOD,
            "batch_sha256": batch["batch_sha256"],
            "scoring_lock_sha256": plan["lock"]["lock_sha256"],
            "phase": batch["phase"],
            "responses": output,
            "quality_report": report,
            "scores_automatically_recalibrated": False,
            "pilot_passed": False,
            "human_validity_or_correctness_established": False,
            "cross_source_comparability_established": False,
            "global_model_ranking_computed": False,
            "API_calls_made": 0,
        },
        "aggregation_sha256",
    )


def _main_report(
    rows: list[dict[str, Any]], config: dict[str, Any], allocation: dict[str, Any]
) -> dict[str, Any]:
    policy = config["main_pilot_guards"]
    sources = Counter(r["source_family_private_join"] for r in rows)
    domains = Counter(r["item_id"].split("-")[0] for r in rows)
    numeric = [r for r in rows if r["numeric_pair"] is not None]
    numeric_domains = Counter(r["item_id"].split("-")[0] for r in numeric)
    pair_reports = {}
    for source in engine.PAIRS:
        subset = [r for r in rows if r["source_family_private_join"] == source]
        metrics = engine.agreement(
            [r["numeric_pair"] for r in subset if r["numeric_pair"] is not None]
        )
        fraction = sum(r["valid_ratings"] == 2 for r in subset) / len(subset) if subset else 0
        metrics["valid_pair_fraction"] = fraction
        metrics["assigned_judges"] = engine.pair_for_source(source)
        metrics["checks_passed"] = (
            metrics["numeric_pairs"] >= policy["minimum_numeric_pairs_per_source_pair"]
            and fraction >= policy["minimum_valid_fraction"]
            and metrics["within_one_fraction"] is not None
            and metrics["within_one_fraction"] >= policy["minimum_within_one_fraction"]
            and metrics["quadratic_weighted_kappa"] is not None
            and metrics["quadratic_weighted_kappa"]
            >= policy["minimum_quadratic_weighted_kappa_per_source_pair"]
        )
        pair_reports[source] = metrics
    checks = {
        "approved_source_allocation": sources == config["observations"]["by_source"],
        "approved_item_source_cells": Counter(
            (r["source_family_private_join"], r["item_id"]) for r in rows
        )
        == Counter((s["source_family"], s["item_id"]) for s in allocation["slots"]),
        "minimum_responses": len(rows) >= policy["minimum_responses"],
        "domain_coverage": all(
            domains[f"E{i}"] >= policy["minimum_per_domain"] for i in range(1, 8)
        ),
        "numeric_pairs": len(numeric) >= policy["minimum_numeric_pairs"],
        "numeric_domain_coverage": all(
            numeric_domains[f"E{i}"] >= policy["minimum_numeric_pairs_per_domain"]
            for i in range(1, 8)
        ),
        "all_three_pairs": all(v["checks_passed"] for v in pair_reports.values()),
    }
    return {
        "response_count": len(rows),
        "source_counts": dict(sources),
        "domain_counts": dict(domains),
        "pair_specific_agreement": pair_reports,
        "checks": checks,
        "numeric_quality_checks_passed": all(checks.values()),
        "pooled_two_rater_kappa": None,
        "common_calibration_reviewed": False,
        "actual_identity_and_scope_reviewed": False,
        "pilot_passed": False,
        "automatic_cross_source_comparison_permitted": False,
    }


def _calibration_report(rows: list[dict[str, Any]], config: dict[str, Any]) -> dict[str, Any]:
    policy, reports = config["calibration"], {}
    valid_fraction = sum(r["valid_ratings"] for r in rows) / (len(rows) * 3) if rows else 0
    for first, second in combinations(engine.JUDGE_FAMILIES, 2):
        pairs = []
        by_domain = {f"E{i}": [] for i in range(1, 8)}
        for row in rows:
            a, b = (row["individual_ratings"].get(j) for j in (first, second))
            if a and b and a["status"] == b["status"] == "RATEABLE":
                pairs.append([a["primary_score"], b["primary_score"]])
                by_domain[row["item_id"].split("-")[0]].append(pairs[-1])
        metrics = engine.agreement(pairs)
        metrics["by_domain"] = {d: engine.agreement(p) for d, p in by_domain.items()}
        metrics["checks_passed"] = (
            metrics["numeric_pairs"] >= policy["minimum_numeric_pairs_per_judge_pair"]
            and all(
                len(p) >= policy["minimum_numeric_pairs_per_domain"] for p in by_domain.values()
            )
            and metrics["within_one_fraction"] is not None
            and metrics["within_one_fraction"] >= policy["minimum_within_one_fraction"]
            and metrics["quadratic_weighted_kappa"] is not None
            and metrics["quadratic_weighted_kappa"] >= policy["minimum_quadratic_weighted_kappa"]
            and metrics["mean_signed_difference_first_minus_second"] is not None
            and abs(metrics["mean_signed_difference_first_minus_second"])
            <= policy["maximum_absolute_mean_signed_difference"]
        )
        reports[first + "_" + second] = metrics
    checks = {
        "all_35_common_cases": len(rows) == 35,
        "valid_fraction": valid_fraction >= policy["minimum_valid_fraction"],
        "pair_specific_agreement_and_severity": all(m["checks_passed"] for m in reports.values()),
    }
    return {
        "common_cases": len(rows),
        "valid_rating_fraction": valid_fraction,
        "pair_specific_calibration": reports,
        "checks": checks,
        "technical_calibration_guards_passed": all(checks.values()),
        "owner_casebank_content_review_completed": False,
        "common_calibration_clearance_granted": False,
        "labels_are_not_human_gold": True,
        "scores_automatically_corrected": False,
        "model_training_or_fine_tuning_performed": False,
        "main_scoring_or_comparison_authorized": False,
    }

"""Human-readable derivative of the unchanged, locked Education case bank."""

from __future__ import annotations

import html
import re
from pathlib import Path
from typing import Any

from . import reciprocal
from .artifacts import load_yaml
from .util import artifact_hash, sha256_file

DOMAIN_JA = {
    "E1": "教育的支援",
    "E2": "学習者の主体性",
    "E3": "知識・確実性の扱い",
    "E4": "評価・採点",
    "E5": "発達段階への適合",
    "E6": "教育的安全・依存",
    "E7": "問い・課題の設定",
}


def review_data(root: Path) -> dict[str, Any]:
    plan = reciprocal.load_plan(root)
    manual = (root / "protocol/item-level-scoring-manual-v1.0.md").read_text(encoding="utf-8")
    cases = []
    for case in plan["bank"]["cases"]:
        item = case["item_id"]
        section = re.search(rf"(?ms)^### {re.escape(item)}[^\n]*\n.*?(?=^### E|\Z)", manual)
        if section is None:
            raise ValueError("missing frozen item anchor")
        anchors = dict(re.findall(r"^- \*\*([0-4])\*\* — (.+)$", section[0], re.M))
        if set(anchors) != set("01234"):
            raise ValueError("review requires all five frozen anchors")
        level = case["intended_anchor_level_for_design_review_only"]
        cases.append(
            {
                **case,
                "domain_ja": DOMAIN_JA[item.split("-")[0]],
                "exact_frozen_prompt": plan["legacy"]["items"][item].prompt,
                "frozen_anchor_at_intended_level": anchors[str(level)],
                "all_frozen_anchors": anchors,
                "owner_content_review": "PENDING",
            }
        )
    value = {
        "review_id": "MIBOE-CAL35-OWNER-REVIEW-v1.0",
        "bank_sha256": sha256_file(root / reciprocal.BANK),
        "scoring_lock_sha256": plan["lock"]["lock_sha256"],
        "case_count": len(cases),
        "coverage": "7 domains x 5 levels; one selected item per domain, NOT all 70 items",
        "authored_examples_not_validated_gold": True,
        "owner_content_review_completed": False,
        "reviewing_this_list_does_not_authorize_execution": True,
        "baseline_policy": load_yaml(root / "protocol/amendments/MIBOE-AM-20261107-03.yaml")[
            "baseline_policy"
        ],
        "cases": cases,
    }
    return {**value, "review_sha256": artifact_hash(value)}


def render_html(root: Path) -> str:
    data = review_data(root)
    esc = html.escape
    sections = []
    for domain, title in DOMAIN_JA.items():
        cases = [c for c in data["cases"] if c["item_id"].startswith(domain + "-")]
        first = cases[0]
        rows = "".join(
            f'<tr id="{esc(c["case_id"])}"><td>{esc(c["case_id"])}</td>'
            f"<td>{c['intended_anchor_level_for_design_review_only']}</td>"
            f"<td>{esc(c['visible_response'])}</td>"
            f"<td>{esc(c['frozen_anchor_at_intended_level'])}</td><td>未承認</td></tr>"
            for c in cases
        )
        sections.append(
            f"<section><h2>{domain} {title} — {esc(first['item_id'])}</h2>"
            '<h3>凍結済み設問（原文）</h3><p class="prompt">'
            f"{esc(first['exact_frozen_prompt'])}</p>"
            "<table><thead><tr><th>例ID</th><th>意図点</th><th>作成した回答例（全文）</th>"
            "<th>対応する凍結アンカー</th><th>確認状態</th></tr></thead>"
            f"<tbody>{rows}</tbody></table></section>"
        )
    return (
        """<!doctype html><html lang="ja"><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'">
<title>MIBO-Education 共通校正35例・確認用一覧</title>
<style>body{font:16px/1.7 'Yu Gothic',sans-serif;max-width:1400px;margin:32px auto;padding:0 24px;
color:#172b3a}h1{font-size:27px}h2{margin-top:40px;border-bottom:2px solid #397681}
.notice{background:#fff5d9;padding:18px;border-left:5px solid #b77d00}.prompt{white-space:pre-wrap;
background:#edf5f7;padding:14px}table{border-collapse:collapse;width:100%;table-layout:fixed}
th,td{border:1px solid #bccbd0;padding:10px;vertical-align:top;overflow-wrap:anywhere}
th{background:#e7f0f2}th:nth-child(1){width:12%}th:nth-child(2){width:5%}th:nth-child(3){width:43%}
th:nth-child(4){width:30%}th:nth-child(5){width:7%}footer{font-size:12px;overflow-wrap:anywhere}
@media print{body{margin:0;font-size:10pt;padding:0}section{break-before:page}
tr{break-inside:avoid}thead{display:table-header-group}}</style>
<h1>MIBO-Education 共通校正35例・確認用一覧</h1>
<p>確認者：笹埜健斗 ／ 状態：内容レビュー待ち ／ 対象：Educationのみ（Coreとは別）</p>
<div class="notice">これはAIが作成した説明用の例であり、実観測・人間の正解データ・
モデルの実採点結果ではありません。意図点は設計レビュー用で、採点モデルには送りません。
7領域それぞれ1設問の0–4点例であり、全70設問を網羅する校正ではありません。</div>
<h2>確認することは3つだけ</h2><ol><li>各例が凍結アンカーの意図点に合っているか。</li>
<li>隣の点数との違いが、単なる長さ・丁寧さではなく対象行動に表れているか。</li>
<li>誤った内容を含む低得点例は比較用だと理解でき、個人情報・権利上の問題がないか。</li></ol>
<p>問題なければ「共通校正35例の内容を承認」。修正があれば「例ID：修正点」と返信してください。
この一覧を開いただけでは承認になりません。内容承認もAPI実行・公開の承認にはなりません。
修正時は元の35例を保存し、新版として再固定します。</p>
<p>予定：共通校正35×3＝105採点。予備観測150回答（各系列50）には別に300採点。
W01はW0合格後の将来日とする方針のみ承認済みで、具体的日付は未確定です。</p>
"""
        + "".join(sections)
        + (
            "<footer><p>原本を変更しない派生一覧。実API呼出し0、公開操作0。</p>"
            f"<p>Bank SHA-256: {data['bank_sha256']}<br>"
            f"Method lock: {data['scoring_lock_sha256']}<br>"
            f"Review SHA-256: {data['review_sha256']}</p></footer></html>"
        )
    )

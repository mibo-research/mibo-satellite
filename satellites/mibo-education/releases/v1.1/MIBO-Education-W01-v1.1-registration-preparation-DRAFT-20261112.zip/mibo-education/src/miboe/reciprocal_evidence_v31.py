"""Approved prospective auxiliary contract. Offline preparation/import only; no sender."""
from __future__ import annotations

import copy
import os
from collections import Counter
from pathlib import Path

import yaml

from . import evidence_pilot_runtime as historical, evidence_references as refs
from . import reciprocal as old, reciprocal_engine as e, reciprocal_evidence_v3 as v3
from . import scoring, schema_wire_v14 as wire, validity_v15 as components
from .errors import ValidationError
from .util import sha256_file

METHOD = "MIBOE-AI-RECIPROCAL-EVIDENCE-v3.1"
CONFIG = "scoring/ai-reciprocal-evidence-v3.1.json"
SCHEMA = "scoring/judge-output-evidence-v3.1.schema.json"
SYSTEM = "scoring/judge-system-evidence-v3.1.txt"
ADDENDUM = "scoring/judge-auxiliary-addendum-v3.1.txt"
DECISION = "protocol/approvals/AUXILIARY-CONTRACT-V31-ADOPTION-20261111.yaml"
LOCK = "scoring/ai-reciprocal-evidence-v3.1.lock.json"
BOUND = {CONFIG, SCHEMA, SYSTEM, ADDENDUM, DECISION, v3.LOCK, historical.LOCK,
    "src/miboe/reciprocal_evidence_v31.py", "src/miboe/evidence_cli_v31.py",
    "tests/test_reciprocal_evidence_v31.py"}
CAPS = {"J01": 8192, "J02": 16384, "J03": 8192}
PRESERVED_CONFIG = ("judges", "source_pairs", "observations", "calibration", "main_pilot_guards", "aggregation")


def load_plan(root: Path):
    root = root.resolve()
    base, previous_run = v3.load_plan(root), historical.load_plan(root)
    lock = scoring.read_json(root / LOCK)
    e.verify(lock, "lock_sha256")
    e.require(lock["method_id"] == METHOD and set(lock["files"]) == BOUND, "v3.1 lock scope differs")
    for name, digest in lock["files"].items():
        e.require(sha256_file(root / name) == digest, "v3.1 locked file changed")
    config = scoring.read_json(root / CONFIG)
    schema = scoring.read_json(root / SCHEMA)
    decision = yaml.safe_load((root / DECISION).read_text("utf-8"))
    e.require(decision["status"] == "APPROVED_PROSPECTIVE_METHOD_AND_OFFLINE_IMPLEMENTATION_ONLY"
        and decision["owner"] == "笹埜健斗" and decision["method_id"] == METHOD
        and decision["API_calls"] is False and decision["new_execution_budget_or_window_approved"] is False,
        "prospective approval does not authorize a run")
    e.require(config["method_id"] == METHOD and config["previous_evidence_lock_sha256"] == base["lock"]["lock_sha256"]
        and config["source_models"] == previous_run["config"]["source_models"], "source models or parent provenance differ")
    for name in PRESERVED_CONFIG:
        e.require(config[name] == base["config"][name], "frozen routing/guard/aggregation changed")
    e.require(config["judge_generation_caps"] == CAPS and config["thinking_parameters_changed"] is False,
        "unapproved generation controls")
    e.require(schema == base["schema"], "auxiliary adoption must not change output schema")
    system = (root / SYSTEM).read_text("utf-8")
    e.require(system == base["system"] + "\n\n" + (root / ADDENDUM).read_text("utf-8"), "unapproved prompt change")
    e.require(config["API_calls_authorized"] is False and config["live_dispatch_enabled"] is False
        and config["production_calibration_materials_approved"] is False, "no new execution or calibration authority")
    return {**base, "config": config, "schema": schema, "system": system, "lock": lock,
        "previous_method": base, "historical_release_sha256": previous_run["lock"]["release_sha256"]}


def status(root):
    p = load_plan(root)
    return {"method_id": METHOD, "lock_sha256": p["lock"]["lock_sha256"],
        "prospective_method_adopted": True, "prepare_import_aggregate_implemented": True,
        "judge_generation_caps": CAPS.copy(), "API_calls_authorized": False, "live_dispatch_enabled": False,
        "production_calibration_materials_approved": False, "calibration_clearance_granted": False,
        "new_execution_budget_or_window_approved": False, "model_acceptance_or_improvement_verified": False,
        "old_data_reclassified": False, "pilot_passed": False, "publication_Core_restart_W01": False}


def build_batch(root, rows, source_families, *, phase="main", synthetic_test_only=False):
    p = load_plan(root)
    e.require(phase in {"main", "calibration"} and type(synthetic_test_only) is bool, "invalid phase/fixture flag")
    e.require(type(rows) is list and rows and type(source_families) is dict, "blind observations required")
    for row in rows:
        scoring._validate_blind(row, p["legacy"])
    ids = [r["observation_id_blind"] for r in rows]
    e.require(len(set(ids)) == len(ids), "duplicate observation")
    if phase == "calibration":
        e.require(synthetic_test_only is True, "new production calibration materials not approved")
        e.require(not source_families and len(rows) == 35
            and Counter(r["item_id"].split("-")[0] for r in rows) == {f"E{i}": 5 for i in range(1, 8)},
            "calibration fixture must contain 35 cases across all seven domains")
    else:
        e.require(set(ids) == set(source_families), "source map coverage mismatch")
        for family in source_families.values():
            e.pair_for_source(family)
    observations, catalogs, requests = {}, {}, []
    judges = {j["judge_id"]: j for j in p["config"]["judges"]}
    for row in sorted(rows, key=lambda r: r["observation_id_blind"]):
        blind = row["observation_id_blind"]
        observations[blind] = copy.deepcopy(row)
        catalog = refs.build_catalog(row["visible_response"], max_characters=p["max_excerpt_characters"])
        catalogs[blind] = catalog
        visible = {**copy.deepcopy(row), "evidence_catalog": [{"id": s["id"], "text": s["text"]} for s in catalog["segments"]]}
        for judge in sorted(judges if phase == "calibration" else e.pair_for_source(source_families[blind])):
            q = e.prepare_request(judges[judge], visible, system=p["system"],
                rubric=scoring._rubric(p["legacy"], row["item_id"]), schema=scoring._native_schema(p["schema"]),
                instruction_schema=p["schema"], phase=phase, cap=CAPS[judge])
            requests.append(e.sealed({k: v for k, v in q.items() if k != "request_id"} | {"method_id": METHOD}, "request_id"))
    return e.sealed({"method_id": METHOD, "scoring_lock_sha256": p["lock"]["lock_sha256"], "phase": phase,
        "observations": observations, "catalogs": catalogs, "requests": requests,
        "private_source_families_never_sent_to_judges": copy.deepcopy(source_families),
        "synthetic_test_only": synthetic_test_only, "engineering_only_not_independent_acceptance": True,
        "API_calls_authorized": False, "new_execution_budget_or_window_approved": False,
        "calibration_material_status": "SYNTHETIC_ONLY_PRODUCTION_MATERIALS_PENDING" if phase == "calibration" else None}, "batch_sha256")


def validate_batch(root, batch):
    e.verify(batch, "batch_sha256")
    e.require(batch.get("method_id") == METHOD, "old/other method batch rejected without conversion")
    rebuilt = build_batch(root, list(batch["observations"].values()),
        batch["private_source_families_never_sent_to_judges"], phase=batch["phase"],
        synthetic_test_only=batch["synthetic_test_only"])
    e.require(rebuilt == batch, "batch/catalog/request differs from approved v3.1 construction")


def wire_artifact(root, batch):
    validate_batch(root, batch)
    jobs = [{"request_id": q["request_id"], "method_id": METHOD, "provider": q["provider"],
        "requested_model": q["requested_model"], "wire": wire.request(q), "binding": wire.binding(q)} for q in batch["requests"]]
    return e.sealed({"method_id": METHOD, "batch_sha256": batch["batch_sha256"], "jobs": jobs,
        "API_calls_authorized": False, "live_dispatch_enabled": False}, "wire_set_sha256")


def assert_live_authorized(*args, **kwargs):
    raise ValidationError("v3.1 adoption is not API authority: new materials, budget, window and execution permit are absent")


def write_artifact(root, path, value):
    """A separate private namespace prevents writes into old trial evidence/approvals."""
    destination = Path(path).resolve()
    namespace = (Path(os.environ["LOCALAPPDATA"]) / "MIBO-Education/EvidenceV31Preparation").resolve()
    e.require(destination != namespace and destination.is_relative_to(namespace),
        "v3.1 prepared artifacts require the separate EvidenceV31Preparation private namespace")
    scoring.write_private_artifact(root, destination, value)


def _import(plan, batch, envelope):
    previous = v3._import(plan, batch, envelope)
    core = {k: v for k, v in previous.items() if k != "view_sha256"}
    core.update(method_id=METHOD, frozen_validator_derivation_sha256=previous["view_sha256"],
        synthetic_test_only=batch["synthetic_test_only"], statistical_independence_established=False,
        engineering_only_not_independent_acceptance=True)
    return e.sealed(core, "view_sha256")


def import_many(root, batch, envelopes):
    validate_batch(root, batch)
    e.require(type(envelopes) is list, "response list required")
    plan = load_plan(root)
    views = [_import(plan, batch, env) for env in envelopes]
    e.require(len({v["request_id"] for v in views}) == len(views), "duplicate attempt; no cherry-picking")
    return views


def aggregate(root, batch, views):
    validate_batch(root, batch)
    plan, by = load_plan(root), {}
    for view in views:
        e.verify(view, "view_sha256")
        e.require(view["request_id"] not in by and view == _import(plan, batch, view["raw_envelope"]),
            "duplicate or changed derived view")
        by[view["request_id"]] = view
    names = list(plan["schema"]["properties"]["codes"]["properties"])
    rows, full_rows = [], []
    for blind, row in batch["observations"].items():
        qs = [q for q in batch["requests"] if q["observation_id_blind"] == blind]
        assigned = {q["judge_id"]: by.get(q["request_id"]) for q in qs}
        core = {"observation_id_blind": blind, "item_id": row["item_id"]}
        full = {j: v["internal_validation_projection"] if v and v["full_record_valid_new_method"] else None for j, v in assigned.items()}
        frow = copy.deepcopy(core)
        if batch["phase"] == "main":
            core.update(components.primary_pair(assigned), auxiliary_consensus=components.auxiliary_pair(assigned, names))
            frow.update(e.combine_pair(full))
            for out in (core, frow):
                out["source_family_private_join"] = batch["private_source_families_never_sent_to_judges"][blind]
        else:
            primary = {j: v["primary"]["judgment"] if v and v["primary"]["valid"] else None for j, v in assigned.items()}
            core.update(individual_ratings=primary, valid_ratings=sum(v is not None for v in primary.values()))
            frow.update(individual_ratings=full, valid_ratings=sum(v is not None for v in full.values()))
        rows.append(core)
        full_rows.append(frow)
    def report(values):
        if batch["phase"] == "calibration":
            return old._calibration_report(values, plan["config"])
        return old._main_report(values, plan["config"], plan["parent"]["allocation"])
    coverage = {}
    for judge in e.JUDGE_FAMILIES:
        expected = [q for q in batch["requests"] if q["judge_id"] == judge]
        fields = {}
        for name in names:
            states = [by[q["request_id"]]["auxiliary"]["codes"][name] for q in expected if q["request_id"] in by]
            fields[name] = {"planned_slots": len(expected), "returned_views": len(states),
                "valid_contract_count": sum(s["valid"] for s in states),
                "available_value_count": sum(s["valid"] and s["available"] for s in states),
                "statuses": dict(Counter(s["status"] for s in states))}
        coverage[judge] = fields
    return e.sealed({"method_id": METHOD, "batch_sha256": batch["batch_sha256"], "phase": batch["phase"],
        "primary_responses": rows, "primary_quality_report": report(rows),
        "new_full_record_quality_report": report(full_rows), "auxiliary_coverage": coverage,
        "all45_auxiliary_fields_retained": names, "numeric_guard_values_changed": False,
        "old_judgments_reclassified": False, "calibration_clearance_granted": False, "pilot_passed": False,
        "synthetic_test_only": batch["synthetic_test_only"], "engineering_only_not_independent_acceptance": True,
        "statistical_independence_established": False, "human_validity_or_correctness_or_comparability_established": False,
        "API_calls_made": 0}, "aggregation_sha256")

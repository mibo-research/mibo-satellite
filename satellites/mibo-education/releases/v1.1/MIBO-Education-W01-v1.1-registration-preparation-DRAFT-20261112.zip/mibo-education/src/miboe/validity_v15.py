"""Additive v1.5 component validity; never repairs raw values or legacy ratings.

The original full-record importer and guard results remain a separate immutable
view. Primary validity is a new analysis policy, not educational correctness or
a retroactive pass of v1.4. All45 auxiliary fields remain visible independently.
"""
from __future__ import annotations

import copy
from collections import Counter
from itertools import combinations
from pathlib import Path
from typing import Any

from . import reciprocal as r
from . import reciprocal_engine as e
from . import scoring
from .errors import ValidationError

VERSION = "MIBOE-SPLIT-VALIDITY-v1.0"
PRIMARY_FIELDS = ("observation_id_blind","item_id","status","primary_score","anchor_reference","evidence","nr_reason")
META_FIELDS = ("identity_leakage","injection_attempt_observed")
E4_NUMBERS = ("MODEL_ASSIGNED_ACCURACY_SCORE","MODEL_ASSIGNED_REASONING_SCORE",
              "MODEL_ASSIGNED_EXPLANATION_SCORE","MODEL_ASSIGNED_TOTAL_SCORE")
CONDITIONAL = {"E2_SUPPORT_QUALITY","MODEL_SCORE_PARSEABLE",*E4_NUMBERS,"EMERGENT_BEHAVIOR_NOTE"}


def _field(values, name, schema):
    present = isinstance(values,dict) and name in values
    state = {"present":present,"valid":False,"available":False,"errors":[],"status":"MISSING"}
    if not present:
        state["errors"].append("FIELD_ABSENT")
        return state
    value = values[name]
    state["raw_value"] = copy.deepcopy(value)
    try:
        scoring._schema_check(value,schema)
        state.update(valid=True,available=value is not None,status="VALID" if value is not None else "MISSING")
    except (ValueError,TypeError,KeyError,ValidationError):
        state.update(status="INVALID",errors=["TYPE_ENUM_RANGE_OR_PATTERN"])
    return state


def _invalidate(state, reason):
    state["valid"], state["available"] = False,False
    state["errors"].append(reason)
    state["status"] = "MISSING" if not state["present"] or state.get("raw_value") is None else "INVALID"


def _expect_null(state):
    if state["present"] and state.get("raw_value") is None and state["valid"]:
        state["status"] = "NOT_APPLICABLE"
    elif state["present"] and state.get("raw_value") is not None:
        _invalidate(state,"VALUE_OUTSIDE_APPLICABLE_CONTEXT")


def _primary(plan,row,result,identity_valid):
    raw = {k:copy.deepcopy(result[k]) for k in PRIMARY_FIELDS if isinstance(result,dict) and k in result}
    errors = []
    if not identity_valid:
        errors.append("SHARED_OBSERVATION_IDENTITY_INVALID")
    for name in PRIMARY_FIELDS:
        state = _field(result,name,plan["legacy"]["schema"]["properties"][name])
        if not state["valid"]:
            errors.append("INVALID_PRIMARY_FIELD:"+name)
    if not errors:
        rateable = raw["status"] == "RATEABLE"
        if rateable:
            if type(raw["primary_score"]) is not int:
                errors.append("RATEABLE_ORDINAL_SCORE_REQUIRED")
            if raw["anchor_reference"] != row["item_id"]+":"+str(raw["primary_score"]):
                errors.append("ANCHOR_REFERENCE_MISMATCH")
            if raw["nr_reason"] is not None or not raw["evidence"]:
                errors.append("RATEABLE_REASON_OR_EVIDENCE_INVALID")
        elif raw["primary_score"] is not None or raw["anchor_reference"] is not None or not (raw["nr_reason"] or "").strip():
            errors.append("NR_MUST_HAVE_REASON_AND_NO_SCORE")
        if not all(q in row["visible_response"] for q in raw["evidence"]):
            errors.append("INVENTED_EVIDENCE_QUOTE")
    valid = not errors
    return {"valid":valid,"errors":errors,"raw_fields":raw,
            "judgment":copy.deepcopy(raw) if valid else None,
            "validity_is_contract_not_correctness":True}


def _auxiliary(plan,row,result,identity_valid):
    props = plan["legacy"]["schema"]["properties"]["codes"]["properties"]
    values = result.get("codes") if isinstance(result,dict) else None
    fields = {k:_field(values,k,v) for k,v in props.items()}
    status = result.get("status") if isinstance(result,dict) else None
    rateable = status == "RATEABLE"
    def value(k):
        return fields[k].get("raw_value")
    for k,state in fields.items():
        if rateable and k not in CONDITIONAL and state["present"] and value(k) is None:
            _invalidate(state,"REQUIRED_RATEABLE_CODE_NULL")
    present, refusal = value("REFUSAL_PRESENT"),value("REFUSAL_TYPE")
    if fields["REFUSAL_PRESENT"]["valid"] and present is not None:
        allowed = ["R1","R2","R3","R4"] if present else ["R0"]
        if refusal not in allowed:
            known_type_conflicts = fields["REFUSAL_TYPE"]["valid"] and refusal is not None
            _invalidate(fields["REFUSAL_TYPE"],"REFUSAL_TYPE_INCONSISTENT_OR_MISSING")
            if known_type_conflicts:
                _invalidate(fields["REFUSAL_PRESENT"],"CROSS_FIELD_CONFLICT")
    if value("SOURCE_FABRICATED") is True and value("SOURCE_FABRICATION_SUSPECTED") is True:
        for k in ("SOURCE_FABRICATED","SOURCE_FABRICATION_SUSPECTED"):
            _invalidate(fields[k],"CROSS_FIELD_CONFLICT")
    if value("EMERGENT_BEHAVIOR") is True:
        if not isinstance(value("EMERGENT_BEHAVIOR_NOTE"),str) or not value("EMERGENT_BEHAVIOR_NOTE").strip():
            _invalidate(fields["EMERGENT_BEHAVIOR_NOTE"],"EMERGENT_NOTE_REQUIRED")
    else:
        _expect_null(fields["EMERGENT_BEHAVIOR_NOTE"])
        if value("EMERGENT_BEHAVIOR") is False and value("EMERGENT_BEHAVIOR_NOTE") is not None:
            _invalidate(fields["EMERGENT_BEHAVIOR"],"CROSS_FIELD_CONFLICT")
    if row["item_id"].startswith("E2-") and rateable:
        if type(value("E2_SUPPORT_QUALITY")) is not int:
            _invalidate(fields["E2_SUPPORT_QUALITY"],"E2_SUPPORT_SCORE_REQUIRED")
    else:
        _expect_null(fields["E2_SUPPORT_QUALITY"])
    if not row["item_id"].startswith("E4-"):
        for k in ("MODEL_SCORE_PARSEABLE",*E4_NUMBERS):
            _expect_null(fields[k])
    else:
        if rateable and type(value("MODEL_SCORE_PARSEABLE")) is not bool:
            _invalidate(fields["MODEL_SCORE_PARSEABLE"],"E4_PARSEABILITY_REQUIRED")
        if value("MODEL_SCORE_PARSEABLE") is True:
            if not all(type(value(k)) is int and fields[k]["valid"] for k in E4_NUMBERS):
                for k in E4_NUMBERS:
                    if type(value(k)) is not int:
                        _invalidate(fields[k],"E4_COMPONENT_REQUIRED")
                _invalidate(fields["MODEL_SCORE_PARSEABLE"],"EXTRACTION_FLAG_WITH_INCOMPLETE_COMPONENTS")
            elif sum(value(k) for k in E4_NUMBERS[:3]) != value(E4_NUMBERS[3]):
                for k in E4_NUMBERS:
                    _invalidate(fields[k],"E4_COMPONENT_TOTAL_CONFLICT")
        else:
            for k in E4_NUMBERS:
                _expect_null(fields[k])
    if not identity_valid:
        for state in fields.values():
            _invalidate(state,"SHARED_OBSERVATION_IDENTITY_INVALID")
    return {
        "codes":fields,"all_code_contracts_valid":all(v["valid"] for v in fields.values()),
        "available_codes":sum(v["available"] for v in fields.values()),
        "missing_or_invalid_codes":[k for k,v in fields.items() if not v["valid"]],
        "unexpected_code_fields":sorted(set(values)-set(props)) if isinstance(values,dict) else [],
        "raw_values_changed":False,
    }


def derive(plan,batch,legacy_rating):
    """A new namespaced view beside the original full-record judgment."""
    q = next(q for q in batch["requests"] if q["request_id"] == legacy_rating["request_id"])
    row = batch["observations"][q["observation_id_blind"]]
    result, parse_error, identity_valid = None,None,False
    try:
        text,_ = e.response_text(q,legacy_rating["raw_envelope"])
        result = scoring.strict_json(text)
        if not isinstance(result,dict):
            raise ValueError("root is not an object")
        props = plan["legacy"]["schema"]["properties"]
        for k in ("observation_id_blind","item_id"):
            scoring._schema_check(result.get(k),props[k])
            e.require(result[k] == row[k],"observation identity mismatch")
        identity_valid = True
    except (ValueError,KeyError,TypeError,AttributeError,ValidationError):
        parse_error = "TRANSPORT_FINISH_JSON_OR_OBSERVATION_IDENTITY_INVALID"
    primary = _primary(plan,row,result,identity_valid)
    aux = _auxiliary(plan,row,result,identity_valid)
    props = plan["legacy"]["schema"]["properties"]
    accuracy = {k:_field(result,k,props[k]) for k in ("accuracy_status","accuracy_code")}
    if all(v["valid"] for v in accuracy.values()):
        assessed = accuracy["accuracy_status"].get("raw_value") == "ASSESSED"
        if (type(accuracy["accuracy_code"].get("raw_value")) is int) != assessed:
            for state in accuracy.values():
                _invalidate(state,"ACCURACY_STATUS_CODE_CONFLICT")
    metadata = {k:_field(result,k,props[k]) for k in META_FIELDS}
    if not identity_valid:
        for state in [*accuracy.values(),*metadata.values()]:
            _invalidate(state,"SHARED_OBSERVATION_IDENTITY_INVALID")
    try:
        scoring._schema_check(result,plan["legacy"]["schema"])
        structure_valid = True
    except (ValueError,KeyError,TypeError,ValidationError):
        structure_valid = False
    return e.sealed({
        "analysis_policy":VERSION,"request_id":q["request_id"],"judge_id":q["judge_id"],
        "phase":batch["phase"],"observation_id_blind":q["observation_id_blind"],
        "legacy_full_rating":copy.deepcopy(legacy_rating),
        "legacy_full_rating_sha256":legacy_rating["rating_sha256"],
        "legacy_full_judgment_valid":legacy_rating["valid"],
        "shared_identity_valid":identity_valid,"shared_error":parse_error,
        "schema_structure_valid":structure_valid,"parsed_result":copy.deepcopy(result),
        "primary":primary,"auxiliary":aux,"accuracy":accuracy,"metadata":metadata,
        "unexpected_top_level_fields":sorted(set(result)-set(props)) if isinstance(result,dict) else [],
        "original_invalid_status_or_raw_value_rewritten":False,
    },"view_sha256")


def import_many(root:Path,batch:dict[str,Any],envelopes:list[dict[str,Any]]):
    legacy = r.import_many(root,batch,envelopes)
    plan = r.load_plan(root)
    return [derive(plan,batch,rating) for rating in legacy]


def primary_pair(views):
    e.require(len(views)==2,"two assigned judges required")
    js = {k:(v["primary"]["judgment"] if v and v["primary"]["valid"] else None) for k,v in views.items()}
    good = [v for v in js.values() if v is not None]
    status,numeric,estimate = "INCOMPLETE",None,None
    if len(good)==2:
        if all(v["status"]=="RATEABLE" for v in good):
            numeric = [v["primary_score"] for v in good]
            if abs(numeric[0]-numeric[1])<=1:
                status,estimate = "PANEL_ESTIMATE",sum(numeric)/2
            else:
                status = "UNRESOLVED_SCORE_DISAGREEMENT"
        elif all(v["status"]=="NR" for v in good):
            status = "NR"
        else:
            status = "UNRESOLVED_RATEABILITY"
    return {"status":status,"numeric_pair":numeric,"panel_estimate":estimate,
            "valid_ratings":len(good),"individual_ratings":js,"scores_recalibrated_or_imputed":False}


def auxiliary_pair(views,names):
    result = {}
    for name in names:
        pair = {j:(v["auxiliary"]["codes"][name] if v else None) for j,v in views.items()}
        available = [v for v in pair.values() if v and v["valid"] and v["available"]]
        if len(available)==2:
            agree = available[0]["raw_value"] == available[1]["raw_value"]
            result[name] = {"status":"AGREEMENT" if agree else "DISAGREEMENT",
                            "value":copy.deepcopy(available[0]["raw_value"]) if agree else None,
                            "individual_states":copy.deepcopy(pair)}
        else:
            result[name] = {"status":"NOT_JOINTLY_AVAILABLE","value":None,"individual_states":copy.deepcopy(pair)}
    return result


def aggregate(root:Path,batch:dict[str,Any],views:list[dict[str,Any]]):
    r.validate_batch(root,batch)
    plan = r.load_plan(root)
    by = {}
    for view in views:
        e.verify(view,"view_sha256")
        e.require(view == derive(plan,batch,view["legacy_full_rating"]),"component view differs from original rating")
        e.require(view["request_id"] not in by,"duplicate component view")
        # Recompute the unchanged historical import, not a patched full judgment.
        e.require(view["legacy_full_rating"] == r._import(plan,batch,view["legacy_full_rating"]["raw_envelope"]),
                  "legacy status changed")
        by[view["request_id"]] = view
    names = list(plan["legacy"]["schema"]["properties"]["codes"]["properties"])
    rows = []
    for blind,row in batch["observations"].items():
        requests = [q for q in batch["requests"] if q["observation_id_blind"]==blind]
        assigned = {q["judge_id"]:by.get(q["request_id"]) for q in requests}
        core = {"observation_id_blind":blind,"item_id":row["item_id"],
                "view_hashes":[by[q["request_id"]]["view_sha256"] for q in requests if q["request_id"] in by]}
        if batch["phase"]=="main":
            core.update(primary_pair(assigned))
            core["source_family_private_join"] = batch["private_source_families_never_sent_to_judges"][blind]
            core["auxiliary_consensus"] = auxiliary_pair(assigned,names)
        else:
            js = {j:(v["primary"]["judgment"] if v and v["primary"]["valid"] else None) for j,v in assigned.items()}
            core.update(individual_ratings=js,valid_ratings=sum(v is not None for v in js.values()))
        rows.append(core)
    legacy_result = r.aggregate(root,batch,[v["legacy_full_rating"] for v in views])
    if batch["phase"]=="calibration":
        old_report = r._calibration_report(rows,plan["config"])
        quality = {k:old_report[k] for k in ("common_cases","valid_rating_fraction","pair_specific_calibration","checks")}
        quality["primary_calibration_guards_passed"] = old_report["technical_calibration_guards_passed"]
    else:
        old_report = r._main_report(rows,plan["config"],plan["allocation"])
        quality = {k:old_report[k] for k in ("response_count","source_counts","domain_counts","pair_specific_agreement","checks","numeric_quality_checks_passed")}
        quality["primary_numeric_quality_checks_passed"] = old_report["numeric_quality_checks_passed"]
    quality.update(metric_scope="PRIMARY_COMPONENT_VALIDITY_NEW_V1_5_POLICY",
                   threshold_values_changed=False,denominator_reduced=False,
                   agreement_is_not_correctness_or_human_validity=True)
    coverage = {}
    for judge in e.JUDGE_FAMILIES:
        expected = [q for q in batch["requests"] if q["judge_id"]==judge]
        fields = {}
        for name in names:
            states = [by[q["request_id"]]["auxiliary"]["codes"][name] for q in expected if q["request_id"] in by]
            fields[name] = {"planned_slots":len(expected),"returned_views":len(states),
                            "missing_views":len(expected)-len(states),
                            "valid_contract_count":sum(s["valid"] for s in states),
                            "available_value_count":sum(s["valid"] and s["available"] for s in states),
                            "statuses":dict(Counter(s["status"] for s in states))}
        coverage[judge] = fields
    return e.sealed({
        "analysis_policy":VERSION,"batch_sha256":batch["batch_sha256"],"phase":batch["phase"],
        "primary_responses":rows,"primary_quality_report":quality,
        "auxiliary_coverage":coverage,"all_auxiliary_fields_retained":names,
        "auxiliary_completeness_is_not_a_primary_gate":True,
        "legacy_full_aggregation":legacy_result,
        "legacy_v1_4_failure_not_relabelled_as_pass":True,
        "raw_or_model_values_changed":False,"pilot_passed":False,
        "human_gold_validity_or_comparability_established":False,
    },"aggregation_sha256")

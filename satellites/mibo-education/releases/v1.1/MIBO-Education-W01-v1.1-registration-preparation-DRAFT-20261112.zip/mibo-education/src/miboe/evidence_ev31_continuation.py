"""Append-only, unsent-only EV31 continuation. Scientific bytes remain the native v1.0 release."""
from __future__ import annotations
import argparse
import copy
import json
import os
import time
from collections import Counter
from datetime import UTC, datetime, timedelta
from pathlib import Path
import httpx
import yaml
from . import evidence_ev31_runtime as rt, reciprocal_engine as e, reciprocal as reports, scoring
from .util import canonical_json_bytes, sha256_file as sha, sha256_bytes, write_immutable

CONFIG="runtime/EV31-continuation-v1.0.json"
LOCK="runtime/EV31-continuation-v1.0.lock.json"
DECISION="protocol/approvals/EV31-UNSENT-CONTINUATION-APPROVAL-20261111.yaml"
BOUND={CONFIG,DECISION,rt.LOCK,"src/miboe/evidence_ev31_continuation.py",
    "tests/test_ev31_continuation.py","runtime/start-ev31-continuation-v1.0.ps1"}
PERMISSIONS={"unsent_only":True,"delegated_READ_TIMEOUT_calibration_main":True,
    "calibration_review_required":True,"failed_request_resend":False,
    "publication":False,"Core_restart":False,"W01":False}
HOLD_REASON="WAITING_FOR_REVIEW_OR_RESULT_REVIEW_OR_FAILURE"
HOLD_BYTES=(rt.method.CAMPAIGN+" "+HOLD_REASON+"; no automatic retry.\n").encode()


def save_once(path,value):
    if path.exists(): e.require(scoring.read_json(path)==value,"immutable continuation artifact differs")
    else: rt.save(path,value)


def load_plan(root):
    root=root.resolve(); native=rt.load_plan(root)
    lock=scoring.read_json(root/LOCK);e.verify(lock,"release_sha256")
    e.require(set(lock["files"])==BOUND,"incomplete continuation release")
    for name,digest in lock["files"].items():e.require(sha(root/name)==digest,"continuation locked input changed")
    c=scoring.read_json(root/CONFIG)
    d=yaml.safe_load((root/DECISION).read_text("utf-8"))
    e.require(c["campaign_id"]==rt.method.CAMPAIGN and c["native_release_sha256"]==native["lock"]["release_sha256"]
        ==d["original_release_sha256"],"scientific release changed")
    e.require(c["initial_requests"]==34 and c["additional_maximum"]==527 and c["prior_requests"]==905
        and c["trial_maximum"]==561 and c["cumulative_maximum"]==1466
        and c["remaining_caps"]=={"metadata":0,"calibration":77,"collection":150,"main":300},"continuation caps differ")
    e.require(d["status"]=="OWNER_APPROVED_SUBJECT_TO_OFFLINE_VERIFICATION" and d["owner"]=="笹埜健斗"
        and d["maximum_unsent_continuation"]==527 and d["automatic_resend_of_failed_or_unknown_request"] is False
        and d["delegated_unsent_only_continuation_after_same_judging_transport_failure"] is True
        and c["eligible_phases"]==["calibration","main"] and c["eligible_error"]=="READ_TIMEOUT"
        and c["permissions"]==PERMISSIONS,"owner continuation scope differs")
    return {"root":root,"native":native,"config":c,"lock":lock,"lock_file_sha256":sha(root/LOCK)}


def validate_grant(p,g,original,simulation):
    e.require(g.get("status")=="FINAL_EV31_UNSENT_CONTINUATION" and g.get("fixture_only") is simulation,
        "separate FINAL continuation grant required; fixture cannot enable live HTTP")
    c=p["config"]
    for k,v in (("owner","笹埜健斗"),("actor_type","HUMAN"),("campaign_id",rt.method.CAMPAIGN),
        ("release_sha256",p["lock"]["release_sha256"]),("native_release_sha256",p["native"]["lock"]["release_sha256"]),
        ("original_authorization_sha256",e.digest(original)),("maximum_additional_requests",527),
        ("initial_requests",34),("maximum_trial_requests",561),("maximum_cumulative_requests",1466)):
        e.require(type(g.get(k)) is type(v) and g[k]==v,"continuation grant differs:"+k)
    e.require(g.get("human_attestation") is True and g.get("permissions")==PERMISSIONS
        and all(isinstance(g.get(k),str) and g[k].strip() for k in ("source_instruction","source_evidence")),"owner decision required")
    e.require(g["remaining_caps"]==c["remaining_caps"],"allocation changed")
    if not simulation:
        e.require(g["original_started_at"]==c["original_started_at"]
            and g["unchanged_deadline"]==c["unchanged_deadline"],"clock changed")


def authorize(root,g,*,execute_approved=False,simulation=False):
    e.require(execute_approved is True,"explicit continuation execute switch required")
    e.require(g.get("status")=="FINAL_EV31_UNSENT_CONTINUATION" and g.get("fixture_only") is simulation,"no matching FINAL continuation authority")
    p=load_plan(root)
    if not simulation:
        evidence=Path(g["offline_report"])
        e.require(sha(evidence)==g["offline_report_file_sha256"],"offline verification changed")
        report=scoring.read_json(evidence)
        e.require(report["status"]=="EV31_UNSENT_CONTINUATION_OFFLINE_VERIFIED"
            and report["release_sha256"]==p["lock"]["release_sha256"] and report["API_calls"]==0
            and report["tests"]["exit_code"]==report["tests"]["failed"]==0
            and report["full_prefix34_plus_unsent527_fixture_completed"] is True,"offline verification required")
    requested=rt.ledger.private_path(root,Path(g["execution_root"]))
    original=scoring.read_json(requested/"authorization.json")
    validate_grant(p,g,original,simulation)
    ctx=rt.authorize(root,original,execute_approved=True,simulation=simulation,continuation=True,preflight_only=True)
    e.require(requested==ctx["destination"],"original execution root differs")
    side=rt.ledger.private_path(root,Path(g["continuation_root"]))
    e.require(sha(side/"authorization.json")==sha256_bytes(canonical_json_bytes(g)+b"\n"),"continuation grant file changed")
    e.require(sha(side/"INITIAL_PREFIX.json")==g["prefix_file_sha256"],"initial prefix binding changed")
    prefix=scoring.read_json(side/"INITIAL_PREFIX.json");e.verify(prefix,"prefix_sha256")
    e.require(prefix["original_authorization_sha256"]==e.digest(original) and prefix["initial_requests"]==34
        and prefix["fixture_only"] is simulation and prefix["original_started_at"]==g["original_started_at"],"wrong preserved prefix")
    for bundle in prefix["preserved_prefix"]:
        folder=rt.ledger.private_path(root,Path(bundle["root"]))
        for name,digest in bundle["files"].items():
            rel=Path(name);e.require(not rel.is_absolute() and ".." not in rel.parts,"invalid prefix path")
            e.require(sha(rt.ledger.private_path(root,folder/rel))==digest,"saved34 evidence changed")
    started=scoring.read_json(ctx["destination"]/"RUN_STARTED.json")
    e.require(started["started_at"]==g["original_started_at"] and sha(ctx["destination"]/"RUN_STARTED.json")==prefix["RUN_STARTED_file_sha256"],"clock reset forbidden")
    e.require(rt.stamp(g["unchanged_deadline"])==rt.stamp(g["original_started_at"])+timedelta(hours=72)
        and rt.prepared.can_reserve_before_deadline(rt.stamp(g["original_started_at"]),datetime.now(UTC)),"original deadline exhausted")
    if not simulation:
        expected=rt.ledger.private_path(root,Path(os.environ["LOCALAPPDATA"])/p["config"]["continuation_relative_root"])
        e.require(side==expected and g["prefix_file_sha256"]==p["config"]["prefix_file_sha256"]
            and g["original_started_at"]==p["config"]["original_started_at"],"live continuation destination differs")
    return {**ctx,"continuation":{"plan":p,"grant":copy.deepcopy(g),"side":side,"prefix":prefix}}


class ContinuedLedger(rt.ledger.Ledger):
    """Reuse the original chain; its baseline was fully verified by authorize()."""
    def __init__(self,ctx):
        self.ctx,self.destination=ctx,ctx["destination"]
        self.root=rt.ledger.private_path(ctx["plan"]["root"],Path(ctx["authorization"]["accounting_root"]))
        self.base=ctx["baseline"]
        self.lease=rt.ledger.Lease(self.root/"worker.lease")
        try:
            binding={"campaign_id":rt.method.CAMPAIGN,"plan_sha256":ctx["plan"]["plan_sha256"],
                "authorization_sha256":ctx["authorization_sha256"],"baseline_file_sha256":ctx["authorization"]["baseline_file_sha256"],
                "execution_root":str(self.destination),"fixture_only":ctx["simulation"]}
            e.require(scoring.read_json(self.root/"RUN_BINDING.json")==binding,"original ledger binding changed")
            self.binding_sha=sha(self.root/"RUN_BINDING.json");self.audit()
            e.require(sum(self.counts.values())>=34,"prefix truncated")
            e.require(scoring.read_json(self.root/"claims/000034.json")["claim_sha256"]==ctx["continuation"]["prefix"]["last_claim_sha256"],"prefix last claim changed")
        except BaseException:self.close();raise


def eligible_timeout(job,response):
    return (job["phase"] in {"calibration","main"} and response["http_status"]==0
        and response["error_code"]=="TRANSPORT_FAILURE_NO_RETRY" and response["transport_error_class"]=="READ_TIMEOUT"
        and response["response_body"] is None)


def release_flags(ctx,stage,counts,last_claim):
    side=ctx["continuation"]["side"]
    flags=[ctx["destination"]/"STOP"]
    if not ctx["simulation"]:flags.append(Path(ctx["plan"]["config"]["credentials"]["restart_hold_file"]))
    e.require(all(f.is_file() and sha(f)==sha256_bytes(HOLD_BYTES) for f in flags),"manual or unexpected STOP/HOLD; do not clear")
    tag=f"{stage}-{sum(counts.values()):06d}-{last_claim[:12]}"
    archive=side/"released-gates"/tag
    e.require(not archive.exists(),"continuation transition already released")
    archive.mkdir(parents=True)
    moved=[]
    try:
        for f in flags:
            rt.ledger.private_path(ctx["plan"]["root"],f)
            dest=rt.ledger.private_path(ctx["plan"]["root"],archive/f.name)
            f.rename(dest);moved.append((f,dest))
        rt.save(archive/"receipt.json",{"stage":stage,"counts":counts,"last_claim_sha256":last_claim,
            "continuation_release_sha256":ctx["continuation"]["plan"]["lock"]["release_sha256"],"fixture_only":ctx["simulation"]})
    except BaseException:
        for f,d in reversed(moved):
            if d.exists() and not f.exists():d.rename(f)
        raise


def derive_one(ctx,batch,q,response):
    job=rt.judge_job(q,batch["phase"])
    e.require(response["error_code"] is None or eligible_timeout(job,response),"nondelegated failure in prefix")
    if not eligible_timeout(job,response):
        body=response["response_body"]
        e.require(response["http_status"]==200 and isinstance(body,dict),"HTTP failure is not a delegated READ_TIMEOUT")
        returned=body.get("modelVersion") if q["provider"]=="gemini" else body.get("model")
        e.require(returned==q["requested_model"] and rt.prep._expected_output_shape(q["provider"],body),"prefix identity/tool HOLD")
    envelope={"request_id":q["request_id"],**{k:response[k] for k in ("http_status","received_at","response_body")}}
    view=rt.method._import(ctx["plan"]["method"],batch,envelope)
    old=ctx["destination"]/(batch["phase"]+"-views")/(q["request_id"]+".json")
    if old.exists():e.require(scoring.read_json(old)==view,"existing judgment differs from raw")
    save_once(ctx["destination"]/"continuation-derived-views"/batch["phase"]/(q["request_id"]+".json"),view)
    return view


def prefix_views(ctx,batch,count):
    values=[]
    for q in batch["requests"][:count]:
        job=rt.judge_job(q,batch["phase"])
        response=rt.raw(ctx["destination"]/"L0_raw"/batch["phase"]/job["job_sha256"],job,ctx["simulation"])
        values.append(derive_one(ctx,batch,q,response))
    return values


def reachable(ctx,batch,views):
    """Conservative constructive feasibility witness, NEVER a scientific imputation.

    Missing requests receive hypothetical scores only in this ephemeral guard
    calculation. Nothing is imported, sent, saved as a rating or used in analysis.
    A passing witness proves that the unchanged numerical guards are still
    attainable. No witness means HOLD, not a relaxed or predicted scientific pass.
    """
    config=ctx["plan"]["method"]["config"]
    by={v["request_id"]:v for v in views}
    targets={c["item_id"]:c["proposed_anchor"] for c in ctx["plan"]["method"]["bank"]["cases"]}
    for mode in ("known_median","balanced","targets"):
        passed=[]
        for full in (False,True):
            rows=[]
            for index,(blind,row) in enumerate(batch["observations"].items()):
                qs=[q for q in batch["requests"] if q["observation_id_blind"]==blind]
                known=[]
                for q in qs:
                    v=by.get(q["request_id"])
                    if v:
                        j=v["internal_validation_projection"] if full and v["full_record_valid_new_method"] else v["primary"]["judgment"] if not full and v["primary"]["valid"] else None
                        if j and j["status"]=="RATEABLE":known.append(j["primary_score"])
                score=(sorted(known)[len(known)//2] if mode=="known_median" and known else
                    targets.get(row["item_id"],index%5) if mode=="targets" else index%5)
                assigned={}
                for q in qs:
                    v=by.get(q["request_id"])
                    assigned[q["judge_id"]]=({"status":"RATEABLE","primary_score":score} if v is None else
                        v["internal_validation_projection"] if full and v["full_record_valid_new_method"] else
                        v["primary"]["judgment"] if not full and v["primary"]["valid"] else None)
                # Quality functions need only these fields. No hypothetical code
                # value is created, and no hypothetical rating leaves this guard.
                assigned={j:({"status":v["status"],"primary_score":v["primary_score"]} if v else None) for j,v in assigned.items()}
                item={"observation_id_blind":blind,"item_id":row["item_id"]}
                if batch["phase"]=="calibration":item.update(individual_ratings=assigned,valid_ratings=sum(j is not None for j in assigned.values()))
                else:item.update(e.combine_pair(assigned),source_family_private_join=batch["private_source_families_never_sent_to_judges"][blind])
                rows.append(item)
            report=(reports._calibration_report(rows,config) if batch["phase"]=="calibration" else
                reports._main_report(rows,config,ctx["plan"]["method"]["parent"]["allocation"]))
            passed.append(report["technical_calibration_guards_passed" if batch["phase"]=="calibration" else "numeric_quality_checks_passed"])
        if all(passed):return True
    return False


class Session(rt.Session):
    def __init__(self,ctx,keys,*,transport=None,sleep=time.sleep):
        rt.old.validate_keys(keys)
        e.require((type(transport) is httpx.MockTransport) if ctx["simulation"] else transport is None,"fixture/live boundary")
        self.ctx,self.keys,self.sleep=ctx,keys,sleep
        self.root,self.started=ctx["destination"],rt.stamp(ctx["continuation"]["grant"]["original_started_at"])
        self.fixed={p:rt.fixed_jobs(ctx["plan"],p) for p in ("metadata","collection")}
        self.batch=scoring.read_json(self.root/"calibration-batch.json")
        rt.method.validate_batch(ctx["plan"]["root"],self.batch)
        self.judges={"calibration":[rt.judge_job(q,"calibration") for q in self.batch["requests"]],"main":[]}
        self.ledger=ContinuedLedger(ctx);self.last_call=time.monotonic();self.failed=False
        try:
            self.client=httpx.Client(transport=transport or httpx.HTTPTransport(retries=0,trust_env=False),
                timeout=httpx.Timeout(600.0),trust_env=False,follow_redirects=False)
        except BaseException:self.ledger.close();raise
    def exchange(self,job):
        c=self.ctx["continuation"];p=c["plan"]
        e.require(sha(p["root"]/LOCK)==p["lock_file_sha256"]
            and sha(c["side"]/"authorization.json")==sha256_bytes(canonical_json_bytes(c["grant"])+b"\n"),"continuation authority/source changed")
        return super().exchange(job)


def run_stage(root,g,*,stage,execute_approved=False,simulation_transport=None,credential_resolver=None,sleep=time.sleep):
    e.require(stage in {"calibration","post-review"},"unknown continuation stage")
    simulation=simulation_transport is not None
    ctx=authorize(root,g,execute_approved=execute_approved,simulation=simulation)
    side=ctx["continuation"]["side"]
    # A competing invocation must not touch the active worker's STOP or keys.
    control=rt.ledger.Lease(side/("controller-"+stage+".lease"))
    memory=rt.old.RunKeyMemory(resolver=credential_resolver or rt.old.resolve_credentials)
    session=None
    try:
        e.require(not (ctx["destination"]/"RUN_FINISHED.json").exists(),"trial already completed; no restart")
        book=ContinuedLedger(ctx)
        try:
            counts,last=copy.deepcopy(book.counts),book.previous
        finally:book.close()
        e.require(counts["metadata"]==6,"never repeat incomplete metadata")
        for job in rt.fixed_jobs(ctx["plan"],"metadata"):
            response=rt.raw(ctx["destination"]/"L0_raw/metadata"/job["job_sha256"],job,simulation)
            body=response["response_body"]
            ident=body.get("name" if job["provider"]=="gemini" else "id") if isinstance(body,dict) else None
            e.require(response["http_status"]==200 and isinstance(ident,str)
                and ident.removeprefix("models/")==job["requested_model"],"metadata identity not confirmed")
        batch=scoring.read_json(ctx["destination"]/"calibration-batch.json")
        if stage=="calibration":
            e.require(28<=counts["calibration"]<105 and counts["collection"]==counts["main"]==0,"wrong calibration checkpoint")
            e.require(reachable(ctx,batch,prefix_views(ctx,batch,counts["calibration"])),"fixed calibration guards cannot be demonstrated reachable")
        else:
            e.require(counts["calibration"]==105,"calibration incomplete")
            rt.verify_review(ctx)
            for job in rt.fixed_jobs(ctx["plan"],"collection")[:counts["collection"]]:
                response=rt.raw(ctx["destination"]/"L0_raw/collection"/job["job_sha256"],job,simulation)
                record=rt.old._source_result(job,response,simulation)
                e.require(scoring.read_json(ctx["destination"]/"collection-records"/(record["request_id"]+".json"))==record,
                    "prior source failure/shortfall cannot be skipped")
        release_flags(ctx,stage,counts,last)
        keys=dict.fromkeys(rt.old.KEY_NAMES,"fixture-credential-not-real") if simulation else memory(root,interactive=False)
        session=Session(ctx,keys,transport=simulation_transport,sleep=sleep)
        if stage=="post-review":
            if session.ledger.counts["collection"]<150:
                e.require(session.ledger.counts["main"]==0,"main before collection complete")
                for job in session.fixed["collection"][session.ledger.counts["collection"]:]:
                    response=session.exchange(job)  # Source failure is NOT delegated continuation.
                    record=rt.old._source_result(job,response,simulation);rt.old._screen(record["response_text"])
                    save_once(session.root/"collection-records"/(record["request_id"]+".json"),record)
            records=[]
            for job in session.fixed["collection"]:
                response=rt.raw(session.root/"L0_raw/collection"/job["job_sha256"],job,simulation)
                record=rt.old._source_result(job,response,simulation)
                e.require(scoring.read_json(session.root/"collection-records"/(record["request_id"]+".json"))==record,"source changed")
                records.append(record)
            e.require(len(records)==150 and Counter(r["source_series"] for r in records)=={"M01":50,"M02":50,"M03":50},"150 actual fresh answers required")
            rows=[];families={}
            for record in records:
                row=scoring.make_blind_observation(record,salt=ctx["preparation"]["blinding_salt"])
                rows.append(row);families[row["observation_id_blind"]]=record["provider"]
            batch=rt.method.build_batch(root,rows,families,synthetic_test_only=simulation)
            save_once(session.root/"main-batch.json",batch);session.bind_main(batch)
        phase=batch["phase"]
        views=prefix_views(ctx,batch,session.ledger.counts[phase])
        while session.ledger.counts[phase]<rt.ledger.CAPS[phase]:
            e.require(reachable(ctx,batch,views),"fixed primary/full guards not demonstrated reachable")
            q=batch["requests"][session.ledger.counts[phase]];job=rt.judge_job(q,phase)
            try:
                response=session.exchange(job)
            except ValueError:
                # Advance ONLY past a fully recorded READ_TIMEOUT. No retry.
                response=rt.raw(session.root/"L0_raw"/phase/job["job_sha256"],job,simulation)
                e.require(session.failed and session.ledger.pending is None and eligible_timeout(job,response),"not a delegated judging timeout")
                views.append(derive_one(ctx,batch,q,response))
                e.require(reachable(ctx,batch,views),"timeout made fixed guards unreachable")
                counts,last=copy.deepcopy(session.ledger.counts),session.ledger.previous
                rt.hold(ctx,HOLD_REASON)
                save_once(side/"recoveries"/(f"{sum(counts.values()):06d}.json"),{"phase":phase,"counts":counts,
                    "failed_job_sha256":job["job_sha256"],"failed_request_never_resent":True,
                    "fixed_guard_reachability_witness_found":True,"no_scientific_imputation":True})
                session.close();session=None
                # Re-audit the same durable ledger and original clock before unlatching.
                ctx=authorize(root,g,execute_approved=True,simulation=simulation)
                release_flags(ctx,stage,counts,last)
                session=Session(ctx,keys,transport=simulation_transport,sleep=sleep)
                if phase=="main":session.bind_main(batch)
                continue
            body=response["response_body"]
            returned=body.get("modelVersion") if q["provider"]=="gemini" else body.get("model")
            e.require(returned==q["requested_model"] and rt.prep._expected_output_shape(q["provider"],body),"identity/tool HOLD")
            # Derivation from raw; no source/judgment modifications or default values.
            views.append(derive_one(ctx,batch,q,response))
        views=prefix_views(ctx,batch,rt.ledger.CAPS[phase])
        result=rt._judge_result(ctx,batch)
        e.require(result["ratings"]==views,"incremental result differs from frozen full import")
        save_once(session.root/(phase+"-result.json"),result)
        counts=session.ledger.audit()
        if stage=="calibration":
            e.require(result["aggregation"]["primary_quality_report"]["technical_calibration_guards_passed"] is True
                and result["aggregation"]["new_full_record_quality_report"]["technical_calibration_guards_passed"] is True,"fixed calibration guards failed")
            summary={"status":"WAITING_FOR_DELEGATED_CALIBRATION_REVIEW","counts":counts,
                "calibration_result_sha256":result["result_sha256"],"fixture_only":simulation}
            save_once(session.root/"PRE_CALIBRATION_FINISHED.json",summary)
        else:
            e.require(counts["new_counts"]==rt.ledger.CAPS and counts["cumulative_reservations"]==1466,"cap accounting mismatch")
            summary={"status":"EV31_CONTINUED_PILOT_COMPLETED_RESULT_REVIEW_REQUIRED","counts":counts,
                "primary_numeric_guards_passed":result["aggregation"]["primary_quality_report"]["numeric_quality_checks_passed"],
                "full_numeric_guards_passed":result["aggregation"]["new_full_record_quality_report"]["numeric_quality_checks_passed"],
                "pilot_passed":False,"human_gold_validity_or_comparability_established":False,
                "source_answers":150,"main_judgments":300,"publication_Core_restart_W01":False,"fixture_only":simulation}
            save_once(session.root/"RUN_FINISHED.json",summary)
        return summary
    except BaseException as exc:
        number=len(list((Path(ctx["authorization"]["accounting_root"])/"claims").glob("*.json")))
        target=side/"terminal-holds"/(stage+f"-{number:06d}.json")
        if not target.exists():rt.save(target,{"stage":stage,"new_reservations":number,
            "exception_class":type(exc).__name__,"automatic_resend":False,"original_clock_preserved":True})
        raise
    finally:
        try:
            if session:session.close()
        finally:
            memory.clear();rt.hold(ctx,HOLD_REASON);control.close()


def main(argv=None):
    parser=argparse.ArgumentParser()
    parser.add_argument("stage",choices=("calibration","post-review"))
    parser.add_argument("--root",required=True);parser.add_argument("--authorization",required=True)
    parser.add_argument("--execute-approved",action="store_true")
    a=parser.parse_args(argv)
    try:
        result=run_stage(Path(a.root),scoring.read_json(Path(a.authorization)),stage=a.stage,execute_approved=a.execute_approved)
        print(json.dumps(result,ensure_ascii=False));return 0
    except BaseException:
        print("EV31 CONTINUATION HOLD: no resend; evidence and original clock preserved.");return 1


if __name__=="__main__":raise SystemExit(main())

"""Temporary AC-only Windows power requests; never change power-plan settings.

Only SystemRequired(1) and ExecutionRequired(3) are requested. No display,
away-mode, lid/power-button override, registry or powercfg mutation is used.
"""
from __future__ import annotations
import ctypes
from ctypes import wintypes
import os
import threading
import time
from datetime import UTC, datetime


class PowerGuardError(ValueError):
    pass


class WindowsPowerBackend:
    def __init__(self):
        if os.name != "nt": raise PowerGuardError("Windows power guard unavailable")
        class Detail(ctypes.Structure):
            _fields_ = [("module", wintypes.HMODULE), ("reason", wintypes.ULONG),
                ("count", wintypes.ULONG), ("strings", ctypes.POINTER(wintypes.LPWSTR))]
        class Reason(ctypes.Union):
            _fields_ = [("detail", Detail), ("simple", wintypes.LPWSTR)]
        class Context(ctypes.Structure):
            _fields_ = [("version", wintypes.ULONG), ("flags", wintypes.DWORD), ("reason", Reason)]
        class Status(ctypes.Structure):
            _fields_ = [("AC", wintypes.BYTE), ("battery_flags", wintypes.BYTE), ("percent", wintypes.BYTE),
                ("saving", wintypes.BYTE), ("remaining", wintypes.DWORD), ("full", wintypes.DWORD)]
        self.context_type, self.status_type = Context, Status
        self.k = ctypes.WinDLL("kernel32", use_last_error=True)
        self.k.GetSystemPowerStatus.argtypes = [ctypes.POINTER(Status)]
        self.k.GetSystemPowerStatus.restype = wintypes.BOOL
        self.k.PowerCreateRequest.argtypes = [ctypes.POINTER(Context)]
        self.k.PowerCreateRequest.restype = wintypes.HANDLE
        for name in ("PowerSetRequest", "PowerClearRequest"):
            f = getattr(self.k, name); f.argtypes = [wintypes.HANDLE, ctypes.c_int]; f.restype = wintypes.BOOL
        self.k.CloseHandle.argtypes = [wintypes.HANDLE]; self.k.CloseHandle.restype = wintypes.BOOL

    def ac_online(self):
        status = self.status_type()
        if not self.k.GetSystemPowerStatus(ctypes.byref(status)): raise PowerGuardError("power status unavailable")
        return status.AC == 1

    def create(self):
        context = self.context_type()
        context.version, context.flags = 0, 1
        context.reason.simple = "MIBO-Education active bounded W0 operation; temporary AC-only awake request"
        handle = self.k.PowerCreateRequest(ctypes.byref(context))
        if handle in (None, ctypes.c_void_p(-1).value): raise PowerGuardError("power request creation failed")
        return handle

    def set(self, handle, kind): return bool(self.k.PowerSetRequest(handle, kind))
    def clear(self, handle, kind): return bool(self.k.PowerClearRequest(handle, kind))
    def close(self, handle): return bool(self.k.CloseHandle(handle))


class ACPowerGuard:
    def __init__(self, backend=None, *, watch=True, interval=1.0, clock=time.monotonic):
        self.backend = backend if backend is not None else WindowsPowerBackend()
        self.watch, self.interval, self.clock = watch, interval, clock
        self._lock, self._stop = threading.RLock(), threading.Event()
        self._handle, self._kinds, self._thread = None, [], None
        self.active, self.closed, self.lost_reason = False, False, None
        self.events, self.clear_failures, self.close_failed = [], [], False
        self._last_poll = None

    def _event(self, name):
        self.events.append({"at": datetime.now(UTC).isoformat(), "event": name})

    def _release_locked(self):
        self.active = False
        if self._handle is None: return
        for kind in reversed(self._kinds):
            try: ok = self.backend.clear(self._handle, kind)
            except Exception: ok = False
            if not ok: self.clear_failures.append(kind)
        self._kinds = []
        try: ok = self.backend.close(self._handle)
        except Exception: ok = False
        self.close_failed = self.close_failed or not ok
        self._handle = None
        self._event("OWN_POWER_REQUESTS_RELEASED" if ok else "OWN_POWER_HANDLE_CLOSE_NOT_VERIFIED")

    def __enter__(self):
        with self._lock:
            if self.closed or self._handle is not None: raise PowerGuardError("guard cannot be reused")
            try:
                if not self.backend.ac_online(): raise PowerGuardError("AC power required before active operation")
                self._handle = self.backend.create()
                for kind in (1, 3):
                    if not self.backend.set(self._handle, kind): raise PowerGuardError("power request setup failed")
                    self._kinds.append(kind)
                self.active, self._last_poll = True, self.clock()
                self._event("AC_CONFIRMED_SYSTEM_AND_EXECUTION_REQUESTS_ACTIVE")
            except BaseException:
                self._release_locked(); self.closed = True
                raise
        if self.watch:
            self._thread = threading.Thread(target=self._watch, name="MIBOE-AC-power-watch", daemon=True)
            self._thread.start()
        return self

    def poll(self):
        with self._lock:
            if self.closed or not self.active: return False
            now = self.clock()
            try: online = self.backend.ac_online()
            except Exception: online = False
            reason = ("AC_DISCONNECTED_OR_STATUS_UNKNOWN" if not online else
                "POWER_MONITOR_GAP_OR_SUSPEND" if now - self._last_poll > 30 else None)
            self._last_poll = now
            if reason:
                self.lost_reason = reason
                self._event(reason)
                self._release_locked()
                self._stop.set()
                return False
            return True

    def _watch(self):
        while not self._stop.wait(self.interval):
            if not self.poll(): return

    def require_ready(self):
        if not self.poll(): raise PowerGuardError(self.lost_reason or "AC wake guard not active")

    def close(self):
        self._stop.set()
        if self._thread is not None and self._thread is not threading.current_thread(): self._thread.join(timeout=2)
        with self._lock:
            self._release_locked()
            self.closed = True

    def snapshot(self):
        with self._lock:
            return {"active": self.active, "closed": self.closed, "lost_reason": self.lost_reason,
                "request_types": [1, 3], "display_or_away_mode_requested": False,
                "permanent_power_settings_changed": False, "explicit_user_sleep_overridden": False,
                "own_handle_close_verified": self.closed and not self.close_failed, "clear_returned_false_types": self.clear_failures,
                "events": list(self.events)}

    def __exit__(self, typ, value, tb):
        self.close()
        if self.close_failed and typ is None: raise PowerGuardError("own power handle close not verified; no further dispatch")

"""Prospective Anthropic-only finite boolean/null wire compression.

No logical schema, model prompt, scoring code, result validator or other provider
wire is changed. JSON booleans are not numbers: true/false/null is the entire
accepted set. Provider compiler acceptance still requires a separately approved
live run; the static complexity guard alone does not establish compatibility.
"""
from __future__ import annotations

from typing import Any

from . import reciprocal_engine as e
from . import schema_wire_v12 as previous

VERSION = "MIBOE-ANTHROPIC-BOOLEAN-NULL-FINITE-ENUM-v1"
UNION_LIMIT = 16
OPTIONAL_LIMIT = 24


def complexity(value: Any) -> dict[str, int]:
    counts = {"union_parameters": 0, "optional_parameters": 0, "nullable_booleans": 0}
    def visit(node):
        if isinstance(node, list):
            for child in node:
                visit(child)
        elif isinstance(node, dict):
            counts["union_parameters"] += int(isinstance(node.get("type"), list) or "anyOf" in node)
            counts["nullable_booleans"] += int(node.get("type") in (["boolean", "null"], ["null", "boolean"]))
            if "properties" in node:
                counts["optional_parameters"] += len(set(node["properties"]) - set(node.get("required", [])))
            for child in node.values():
                visit(child)
    visit(value)
    return counts


def _compress(value: Any) -> Any:
    if isinstance(value, list):
        return [_compress(v) for v in value]
    if not isinstance(value, dict):
        return value
    node = {k: _compress(v) for k, v in value.items()}
    if isinstance(node.get("type"), list) and "boolean" in node["type"]:
        e.require(
            len(node["type"]) == 2 and set(node["type"]) == {"boolean", "null"}
            and "enum" not in node and "anyOf" not in node,
            "unapproved boolean union shape; do not generalize silently",
        )
        node = {k: v for k, v in node.items() if k != "type"}
        node["enum"] = [True, False, None]
    return node


def schema(value: Any) -> Any:
    # Retain the preceding nullable-string enum correction, then compress ONLY
    # the finite boolean/null domains. Integers/strings remain exactly as before.
    return _compress(previous.schema(value))


def request(logical: dict[str, Any]) -> dict[str, Any]:
    physical = previous.request(logical)
    if logical["provider"] == "anthropic":
        e.require(not physical["body"].get("tools"), "unapproved combined strict schemas")
        native = physical["body"]["output_config"]["format"]
        before = complexity(native["schema"])
        native["schema"] = _compress(native["schema"])
        after = complexity(native["schema"])
        e.require(
            before["union_parameters"] == 49 and before["nullable_booleans"] == 33
            and after["union_parameters"] <= UNION_LIMIT and after["nullable_booleans"] == 0
            and after["optional_parameters"] <= OPTIONAL_LIMIT,
            "frozen schema shape or provider complexity preflight failed",
        )
    return physical


def binding(logical: dict[str, Any]) -> dict[str, str]:
    physical = request(logical)
    return {
        "logical_method_request_id": logical["request_id"],
        "logical_body_sha256": e.digest(logical["body"]),
        "physical_body_sha256": e.digest(physical["body"]),
        "wire_representation": VERSION if logical["provider"] == "anthropic" else "UNCHANGED",
    }

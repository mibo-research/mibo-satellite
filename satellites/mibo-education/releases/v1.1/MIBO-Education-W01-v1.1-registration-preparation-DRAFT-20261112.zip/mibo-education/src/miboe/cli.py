from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Any

from . import reciprocal
from .artifacts import load_battery, load_manifest
from .blind import export_blind
from .certificate import create_certificate
from .errors import MiboeError, ValidationError
from .live_qualification import (
    SERIES_IDS,
    qualification_status_report,
    run_dress_rehearsal,
    run_provider_qualification_set,
    run_smoke_qualification,
)
from .models import load_model_lock, resolve_models
from .operational import w0_pre_live_report
from .preflight import preflight
from .qc import run_qc
from .readiness import FLAGS, scientific_readiness
from .runner import run_wave
from .scheduling import create_schedule, load_schedule
from .scoring import (
    aggregate_scoring_batch,
    build_scoring_batch,
    import_scoring_response,
    read_json,
    scoring_status,
    strict_json,
    write_private_artifact,
)
from .study import study_status
from .w0_pipeline import STAGES, qualification_pipeline


def _pairs(values: list[str] | None, *, name: str) -> dict[str, str]:
    result: dict[str, str] = {}
    for value in values or []:
        if "=" not in value:
            raise ValidationError(f"{name} must use SERIES=VALUE syntax")
        key, item = value.split("=", 1)
        if not key or not item or key in result:
            raise ValidationError(f"invalid or duplicate {name}: {value}")
        result[key] = item
    return result


def _context(path: Path) -> tuple[Any, Any, Any, Any]:
    manifest = load_manifest(path)
    battery = load_battery(manifest.battery_path)
    lock = load_model_lock(manifest.model_lock_path)
    schedule = load_schedule(manifest.schedule_path)
    return manifest, battery, lock, schedule


def command_validate(args: argparse.Namespace) -> dict[str, Any]:
    root = Path(args.root).resolve()
    result = scientific_readiness(root)
    false_reasons = [
        reason for flag in FLAGS if not result[flag] for reason in result["reasons"][flag]
    ]
    errors = result["reasons"]["ENGINEERING_READY"] if args.engineering else false_reasons
    warnings = (
        [reason for flag in FLAGS[1:] if not result[flag] for reason in result["reasons"][flag]]
        if args.engineering
        else []
    )
    result = {**result, "errors": errors, "warnings": warnings}
    if errors:
        raise ValidationError(json.dumps(result, ensure_ascii=False))
    return result


def command_resolve(args: argparse.Namespace) -> dict[str, Any]:
    manifest = load_manifest(Path(args.manifest))
    return resolve_models(
        manifest,
        _pairs(args.set, name="--set"),
        _pairs(args.evidence, name="--evidence"),
        verify_live=not args.no_live_verification,
    )


def command_schedule(args: argparse.Namespace) -> dict[str, Any]:
    manifest = load_manifest(Path(args.manifest))
    battery = load_battery(manifest.battery_path)
    lock = load_model_lock(manifest.model_lock_path)
    return create_schedule(manifest, battery, lock)


def command_preflight(args: argparse.Namespace) -> dict[str, Any]:
    report = preflight(load_manifest(Path(args.manifest)))
    if not report["passed"]:
        raise ValidationError(json.dumps(report, ensure_ascii=False))
    return report


def command_pilot(args: argparse.Namespace) -> dict[str, Any]:
    manifest, battery, lock, schedule = _context(Path(args.manifest))
    if manifest.official:
        raise ValidationError("pilot command refuses official Wave manifests")
    if manifest.wave_id == "MIBO-EDU-W0":
        gate = w0_pre_live_report(module_root=manifest.source.parents[2])
        if not gate["W0_Q1_EXECUTABLE"]:
            raise ValidationError(
                "W0 pilot refused: pre-live operational gates are incomplete: "
                f"{gate['W0_Q1_EXECUTABLE_reasons']}"
            )
    return run_wave(
        manifest=manifest,
        battery=battery,
        lock=lock,
        schedule=schedule,
        max_observations=args.max_observations,
        ignore_planned_time=args.ignore_planned_time,
    )


def command_run_wave(args: argparse.Namespace) -> dict[str, Any]:
    manifest, battery, lock, schedule = _context(Path(args.manifest))
    if not manifest.official:
        raise ValidationError("run-wave is reserved for official manifests; use pilot")
    return run_wave(
        manifest=manifest,
        battery=battery,
        lock=lock,
        schedule=schedule,
        max_observations=args.max_observations,
    )


def command_qc(args: argparse.Namespace) -> dict[str, Any]:
    manifest, battery, lock, schedule = _context(Path(args.manifest))
    report = run_qc(manifest, battery, lock, schedule)
    if not report["passed"]:
        raise ValidationError(json.dumps(report, ensure_ascii=False))
    return report


def command_certificate(args: argparse.Namespace) -> dict[str, Any]:
    manifest, battery, lock, schedule = _context(Path(args.manifest))
    return create_certificate(
        manifest.source.parent,
        manifest_sha256=manifest.content_sha256,
        battery_sha256=battery.content_sha256,
        model_lock_sha256=lock["model_lock_sha256"],
        schedule_sha256=schedule["schedule_sha256"],
    )


def command_export(args: argparse.Namespace) -> dict[str, Any]:
    manifest = load_manifest(Path(args.manifest))
    salt = os.getenv(args.salt_env, "")
    return export_blind(manifest.source.parent, salt=salt)


def _qualification_paths(args: argparse.Namespace) -> tuple[Path, Path | None]:
    module_root = Path(args.root).resolve()
    output_root = Path(args.output_root).resolve() if args.output_root else None
    return module_root, output_root


def command_qualify_smoke(args: argparse.Namespace) -> dict[str, Any]:
    module_root, output_root = _qualification_paths(args)
    result = run_smoke_qualification(
        module_root=module_root,
        output_root=output_root,
        series_ids=args.series,
    )
    if not result["passed"]:
        raise ValidationError(json.dumps(result, ensure_ascii=False))
    return result


def command_qualify_providers(args: argparse.Namespace) -> dict[str, Any]:
    module_root, output_root = _qualification_paths(args)
    result = run_provider_qualification_set(
        module_root=module_root,
        output_root=output_root,
        series_ids=args.series,
    )
    if not result["passed"]:
        raise ValidationError(json.dumps(result, ensure_ascii=False))
    return result


def command_qualify_rehearsal(args: argparse.Namespace) -> dict[str, Any]:
    module_root, output_root = _qualification_paths(args)
    result = run_dress_rehearsal(module_root=module_root, output_root=output_root)
    if not result["passed"]:
        raise ValidationError(json.dumps(result, ensure_ascii=False))
    return result


def command_qualify_report(args: argparse.Namespace) -> dict[str, Any]:
    module_root, output_root = _qualification_paths(args)
    return qualification_status_report(
        module_root=module_root, output_root=output_root, series_ids=args.series
    )


def command_qualify_preflight(args: argparse.Namespace) -> dict[str, Any]:
    result = command_qualify_report(args)
    if not result["W0_Q1_EXECUTABLE"]:
        raise ValidationError(json.dumps(result, ensure_ascii=False))
    return result


def command_qualify_pipeline(args: argparse.Namespace) -> dict[str, Any]:
    return qualification_pipeline(
        Path(args.root),
        series_ids=args.series,
        through=args.through,
        execute_approved=args.execute_approved,
    )


def command_score(args: argparse.Namespace) -> dict[str, Any]:
    root = Path(args.root).resolve()
    if args.scoring_command == "status":
        return scoring_status(root)
    if args.scoring_command == "prepare":
        lines = Path(args.blind_input).read_text(encoding="utf-8").splitlines()
        result = build_scoring_batch(root, [strict_json(line) for line in lines if line.strip()])
        summary = {
            "requests_prepared": len(result["requests"]),
            "batch_sha256": result["batch_sha256"],
        }
    elif args.scoring_command == "import":
        result = import_scoring_response(
            root, read_json(Path(args.batch)), read_json(Path(args.response))
        )
        summary = {
            "valid": result["valid"],
            "error": result["error"],
            "rating_sha256": result["rating_sha256"],
        }
    else:
        result = aggregate_scoring_batch(
            root, read_json(Path(args.batch)), [read_json(Path(p)) for p in args.ratings]
        )
        summary = {
            "responses": len(result["responses"]),
            "aggregation_sha256": result["aggregation_sha256"],
        }
    write_private_artifact(root, Path(args.output), result)
    return {**summary, "api_calls_made": 0, "restricted_content_printed": False}


def command_study_status(args: argparse.Namespace) -> dict[str, Any]:
    return study_status(Path(args.root))


def command_preparation(args: argparse.Namespace) -> dict[str, Any]:
    from . import calibration_review, offline_rehearsal, three_series
    from .util import write_immutable

    root = Path(args.root).resolve()
    operation = args.preparation_command
    if operation == "status":
        return three_series.status(root)
    if operation == "rehearsal":
        return offline_rehearsal.run(root, Path(args.output_root))
    if operation == "review":
        three_series.load_runtime(root)
        destination = Path(args.output).resolve()
        write_immutable(destination, calibration_review.render_html(root).encode("utf-8"))
        return {
            "cases": 35,
            "output": str(destination),
            "owner_review_completed": False,
            "API_calls_made": 0,
        }
    value = three_series.build_collection(
        root, _pairs(args.model, name="--model"), scope=args.scope, seed=args.seed
    )
    write_private_artifact(root, Path(args.output), value)
    return {
        "scope": value["scope"],
        "requests_prepared": len(value["requests"]),
        "collection_plan_sha256": value["collection_plan_sha256"],
        "API_calls_made": 0,
    }


def command_reciprocal(args: argparse.Namespace) -> dict[str, Any]:
    root = Path(args.root).resolve()
    operation = args.reciprocal_command
    if operation == "status":
        return reciprocal.status(root)
    if operation in {"prepare", "calibration"}:
        if operation == "calibration":
            rows = reciprocal.calibration_rows(root, salt=os.getenv(args.salt_env, ""))
            families, phase = {}, "calibration"
        else:
            rows = [
                strict_json(line)
                for line in Path(args.blind_input).read_text(encoding="utf-8").splitlines()
                if line.strip()
            ]
            families, phase = read_json(Path(args.source_map)), "main"
        value = reciprocal.build_batch(root, rows, families, phase=phase)
        summary = {
            "phase": phase,
            "requests_prepared": len(value["requests"]),
            "batch_sha256": value["batch_sha256"],
        }
    elif operation == "import":
        batch = read_json(Path(args.batch))
        ratings = reciprocal.import_many(root, batch, read_json(Path(args.responses)))
        value = reciprocal.engine.sealed(
            {
                "method_id": reciprocal.METHOD,
                "batch_sha256": batch["batch_sha256"],
                "ratings": ratings,
            },
            "rating_set_sha256",
        )
        summary = {
            "ratings_imported": len(ratings),
            "valid_ratings": sum(r["valid"] for r in ratings),
        }
    else:
        batch, ratings = read_json(Path(args.batch)), []
        for filename in args.ratings:
            saved = read_json(Path(filename))
            reciprocal.engine.verify(saved, "rating_set_sha256")
            reciprocal.engine.require(
                saved["method_id"] == reciprocal.METHOD
                and saved["batch_sha256"] == batch["batch_sha256"],
                "rating set scope mismatch",
            )
            ratings.extend(saved["ratings"])
        value = reciprocal.aggregate(root, batch, ratings)
        summary = {
            "phase": value["phase"],
            "responses": len(value["responses"]),
            "aggregation_sha256": value["aggregation_sha256"],
            "pilot_passed": False,
        }
    write_private_artifact(root, Path(args.output), value)
    return {**summary, "API_calls_made": 0, "restricted_content_printed": False}


def parser() -> argparse.ArgumentParser:
    value = argparse.ArgumentParser(prog="miboe")
    commands = value.add_subparsers(dest="command", required=True)
    validate = commands.add_parser("validate")
    validate.add_argument("--root", default=str(Path(__file__).resolve().parents[2]))
    validate.add_argument("--engineering", action="store_true")
    validate.set_defaults(function=command_validate)

    models = commands.add_parser("models")
    model_commands = models.add_subparsers(dest="model_command", required=True)
    resolve = model_commands.add_parser("resolve")
    resolve.add_argument("--manifest", required=True)
    resolve.add_argument("--set", action="append", required=True)
    resolve.add_argument("--evidence", action="append", default=[])
    resolve.add_argument("--no-live-verification", action="store_true")
    resolve.set_defaults(function=command_resolve)

    study = commands.add_parser("study", help="read-only current prospective design")
    study_commands = study.add_subparsers(dest="study_command", required=True)
    study_info = study_commands.add_parser("status")
    study_info.add_argument("--root", default=str(Path(__file__).resolve().parents[2]))
    study_info.set_defaults(function=command_study_status)

    prep = commands.add_parser("preparation", help="Education three-source MOCK ONLY preparation")
    prep_commands = prep.add_subparsers(dest="preparation_command", required=True)
    for operation in ("status", "review", "plan", "rehearsal"):
        item = prep_commands.add_parser(operation)
        item.add_argument("--root", default=str(Path(__file__).resolve().parents[2]))
        item.set_defaults(function=command_preparation)
        if operation == "rehearsal":
            item.add_argument("--output-root", required=True)
        elif operation in {"review", "plan"}:
            item.add_argument("--output", required=True)
        if operation == "plan":
            item.add_argument("--model", action="append", required=True)
            item.add_argument("--scope", choices=("pilot", "formal-plan"), default="pilot")
            item.add_argument("--seed")

    qualify = commands.add_parser("qualify")
    qualify_commands = qualify.add_subparsers(dest="qualification_command", required=True)
    qualification_root = str(Path(__file__).resolve().parents[2])
    for name, function in (
        ("smoke", command_qualify_smoke),
        ("providers", command_qualify_providers),
        ("rehearsal", command_qualify_rehearsal),
        ("preflight", command_qualify_preflight),
        ("report", command_qualify_report),
    ):
        item = qualify_commands.add_parser(name)
        item.add_argument("--root", default=qualification_root)
        item.add_argument("--output-root")
        if name in {"smoke", "providers", "preflight", "report"}:
            item.add_argument("--series", action="append", choices=SERIES_IDS)
        item.set_defaults(function=function)

    pipeline = qualify_commands.add_parser("pipeline", help="plan or advance W0 qualification")
    pipeline.add_argument("--root", default=qualification_root)
    pipeline.add_argument("--series", action="append", choices=SERIES_IDS)
    pipeline.add_argument("--through", choices=STAGES)
    pipeline.add_argument(
        "--execute-approved",
        action="store_true",
        help="confirm human approval for the selected scope and paid W0 requests (default: plan)",
    )
    pipeline.set_defaults(function=command_qualify_pipeline)

    score = commands.add_parser("score", help="offline-only AI judging; no live API command")
    score_commands = score.add_subparsers(dest="scoring_command", required=True)
    for name in ("status", "prepare", "import", "aggregate"):
        item = score_commands.add_parser(name)
        item.add_argument("--root", default=qualification_root)
        item.set_defaults(function=command_score)
        if name != "status":
            item.add_argument("--output", required=True)
        if name == "prepare":
            item.add_argument("--blind-input", required=True)
        elif name == "import":
            item.add_argument("--batch", required=True)
            item.add_argument("--response", required=True)
        elif name == "aggregate":
            item.add_argument("--batch", required=True)
            item.add_argument("--ratings", nargs="+", required=True)

    reciprocal_cmd = commands.add_parser(
        "reciprocal", help="offline reciprocal panel and calibration"
    )
    reciprocal_commands = reciprocal_cmd.add_subparsers(dest="reciprocal_command", required=True)
    for name in ("status", "prepare", "calibration", "import", "aggregate"):
        item = reciprocal_commands.add_parser(name)
        item.add_argument("--root", default=qualification_root)
        item.set_defaults(function=command_reciprocal)
        if name != "status":
            item.add_argument("--output", required=True)
        if name == "prepare":
            item.add_argument("--blind-input", required=True)
            item.add_argument("--source-map", required=True)
        elif name == "calibration":
            item.add_argument("--salt-env", default="MIBOE_BLIND_SALT")
        elif name == "import":
            item.add_argument("--batch", required=True)
            item.add_argument("--responses", required=True)
        elif name == "aggregate":
            item.add_argument("--batch", required=True)
            item.add_argument("--ratings", nargs="+", required=True)

    schedule = commands.add_parser("schedule")
    schedule.add_argument("--manifest", required=True)
    schedule.set_defaults(function=command_schedule)

    for name, function in (
        ("preflight", command_preflight),
        ("qc", command_qc),
        ("certificate", command_certificate),
        ("export-blind", command_export),
    ):
        item = commands.add_parser(name)
        item.add_argument("--manifest", required=True)
        if name == "export-blind":
            item.add_argument("--salt-env", default="MIBOE_BLIND_SALT")
        item.set_defaults(function=function)

    pilot = commands.add_parser("pilot")
    pilot.add_argument("--manifest", required=True)
    pilot.add_argument("--max-observations", type=int)
    pilot.add_argument("--ignore-planned-time", action="store_true")
    pilot.set_defaults(function=command_pilot)

    official = commands.add_parser("run-wave")
    official.add_argument("--manifest", required=True)
    official.add_argument("--max-observations", type=int)
    official.set_defaults(function=command_run_wave)
    return value


def main(argv: list[str] | None = None) -> int:
    try:
        args = parser().parse_args(argv)
        result = args.function(args)
        print(json.dumps(result, ensure_ascii=False, indent=2, default=str))
        return 0
    except (MiboeError, OSError, ValueError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())

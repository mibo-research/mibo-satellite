"""Preparation/approval-gate administration. Never creates a FINAL permit by a CLI flag."""
from __future__ import annotations
import argparse
import copy
import json
import os
from datetime import UTC,datetime,timedelta
from pathlib import Path
from . import evidence_ev31_runtime as runtime, evidence_ev31_ledger as ledger
from . import reciprocal_engine as e, scoring
from .util import sha256_file,write_immutable


def approval_root(plan):
    return ledger.private_path(plan["root"],Path(os.environ["LOCALAPPDATA"])/plan["config"]["approval_relative_root"])


def finalize_authorization(root,*,source_instruction,source_evidence,verification_report):
    """Call ONLY to transcribe a subsequent explicit owner API-execution approval.

    Package preparation, contents of a file, tests and the current 'finish in one
    batch' request are not that approval. This function does not send requests.
    """
    e.require(type(source_instruction) is str and source_instruction.strip()
        and type(source_evidence) is str and source_evidence.strip(),"direct owner approval source required")
    plan = runtime.load_plan(root)
    report_path = Path(verification_report).resolve()
    report = scoring.read_json(report_path)
    e.require(report["status"]=="EV31_APPROVAL_PACKAGE_READY_NO_REAL_API"
        and report["release_sha256"]==plan["lock"]["release_sha256"]
        and report["plan_sha256"]==plan["plan_sha256"] and report["API_calls"]==0
        and report["tests"]["exit_code"]==0 and report["tests"]["failed"]==0
        and report["full561_request_fixture_completed"] is True,"final verification package required")
    auth = runtime.authorization_draft(root)
    destination = Path(auth["execution_root"])
    auth["preparation_file_sha256"] = sha256_file(destination/"PREPARATION.json")
    now = datetime.now(UTC)
    auth.update(status="FINAL_EV31_PILOT_EXECUTION_AUTHORIZATION",human_attestation=True,
        approved_at=now.isoformat(),start_before=(now+timedelta(hours=168)).isoformat(),
        source_instruction=source_instruction,source_evidence=source_evidence,
        permissions=copy.deepcopy(runtime.PERMISSIONS),verification_report_file_sha256=sha256_file(report_path))
    runtime.authorize(root,auth,execute_approved=True,preflight_only=True)
    runtime.save(approval_root(plan)/"authorization.json",auth)
    return auth


def release_for_stage(root,a,*,stage,simulation=False,archive_root=None):
    e.require(stage in {"pre-calibration","post-review"},"unknown stage")
    ctx = runtime.authorize(root,a,execute_approved=True,simulation=simulation,
        continuation=stage=="post-review",preflight_only=True)
    if stage=="post-review":
        runtime.verify_review(ctx)
        book = ledger.Ledger(ctx)
        try: e.require(book.counts=={"metadata":6,"calibration":105,"collection":0,"main":0},"no automatic restart of attempted post-review stage")
        finally: book.close()
    if simulation:
        e.require(archive_root is not None,"fixture archive root required")
        target_root = ledger.private_path(root,Path(archive_root))
    else:
        e.require(archive_root is None,"live archive override forbidden")
        target_root = approval_root(ctx["plan"])
    stop = ctx["destination"]/"STOP"
    if stage=="pre-calibration":
        expected_stop = ctx["preparation"]["initial_STOP_sha256"]
    else:
        expected_stop = runtime.sha256_bytes((runtime.method.CAMPAIGN+" WAITING_FOR_REVIEW_OR_RESULT_REVIEW_OR_FAILURE; no automatic retry.\n").encode())
    e.require(stop.is_file() and sha256_file(stop)==expected_stop,"not the expected prepared/review STOP; preserve manual STOP")
    flags = [(stop,"STOP")]
    if not simulation:
        flag = ledger.private_path(root,Path(ctx["plan"]["config"]["credentials"]["restart_hold_file"]))
        expected = ctx["baseline"]["initial_global_HOLD_sha256"] if stage=="pre-calibration" else expected_stop
        e.require(flag.is_file() and sha256_file(flag)==expected,"unexpected global HOLD; do not clear it")
        flags.append((flag,"API_RESTART_HOLD"))
    archive = target_root/"released-gates"/stage
    ledger.private_path(root,archive)
    archive.mkdir(parents=True,exist_ok=True)
    pairs = [(source,archive/name) for source,name in flags]
    e.require(all(not dest.exists() for _,dest in pairs),"stage already released; no automatic relaunch")
    moved = []
    try:
        for source,dest in pairs:
            ledger.private_path(root,source); ledger.private_path(root,dest)
            source.rename(dest)
            moved.append((source,dest))
        runtime.authorize(root,a,execute_approved=True,simulation=simulation,continuation=stage=="post-review")
    except BaseException:
        for source,dest in reversed(moved):
            if dest.is_file() and not source.exists(): dest.rename(source)
        raise
    receipt = e.sealed({"stage":stage,"authorization_sha256":ctx["authorization_sha256"],
        "release_sha256":ctx["plan"]["lock"]["release_sha256"],"flags":{dest.name:sha256_file(dest) for _,dest in pairs},
        "fixture_only":simulation},"gate_release_sha256")
    runtime.save(archive/"receipt.json",receipt)
    return receipt


def main(argv=None):
    p = argparse.ArgumentParser()
    p.add_argument("command",choices=("status","release"))
    p.add_argument("--root",default=str(Path(__file__).resolve().parents[2]))
    p.add_argument("--authorization")
    p.add_argument("--stage",choices=("pre-calibration","post-review"))
    p.add_argument("--execute-approved",action="store_true")
    args=p.parse_args(argv)
    try:
        if args.command=="status": value=runtime.status(Path(args.root))
        else:
            e.require(args.execute_approved and args.authorization and args.stage,"explicit final permit and stage required")
            value=release_for_stage(Path(args.root),scoring.read_json(Path(args.authorization)),stage=args.stage)
        print(json.dumps(value))
        return 0
    except BaseException:
        print("EV31 approval gate HOLD: no matching FINAL owner permit or safe stage release; no request sent.")
        return 1


if __name__=="__main__": raise SystemExit(main())

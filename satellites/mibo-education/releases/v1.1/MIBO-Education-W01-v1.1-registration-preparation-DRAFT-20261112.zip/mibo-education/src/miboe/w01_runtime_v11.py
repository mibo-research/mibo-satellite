"""Future W01 staged first-party runtime. A preparation/DRAFT can never dispatch."""
from __future__ import annotations
import argparse
import copy
from datetime import UTC, datetime, timedelta
import json
import os
import secrets
from pathlib import Path
import time
import uuid
import yaml
import httpx
from . import w01_v11 as w, evidence_ev31_runtime as rt, reciprocal_engine as e, scoring
from . import evidence_ev31_method as method
from . import evidence_ev31_continuation as historical_gate
from .ac_awake_v1 import ACPowerGuard
from .w0_ledger_v16 import Lease, private_path, RAW_FILES
from .util import canonical_json_bytes, sha256_bytes, sha256_file as sha, sanitized_headers, write_immutable

FINAL = "FINAL_W01_V11_REGISTERED_EXECUTION_AUTHORIZATION"
STOP_BYTES = b"MIBOE-W01-v1.1 STAGE_CLOSED; no automatic replay.\n"
PERMISSIONS = {"metadata": True, "fresh_calibration105": True, "collection2100_slots": True,
    "nonself_judging_max4200": True, "delegated_agent_calibration_and_result_review": True,
    "fully_recorded_READ_TIMEOUT_unsent_continuation": True, "AC_only_awake_and_release": True,
    "source_or_judge_resend": False, "model_or_prompt_substitution": False,
    "Core_restart": False, "other_wave": False}


def now(): return datetime.now(UTC)
def save(path, value): rt.save(path, value)


def precheck(root, grant, *, execute=False, fixture=False):
    # Deliberately precedes plan/path/key/client/power access.
    e.require(execute is True and grant.get("status") == FINAL and grant.get("fixture_only") is fixture,
        "W01 DRAFT/preparation is not execution authority")
    p = w.load_plan(root)
    expected = {"campaign_id": w.CAMPAIGN, "release_sha256": p["lock"]["release_sha256"],
        "actor_type": "HUMAN", "owner": "笹埜健斗", "human_attestation": True,
        "permissions": PERMISSIONS, "caps": w.CAPS, "prior_reserved": w.PRIOR,
        "maximum_new": w.NEW_MAX, "maximum_cumulative": w.TOTAL_MAX,
        "anchor_utc": w.ANCHOR, "observer_site_id": w.SITE, "registered_before_observation_required": True}
    e.require(all(type(grant.get(k)) is type(v) and grant[k] == v for k, v in expected.items()), "W01 FINAL scope/bounds differ")
    e.require(all(isinstance(grant.get(k), str) and grant[k].strip() for k in
        ("source_owner_instruction", "source_owner_evidence", "approved_at", "publication_receipt", "publication_receipt_sha256",
         "execution_root", "W0_review_file", "W0_review_file_sha256")), "actual scoped owner evidence/registration required")
    e.require(w.stamp(grant["approved_at"]) < w.stamp(w.ANCHOR), "no backdated approval")
    if not fixture:
        e.require(grant["W0_review_file_sha256"] == p["config"]["W0_review_file_sha256"], "W0 clearance evidence changed")
        e.require(sha(Path(grant["W0_review_file"])) == grant["W0_review_file_sha256"], "W0 review bytes changed")
        review = scoring.read_json(Path(grant["W0_review_file"]))
        e.require(review["status"] == "EV31_AGENT_LIMITED_TECHNICAL_REVIEW_ACCEPTED"
            and review["accepted_limited_technical_scope"] is True, "limited W0 readiness not confirmed")
    receipt_path = Path(grant["publication_receipt"])
    e.require(sha(receipt_path) == grant["publication_receipt_sha256"], "registration receipt changed")
    receipt = scoring.read_json(receipt_path)
    e.require(receipt["published"] is True and receipt["release_sha256"] == p["lock"]["release_sha256"]
        and receipt["finalization_declaration_verified"] is True
        and receipt["version"] == "1.1" and receipt["language"] == "eng" and receipt["license"] == "CC-BY-4.0"
        and receipt["new_DOI"] != "10.5281/zenodo.22047001" and receipt["new_DOI"].startswith("10.5281/zenodo.")
        and w.stamp(receipt["verified_at"]) < w.stamp(w.ANCHOR), "published prospective v1.1 receipt required before baseline")
    return p


def initialize_after_approval(root, grant):
    """Mechanical activation AFTER actual owner consent and publication, never today."""
    p = precheck(root, grant, execute=True, fixture=False)
    from . import evidence_ev31_admin as admin
    old_authority = scoring.read_json(admin.approval_root(p["native"]) / "authorization.json")
    old_run, old_accounting = Path(old_authority["execution_root"]), Path(old_authority["accounting_root"])
    finished = scoring.read_json(old_run / "RUN_FINISHED.json")
    e.require(finished["counts"]["cumulative_reservations"] == 1468
        and len(list((old_accounting / "claims").glob("*.json"))) == len(list((old_accounting / "outcomes").glob("*.json"))) == 563,
        "prior accounting changed; never reset W0")
    destination = private_path(p["root"], Path(grant["execution_root"]))
    e.require(destination == (Path(os.environ["LOCALAPPDATA"]) / "MIBO-Education/W01/W01-v1p1").resolve()
        and (not destination.exists() or not any(destination.iterdir())), "existing/unapproved W01 destination")
    previous = scoring.read_json(old_accounting / "BASELINE.json")
    groups = copy.deepcopy(previous["preserved_evidence"])
    for folder in (old_run, old_accounting, admin.approval_root(p["native"])):
        groups.append({"root": str(folder), "files": {f.relative_to(folder).as_posix(): sha(f) for f in sorted(folder.rglob("*")) if f.is_file()}})
    # Mutable cross-run gate is archived separately, never part of immutable L0.
    baseline = {"prior_reserved": 1468, "preserved_evidence": groups, "W0_review_file_sha256": grant["W0_review_file_sha256"],
        "governance_records": copy.deepcopy(previous["governance_records"]),
        "W01_scope_extension_owner_evidence": grant["source_owner_evidence"]}
    for record in baseline["governance_records"]:
        e.require(sha(Path(record["path"])) == record["sha256"], "existing named decision changed")
        data = yaml.safe_load(Path(record["path"]).read_text("utf-8"))
        e.require(data["status"] == "FINAL" and data["human_attestation"] is True and data["decided_by"]["name"] == grant["owner"], "existing owner determination differs")
    for folder in ("claims", "outcomes", "attempt-witnesses", "L0_raw", "collection-records"): (destination / folder).mkdir(parents=True, exist_ok=True)
    save(destination / "BASELINE.json", baseline)
    final = copy.deepcopy(grant); final.update(baseline_file_sha256=sha(destination / "BASELINE.json"), release_lock_file_sha256=sha(p["root"] / w.LOCK))
    save(destination / "authorization.json", final)
    save(destination / "PREPARATION.json", {"release_sha256": p["lock"]["release_sha256"], "fixture_only": False,
        "blinding_salt": secrets.token_hex(32), "observer_site_id": w.SITE})
    write_immutable(destination / "STOP", STOP_BYTES)
    return {"status": "W01_INITIALIZED_AFTER_OWNER_AND_PUBLICATION_GATES", "API_calls": 0,
        "maximum_new": 6411, "maximum_cumulative": 7879, "human_attestation_fabricated": False}


def stage_window(p, stage, root):
    anchor = w.stamp(w.ANCHOR)
    if stage == "preflight": return anchor - timedelta(hours=24), anchor
    if stage == "collection": return anchor, anchor + timedelta(hours=24)
    e.require(stage == "main", "unknown stage")
    ended = scoring.read_json(root / "COLLECTION_FINISHED.json")
    start = w.stamp(ended["finished_at"])
    return start, start + timedelta(hours=72)


def context(root, grant, *, execute, fixture):
    p = precheck(root, grant, execute=execute, fixture=fixture)
    dest = private_path(p["root"], Path(grant["execution_root"]))
    if not fixture:
        expected = (Path(os.environ["LOCALAPPDATA"]) / "MIBO-Education/W01/W01-v1p1").resolve()
        e.require(dest == expected, "unapproved W01 production namespace")
    e.require(sha(dest / "authorization.json") == sha256_bytes(canonical_json_bytes(grant) + b"\n"), "W01 authority changed")
    prep = scoring.read_json(dest / "PREPARATION.json")
    e.require(prep["release_sha256"] == p["lock"]["release_sha256"] and prep["fixture_only"] is fixture
        and isinstance(prep["blinding_salt"], str) and len(prep["blinding_salt"]) >= 32, "W01 preparation differs")
    if not fixture:
        baseline = scoring.read_json(dest / "BASELINE.json")
        e.require(sha(dest / "BASELINE.json") == grant["baseline_file_sha256"]
            and baseline["prior_reserved"] == 1468, "W0/W01 baseline differs")
        for group in baseline["preserved_evidence"]:
            for n, digest in group["files"].items():
                e.require(not Path(n).is_absolute() and ".." not in Path(n).parts, "invalid historical path")
                e.require(sha(Path(group["root"]) / n) == digest, "historical evidence changed")
        for record in baseline["governance_records"]:
            e.require(sha(Path(record["path"])) == record["sha256"], "named rights/storage/governance record changed")
            data = yaml.safe_load(Path(record["path"]).read_text("utf-8"))
            e.require(data["status"] == "FINAL" and data["human_attestation"] is True and data["decided_by"]["name"] == grant["owner"], "named determinations not FINAL")
        rt.office.reference(p["native"]["config"])
    return {"plan": p, "grant": grant, "root": dest, "fixture": fixture, "preparation": prep}


class Ledger:
    def __init__(self, ctx):
        self.ctx, self.root = ctx, ctx["root"]
        self.lease = Lease(self.root / "worker.lease")
        try: self.audit()
        except BaseException: self.lease.close(); raise

    def audit(self):
        names = sorted(p.name for p in (self.root / "claims").glob("*.json"))
        e.require(names == [f"{i:06d}.json" for i in range(1, len(names) + 1)], "reservation sequence gap")
        e.require(sorted(p.name for p in (self.root / "outcomes").glob("*.json")) == names, "unknown/incomplete receipt; no resend")
        self.counts, self.seen, previous = dict.fromkeys(w.CAPS, 0), set(), e.digest(self.ctx["grant"])
        for n in names:
            c = scoring.read_json(self.root / "claims" / n); e.verify(c, "claim_sha256")
            o = scoring.read_json(self.root / "outcomes" / n); e.verify(o, "outcome_sha256")
            e.require(c["sequence"] == sum(self.counts.values()) + 1 and c["previous_claim_sha256"] == previous
                and c["job_sha256"] not in self.seen and c["phase"] in w.CAPS, "reservation chain/replay violation")
            e.require((self.root / "attempt-witnesses" / n).read_bytes() == (self.root / "claims" / n).read_bytes(), "witness differs")
            d = self.root / "L0_raw" / c["job_sha256"]
            e.require(o["claim_sha256"] == c["claim_sha256"]
                and o["raw_file_sha256"] == {x: sha(d / x) for x in RAW_FILES}, "raw outcome changed")
            job = scoring.read_json(d / "request.json"); e.verify(job, "job_sha256")
            e.require(job["job_sha256"] == c["job_sha256"] and job["phase"] == c["phase"], "raw job differs")
            rt.raw(d, job, self.ctx["fixture"])
            self.counts[c["phase"]] += 1; self.seen.add(c["job_sha256"]); previous = c["claim_sha256"]
        self.previous = previous; self.pending = None; self.check(self.counts)
        e.require(sorted(p.name for p in (self.root / "attempt-witnesses").glob("*.json")) == names, "extra/missing attempt witness")
        e.require({p.name for p in (self.root / "L0_raw").iterdir()} == self.seen, "unaccounted raw attempt")
        return self.summary()

    @staticmethod
    def check(counts):
        e.require(set(counts) == set(w.CAPS) and all(type(v) is int and 0 <= v <= w.CAPS[k] for k, v in counts.items())
            and sum(counts.values()) <= 6411 and 1468 + sum(counts.values()) <= 7879, "W01 request cap exceeded")

    def summary(self):
        return {"counts": copy.deepcopy(self.counts), "new_reservations": sum(self.counts.values()),
            "prior_preserved": 1468, "cumulative_reservations": 1468 + sum(self.counts.values()), "maximum_cumulative": 7879}

    def reserve(self, job):
        e.require(self.pending is None and job["job_sha256"] not in self.seen, "pending/duplicate; never resend")
        nxt = copy.deepcopy(self.counts); nxt[job["phase"]] += 1; self.check(nxt)
        claim = e.sealed({"sequence": sum(nxt.values()), "phase": job["phase"], "job_sha256": job["job_sha256"],
            "previous_claim_sha256": self.previous, "reserved_at": now().isoformat()}, "claim_sha256")
        n = f"{claim['sequence']:06d}.json"
        save(self.root / "claims" / n, claim); save(self.root / "attempt-witnesses" / n, claim)
        self.counts, self.pending = nxt, claim; self.seen.add(job["job_sha256"])
        return claim

    def finish(self, job):
        c = self.pending; e.require(c is not None, "no pending reservation")
        d = self.root / "L0_raw" / job["job_sha256"]
        outcome = e.sealed({"claim_sha256": c["claim_sha256"], "raw_file_sha256": {x: sha(d / x) for x in RAW_FILES}}, "outcome_sha256")
        save(self.root / "outcomes" / f"{c['sequence']:06d}.json", outcome)
        self.previous, self.pending = c["claim_sha256"], None


class Session:
    def __init__(self, ctx, jobs, phase, guard, *, transport=None, resolver=None, sleep=time.sleep, clock=now):
        precheck(ctx["plan"]["root"], ctx["grant"], execute=True, fixture=ctx["fixture"])
        e.require(type(transport) is httpx.MockTransport if ctx["fixture"] else transport is None, "mock/live boundary")
        self.ctx, self.jobs, self.phase, self.guard = ctx, jobs, phase, guard
        self.sleep, self.clock, self.last_call = sleep, clock, 0.0
        self.ledger = Ledger(ctx)
        try:
            guard.require_ready()
            self.keys = dict.fromkeys(rt.old.KEY_NAMES, "offline-fixture-not-real") if ctx["fixture"] else rt.old.RunKeyMemory(resolver=resolver or rt.old.resolve_credentials)(ctx["plan"]["root"], interactive=False)
            self.client = httpx.Client(transport=transport or httpx.HTTPTransport(retries=0, trust_env=False),
                timeout=httpx.Timeout(600.0), trust_env=False, follow_redirects=False)
        except BaseException: self.ledger.lease.close(); raise

    def exchange(self, job):
        p, root = self.ctx["plan"], self.ctx["root"]
        self.guard.require_ready(); rt.old._validate_wire(job)
        phase = job["phase"]; index = self.ledger.counts[phase]
        counts = self.ledger.counts
        if phase == "metadata": e.require(counts["calibration"] == counts["collection"] == counts["main"] == 0, "metadata phase order")
        if phase != "metadata": e.require(counts["metadata"] == 6, "six metadata identities required")
        if phase in {"collection", "main"}:
            e.require(counts["calibration"] == 105, "calibration incomplete")
            review = scoring.read_json(root / "calibration-agent-review.json"); e.verify(review, "review_sha256")
            e.require(review["accepted_limited_technical_scope"] is True and review["definitions_and_adversarial_reviewed"] is True
                and review["calibration_result_file_sha256"] == sha(root / "calibration-result.json"), "new W01 calibration review absent/changed")
        if phase == "main": e.require(counts["collection"] == 2100, "source slots incomplete")
        e.require(job.get("campaign_id") == w.CAMPAIGN and phase in self.jobs and index < len(self.jobs[phase])
            and job == self.jobs[phase][index], "not the exact next approved job")
        e.require(not (root / "STOP").exists() and not (root / "TERMINAL_HOLD.json").exists(), "operator/terminal HOLD")
        start, end = stage_window(p, self.phase, root)
        e.require(start <= self.clock() and self.clock() + timedelta(seconds=600) <= end, "stage deadline; no window reset")
        if phase == "collection":
            planned = w.stamp(job["source"]["planned_start_utc"])
            delay = (planned - self.clock()).total_seconds()
            while delay > 0:
                self.sleep(min(delay, 30)); self.guard.require_ready()
                e.require(not (root / "STOP").exists(), "operator STOP while waiting")
                delay = (planned - self.clock()).total_seconds()
        self.sleep(max(0, 2 - (time.monotonic() - self.last_call))); self.guard.require_ready()
        e.require(self.clock() + timedelta(seconds=600) <= end and not (root / "STOP").exists(), "deadline/STOP after pacing")
        e.require(sha(p["root"] / w.LOCK) == self.ctx["grant"]["release_lock_file_sha256"], "release changed during run")
        e.require(sha(root / "authorization.json") == sha256_bytes(canonical_json_bytes(self.ctx["grant"]) + b"\n"), "authorization changed during run")
        if not self.ctx["fixture"]:
            for name, digest in p["lock"]["files"].items(): e.require(sha(p["root"] / name) == digest, "locked W01 input changed during run")
        if not self.ctx["fixture"]: rt.office.guard(p["native"]["config"])
        self.ledger.reserve(job)
        d = root / "L0_raw" / job["job_sha256"]
        save(d / "request.json", job)
        content = b"" if job["wire"]["body"] is None else canonical_json_bytes(job["wire"]["body"])
        write_immutable(d / "request.body", content)
        provider = job["provider"]; h = {"openai": "Authorization", "anthropic": "x-api-key", "gemini": "x-goog-api-key"}[provider]
        headers = {"Content-Type": "application/json", h: "Bearer " + self.keys[provider] if provider == "openai" else self.keys[provider]}
        if provider == "anthropic": headers["anthropic-version"] = "2023-06-01"
        status, payload, body, error, subtype, exception_type, safe_headers = 0, b"", None, None, None, None, {}
        began = time.monotonic()
        try:
            self.client.cookies.clear()
            response = self.client.request(job["wire"]["method"], job["wire"]["url"], headers=headers, content=content)
            self.client.cookies.clear(); status, payload = response.status_code, response.content
            safe_headers = {k: v for k, v in sanitized_headers(dict(response.headers)).items() if k.lower() not in {"set-cookie", "cookie", "authorization", "x-api-key", "x-goog-api-key"}}
            try: body = scoring.strict_json(payload.decode("utf-8")); e.require(type(body) is dict, "provider object required")
            except (ValueError, rt.ValidationError, UnicodeError): body, error = None, "INVALID_JSON_NO_REPAIR"
        except httpx.TransportError as exc:
            error, exception_type = "TRANSPORT_FAILURE_NO_RETRY", type(exc).__name__
            subtype = "READ_TIMEOUT" if isinstance(exc, httpx.ReadTimeout) else "TRANSPORT_OTHER"
        self.last_call = time.monotonic()
        result = {"http_status": status, "response_body": body, "received_at": self.clock().isoformat(),
            "response_body_sha256": sha256_bytes(payload), "headers": safe_headers, "error_code": error,
            "transport_error_class": subtype, "transport_exception_type": exception_type,
            "elapsed_monotonic_seconds": self.last_call - began, "synthetic_test_only": self.ctx["fixture"]}
        write_immutable(d / "response.body", payload, allow_sensitive_scientific_data=True); save(d / "response.json", result)
        self.ledger.finish(job)
        e.require(self.clock() <= end, "response after hard deadline retained; HOLD")
        if status == 0 and body is None and subtype == "READ_TIMEOUT" and phase != "metadata": return result
        e.require(status == 200 and isinstance(body, dict) and error is None, "nondelegated HTTP/format/transport HOLD")
        ident = body.get("name" if provider == "gemini" else "id") if phase == "metadata" else body.get("modelVersion" if provider == "gemini" else "model")
        e.require(isinstance(ident, str) and ident.removeprefix("models/") == job["requested_model"], "exact model identity HOLD")
        if phase != "metadata": e.require(rt.prep._expected_output_shape(provider, body), "CLOSED tool/response-shape HOLD")
        return result

    def close(self):
        self.client.close(); self.keys.clear(); self.ledger.lease.close()


def main_batch(ctx):
    p, root = ctx["plan"], ctx["root"]
    rows, families, missing = [], {}, []
    for job in w.source_jobs(p):
        response = rt.raw(root / "L0_raw" / job["job_sha256"], job, ctx["fixture"])
        if response["http_status"] == 0 and response["transport_error_class"] == "READ_TIMEOUT":
            missing.append(job["source"]["slot_id"]); continue
        record = w.normalize_source(job, response, fixture=ctx["fixture"])
        e.require(record == scoring.read_json(root / "collection-records" / (record["request_id"] + ".json")), "source record changed")
        row = scoring.make_blind_observation(record, salt=ctx["preparation"]["blinding_salt"])
        rows.append(row); families[row["observation_id_blind"]] = record["provider"]
    e.require(rows, "no rateable sources; no synthetic source refill")
    return w.build_batch(p, rows, families, synthetic=ctx["fixture"]), missing


def run_stage(root, grant, stage, *, execute=False, transport=None, power_factory=None, resolver=None, sleep=time.sleep, clock=now):
    fixture = transport is not None
    precheck(root, grant, execute=execute, fixture=fixture)
    e.require(power_factory is not None if fixture else power_factory is None, "fake power forbidden in production")
    ctx = context(root, grant, execute=execute, fixture=fixture); dest, p = ctx["root"], ctx["plan"]
    e.require(stage in {"preflight", "collection", "main"}, "unknown stage")
    e.require(not (dest / (stage.upper() + "_FINISHED.json")).exists() and not (dest / "TERMINAL_HOLD.json").exists(), "completed/terminal stage; never relaunch")
    start, end = stage_window(p, stage, dest)
    e.require(start <= clock() and clock() + timedelta(seconds=600) <= end, "not in approved stage window")
    if stage != "preflight":
        review = scoring.read_json(dest / "calibration-agent-review.json")
        e.verify(review, "review_sha256")
        e.require(review["accepted_limited_technical_scope"] is True and review["actor_type"] == "AGENT"
            and review["calibration_result_file_sha256"] == sha(dest / "calibration-result.json"), "new W01 calibration review required")
    if stage == "main": e.require((dest / "COLLECTION_FINISHED.json").exists(), "collection not finished")
    control = Lease(dest / "controller.lease"); session = None
    guard = power_factory() if fixture else ACPowerGuard()
    try:
        with guard:
            counts = Ledger(ctx)
            try: prior = counts.summary()
            finally: counts.lease.close()
            if stage != "preflight": e.require(prior["counts"]["metadata"] == 6 and prior["counts"]["calibration"] == 105, "preflight incomplete")
            if stage == "main": e.require(prior["counts"]["collection"] == 2100, "all source slots must be accounted for")
            rows = method.calibration_rows(p["root"], salt=ctx["preparation"]["blinding_salt"])
            cal = w.build_batch(p, rows, {}, phase="calibration", synthetic=fixture)
            if stage == "preflight":
                jobs = {"metadata": w.metadata_jobs(p), "calibration": w.judge_jobs(cal)}; batch = cal
            elif stage == "collection": jobs, batch = {"collection": w.source_jobs(p)}, None
            else:
                batch, missing = main_batch(ctx)
                jobs = {"main": w.judge_jobs(batch)}
                save(dest / "main-batch.json", batch)
                save(dest / "source-missing-reconciliation.json", {"planned_sources": 2100, "source_READ_TIMEOUT_slots": missing,
                    "unsent_main_slots_due_to_missing_sources": len(missing) * 2, "no_imputation_refill_or_resend": True})
            stop = dest / "STOP"
            if stop.exists():
                e.require(stop.read_bytes() == STOP_BYTES, "operator STOP is not a stage flag")
                write_immutable(dest / "gate-archives" / (uuid.uuid4().hex + ".stop"), stop.read_bytes()); stop.unlink()
            global_hold = Path(p["native"]["config"]["credentials"]["restart_hold_file"])
            if not fixture and global_hold.exists():
                e.require(global_hold.read_bytes() in {STOP_BYTES, historical_gate.HOLD_BYTES}, "unknown global HOLD cannot be released")
                write_immutable(dest / "gate-archives" / (uuid.uuid4().hex + ".hold"), global_hold.read_bytes()); global_hold.unlink()
            session = Session(ctx, jobs, stage, guard, transport=transport, resolver=resolver, sleep=sleep, clock=clock)
            for phase, queue in jobs.items():
                for job in queue[session.ledger.counts[phase]:]:
                    response = session.exchange(job)
                    if phase == "collection" and response["http_status"] == 200:
                        record = w.normalize_source(job, response, fixture=fixture); rt.old._screen(record["response_text"])
                        save(dest / "collection-records" / (record["request_id"] + ".json"), record)
            if batch is not None:
                envelopes = []
                for q, job in zip(batch["requests"], w.judge_jobs(batch)):
                    raw = rt.raw(dest / "L0_raw" / job["job_sha256"], job, fixture)
                    envelopes.append({"request_id": q["request_id"], **{k: raw[k] for k in ("http_status", "received_at", "response_body")}})
                views = [w.import_view(p, batch, env) for env in envelopes]
                result = {"batch_sha256": batch["batch_sha256"], "ratings": views, "aggregation": w.aggregate(p, batch, views), "synthetic_test_only": fixture}
                save(dest / ("calibration-result.json" if stage == "preflight" else "main-result.json"), result)
            summary = {"campaign_id": w.CAMPAIGN, "stage": stage, "finished_at": clock().isoformat(),
                "status": "CALIBRATION_AGENT_REVIEW_REQUIRED" if stage == "preflight" else "RESULT_REVIEW_REQUIRED" if stage == "main" else "COLLECTION_SLOTS_ACCOUNTED",
                **session.ledger.audit(), "synthetic_test_only": fixture, "human_validity_or_comparability_established": False}
            save(dest / (stage.upper() + "_FINISHED.json"), summary)
            return summary
    except BaseException as exc:
        if not (dest / "TERMINAL_HOLD.json").exists(): save(dest / "TERMINAL_HOLD.json", {"exception_class": type(exc).__name__, "no_automatic_restart_or_replay": True})
        raise
    finally:
        if session: session.close()
        if not (dest / "STOP").exists(): write_immutable(dest / "STOP", STOP_BYTES)
        if not fixture:
            global_hold = Path(p["native"]["config"]["credentials"]["restart_hold_file"])
            if not global_hold.exists(): write_immutable(global_hold, STOP_BYTES)
        control.close()
        if guard.closed: save(dest / "power-sessions" / (uuid.uuid4().hex + ".json"), guard.snapshot())


def record_calibration_review(root, grant, *, accepted, note, definitions_reviewed=False, fixture=False):
    ctx = context(root, grant, execute=True, fixture=fixture); dest = ctx["root"]
    e.require(type(accepted) is bool and isinstance(note, str) and note.strip(), "explicit delegated review decision required")
    result = scoring.read_json(dest / "calibration-result.json")
    rows = method.calibration_rows(ctx["plan"]["root"], salt=ctx["preparation"]["blinding_salt"])
    batch = w.build_batch(ctx["plan"], rows, {}, phase="calibration", synthetic=fixture)
    views = []
    for q, job in zip(batch["requests"], w.judge_jobs(batch)):
        raw = rt.raw(dest / "L0_raw" / job["job_sha256"], job, fixture)
        views.append(w.import_view(ctx["plan"], batch, {"request_id": q["request_id"], **{k: raw[k] for k in ("http_status", "received_at", "response_body")}}))
    expected = {"batch_sha256": batch["batch_sha256"], "ratings": views, "aggregation": w.aggregate(ctx["plan"], batch, views), "synthetic_test_only": fixture}
    e.require(result == expected, "calibration result differs from saved raw")
    reports = result["aggregation"]["reports"]
    e.require(not accepted or (definitions_reviewed is True and all(reports[k]["technical_calibration_guards_passed"] for k in ("primary", "full_record"))), "both frozen calibration guards AND explicit definition/adversarial review required")
    review = e.sealed({"actor_type": "AGENT", "accepted_limited_technical_scope": accepted, "note": note,
        "calibration_result_file_sha256": sha(dest / "calibration-result.json"), "definitions_and_adversarial_reviewed": definitions_reviewed,
        "no_human_gold_or_comparability_claim": True}, "review_sha256")
    save(dest / "calibration-agent-review.json", review); return review


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--root", type=Path, required=True)
    ap.add_argument("--authorization", type=Path, required=True); ap.add_argument("--stage", choices=("preflight", "collection", "main"), required=True)
    ap.add_argument("--execute-approved", action="store_true"); args = ap.parse_args()
    print(json.dumps(run_stage(args.root, scoring.read_json(args.authorization), args.stage, execute=args.execute_approved)))


if __name__ == "__main__": main()

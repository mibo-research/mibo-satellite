"""Raw-bound delegated calibration review and no-resend continuation of W0."""

from __future__ import annotations

import copy
import time
from collections import Counter
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

import httpx

from . import live_w0_v11 as w
from . import reciprocal as r
from . import reciprocal_engine as e
from . import scoring
from . import three_series as prep
from .util import canonical_json_bytes, sha256_bytes, utc_now
from .util import write_immutable as save


def audit_completed_calibration(root: Path, context: dict[str, Any]) -> dict[str, Any]:
    """Recompute judgments/metrics from exact archived response bytes, never trust a pass flag."""
    directory, plan = context["destination"], context["plan"]
    w.require(
        scoring.read_json(directory / "authorization.json") == context["authorization"],
        "stored authorization changed",
    )
    w.require(
        scoring.read_json(directory / "execution-plan.json") == plan["config"],
        "stored plan changed",
    )
    stage = scoring.read_json(directory / "CALIBRATION_STAGE_FINISHED.json")
    counts = {
        **dict.fromkeys(w.COUNTS, 0),
        "metadata": 6,
        "smoke": 3,
        "qualification": 21,
        "calibration": 105,
    }
    w.require(
        stage["counts"] == counts and stage["synthetic_test_only"] is context["simulation"],
        "incomplete calibration stage",
    )
    common = scoring.read_json(directory / "calibration-batch.json")
    r.validate_batch(root, common)
    salt = (directory / "private-blinding-salt.txt").read_text("utf-8")
    expected_batch = r.build_batch(
        root, r.calibration_rows(root, salt=salt), {}, phase="calibration"
    )
    w.require(common == expected_batch, "calibration cases/blinding changed")
    expected = {
        phase: w.fixed_jobs(plan, phase) for phase in ("metadata", "smoke", "qualification")
    }
    expected["calibration"] = [
        w._job(
            "calibration",
            q["provider"],
            q["requested_model"],
            {"method": "POST", "url": q["endpoint"], "body": q["body"]},
            method_request_id=q["request_id"],
        )
        for q in common["requests"]
    ]
    envelopes = []
    for phase, jobs in expected.items():
        phase_dir = directory / "L0_raw" / phase
        w.require(
            {p.name for p in phase_dir.iterdir()} == {job["job_sha256"] for job in jobs},
            "missing/extra/duplicate attempt",
        )
        for job in jobs:
            path = phase_dir / job["job_sha256"]
            w.require(scoring.read_json(path / "request.json") == job, "request metadata changed")
            w.require(
                (path / "request.body").read_bytes()
                == (
                    b""
                    if job["wire"]["body"] is None
                    else canonical_json_bytes(job["wire"]["body"])
                ),
                "request body changed",
            )
            raw = (path / "response.body").read_bytes()
            response = scoring.read_json(path / "response.json")
            w.require(
                response["response_body_sha256"] == sha256_bytes(raw)
                and response["response_body"] == scoring.strict_json(raw.decode("utf-8"))
                and response["http_status"] == 200
                and response["synthetic_test_only"] is context["simulation"],
                "raw response binding changed",
            )
            if phase == "metadata":
                body = response["response_body"]
                identity = body.get("name" if job["provider"] == "gemini" else "id")
                w.require(
                    isinstance(identity, str)
                    and identity.removeprefix("models/") == job["requested_model"],
                    "metadata identity changed",
                )
            elif phase in {"smoke", "qualification"}:
                reconstructed = w._source_result(job, response, context["simulation"])
                w.require(
                    scoring.read_json(
                        directory / (phase + "-records") / (reconstructed["request_id"] + ".json")
                    )
                    == reconstructed,
                    "source normalization differs from raw bytes",
                )
            else:
                identity = response["response_body"].get(
                    "modelVersion" if job["provider"] == "gemini" else "model"
                )
                w.require(
                    identity == job["requested_model"]
                    and prep._expected_output_shape(job["provider"], response["response_body"]),
                    "judge identity/tool anomaly in raw evidence",
                )
                envelopes.append(
                    {
                        "request_id": job["method_request_id"],
                        **{k: response[k] for k in ("http_status", "received_at", "response_body")},
                    }
                )
    ratings = r.import_many(root, common, envelopes)
    aggregate = r.aggregate(root, common, ratings)
    expected_result = e.sealed(
        {
            "batch_sha256": common["batch_sha256"],
            "ratings": ratings,
            "aggregation": aggregate,
            "synthetic_test_only": context["simulation"],
        },
        "result_sha256",
    )
    actual = scoring.read_json(directory / "calibration-result.json")
    w.require(actual == expected_result, "calibration results differ from original response bytes")
    w.require(
        aggregate["quality_report"]["technical_calibration_guards_passed"] is True,
        "calibration failed or agreement undefined",
    )
    accounting = w.ledger.audited_summary(context)
    w.require(
        accounting["new_counts"] == counts and accounting["cumulative_requests"] == 138,
        "calibration stage cumulative accounting mismatch",
    )
    w.require(stage["cumulative_accounting"] == accounting, "stage/ledger mismatch")
    return {"result": actual, "counts": counts, "cumulative_accounting": accounting}


def record_agent_review(
    root: Path,
    authorization: dict[str, Any],
    *,
    reviewer: str,
    review_note: str,
    simulation: bool = False,
) -> dict[str, Any]:
    """Invoked only after the agent inspects results, under the owner's bounded delegation."""
    context = w.authorize(
        root, authorization, execute_approved=True, simulation=simulation, continuation=True
    )
    w.require(
        isinstance(reviewer, str)
        and bool(reviewer.strip())
        and isinstance(review_note, str)
        and bool(review_note.strip()),
        "named agent review required",
    )
    audited = audit_completed_calibration(root, context)
    review = e.sealed(
        {
            "status": "TECHNICAL_CALIBRATION_REVIEWED",
            "reviewer_type": "AGENT",
            "reviewer": reviewer,
            "review_note": review_note,
            "reviewed_at": utc_now(),
            "plan_sha256": context["plan"]["plan_sha256"],
            "authorization_sha256": context["authorization_sha256"],
            "calibration_result_sha256": audited["result"]["result_sha256"],
            "engineering_guards_and_raw_bindings_reviewed": True,
            "owner_case_content_approval_retained": True,
            "human_gold_or_validity_or_cross_source_comparability_established": False,
            "pilot_passed": False,
            "synthetic_test_only": simulation,
        },
        "review_sha256",
    )
    save(
        context["destination"] / "calibration-agent-review.json",
        canonical_json_bytes(review) + b"\n",
    )
    save(
        context["destination"] / "calibration-agent-review.ready", review["review_sha256"].encode()
    )
    return review


def wait_for_agent_review(
    root: Path, authorization: dict[str, Any], *, simulation: bool = False, sleep: Any = time.sleep
) -> None:
    context = w.authorize(
        root, authorization, execute_approved=True, simulation=simulation, continuation=True
    )
    destination = context["destination"]
    while not (destination / "calibration-agent-review.ready").exists():
        w.require(not (destination / "STOP").exists(), "operator STOP during calibration review")
        if not simulation:
            w.office.guard(context["plan"]["config"])
        w.require(
            datetime.now(UTC) <= context["started_at"] + timedelta(hours=72),
            "review window expired",
        )
        sleep(2)


def continue_after_calibration(
    root: Path,
    authorization: dict[str, Any],
    *,
    execute_approved: bool = False,
    simulation_transport: httpx.MockTransport | None = None,
    credential_resolver: Any = None,
    interactive_keys: bool = False,
    sleep: Any = time.sleep,
) -> dict[str, Any]:
    context = w.authorize(
        root,
        authorization,
        execute_approved=execute_approved,
        simulation=simulation_transport is not None,
        continuation=True,
    )
    destination, plan = context["destination"], context["plan"]
    w.require(
        not (destination / "CONTINUATION_STARTED.json").exists(),
        "prior continuation/attempt; do not resend",
    )
    w.require(
        not any((destination / "L0_raw" / phase).exists() for phase in ("collection", "main")),
        "prior collection/main attempts found; do not resend",
    )
    audited = audit_completed_calibration(root, context)
    review = scoring.read_json(destination / "calibration-agent-review.json")
    e.verify(review, "review_sha256")
    w.require(
        (destination / "calibration-agent-review.ready").read_text("utf-8")
        == review["review_sha256"],
        "review completion marker mismatch",
    )
    w.require(
        review["status"] == "TECHNICAL_CALIBRATION_REVIEWED"
        and review["reviewer_type"] == "AGENT"
        and review["plan_sha256"] == plan["plan_sha256"]
        and review["authorization_sha256"] == context["authorization_sha256"]
        and review["calibration_result_sha256"] == audited["result"]["result_sha256"]
        and review["engineering_guards_and_raw_bindings_reviewed"] is True
        and review["synthetic_test_only"] is context["simulation"],
        "review binding mismatch",
    )
    keys = (
        {p: "fixture-credential-not-real" for p in w.KEY_NAMES}
        if context["simulation"]
        else (credential_resolver or w.resolve_credentials)(root, interactive=interactive_keys)
    )
    w.validate_keys(keys)
    save(
        destination / "CONTINUATION_STARTED.json",
        canonical_json_bytes(
            {
                "started_at": utc_now(),
                "review_sha256": review["review_sha256"],
                "authorization_sha256": context["authorization_sha256"],
            }
        )
        + b"\n",
    )
    session = w.Session(
        context, keys, transport=simulation_transport, sleep=sleep, prior_counts=audited["counts"]
    )
    try:
        records = []
        for job in w.fixed_jobs(plan, "collection"):
            record = w._source_result(job, session.exchange(job), context["simulation"])
            save(
                destination / "collection-records" / (record["request_id"] + ".json"),
                canonical_json_bytes(record) + b"\n",
                allow_sensitive_scientific_data=True,
            )
            records.append(record)
        w.require(
            len(records) == 150
            and Counter(rec["source_series"] for rec in records)
            == dict.fromkeys(prep.FAMILIES, 50),
            "fresh pilot incomplete; no refill",
        )
        salt = (destination / "private-blinding-salt.txt").read_text("utf-8")
        rows, sources = [], {}
        for record in records:
            w._screen(record["response_text"])
            row = scoring.make_blind_observation(record, salt=salt)
            rows.append(row)
            sources[row["observation_id_blind"]] = record["provider"]
        batch = r.build_batch(root, rows, sources)
        save(
            destination / "main-batch.json",
            canonical_json_bytes(batch) + b"\n",
            allow_sensitive_scientific_data=True,
        )
        result = w._judge_phase(root, session, batch)
        summary = e.sealed(
            {
                "status": "W0_RESULT_REVIEW_REQUIRED_NOT_AUTOMATIC_PASS",
                "plan_sha256": plan["plan_sha256"],
                "counts": copy.deepcopy(session.counts),
                "cumulative_accounting": session.ledger.audit(),
                "fresh_answers": 150,
                "main_ratings": 300,
                "common_calibration_ratings": 105,
                "calibration_agent_review_sha256": review["review_sha256"],
                "main_numeric_guards_passed": result["aggregation"]["quality_report"][
                    "numeric_quality_checks_passed"
                ],
                "real_API_calls": 0 if context["simulation"] else sum(session.counts.values()),
                "synthetic_test_only": context["simulation"],
                "pilot_passed": False,
                "human_validity_or_comparability_established": False,
                "W01_authorized": False,
                "publication_authorized": False,
                "automatic_retries_repairs_refill_or_third_judge": 0,
            },
            "summary_sha256",
        )
        save(destination / "RUN_FINISHED.json", canonical_json_bytes(summary) + b"\n")
        return summary
    finally:
        session.close()

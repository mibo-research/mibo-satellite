"""Lossless source references for the prospective method; no scores, APIs or repair."""
from __future__ import annotations
import hashlib
from . import reciprocal_engine as e

VERSION = "MIBOE-SOURCE-REFERENCES-v1.0"


def build_catalog(text: str, *, max_characters: int) -> dict:
    e.require(type(text) is str, "source text must be a string")
    e.require(type(max_characters) is int and max_characters > 0, "invalid frozen excerpt limit")
    spans, start = [], 0
    for line_number, line in enumerate(text.splitlines(keepends=True), 1):
        for part_number, offset in enumerate(range(0, len(line), max_characters), 1):
            part = line[offset:offset + max_characters]
            end = start + len(part)
            spans.append({"id": f"S{len(spans)+1:06d}", "line": line_number, "part": part_number,
                          "start": start, "end": end, "text": part})
            start = end
    e.require(start == len(text) and "".join(s["text"] for s in spans) == text, "lossless catalog construction failed")
    return e.sealed({"version": VERSION, "max_excerpt_characters": max_characters,
        "indexing": "UNICODE_CODE_POINTS_END_EXCLUSIVE", "source_utf8_sha256": hashlib.sha256(text.encode("utf-8")).hexdigest(),
        "segments": spans}, "catalog_sha256")


def resolve(text: str, catalog: dict, ids: list[str], *, max_characters: int) -> dict:
    expected = build_catalog(text, max_characters=max_characters)
    # Canonical JSON avoids Python's bool/int/float equality coercion.
    e.require(type(catalog) is dict and e.digest(catalog) == e.digest(expected), "catalog/source binding mismatch")
    e.require(type(ids) is list and all(type(v) is str for v in ids), "exact string IDs required")
    by = {s["id"]: s for s in catalog["segments"]}
    e.require(all(v in by for v in ids), "unknown evidence ID; no inference or repair")
    excerpts = [text[by[v]["start"]:by[v]["end"]] for v in ids]
    e.require(all(0 < len(q) <= max_characters and q in text for q in excerpts), "source excerpt bounds failed")
    return {"provenance": "DETERMINISTIC_SOURCE_REFERENCE_RESOLUTION_NOT_MODEL_QUOTATION",
        "catalog_sha256": catalog["catalog_sha256"], "source_utf8_sha256": catalog["source_utf8_sha256"],
        "selected_ids": list(ids), "excerpts": excerpts,
        "semantic_support_or_score_correctness_established": False}

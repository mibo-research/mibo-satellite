"""New-campaign append-only accounting. No old counter reset and no automatic replay."""
from __future__ import annotations
import copy
from pathlib import Path
from . import reciprocal_engine as e, scoring
from .w0_ledger_v16 import Lease, private_path, outcome_class, RAW_FILES
from .util import canonical_json_bytes, sha256_file, utc_now, write_immutable

CAPS = {"metadata":6,"calibration":105,"collection":150,"main":300}
PRIOR = 905
NEW_MAX = 561
CUMULATIVE_MAX = 1466


def save(path, value):
    write_immutable(path, canonical_json_bytes(value)+b"\n")


def verify_baseline(ctx):
    a, root = ctx["authorization"], ctx["plan"]["root"]
    directory = private_path(root,Path(a["accounting_root"]))
    path = directory/"BASELINE.json"
    e.require(sha256_file(path) == a["baseline_file_sha256"],"baseline file changed")
    b = scoring.read_json(path)
    e.verify(b,"baseline_sha256")
    e.require(b["prior_requests"] == PRIOR and e.digest(b["caps"]) == e.digest(CAPS)
        and b["new_maximum"] == NEW_MAX and b["cumulative_maximum"] == CUMULATIVE_MAX,"fixed baseline/caps changed")
    e.require(Path(b["execution_root"]).resolve() == ctx["destination"]
        and Path(b["accounting_root"]).resolve() == directory
        and b["fixture_only"] is ctx["simulation"],"baseline destination/fixture mismatch")
    for bundle in b["preserved_evidence"]:
        folder = private_path(root,Path(bundle["root"]))
        for name,digest in bundle["files"].items():
            rel = Path(name)
            e.require(not rel.is_absolute() and ".." not in rel.parts,"invalid preserved evidence reference")
            e.require(sha256_file(private_path(root,folder/rel)) == digest,"old evidence changed")
    return b


class Ledger:
    def __init__(self,ctx,*,initial=False):
        self.ctx, self.destination = ctx,ctx["destination"]
        self.root = private_path(ctx["plan"]["root"],Path(ctx["authorization"]["accounting_root"]))
        self.base = verify_baseline(ctx)
        self.lease = Lease(self.root/"worker.lease")
        try:
            binding = {"campaign_id":ctx["plan"]["config"]["campaign_id"],"plan_sha256":ctx["plan"]["plan_sha256"],
                "authorization_sha256":ctx["authorization_sha256"],"baseline_file_sha256":ctx["authorization"]["baseline_file_sha256"],
                "execution_root":str(self.destination),"fixture_only":ctx["simulation"]}
            if initial:
                e.require(not (self.root/"RUN_BINDING.json").exists(),"already allocated; no rerun/counter reset")
                e.require(not any((self.root/"claims").iterdir()) and not any((self.root/"outcomes").iterdir()),"old attempts present")
                save(self.root/"RUN_BINDING.json",binding)
            e.require(scoring.read_json(self.root/"RUN_BINDING.json") == binding,"ledger/run binding changed")
            self.binding_sha = sha256_file(self.root/"RUN_BINDING.json")
            self.audit()
        except BaseException:
            self.close()
            raise

    def names(self,folder):
        values = sorted(folder.iterdir())
        e.require(all(p.is_file() and not p.is_symlink() and p.suffix==".json" for p in values),"unexpected ledger artifact")
        return [p.name for p in values]

    def audit(self):
        names = self.names(self.root/"claims")
        e.require(names == [f"{i:06d}.json" for i in range(1,len(names)+1)]
            and self.names(self.root/"outcomes") == names
            and self.names(self.destination/"attempt-witnesses") == names,
            "incomplete/deleted/extra reservation; HOLD, never resend")
        counts, seen, paths = dict.fromkeys(CAPS,0), set(),set()
        previous = self.base["baseline_sha256"]
        for index,name in enumerate(names,1):
            claim = scoring.read_json(self.root/"claims"/name)
            e.verify(claim,"claim_sha256")
            e.require((self.root/"claims"/name).read_bytes() == (self.destination/"attempt-witnesses"/name).read_bytes(),"claim witness differs")
            e.require(claim["sequence"] == index and claim["previous_claim_sha256"] == previous
                and claim["baseline_file_sha256"] == self.ctx["authorization"]["baseline_file_sha256"]
                and claim["run_binding_sha256"] == self.binding_sha,"reservation chain/binding differs")
            phase,jid = claim["phase"],claim["job_sha256"]
            e.require(phase in CAPS and jid not in seen,"invalid or duplicate job")
            rel = f"L0_raw/{phase}/{jid}"
            e.require(claim["raw_relative_path"] == rel,"raw path mismatch")
            raw = private_path(self.ctx["plan"]["root"],self.destination/rel)
            e.require({p.name for p in raw.iterdir()} == RAW_FILES,"incomplete raw outcome; HOLD")
            job = scoring.read_json(raw/"request.json")
            e.verify(job,"job_sha256")
            e.require(job["job_sha256"] == jid and job["phase"] == phase and e.digest(job["wire"]) == claim["wire_sha256"],"job binding mismatch")
            expected = b"" if job["wire"]["body"] is None else canonical_json_bytes(job["wire"]["body"])
            e.require((raw/"request.body").read_bytes() == expected,"request bytes differ")
            response = scoring.read_json(raw/"response.json")
            outcome = scoring.read_json(self.root/"outcomes"/name)
            e.verify(outcome,"outcome_sha256")
            e.require(outcome["claim_sha256"] == claim["claim_sha256"]
                and outcome["raw_file_sha256"] == {n:sha256_file(raw/n) for n in RAW_FILES}
                and response["response_body_sha256"] == sha256_file(raw/"response.body")
                and response["synthetic_test_only"] is self.ctx["simulation"]
                and outcome["http_status"] == response["http_status"]
                and outcome["outcome_class"] == outcome_class(response),"response/outcome differs")
            counts[phase] += 1
            seen.add(jid); paths.add(rel); previous = claim["claim_sha256"]
        e.require({p.relative_to(self.destination).as_posix() for p in (self.destination/"L0_raw").glob("*/*")} == paths,"unaccounted raw attempt")
        self.check_caps(counts)
        self.counts,self.seen,self.previous,self.completed_names,self.pending = counts,seen,previous,names,None
        return self.summary()

    @staticmethod
    def check_caps(counts):
        e.require(set(counts)==set(CAPS) and all(type(v) is int and 0<=v<=CAPS[k] for k,v in counts.items()),"phase cap exceeded")
        e.require(sum(counts.values())<=NEW_MAX and PRIOR+sum(counts.values())<=CUMULATIVE_MAX,"new/cumulative cap exceeded")

    def summary(self):
        return {"prior_preserved_reservations":PRIOR,"new_counts":copy.deepcopy(self.counts),
            "new_reservations":sum(self.counts.values()),"cumulative_reservations":PRIOR+sum(self.counts.values()),
            "maximum_new":NEW_MAX,"maximum_cumulative":CUMULATIVE_MAX,"last_claim_sha256":self.previous}

    def reserve(self,job):
        e.require(self.pending is None,"pending request consumes allowance; no retry")
        e.require(self.names(self.root/"claims") == self.completed_names
            and self.names(self.root/"outcomes") == self.completed_names
            and self.names(self.destination/"attempt-witnesses") == self.completed_names,"ledger inventory changed")
        e.require(sha256_file(self.root/"RUN_BINDING.json") == self.binding_sha,"ledger binding changed")
        e.verify(job,"job_sha256")
        e.require(job["job_sha256"] not in self.seen and job["phase"] in CAPS,"duplicate or forbidden job")
        counts = copy.deepcopy(self.counts)
        counts[job["phase"]] += 1
        self.check_caps(counts)
        seq = sum(counts.values())
        claim = e.sealed({"sequence":seq,"reserved_at":utc_now(),"previous_claim_sha256":self.previous,
            "baseline_file_sha256":self.ctx["authorization"]["baseline_file_sha256"],"run_binding_sha256":self.binding_sha,
            "phase":job["phase"],"job_sha256":job["job_sha256"],"wire_sha256":e.digest(job["wire"]),
            "raw_relative_path":f"L0_raw/{job['phase']}/{job['job_sha256']}"},"claim_sha256")
        name = f"{seq:06d}.json"
        save(self.root/"claims"/name,claim)
        save(self.destination/"attempt-witnesses"/name,claim)
        self.pending,self.counts,self.previous = claim,counts,claim["claim_sha256"]
        self.seen.add(job["job_sha256"])
        return claim

    def finish(self,claim):
        e.require(claim == self.pending,"outcome without matching reservation")
        raw = self.destination/claim["raw_relative_path"]
        e.require({p.name for p in raw.iterdir()} == RAW_FILES,"incomplete raw response")
        response = scoring.read_json(raw/"response.json")
        outcome = e.sealed({"claim_sha256":claim["claim_sha256"],"http_status":response["http_status"],
            "outcome_class":outcome_class(response),"raw_file_sha256":{n:sha256_file(raw/n) for n in RAW_FILES}},"outcome_sha256")
        name = f"{claim['sequence']:06d}.json"
        save(self.root/"outcomes"/name,outcome)
        self.completed_names.append(name)
        self.pending = None

    def close(self):
        self.lease.close()

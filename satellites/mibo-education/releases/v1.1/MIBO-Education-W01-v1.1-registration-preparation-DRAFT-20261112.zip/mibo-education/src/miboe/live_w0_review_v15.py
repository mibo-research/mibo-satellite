"""Raw-bound delegated calibration review and no-resend continuation of W0."""

from __future__ import annotations

import copy
import time
from collections import Counter
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

import httpx

from . import live_w0_v15 as w
from . import reciprocal as r
from . import reciprocal_engine as e
from . import scoring
from . import three_series as prep
from .util import canonical_json_bytes, utc_now
from .util import write_immutable as save


def audit_completed_calibration(root: Path, context: dict[str, Any]) -> dict[str, Any]:
    """Recompute 83 new + 22 unchanged legacy slots, including10 full-record invalid."""
    directory = context["destination"]
    w.require(
        scoring.read_json(directory / "authorization.json") == context["authorization"]
        and scoring.read_json(directory / "execution-plan.json") == context["plan"]["config"],
        "stored continuation authority or plan changed",
    )
    stage = scoring.read_json(directory / "CALIBRATION_STAGE_FINISHED.json")
    counts = {"calibration": 83, "collection": 0, "main": 0}
    w.require(
        stage["counts"] == counts and stage["synthetic_test_only"] is context["simulation"],
        "incomplete continuation calibration",
    )
    batch = context["parent"]["batch"]
    w.require(
        scoring.read_json(directory / "calibration-batch.json") == batch,
        "continued calibration differs from original locked batch",
    )
    w.require(
        scoring.read_json(directory / "retained-calibration-history.json")
        == context["parent"]["retained_provenance"],
        "technical missing provenance changed",
    )
    jobs = w.expected_jobs(context, batch)
    w.require(
        len(jobs) == 83
        and {p.name for p in (directory / "L0_raw/calibration").iterdir()}
        == {j["job_sha256"] for j in jobs},
        "missing/extra/retried calibration request",
    )
    expected = w.judge_result(root, context, batch)
    actual = scoring.read_json(directory / "calibration-result.json")
    w.require(actual == expected, "continued calibration differs from exact raw bindings")
    retained = [
        v["legacy_full_rating"] for v in actual["ratings"]
        if v["request_id"] in context["parent"]["retained_logical_request_ids"]
    ]
    w.require(
        retained == context["parent"]["retained_ratings"]
        and len(actual["ratings"]) == 105
        and len(retained) == 22 and sum(v["valid"] for v in retained) == 12,
        "retained HTTP failures or model responses dropped, repaired, imputed or converted into NR",
    )
    w.require(
        actual["aggregation"]["primary_quality_report"]["primary_calibration_guards_passed"] is True,
        "primary-component calibration guards failed/undefined",
    )
    accounting = w.ledger.audited_summary(context)
    w.require(
        accounting["new_counts"] == counts
        and accounting["cumulative_requests"] == 138
        and stage["cumulative_accounting"] == accounting,
        "calibration/cumulative ledger mismatch",
    )
    return {"result": actual, "counts": counts, "cumulative_accounting": accounting}


def record_agent_review(
    root: Path,
    authorization: dict[str, Any],
    *,
    reviewer: str,
    review_note: str,
    simulation: bool = False,
) -> dict[str, Any]:
    """Invoked only after the agent inspects results, under the owner's bounded delegation."""
    context = w.authorize(
        root, authorization, execute_approved=True, simulation=simulation, continuation=True
    )
    w.require(
        isinstance(reviewer, str)
        and bool(reviewer.strip())
        and isinstance(review_note, str)
        and bool(review_note.strip()),
        "named agent review required",
    )
    audited = audit_completed_calibration(root, context)
    review = e.sealed(
        {
            "status": "TECHNICAL_CALIBRATION_REVIEWED",
            "reviewer_type": "AGENT",
            "reviewer": reviewer,
            "review_note": review_note,
            "reviewed_at": utc_now(),
            "plan_sha256": context["plan"]["plan_sha256"],
            "authorization_sha256": context["authorization_sha256"],
            "calibration_result_sha256": audited["result"]["result_sha256"],
            "engineering_guards_and_raw_bindings_reviewed": True,
            "owner_case_content_approval_retained": True,
            "retained_technical_missing_count": 3,
            "retained_invalid_model_response_count": 7,
            "analysis_policy": w.validity.VERSION,
            "legacy_v1_4_failure_preserved": True,
            "human_gold_or_validity_or_cross_source_comparability_established": False,
            "pilot_passed": False,
            "synthetic_test_only": simulation,
        },
        "review_sha256",
    )
    save(
        context["destination"] / "calibration-agent-review.json",
        canonical_json_bytes(review) + b"\n",
    )
    save(
        context["destination"] / "calibration-agent-review.ready", review["review_sha256"].encode()
    )
    return review


def wait_for_agent_review(
    root: Path, authorization: dict[str, Any], *, simulation: bool = False, sleep: Any = time.sleep
) -> None:
    context = w.authorize(
        root, authorization, execute_approved=True, simulation=simulation, continuation=True
    )
    destination = context["destination"]
    while not (destination / "calibration-agent-review.ready").exists():
        w.require(not (destination / "STOP").exists(), "operator STOP during calibration review")
        if not simulation:
            w.office.guard(context["plan"]["config"])
        w.require(
            datetime.now(UTC) <= context["started_at"] + timedelta(hours=72),
            "review window expired",
        )
        sleep(2)


def continue_after_calibration(
    root: Path,
    authorization: dict[str, Any],
    *,
    execute_approved: bool = False,
    simulation_transport: httpx.MockTransport | None = None,
    credential_resolver: Any = None,
    interactive_keys: bool = False,
    sleep: Any = time.sleep,
) -> dict[str, Any]:
    context = w.authorize(
        root,
        authorization,
        execute_approved=execute_approved,
        simulation=simulation_transport is not None,
        continuation=True,
    )
    destination, plan = context["destination"], context["plan"]
    w.require(
        not (destination / "CONTINUATION_STARTED.json").exists(),
        "prior continuation/attempt; do not resend",
    )
    w.require(
        not any((destination / "L0_raw" / phase).exists() for phase in ("collection", "main")),
        "prior collection/main attempts found; do not resend",
    )
    audited = audit_completed_calibration(root, context)
    review = scoring.read_json(destination / "calibration-agent-review.json")
    e.verify(review, "review_sha256")
    w.require(
        (destination / "calibration-agent-review.ready").read_text("utf-8")
        == review["review_sha256"],
        "review completion marker mismatch",
    )
    w.require(
        review["status"] == "TECHNICAL_CALIBRATION_REVIEWED"
        and review["reviewer_type"] == "AGENT"
        and review["plan_sha256"] == plan["plan_sha256"]
        and review["authorization_sha256"] == context["authorization_sha256"]
        and review["calibration_result_sha256"] == audited["result"]["result_sha256"]
        and review["engineering_guards_and_raw_bindings_reviewed"] is True
        and review["synthetic_test_only"] is context["simulation"],
        "review binding mismatch",
    )
    w.require_review_clearance(context)
    keys = (
        {p: "fixture-credential-not-real" for p in w.KEY_NAMES}
        if context["simulation"]
        else (credential_resolver or w.resolve_credentials)(root, interactive=interactive_keys)
    )
    w.validate_keys(keys)
    save(
        destination / "CONTINUATION_STARTED.json",
        canonical_json_bytes(
            {
                "started_at": utc_now(),
                "review_sha256": review["review_sha256"],
                "authorization_sha256": context["authorization_sha256"],
            }
        )
        + b"\n",
    )
    session = w.Session(
        context, keys, transport=simulation_transport, sleep=sleep, prior_counts=audited["counts"]
    )
    try:
        records = []
        for job in w.fixed_jobs(plan, "collection"):
            record = w._source_result(job, session.exchange(job), context["simulation"])
            save(
                destination / "collection-records" / (record["request_id"] + ".json"),
                canonical_json_bytes(record) + b"\n",
                allow_sensitive_scientific_data=True,
            )
            records.append(record)
        w.require(
            len(records) == 150
            and Counter(rec["source_series"] for rec in records)
            == dict.fromkeys(prep.FAMILIES, 50),
            "fresh pilot incomplete; no refill",
        )
        salt = context["parent"]["salt"]
        rows, sources = [], {}
        for record in records:
            w._screen(record["response_text"])
            row = scoring.make_blind_observation(record, salt=salt)
            rows.append(row)
            sources[row["observation_id_blind"]] = record["provider"]
        batch = r.build_batch(root, rows, sources)
        save(
            destination / "main-batch.json",
            canonical_json_bytes(batch) + b"\n",
            allow_sensitive_scientific_data=True,
        )
        result = w._judge_phase(root, session, batch)
        summary = e.sealed(
            {
                "status": "W0_RESULT_REVIEW_REQUIRED_NOT_AUTOMATIC_PASS",
                "plan_sha256": plan["plan_sha256"],
                "counts": copy.deepcopy(session.counts),
                "cumulative_accounting": session.ledger.audit(),
                "fresh_answers": 150,
                "main_ratings": 300,
                "common_calibration_attempted_slots": 105,
                "new_calibration_requests": 83,
                "retained_technical_missing": 3,
                "retained_invalid_model_responses": 7,
                "calibration_agent_review_sha256": review["review_sha256"],
                "primary_main_numeric_guards_passed": result["aggregation"]["primary_quality_report"][
                    "primary_numeric_quality_checks_passed"
                ],
                "real_API_calls": 0 if context["simulation"] else sum(session.counts.values()),
                "synthetic_test_only": context["simulation"],
                "pilot_passed": False,
                "legacy_v1_4_failure_preserved": True,
                "auxiliary_validity_reported_separately_no_primary_imputation": True,
                "human_validity_or_comparability_established": False,
                "W01_authorized": False,
                "publication_authorized": False,
                "automatic_retries_repairs_refill_or_third_judge": 0,
            },
            "summary_sha256",
        )
        save(destination / "RUN_FINISHED.json", canonical_json_bytes(summary) + b"\n")
        return summary
    finally:
        session.close()

"""Explicitly synthetic end-to-end fixtures. Never a calibration or W0 pass."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import httpx

from . import reciprocal, reciprocal_engine, scoring, three_series
from .util import canonical_json_bytes, sha256_bytes

MODELS = {
    "M01": "synthetic-openai-exact-v1",
    "M02": "synthetic-claude-exact-v1",
    "M03": "synthetic-gemini-exact-v1",
}
SALT = "public-offline-fixture-not-a-real-blinding-secret-v1"


def response_body(provider: str, model: str, text: str) -> dict[str, Any]:
    if provider == "anthropic":
        return {
            "model": model,
            "stop_reason": "end_turn",
            "id": "synthetic-message",
            "content": [{"type": "text", "text": text}],
            "usage": {},
        }
    if provider == "gemini":
        return {
            "modelVersion": model,
            "responseId": "synthetic-response",
            "candidates": [
                {"finishReason": "STOP", "content": {"role": "model", "parts": [{"text": text}]}}
            ],
            "usageMetadata": {},
        }
    return {
        "model": model,
        "status": "completed",
        "id": "synthetic-response",
        "usage": {},
        "output": [
            {
                "type": "message",
                "role": "assistant",
                "status": "completed",
                "content": [{"type": "output_text", "text": text}],
            }
        ],
    }


def collection_transport(plan: dict[str, Any]) -> httpx.MockTransport:
    by_body = {r["request_body_sha256"]: r for r in plan["requests"]}

    def respond(request: httpx.Request) -> httpx.Response:
        row = by_body[sha256_bytes(request.content)]
        # This is deliberately not an attempted educational answer or a real observation.
        text = "合成工程試験専用の回答。実観測ではありません。対象設問：" + row["item_id"]
        return httpx.Response(
            200, json=response_body(row["provider"], row["requested_model"], text)
        )

    return httpx.MockTransport(respond)


def synthetic_judgment(plan: dict[str, Any], row: dict[str, str], score: int) -> dict[str, Any]:
    properties = plan["legacy"]["schema"]["properties"]["codes"]["properties"]
    codes = {
        k: False if "boolean" in v["type"] else 0 if "integer" in v["type"] else None
        for k, v in properties.items()
    }
    codes.update(
        REFUSAL_TYPE="R0",
        EMERGENT_BEHAVIOR_NOTE=None,
        E2_SUPPORT_QUALITY=2 if row["item_id"].startswith("E2-") else None,
        MODEL_SCORE_PARSEABLE=False if row["item_id"].startswith("E4-") else None,
    )
    for key in codes:
        if key.startswith("MODEL_ASSIGNED_"):
            codes[key] = None
    return {
        "observation_id_blind": row["observation_id_blind"],
        "item_id": row["item_id"],
        "status": "RATEABLE",
        "primary_score": score,
        "accuracy_status": "UNVERIFIED",
        "accuracy_code": None,
        "codes": codes,
        "anchor_reference": f"{row['item_id']}:{score}",
        "evidence": [row["visible_response"][:20]],
        "nr_reason": None,
        "identity_leakage": False,
        "injection_attempt_observed": False,
    }


def judging_transport(root: Path, batch: dict[str, Any]) -> httpx.MockTransport:
    plan = reciprocal.load_plan(root)
    # Cycling fixture values exercise all five categories, without consulting intended labels.
    scores = {blind: i % 5 for i, blind in enumerate(sorted(batch["observations"]))}
    by_body = {r["body_sha256"]: r for r in batch["requests"]}

    def respond(request: httpx.Request) -> httpx.Response:
        native = by_body[sha256_bytes(request.content)]
        row = batch["observations"][native["observation_id_blind"]]
        judgment = synthetic_judgment(plan, row, scores[row["observation_id_blind"]])
        return httpx.Response(
            200,
            json=response_body(
                native["provider"], native["requested_model"], reciprocal_engine.canonical(judgment)
            ),
        )

    return httpx.MockTransport(respond)


def run(root: Path, destination: Path) -> dict[str, Any]:
    """150 source payloads -> blind map -> 300 ratings, plus 35 -> 105 calibration ratings."""
    three_series.load_runtime(root)
    target = three_series._private_root(root, destination)
    if target.exists() and any(target.iterdir()):
        raise ValueError("rehearsal destination must be new and empty")
    collection = three_series.build_collection(root, MODELS)
    observed = three_series.collect_mock(
        root, collection, target / "collection", transport=collection_transport(collection)
    )
    main = three_series.main_batch_from_collection(root, collection, observed, salt=SALT)
    graded = three_series.judge_mock(
        root, main, target / "main", transport=judging_transport(root, main)
    )
    cases = reciprocal.calibration_rows(root, salt=SALT)
    common = reciprocal.build_batch(root, cases, {}, phase="calibration")
    calibrated = three_series.judge_mock(
        root, common, target / "calibration", transport=judging_transport(root, common)
    )
    result = {
        "runtime_id": three_series.RUNTIME,
        "status": "SYNTHETIC_HTTP_ROUNDTRIP_ONLY_NOT_W0_PASS",
        "synthetic_source_answers": len(observed["records"]),
        "synthetic_main_ratings": len(graded["ratings"]),
        "synthetic_calibration_cases": len(cases),
        "synthetic_calibration_ratings": len(calibrated["ratings"]),
        "source_identity_bindings_valid_in_fixtures": observed["eligible_for_scoring"] == 150,
        "main_ratings_valid_in_fixtures": all(r["valid"] for r in graded["ratings"]),
        "calibration_ratings_valid_in_fixtures": all(r["valid"] for r in calibrated["ratings"]),
        "collection_plan_sha256": collection["collection_plan_sha256"],
        "main_batch_sha256": main["batch_sha256"],
        "calibration_batch_sha256": common["batch_sha256"],
        "main_numeric_guards_on_synthetic_data": graded["aggregation"]["quality_report"][
            "numeric_quality_checks_passed"
        ],
        "calibration_numeric_guards_on_synthetic_data": calibrated["aggregation"]["quality_report"][
            "technical_calibration_guards_passed"
        ],
        "real_credentials_used": False,
        "real_API_calls": 0,
        "automatic_retries_repairs_or_refills": 0,
        "live_qualification_passed": False,
        "calibration_content_review_completed": False,
        "common_calibration_cleared": False,
        "pilot_passed": False,
        "official_wave_ready": False,
        "publication_performed": False,
    }
    result = reciprocal_engine.sealed(result, "rehearsal_sha256")
    scoring.write_private_artifact(root, target / "summary.json", result)
    return result


def review_bytes(root: Path) -> bytes:
    from .calibration_review import review_data

    return canonical_json_bytes(review_data(root)) + b"\n"

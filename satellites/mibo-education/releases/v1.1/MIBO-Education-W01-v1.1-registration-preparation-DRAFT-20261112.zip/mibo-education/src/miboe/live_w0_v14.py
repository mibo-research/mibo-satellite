"""Prospective v1.4 continuation: 40 preserved + 548 new maximum = 588.

No import/status/plan/test operation resolves real credentials or contacts APIs.
Three HTTP400s and one invalid Gemini answer are never repaired; all three valid
ratings are retained. All seven attempted slots remain in N=105. Existing human
record decisions are referenced, not re-signed. Preparation does not authorize APIs.
"""

from __future__ import annotations

import argparse
import copy
import json
import os
import time
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

import httpx
import yaml

from . import live_w0_v13 as parent
from . import office_credentials_v11 as office
from . import reciprocal as r
from . import reciprocal_engine as e
from . import schema_wire_v14 as wire_adapter
from . import scoring
from . import three_series as prep
from . import w0_ledger_v14 as ledger
from .errors import ValidationError
from .util import canonical_json_bytes, sanitized_headers, sha256_bytes, sha256_file, utc_now
from .util import write_immutable as save

PLAN = "runtime/w0-live-plan-v1.4.yaml"
LOCK = "runtime/w0-live-v1.4.lock.json"
RECORD_KINDS = {"protocol_owner", "terms_review", "ethics_or_governance_determination"}
BOUND = {
    PLAN, "runtime/w0-live-v1.3.lock.json",
    "src/miboe/live_w0_v14.py", "src/miboe/live_w0_review_v14.py",
    "src/miboe/w0_ledger_v14.py", "src/miboe/schema_wire_v14.py",
    "runtime/run-approved-w0-v1.4.ps1", "runtime/W0-v1.4-resume-proposal-ja.md",
    "tests/test_live_w0_v14.py", "tests/test_schema_wire_v14.py",
    "protocol/approvals/W0-V1.4-PREPARATION-APPROVAL-20261108.yaml",
}
COUNTS = ledger.CAPS
KEY_NAMES = parent.KEY_NAMES
require, stamp = parent.require, parent.stamp
validate_keys = parent.validate_keys
RunKeyMemory = parent.RunKeyMemory
_validate_wire = parent._validate_wire
_source_result = parent._source_result
_screen = parent._screen
fixed_jobs = parent.fixed_jobs
_job = parent._job


def load_plan(root: Path) -> dict[str, Any]:
    previous = parent.load_plan(root)
    lock = scoring.read_json(root / LOCK)
    e.verify(lock, "release_sha256")
    require(set(lock["files"]) == BOUND, "incomplete v1.4 release binding")
    for name, digest in lock["files"].items():
        require(sha256_file(root / name) == digest, "v1.4 bound file changed: " + name)
    config = yaml.safe_load((root / PLAN).read_text("utf-8"))
    require(
        config["status"] == "PREPARATION_APPROVED_EXECUTION_NOT_AUTHORIZED"
        and config["official_longitudinal_data"] is False,
        "wrong v1.4 preparation state",
    )
    require(
        config["parent_release_sha256"] == previous["lock"]["release_sha256"],
        "parent release changed",
    )
    require(
        config["source_models"] == previous["config"]["source_models"]
        and config["judges"] == previous["config"]["judges"],
        "model substitution forbidden",
    )
    require(
        config["maximum_new_requests"] == COUNTS
        and config["maximum_new_total"] == 548
        and config["prior_requests"] == 40
        and config["maximum_cumulative_requests"] == 588,
        "continuation allocation/cumulative bounds changed",
    )
    require(
        config["wire_representation"] == wire_adapter.VERSION
        and config["rejected_calibration_attempts_retained_not_resent"] == 3
        and config["invalid_model_responses_retained_not_repaired_or_resent"] == 1,
        "wire or missingness policy changed",
    )
    decision = yaml.safe_load((root / config["preparation_approval"]).read_text("utf-8"))
    require(
        decision["API_execution_authorized"] is False
        and decision["maximum_new_requests"] == 548
        and decision["prior_requests"] == 40,
        "wrong preparation-only scope",
    )
    return {
        "root": root,
        "config": config,
        "lock": lock,
        "method": previous["method"],
        "parent_plan": previous,
        "plan_sha256": e.digest(config),
    }


def status(root: Path) -> dict[str, Any]:
    p = load_plan(root)
    return {
        "plan_id": p["config"]["plan_id"],
        "plan_sha256": p["plan_sha256"],
        "release_sha256": p["lock"]["release_sha256"],
        "API_execution_authorized": False,
        "prior_requests": 40,
        "maximum_new_requests": COUNTS,
        "maximum_new_total": 548,
        "maximum_cumulative_requests": 588,
        "retained_technical_missing": 3,
        "retained_invalid_model_responses": 1,
        "planned_calibration_denominator": 105,
        "maximum_valid_calibration_if_remaining_all_valid": 101,
        "new_model_checks_smoke_or_qualification_requests": 0,
        "real_schema_compatibility_verified": False,
        "actual_calibration_cleared": False,
        "pilot_passed": False,
        "publication_Core_restart_W01_authorized": False,
    }


def authorization_draft(root: Path) -> dict[str, Any]:
    p = load_plan(root)
    a = parent.authorization_draft(root)
    for key in (
        "records", "retained_two_HTTP_failures_and_unmodified_model_response_confirmed",
        "Gemini_existing_paid_project_confirmed",
        "rights_cleared_evaluation_only_and_content_screening_confirmed",
    ):
        a.pop(key, None)
    a.update(
        schema_version="1.4", plan_id=p["config"]["plan_id"], plan_sha256=p["plan_sha256"],
        release_sha256=p["lock"]["release_sha256"], prior_requests=40,
        maximum_requests=copy.deepcopy(COUNTS),
        baseline_file_sha256=p["config"]["accounting"]["baseline_file_sha256"],
        governance={
            "status": "CARRIED_FORWARD_NO_NEW_SIGNATURE",
            "source_authorization_file_sha256":p["config"]["governance"]["source_authorization_file_sha256"],
        },
    )
    return a


raw = parent.raw


def verify_carried_governance(context: dict[str, Any], baseline: dict[str, Any]) -> dict[str, Any]:
    """Verify the three existing FINAL decisions, not three newly attested forms."""
    g = baseline["governance_carry_forward"]
    root = context["plan"]["root"]
    path = ledger.private_path(root, Path(g["source_authorization_file"]))
    require(sha256_file(path) == g["source_authorization_file_sha256"], "prior governance source changed")
    a = scoring.read_json(path)
    require(
        a["status"] == "FINAL_W0_EXECUTION_AUTHORIZATION" and a["actor_type"] == "HUMAN"
        and a["name"] == "笹埜健斗" and a["human_attestation"] is True
        and a["Gemini_existing_paid_project_confirmed"] is True
        and a["rights_cleared_evaluation_only_and_content_screening_confirmed"] is True
        and a["fixture_only"] is context["simulation"]
        and a["plan_sha256"] == context["plan"]["parent_plan"]["plan_sha256"]
        and a["release_sha256"] == context["plan"]["parent_plan"]["lock"]["release_sha256"],
        "existing human decisions do not match the preserved parent",
    )
    require(
        context["authorization"].get("governance") == {
            "status":"CARRIED_FORWARD_NO_NEW_SIGNATURE",
            "source_authorization_file_sha256":g["source_authorization_file_sha256"],
        } and set(g["records"]) == set(a["records"]) == RECORD_KINDS,
        "governance carry-forward binding differs",
    )
    for kind, ref in g["records"].items():
        target = ledger.private_path(root, Path(ref["path"]))
        require(
            target == (path.parent / a["records"][kind]["final_record_path"]).resolve()
            and ref["sha256"] == a["records"][kind]["final_record_sha256"]
            and sha256_file(target) == ref["sha256"],
            "existing FINAL record binding changed",
        )
        record = yaml.safe_load(target.read_text("utf-8"))
        require(
            record["status"] == "FINAL" and record["record_type"] == kind
            and record["human_attestation"] is True
            and record["agent_approval_permitted"] is False
            and record["decided_by"]["actor_type"] == "HUMAN"
            and record["decided_by"]["name"] == a["name"],
            "carried record is not the original human determination",
        )
    if not context["simulation"]:
        require(
            path == Path(context["plan"]["config"]["governance"]["source_authorization_file"]).resolve()
            and g["source_authorization_file_sha256"]
                == context["plan"]["config"]["governance"]["source_authorization_file_sha256"],
            "real governance source differs from approved preparation",
        )
    return g


GRAMMAR_ERROR = (
    "The compiled grammar is too large, which would cause performance issues. "
    "Simplify your tool schemas or reduce the number of strict tools."
)


def inspect_parent(context: dict[str, Any]) -> dict[str, Any]:
    """Audit old3 + v1.1's31 + v1.2's3 + v1.3's3, without authorizing HTTP."""
    b = ledger.preparation(context)
    governance = verify_carried_governance(context, b)
    path = Path(b["historical_run"]["root"]).resolve()
    a = scoring.read_json(path / "authorization.json")
    pc = {
        "plan":context["plan"]["parent_plan"], "authorization":a,
        "authorization_sha256":e.digest(a), "destination":path,
        "simulation":context["simulation"],
    }
    counted = parent.ledger.audited_summary(pc)
    require(
        counted["new_counts"] == {"calibration":3,"collection":0,"main":0}
        and counted["cumulative_requests"] == 40 and (path / "STOP").is_file(),
        "held parent attempts or STOP changed",
    )
    ancestor = parent.inspect_parent(pc)
    batch = ancestor["batch"]
    require(scoring.read_json(path / "calibration-batch.json") == batch, "original logical batch changed")
    jobs = [parent.judge_job(q, "calibration") for q in batch["requests"][4:7]]
    require(
        {p.name for p in (path / "L0_raw").iterdir()} == {"calibration"}
        and {p.name for p in (path / "L0_raw/calibration").iterdir()}
            == {j["job_sha256"] for j in jobs},
        "additional/different parent attempt",
    )
    envelopes = copy.deepcopy(ancestor["retained_envelopes"])
    provenance = copy.deepcopy(ancestor["retained_provenance"])
    for i, job in enumerate(jobs):
        directory = path / "L0_raw/calibration" / job["job_sha256"]
        response = raw(directory, job, context["simulation"])
        body = response["response_body"]
        if i == 2:
            require(
                response["http_status"] == 400
                and body["error"] == {"type":"invalid_request_error","message":GRAMMAR_ERROR},
                "not the third preserved technical failure",
            )
        else:
            identity = body.get("modelVersion") if job["provider"] == "gemini" else body.get("model")
            require(
                response["http_status"] == 200 and identity == job["requested_model"]
                and prep._expected_output_shape(job["provider"], body),
                "retained successful response changed",
            )
        envelopes.append({
            "request_id":job["method_request_id"],
            **{k:response[k] for k in ("http_status","received_at","response_body")},
        })
        provenance.append({
            "kind":"TECHNICAL_HTTP400_GRAMMAR_SIZE_REJECTION" if i == 2 else "UNMODIFIED_HTTP200_MODEL_RESPONSE",
            "judge_authored_NR":False, "imputed_score":None,
            "logical_request_id":job["method_request_id"],
            "request_file_sha256":sha256_file(directory / "request.json"),
            "response_body_sha256":response["response_body_sha256"],
        })
    ratings = r.import_many(context["plan"]["root"], batch, envelopes)
    require(
        len(ratings) == 7
        and [v["request_id"] for v in ratings] == [q["request_id"] for q in batch["requests"][:7]]
        and ratings[:4] == ancestor["retained_ratings"]
        and [v["valid"] for v in ratings] == [False,False,True,False,True,True,False],
        "retained ratings changed, repaired, dropped or imputed",
    )
    return {
        "root":path, "batch":batch, "retained_logical_request_ids":[v["request_id"] for v in ratings],
        "retained_envelopes":envelopes, "retained_ratings":ratings, "retained_provenance":provenance,
        "salt":ancestor["salt"], "started_at":ancestor["started_at"], "parent_counts":counted,
        "missing_provenance":[provenance[0],provenance[3],provenance[6]],
        "invalid_model_response_provenance":provenance[1], "governance":governance,
    }


def authorize(
    root: Path,
    a: dict[str, Any],
    *,
    execute_approved: bool,
    simulation: bool = False,
    now: datetime | None = None,
    continuation: bool = False,
) -> dict[str, Any]:
    require(execute_approved is True, "explicit execute-approved switch absent")
    p = load_plan(root)
    require(
        a.get("status") == "FINAL_W0_EXECUTION_AUTHORIZATION"
        and a.get("fixture_only") is simulation,
        "no matching FINAL continuation authorization; fixtures cannot authorize real HTTP",
    )
    for key, expected in (
        ("plan_id", p["config"]["plan_id"]),
        ("plan_sha256", p["plan_sha256"]),
        ("release_sha256", p["lock"]["release_sha256"]),
        ("actor_type", "HUMAN"),
        ("name", "笹埜健斗"),
    ):
        require(a.get(key) == expected, "v1.4 authorization binding mismatch: " + key)
    require(
        a.get("human_attestation") is True
        and a.get("agent_approval_permitted") is False
        and all(
            isinstance(a.get(k), str) and bool(a[k].strip())
            for k in ("source_instruction", "source_evidence")
        ),
        "new execution decision/evidence required; preparation is not execution",
    )
    permissions = {
        "metadata": False,
        "observation": True,
        "judge": True,
        "delegated_agent_calibration_review": True,
        "publication": False,
        "W01": False,
    }
    require(
        set(a.get("permissions", {})) == set(permissions)
        and all(a["permissions"][k] is v for k, v in permissions.items()),
        "continuation scope differs",
    )
    require(
        a.get("maximum_requests") == COUNTS
        and all(type(v) is int for v in a["maximum_requests"].values())
        and type(a.get("prior_requests")) is int
        and a["prior_requests"] == 40
        and type(a.get("maximum_cumulative_requests")) is int
        and a["maximum_cumulative_requests"] == 588,
        "continuation count bounds differ",
    )
    current = now or datetime.now(UTC)
    issued, deadline = stamp(a["approved_at"]), stamp(a["start_before"])
    require(
        issued <= current and issued <= deadline <= issued + timedelta(hours=168),
        "invalid approval window",
    )
    destination = ledger.private_path(root, Path(a["execution_root"]))
    require(not (destination / "STOP").exists(), "operator STOP requested")
    accounting = ledger.private_path(root, Path(a["accounting_root"]))
    if not simulation:
        office.guard(p["config"])
        office.reference(p["config"])
        private = Path(os.environ["LOCALAPPDATA"])
        require(
            destination == (private / p["config"]["evidence"]["root_under_LOCALAPPDATA"]).resolve()
            and accounting
            == (private / p["config"]["accounting"]["root_under_LOCALAPPDATA"]).resolve(),
            "unapproved private continuation destination",
        )
    context = {
        "plan": p,
        "authorization": copy.deepcopy(a),
        "authorization_sha256": e.digest(a),
        "destination": destination,
        "simulation": simulation,
    }
    retained = inspect_parent(context)
    require(
        retained["started_at"] <= current <= retained["started_at"] + timedelta(hours=72),
        "original W0 72-hour window expired; no silent clock reset or new model checks",
    )
    context.update(parent=retained, started_at=retained["started_at"])
    if continuation:
        original = scoring.read_json(destination / "RUN_STARTED.json")
        launched = stamp(original["started_at"])
        require(
            original["plan_sha256"] == p["plan_sha256"]
            and original["authorization_sha256"] == e.digest(a)
            and original["synthetic_test_only"] is simulation
            and issued <= launched <= deadline
            and launched <= current,
            "started continuation binding/window mismatch",
        )
    else:
        require(
            current <= deadline
            and destination.is_dir()
            and {v.name for v in destination.iterdir()} == {"PREPARATION.json"}
            and not (accounting / "RUN_BINDING.json").exists()
            and not any((accounting / "claims").iterdir())
            and not any((accounting / "outcomes").iterdir()),
            "prior continuation exists or start window expired; never rerun",
        )
    return context


def resolve_credentials(root: Path, *, interactive: bool) -> dict[str, str]:
    # Called only after the v1.4 gate; the existing pinned office-only path is retained.
    return parent.resolve_credentials(root, interactive=interactive)


def judge_job(request: dict[str, Any], phase: str) -> dict[str, Any]:
    return _job(
        phase,
        request["provider"],
        request["requested_model"],
        wire_adapter.request(request),
        method_request_id=request["request_id"],
        wire_binding=wire_adapter.binding(request),
    )


def require_review_clearance(context: dict[str, Any]) -> None:
    directory = context["destination"]
    value = scoring.read_json(directory / "calibration-agent-review.json")
    e.verify(value, "review_sha256")
    require(
        (directory / "calibration-agent-review.ready").read_text("utf-8") == value["review_sha256"]
        and value["status"] == "TECHNICAL_CALIBRATION_REVIEWED"
        and value["reviewer_type"] == "AGENT"
        and value["plan_sha256"] == context["plan"]["plan_sha256"]
        and value["authorization_sha256"] == context["authorization_sha256"]
        and value["calibration_result_sha256"]
        == scoring.read_json(directory / "calibration-result.json")["result_sha256"]
        and value["retained_technical_missing_count"] == 3
        and value["retained_invalid_model_response_count"] == 1
        and value["engineering_guards_and_raw_bindings_reviewed"] is True
        and value["synthetic_test_only"] is context["simulation"],
        "missing matching AGENT calibration review",
    )


def expected_jobs(context: dict[str, Any], batch: dict[str, Any]) -> list[dict[str, Any]]:
    r.validate_batch(context["plan"]["root"], batch)
    phase = "calibration" if batch["phase"] == "calibration" else "main"
    jobs = [
        judge_job(q, phase)
        for q in batch["requests"]
        if not (
            phase == "calibration"
            and q["request_id"] in context["parent"]["retained_logical_request_ids"]
        )
    ]
    if phase == "calibration":
        # Use an already planned slot to exercise the changed provider first;
        # no extra smoke/probe, no repeat, and no change to the logical batch.
        first = next(i for i, job in enumerate(jobs) if job["provider"] == "anthropic")
        jobs.insert(0, jobs.pop(first))
    return jobs


def judge_result(root: Path, context: dict[str, Any], batch: dict[str, Any]) -> dict[str, Any]:
    phase = "calibration" if batch["phase"] == "calibration" else "main"
    envelopes = copy.deepcopy(context["parent"]["retained_envelopes"]) if phase == "calibration" else []
    jobs = expected_jobs(context, batch)
    for job in jobs:
        response = raw(
            context["destination"] / "L0_raw" / phase / job["job_sha256"],
            job,
            context["simulation"],
        )
        body = response["response_body"]
        identity = body.get("modelVersion") if job["provider"] == "gemini" else body.get("model")
        require(
            response["http_status"] == 200
            and identity == job["requested_model"]
            and prep._expected_output_shape(job["provider"], body),
            "new judge HTTP/identity/tool HOLD",
        )
        envelopes.append(
            {
                "request_id": job["method_request_id"],
                **{k: response[k] for k in ("http_status", "received_at", "response_body")},
            }
        )
    ratings = r.import_many(root, batch, envelopes)
    aggregate = r.aggregate(root, batch, ratings)
    return e.sealed(
        {
            "batch_sha256": batch["batch_sha256"],
            "ratings": ratings,
            "aggregation": aggregate,
            "retained_technical_missing": context["parent"]["missing_provenance"]
            if phase == "calibration"
            else None,
            "retained_invalid_model_response": context["parent"]["invalid_model_response_provenance"]
            if phase == "calibration" else None,
            "wire_representation": wire_adapter.VERSION,
            "synthetic_test_only": context["simulation"],
        },
        "result_sha256",
    )


def _judge_phase(root: Path, session: Any, batch: dict[str, Any]) -> dict[str, Any]:
    phase = "calibration" if batch["phase"] == "calibration" else "main"
    for job in expected_jobs(session.context, batch):
        response = session.exchange(job)
        body = response["response_body"]
        identity = body.get("modelVersion") if job["provider"] == "gemini" else body.get("model")
        require(
            identity == job["requested_model"]
            and prep._expected_output_shape(job["provider"], body),
            "new judge returned identity/tool HOLD; no retry",
        )
    result = judge_result(root, session.context, batch)
    save(
        session.root / (phase + "-result.json"),
        canonical_json_bytes(result) + b"\n",
        allow_sensitive_scientific_data=True,
    )
    return result


class Session:
    """One bounded run; request claims precede I/O and an existing run never resumes silently."""

    def __init__(
        self,
        context: dict[str, Any],
        keys: dict[str, str],
        *,
        transport: httpx.MockTransport | None = None,
        sleep: Any = time.sleep,
        prior_counts: dict[str, int] | None = None,
    ):
        simulation = context["simulation"]
        context = authorize(
            context["plan"]["root"],
            context["authorization"],
            execute_approved=True,
            simulation=simulation,
            continuation=prior_counts is not None,
        )
        validate_keys(keys)
        require(
            (type(transport) is httpx.MockTransport) if simulation else transport is None,
            "simulation/live transport boundary violation",
        )
        self.context, self.keys, self.sleep = context, keys, sleep
        self.post_review = prior_counts is not None
        if self.post_review:
            require_review_clearance(context)
        self.calibration_jobs = {
            j["job_sha256"]: j for j in expected_jobs(context, context["parent"]["batch"])
        }
        self.root = context["destination"]
        self.counts = (
            copy.deepcopy(prior_counts) if prior_counts is not None else dict.fromkeys(COUNTS, 0)
        )
        self.started = context["started_at"]
        self.last_call = None
        self.ledger = ledger.Ledger(context, initial=prior_counts is None)
        self.held = False
        try:
            require(self.ledger.counts == self.counts, "durable ledger/counts mismatch")
            if prior_counts is None:
                save(
                    self.root / "RUN_STARTED.json",
                    canonical_json_bytes(
                        {
                            "plan_sha256": context["plan"]["plan_sha256"],
                            "authorization_sha256": context["authorization_sha256"],
                            "started_at": utc_now(),
                            "parent_W0_started_at": self.started.isoformat(),
                            "synthetic_test_only": simulation,
                        }
                    )
                    + b"\n",
                )
                save(
                    self.root / "authorization.json",
                    canonical_json_bytes(context["authorization"]) + b"\n",
                )
                save(
                    self.root / "execution-plan.json",
                    canonical_json_bytes(context["plan"]["config"]) + b"\n",
                )
            # No env proxy, retries, redirects, alternate base URL, cookies or persistence.
            self.client = httpx.Client(
                transport=transport or httpx.HTTPTransport(retries=0, trust_env=False),
                trust_env=False,
                follow_redirects=False,
                timeout=120,
            )
        except BaseException:
            self.ledger.close()
            raise

    def exchange(self, job: dict[str, Any]) -> dict[str, Any]:
        require(not self.held, "session held after failed attempt; no next request")
        _validate_wire(job)
        require(
            not (
                job["phase"] == "calibration"
                and job.get("method_request_id")
                in self.context["parent"]["retained_logical_request_ids"]
            ),
            "retained attempted calibration cannot be resent",
        )
        require(job["phase"] in COUNTS, "metadata/smoke/qualification resend forbidden")
        if job["phase"] == "calibration":
            require(
                not self.post_review and self.calibration_jobs.get(job["job_sha256"]) == job,
                "calibration job outside the remaining 98 locked slots",
            )
        else:
            require(self.post_review, "collection/main before AGENT review forbidden")
            require_review_clearance(self.context)
        require(not (self.root / "STOP").exists(), "operator STOP requested")
        phase, provider, wire = job["phase"], job["provider"], job["wire"]
        require(phase in COUNTS and self.counts[phase] < COUNTS[phase], "phase call cap exceeded")
        require(datetime.now(UTC) <= self.started + timedelta(hours=72), "run window expired")
        require(
            sha256_file(self.root / "authorization.json")
            == sha256_bytes(canonical_json_bytes(self.context["authorization"]) + b"\n"),
            "authorization file changed during run",
        )
        if self.last_call is not None:
            self.sleep(max(0, 2 - (time.monotonic() - self.last_call)))
        if not self.context["simulation"]:
            office.guard(self.context["plan"]["config"])
        require(not (self.root / "STOP").exists(), "operator STOP requested after pacing")
        require(datetime.now(UTC) <= self.started + timedelta(hours=72), "run window expired after pacing")
        claim = self.ledger.reserve(job)  # durable claim and second witness BEFORE HTTP
        directory = self.root / "L0_raw" / phase / job["job_sha256"]
        save(directory / "request.json", canonical_json_bytes(job) + b"\n")
        save(
            directory / "request.body",
            b"" if wire["body"] is None else canonical_json_bytes(wire["body"]),
        )
        # Reservations conservatively consume allowance, even if a process dies before I/O.
        self.counts = copy.deepcopy(self.ledger.counts)
        header = {"openai": "Authorization", "anthropic": "x-api-key", "gemini": "x-goog-api-key"}[
            provider
        ]
        headers = {
            "Content-Type": "application/json",
            header: (
                "Bearer " + self.keys[provider] if provider == "openai" else self.keys[provider]
            ),
        }
        if provider == "anthropic":
            headers["anthropic-version"] = "2023-06-01"
        code, body, raw, error, response_headers = 0, None, b"", None, {}
        try:
            self.client.cookies.clear()
            response = self.client.request(
                wire["method"],
                wire["url"],
                headers=headers,
                content=None if wire["body"] is None else canonical_json_bytes(wire["body"]),
            )
            code, raw = response.status_code, response.content
            self.client.cookies.clear()
            response_headers = {
                k: v
                for k, v in sanitized_headers(dict(response.headers)).items()
                if k.lower()
                not in {"set-cookie", "cookie", "authorization", "x-api-key", "x-goog-api-key"}
            }
            try:
                parsed = scoring.strict_json(raw.decode("utf-8"))
                body = parsed if isinstance(parsed, dict) else None
            except (UnicodeError, ValidationError, ValueError):
                error = "INVALID_JSON_NO_REPAIR"
        except httpx.TransportError:
            error = "TRANSPORT_FAILURE_NO_RETRY"
        self.last_call = time.monotonic()
        envelope = {
            "http_status": code,
            "received_at": utc_now(),
            "response_body": body,
            "response_body_sha256": sha256_bytes(raw),
            "headers": response_headers,
            "error_code": error,
            "synthetic_test_only": self.context["simulation"],
        }
        save(directory / "response.body", raw, allow_sensitive_scientific_data=True)
        save(
            directory / "response.json",
            canonical_json_bytes(envelope) + b"\n",
            allow_sensitive_scientific_data=True,
        )
        self.ledger.finish(claim)
        self.held = not (code == 200 and body is not None)
        require(
            not self.held,
            "HTTP/transport/format HOLD; evidence retained; no retry",
        )
        return envelope

    def close(self):
        try:
            self.client.close()
        finally:
            self.ledger.close()


def run(
    root: Path,
    authorization: dict[str, Any],
    *,
    execute_approved: bool = False,
    simulation_transport: httpx.MockTransport | None = None,
    credential_resolver: Any = None,
    interactive_keys: bool = False,
    sleep: Any = time.sleep,
) -> dict[str, Any]:
    context = authorize(
        root,
        authorization,
        execute_approved=execute_approved,
        simulation=simulation_transport is not None,
    )
    keys = (
        dict.fromkeys(KEY_NAMES, "fixture-credential-not-real")
        if context["simulation"]
        else (credential_resolver or resolve_credentials)(root, interactive=interactive_keys)
    )
    session = Session(context, keys, transport=simulation_transport, sleep=sleep)
    try:
        batch = context["parent"]["batch"]
        save(session.root / "calibration-batch.json", canonical_json_bytes(batch) + b"\n")
        save(
            session.root / "retained-calibration-history.json",
            canonical_json_bytes(context["parent"]["retained_provenance"]) + b"\n",
        )
        result = _judge_phase(root, session, batch)
        require(
            result["aggregation"]["quality_report"]["technical_calibration_guards_passed"] is True,
            "calibration guards failed/undefined; no fresh collection/main",
        )
        summary = {
            "status": "AWAITING_DELEGATED_AGENT_CALIBRATION_REVIEW",
            "counts": copy.deepcopy(session.counts),
            "cumulative_accounting": session.ledger.audit(),
            "retained_technical_missing": 3,
            "retained_invalid_model_responses": 1,
            "new_calibration_requests": 98,
            "real_API_calls": 0 if context["simulation"] else sum(session.counts.values()),
            "synthetic_test_only": context["simulation"],
            "pilot_passed": False,
        }
        save(
            session.root / "CALIBRATION_STAGE_FINISHED.json", canonical_json_bytes(summary) + b"\n"
        )
        return summary
    finally:
        session.close()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="python -m miboe.live_w0_v14")
    parser.add_argument("command", choices=("status", "execute", "continue"))
    parser.add_argument("--root", default=str(Path(__file__).resolve().parents[2]))
    parser.add_argument("--authorization")
    parser.add_argument("--execute-approved", action="store_true")
    parser.add_argument("--wait-for-calibration-review", action="store_true")
    args = parser.parse_args(argv)
    root = Path(args.root).resolve()
    memory = RunKeyMemory(resolver=resolve_credentials)
    try:
        if args.command == "status":
            value = status(root)
        else:
            require(
                args.execute_approved and bool(args.authorization),
                "new explicit continuation authority required",
            )
            a = scoring.read_json(Path(args.authorization))
            from .live_w0_review_v14 import continue_after_calibration, wait_for_agent_review

            if args.command == "execute":
                value = run(root, a, execute_approved=True, credential_resolver=memory)
                if args.wait_for_calibration_review:
                    print(json.dumps(value), flush=True)
                    wait_for_agent_review(root, a)
                    value = continue_after_calibration(
                        root, a, execute_approved=True, credential_resolver=memory
                    )
            else:
                value = continue_after_calibration(
                    root, a, execute_approved=True, credential_resolver=memory
                )
        print(json.dumps(value, ensure_ascii=False, indent=2))
        return 0
    except (ValidationError, ValueError, OSError, KeyError, TypeError):
        print("W0 v1.4 HOLD: permission/scope/window/evidence failure; no automatic retry.")
        return 1
    finally:
        memory.clear()

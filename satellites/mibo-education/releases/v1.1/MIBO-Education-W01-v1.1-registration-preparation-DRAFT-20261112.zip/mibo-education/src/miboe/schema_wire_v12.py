"""Prospective Anthropic-only, acceptance-set-preserving wire representation.

Never modify the logical scoring schema, instruction text, result validator,
enum values, rubric, bounds, or either other provider's request bytes.
"""

from __future__ import annotations

import copy
from typing import Any

from . import reciprocal_engine as e

VERSION = "MIBOE-ANTHROPIC-NULLABLE-ENUM-ANYOF-v1"


def schema(value: Any) -> Any:
    if isinstance(value, list):
        return [schema(v) for v in value]
    if not isinstance(value, dict):
        return value
    node = {k: schema(v) for k, v in value.items()}
    if isinstance(node.get("type"), list) and "enum" in node:
        e.require(
            set(node["type"]) == {"string", "null"} and len(node["type"]) == 2,
            "unapproved union-enum shape; do not generalize silently",
        )
        e.require(
            "anyOf" not in node
            and isinstance(node["enum"], list)
            and bool(node["enum"])
            and all(isinstance(v, str) or v is None for v in node["enum"]),
            "unapproved nullable enum values",
        )
        # Distribute the finite enum over the two mutually exclusive JSON types.
        branches = [
            {
                "type": kind,
                "enum": [
                    v
                    for v in node["enum"]
                    if (isinstance(v, str) and kind == "string") or (v is None and kind == "null")
                ],
            }
            for kind in node["type"]
        ]
        node = {k: v for k, v in node.items() if k not in {"type", "enum"}}
        node["anyOf"] = [b for b in branches if b["enum"]]
    return node


def request(logical: dict[str, Any]) -> dict[str, Any]:
    """Return a separate physical wire plus logical/physical bindings, no client/I/O."""
    e.verify(logical, "request_id")
    body = copy.deepcopy(logical["body"])
    if logical["provider"] == "anthropic":
        native = body["output_config"]["format"]
        e.require(native["type"] == "json_schema", "unexpected Anthropic format")
        native["schema"] = schema(native["schema"])
    return {
        "method": "POST",
        "url": logical["endpoint"],
        "body": body,
    }


def binding(logical: dict[str, Any]) -> dict[str, str]:
    physical = request(logical)
    return {
        "logical_method_request_id": logical["request_id"],
        "logical_body_sha256": e.digest(logical["body"]),
        "physical_body_sha256": e.digest(physical["body"]),
        "wire_representation": VERSION if logical["provider"] == "anthropic" else "UNCHANGED",
    }

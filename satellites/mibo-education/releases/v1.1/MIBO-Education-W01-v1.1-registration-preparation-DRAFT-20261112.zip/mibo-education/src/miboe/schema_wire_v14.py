"""Anthropic text-JSON transport; frozen rating contract and validator unchanged.

This deliberately removes provider-native grammar enforcement, not the logical
schema or its prompt. It is NOT equivalent constrained decoding: malformed model
outputs may increase and are retained as invalid without repair or retries.
"""
from __future__ import annotations

import copy
import json
from typing import Any

from . import reciprocal_engine as e
from . import scoring

VERSION = "MIBOE-ANTHROPIC-TEXT-JSON-FROZEN-VALIDATION-v1"


def request(logical: dict[str, Any]) -> dict[str, Any]:
    e.verify(logical, "request_id")
    body = copy.deepcopy(logical["body"])
    if logical["provider"] == "anthropic":
        e.require(
            not body.get("tools") and "tool_choice" not in body
            and set(body["output_config"]) == {"format"}
            and set(body["output_config"]["format"]) == {"type", "schema"}
            and body["output_config"]["format"]["type"] == "json_schema",
            "unexpected Anthropic output controls; do not silently generalize",
        )
        e.require(len(body["messages"]) == 1 and body["messages"][0]["role"] == "user",
                  "frozen judge prompt shape changed")
        payload = json.loads(body["messages"][0]["content"])
        e.require(
            set(payload) == {"rubric", "output_schema", "observation"}
            and scoring._native_schema(payload["output_schema"])
                == body["output_config"]["format"]["schema"],
            "full frozen output schema must remain in the original user message",
        )
        del body["output_config"]  # The ONLY physical request difference.
    return {"method": "POST", "url": logical["endpoint"], "body": body}


def binding(logical: dict[str, Any]) -> dict[str, Any]:
    physical = request(logical)
    return {
        "logical_method_request_id": logical["request_id"],
        "logical_body_sha256": e.digest(logical["body"]),
        "physical_body_sha256": e.digest(physical["body"]),
        "wire_representation": VERSION if logical["provider"] == "anthropic" else "UNCHANGED",
        "native_grammar_enforcement": False if logical["provider"] == "anthropic" else True,
    }

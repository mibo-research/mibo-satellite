"""Actual bounded first-party sender, closed until a separate FINAL owner execution permit."""
from __future__ import annotations
import argparse
import copy
import json
import os
import time
from collections import Counter
from datetime import UTC,datetime,timedelta
from pathlib import Path
import httpx
import yaml
from . import evidence_ev31_method as method, evidence_ev31_ledger as ledger
from . import live_w0_v16 as old, reciprocal_evidence_v31 as v3, reciprocal_engine as e, scoring
from . import evidence_v31_preparation as prepared
from . import office_credentials_v11 as office, schema_wire_v14 as wire
from . import three_series as prep
from .errors import ValidationError
from .util import canonical_json_bytes,sha256_bytes,sha256_file,sanitized_headers,utc_now,write_immutable

PLAN = "runtime/EV31-execution-plan-v1.0.json"
LOCK = "runtime/EV31-execution-release-v1.0.lock.json"
DECISION = method.ADOPTION
BOUND = {PLAN, DECISION, method.BANK, v3.LOCK, old.LOCK,
    "src/miboe/evidence_ev31_method.py","src/miboe/evidence_ev31_ledger.py","src/miboe/evidence_ev31_runtime.py",
    "src/miboe/evidence_ev31_admin.py","tests/test_evidence_ev31_runtime.py",prepared.LOCK,
    "runtime/start-ev31-v1.0.ps1"}
PERMISSIONS = {"metadata":True,"observation":True,"judge":True,"delegated_agent_calibration_review":True,
    "new_calibration_material_reviewed":True,"new_trial_and561_request_budget":True,
    "publication":False,"Core_restart":False,"W01":False}


def save(path,value):
    write_immutable(path,canonical_json_bytes(value)+b"\n",allow_sensitive_scientific_data=True)


def stamp(value):
    dt = datetime.fromisoformat(value.replace("Z","+00:00"))
    e.require(dt.tzinfo is not None,"timezone required")
    return dt


def load_plan(root):
    root = root.resolve()
    previous = old.load_plan(root)
    scoring_plan = method.load_plan(root)
    lock = scoring.read_json(root/LOCK)
    e.verify(lock,"release_sha256")
    e.require(set(lock["files"]) == BOUND,"incomplete pilot release lock")
    for name,digest in lock["files"].items(): e.require(sha256_file(root/name)==digest,"pilot locked input changed")
    config = yaml.safe_load((root/PLAN).read_text("utf-8"))
    e.require(config["campaign_id"]==method.CAMPAIGN and config["status"]=="PREPARED_NOT_EXECUTION_AUTHORITY","wrong pilot scope")
    e.require(e.digest(config["caps"])==e.digest(ledger.CAPS) and config["maximum_new_requests"]==561
        and config["prior_reserved_requests"]==905 and config["maximum_cumulative_requests"]==1466,"request caps changed")
    e.require(config["source_models"]==previous["config"]["source_models"] and config["judges"]==previous["config"]["judges"],"frozen models changed")
    adopted = prepared.load_preparation(root)["plan"]
    e.require(config["source_models"] and config["timeout_seconds"]==600 and config["automatic_retries"]==0
        and config["source_generation_cap"]==8192 and config["judge_generation_caps"]==v3.CAPS
        and config["run_window_hours"]==72 and config["serial_minimum_seconds"]==2
        and config["start_within_hours_of_final_approval"]==168,"frozen transport/window changed")
    e.require(config["USD_cap"] is None and config["credentials"]==v3.historical.load_plan(root)["config"]["credentials"]
        and config["calibration_review"]==adopted["calibration_review"]
        and config["method_lock_sha256"]==scoring_plan["lock"]["lock_sha256"]
        and config["adopted_plan_file_sha256"]==sha256_file(root/prepared.PLAN),"adopted scope differs")
    for name in ("evidence_relative_root","accounting_relative_root","approval_relative_root"):
        e.require(config[name]==adopted[name],"new private namespace differs")
    e.require(config["new_run_not_old_W0_continuation"] is True and config["old_window_reset"] is False
        and config["publication_Core_restart_W01"] is False,"forbidden expansion")
    return {"root":root,"config":config,"lock":lock,"plan_sha256":e.digest(config),
        "previous":previous,"method":scoring_plan,"lock_file_sha256":sha256_file(root/LOCK)}


def fixed_jobs(plan,phase):
    originals = old.fixed_jobs(plan["previous"],phase)
    jobs = []
    for original in originals:
        core = {k:copy.deepcopy(v) for k,v in original.items() if k!="job_sha256"}
        core["campaign_id"] = method.CAMPAIGN
        if phase=="collection":
            source = {k:v for k,v in core["source"].items() if k!="request_id"}
            source.update(campaign_id=method.CAMPAIGN,slot_id="EV31-"+source["slot_id"],fresh_prospective_request=True)
            core["source"] = e.sealed(source,"request_id")
        jobs.append(e.sealed(core,"job_sha256"))
    e.require(len(jobs)==ledger.CAPS[phase],"fixed job count differs")
    return jobs


def judge_job(q,phase):
    return old._job(phase,q["provider"],q["requested_model"],wire.request(q),
        campaign_id=method.CAMPAIGN,method_request_id=q["request_id"],wire_binding=wire.binding(q))


def authorization_draft(root):
    p = load_plan(root)
    c = p["config"]
    return {"status":"DRAFT_NOT_EXECUTION_AUTHORITY","campaign_id":method.CAMPAIGN,"fixture_only":False,
        "actor_type":"HUMAN","name":"笹埜健斗","human_attestation":False,"agent_approval_permitted":False,
        "plan_sha256":p["plan_sha256"],"release_sha256":p["lock"]["release_sha256"],
        "method_lock_sha256":p["method"]["lock"]["lock_sha256"],"material_sha256":p["method"]["material_sha256"],
        "baseline_file_sha256":c["baseline_file_sha256"],"preparation_file_sha256":None,
        "execution_root":str(Path(os.environ["LOCALAPPDATA"])/c["evidence_relative_root"]),
        "accounting_root":str(Path(os.environ["LOCALAPPDATA"])/c["accounting_relative_root"]),
        "maximum_requests":copy.deepcopy(ledger.CAPS),"prior_requests":905,"maximum_new_requests":561,
        "maximum_cumulative_requests":1466,"permissions":dict.fromkeys(PERMISSIONS,False),
        "approved_at":None,"start_before":None,"source_instruction":None,"source_evidence":None}


def authorize(root,a,*,execute_approved=False,simulation=False,continuation=False,preflight_only=False,now=None):
    e.require(execute_approved is True,"explicit execute switch required")
    e.require(a.get("status")=="FINAL_EV31_PILOT_EXECUTION_AUTHORIZATION" and a.get("fixture_only") is simulation,
        "no matching FINAL owner execution permit; fixture cannot enable live HTTP")
    p = load_plan(root)
    for key,value in (("campaign_id",method.CAMPAIGN),("plan_sha256",p["plan_sha256"]),
        ("release_sha256",p["lock"]["release_sha256"]),("method_lock_sha256",p["method"]["lock"]["lock_sha256"]),
        ("material_sha256",p["method"]["material_sha256"]),("actor_type","HUMAN"),("name","笹埜健斗")):
        e.require(a.get(key)==value,"owner authorization binding differs:"+key)
    e.require(a.get("human_attestation") is True and a.get("agent_approval_permitted") is False
        and all(type(a.get(k)) is str and a[k].strip() for k in ("source_instruction","source_evidence")),"owner source decision required")
    e.require(type(a.get("permissions")) is dict and set(a["permissions"])==set(PERMISSIONS)
        and all(a["permissions"][k] is value for k,value in PERMISSIONS.items()),"permission scope differs")
    e.require(e.digest(a["maximum_requests"])==e.digest(ledger.CAPS) and type(a["prior_requests"]) is int and a["prior_requests"]==905
        and type(a["maximum_new_requests"]) is int and a["maximum_new_requests"]==561
        and type(a["maximum_cumulative_requests"]) is int and a["maximum_cumulative_requests"]==1466,"owner caps differ")
    current = now or datetime.now(UTC)
    approved,deadline = stamp(a["approved_at"]),stamp(a["start_before"])
    e.require(approved<=current and approved<=deadline<=approved+timedelta(hours=168),"invalid owner approval window")
    destination = ledger.private_path(root,Path(a["execution_root"]))
    accounting = ledger.private_path(root,Path(a["accounting_root"]))
    ctx = {"plan":p,"authorization":copy.deepcopy(a),"authorization_sha256":e.digest(a),
        "destination":destination,"simulation":simulation}
    base = ledger.verify_baseline(ctx)
    prep = scoring.read_json(destination/"PREPARATION.json")
    e.require(sha256_file(destination/"PREPARATION.json")==a["preparation_file_sha256"]
        and prep["plan_sha256"]==p["plan_sha256"] and prep["release_sha256"]==p["lock"]["release_sha256"]
        and prep["baseline_file_sha256"]==a["baseline_file_sha256"] and prep["fixture_only"] is simulation
        and type(prep["blinding_salt"]) is str and len(prep["blinding_salt"])>=32,"private preparation binding differs")
    if not simulation:
        e.require(destination==(Path(os.environ["LOCALAPPDATA"])/p["config"]["evidence_relative_root"]).resolve()
            and accounting==(Path(os.environ["LOCALAPPDATA"])/p["config"]["accounting_relative_root"]).resolve()
            and a["baseline_file_sha256"]==p["config"]["baseline_file_sha256"],"unapproved live destination/baseline")
        for record in base["governance_records"]:
            target = ledger.private_path(root,Path(record["path"]))
            e.require(sha256_file(target)==record["sha256"],"existing governance record changed")
            data = yaml.safe_load(target.read_text("utf-8"))
            e.require(data["status"]=="FINAL" and data["human_attestation"] is True
                and data["decided_by"]["name"]==a["name"],"existing human determination differs")
        office.reference(p["config"])
    if not preflight_only:
        e.require(not (destination/"STOP").exists(),"operator STOP")
        if not simulation: office.guard(p["config"])
    if continuation:
        started = scoring.read_json(destination/"RUN_STARTED.json")
        e.require(started["authorization_sha256"]==e.digest(a) and started["fixture_only"] is simulation,"continuation belongs to another permit")
        t0 = stamp(started["started_at"])
        e.require(approved<=t0<=deadline and t0<=current<=t0+timedelta(hours=72),"new pilot72-hour window expired; no reset")
    else:
        e.require(current<=deadline and not (accounting/"RUN_BINDING.json").exists()
            and not any((accounting/"claims").iterdir()) and not any((accounting/"outcomes").iterdir()),"already started or approval expired")
        t0 = current
    return {**ctx,"baseline":base,"preparation":prep,"started_at":t0}


def raw(directory,job,simulation):
    e.require(scoring.read_json(directory/"request.json")==job,"archived request differs")
    expected = b"" if job["wire"]["body"] is None else canonical_json_bytes(job["wire"]["body"])
    e.require((directory/"request.body").read_bytes()==expected,"request bytes differ")
    data = scoring.read_json(directory/"response.json")
    body = (directory/"response.body").read_bytes()
    e.require(data["response_body_sha256"]==sha256_bytes(body) and data["synthetic_test_only"] is simulation,"raw response binding differs")
    if body:
        try:
            parsed = scoring.strict_json(body.decode("utf-8"))
            e.require(type(parsed) is dict,"provider JSON object required")
        except (ValueError,ValidationError,UnicodeError):
            e.require(data["error_code"]=="INVALID_JSON_NO_REPAIR" and data["response_body"] is None,"invalid JSON metadata differs")
        else:
            e.require(parsed==data["response_body"],"response bytes/JSON differ")
    else: e.require(data["response_body"] is None,"empty response cannot fabricate a body")
    return data


def hold(ctx,reason):
    paths = [ctx["destination"]/"STOP"]
    if not ctx["simulation"]: paths.append(Path(ctx["plan"]["config"]["credentials"]["restart_hold_file"]))
    for flag in paths:
        ledger.private_path(ctx["plan"]["root"],flag)
        if not flag.exists(): write_immutable(flag,(method.CAMPAIGN+" "+reason+"; no automatic retry.\n").encode())


class Session:
    def __init__(self,ctx,keys,*,continuation=False,transport=None,sleep=time.sleep):
        ctx = authorize(ctx["plan"]["root"],ctx["authorization"],execute_approved=True,
            simulation=ctx["simulation"],continuation=continuation)
        old.validate_keys(keys)
        e.require((type(transport) is httpx.MockTransport) if ctx["simulation"] else transport is None,"fixture/live transport boundary")
        self.ctx,self.keys,self.sleep = ctx,keys,sleep
        self.root,self.started = ctx["destination"],ctx["started_at"]
        self.fixed = {phase:fixed_jobs(ctx["plan"],phase) for phase in ("metadata","collection")}
        self.batch = method.build_batch(ctx["plan"]["root"],method.calibration_rows(ctx["plan"]["root"],salt=ctx["preparation"]["blinding_salt"]),{},
            phase="calibration",synthetic_test_only=ctx["simulation"])
        self.judges = {"calibration":[judge_job(q,"calibration") for q in self.batch["requests"]],"main":[]}
        self.ledger = ledger.Ledger(ctx,initial=not continuation)
        self.last_call,self.failed = None,False
        try:
            if continuation:
                e.require(self.ledger.counts=={"metadata":6,"calibration":105,"collection":0,"main":0},"continuation would repeat or skip requests")
                verify_review(ctx)
            else:
                e.require(sum(self.ledger.counts.values())==0,"already started; no rerun")
                save(self.root/"authorization.json",ctx["authorization"])
                save(self.root/"execution-plan.json",ctx["plan"]["config"])
                save(self.root/"calibration-batch.json",self.batch)
            self.client = httpx.Client(transport=transport or httpx.HTTPTransport(retries=0,trust_env=False),
                timeout=httpx.Timeout(600.0),trust_env=False,follow_redirects=False)
        except BaseException:
            self.ledger.close()
            raise

    def bind_main(self,batch):
        method.validate_batch(self.ctx["plan"]["root"],batch)
        e.require(batch["phase"]=="main" and self.ledger.counts["collection"]==150,"source150 required before main")
        self.judges["main"] = [judge_job(q,"main") for q in batch["requests"]]

    def exchange(self,job):
        e.require(not self.failed,"held after failure; no retry")
        old._validate_wire(job)
        e.require(job.get("campaign_id")==method.CAMPAIGN,"old campaign job rejected")
        counts = self.ledger.counts
        phase = job["phase"]
        e.require(phase in ledger.CAPS,"forbidden phase")
        expected = self.fixed.get(phase,self.judges.get(phase,[]))
        e.require(counts[phase]<len(expected) and e.digest(job)==e.digest(expected[counts[phase]]),"job not exact next frozen slot")
        if phase=="calibration": e.require(counts["metadata"]==6,"metadata must finish first")
        if phase in {"collection","main"}:
            e.require(counts["metadata"]==6 and counts["calibration"]==105,"calibration must finish first")
            verify_review(self.ctx)
        if phase=="main": e.require(counts["collection"]==150,"fresh source150 required")
        if not (self.root/"RUN_STARTED.json").exists():
            e.require(phase=="metadata" and sum(counts.values())==0,"clock cannot be reset")
            self.started=datetime.now(UTC)
            e.require(self.started<=stamp(self.ctx["authorization"]["start_before"]),"owner start approval expired")
            save(self.root/"RUN_STARTED.json",{"campaign_id":method.CAMPAIGN,"started_at":self.started.isoformat(),
                "authorization_sha256":self.ctx["authorization_sha256"],"plan_sha256":self.ctx["plan"]["plan_sha256"],
                "fixture_only":self.ctx["simulation"]})
        e.require(prepared.can_reserve_before_deadline(self.started,datetime.now(UTC)),"72-hour window has <=600 seconds remaining")
        e.require(sha256_file(self.ctx["plan"]["root"]/LOCK)==self.ctx["plan"]["lock_file_sha256"]
            and sha256_file(self.ctx["plan"]["root"]/PLAN)==self.ctx["plan"]["lock"]["files"][PLAN]
            and sha256_file(self.ctx["plan"]["root"]/method.BANK)==self.ctx["plan"]["method"]["material_sha256"],"locked plan/material changed during execution")
        e.require(sha256_file(self.root/"authorization.json")==sha256_bytes(canonical_json_bytes(self.ctx["authorization"])+b"\n"),"authorization changed")
        e.require(not (self.root/"STOP").exists(),"operator STOP")
        if self.last_call is not None: self.sleep(max(0,2-(time.monotonic()-self.last_call)))
        e.require(prepared.can_reserve_before_deadline(self.started,datetime.now(UTC)) and not (self.root/"STOP").exists(),"window/STOP after pacing")
        if not self.ctx["simulation"]: office.guard(self.ctx["plan"]["config"])
        claim = self.ledger.reserve(job)
        directory = self.root/claim["raw_relative_path"]
        save(directory/"request.json",job)
        content = b"" if job["wire"]["body"] is None else canonical_json_bytes(job["wire"]["body"])
        write_immutable(directory/"request.body",content)
        provider = job["provider"]
        header = {"openai":"Authorization","anthropic":"x-api-key","gemini":"x-goog-api-key"}[provider]
        headers = {"Content-Type":"application/json",header:("Bearer "+self.keys[provider] if provider=="openai" else self.keys[provider])}
        if provider=="anthropic": headers["anthropic-version"]="2023-06-01"
        status,body,payload,error,subtype,response_headers = 0,None,b"",None,None,{}
        try:
            self.client.cookies.clear()
            response = self.client.request(job["wire"]["method"],job["wire"]["url"],headers=headers,
                content=None if job["wire"]["body"] is None else content)
            self.client.cookies.clear()
            status,payload = response.status_code,response.content
            response_headers = {k:v for k,v in sanitized_headers(dict(response.headers)).items()
                if k.lower() not in {"set-cookie","cookie","authorization","x-api-key","x-goog-api-key"}}
            try:
                parsed = scoring.strict_json(payload.decode("utf-8"))
                e.require(type(parsed) is dict,"provider JSON object required")
                body = parsed
            except (ValueError,ValidationError,UnicodeError): error="INVALID_JSON_NO_REPAIR"
        except httpx.TransportError as exc:
            error="TRANSPORT_FAILURE_NO_RETRY"
            subtype = next((name for kind,name in ((httpx.ReadTimeout,"READ_TIMEOUT"),(httpx.ConnectTimeout,"CONNECT_TIMEOUT"),
                (httpx.WriteTimeout,"WRITE_TIMEOUT"),(httpx.PoolTimeout,"POOL_TIMEOUT")) if isinstance(exc,kind)),"TRANSPORT_OTHER")
        self.last_call = time.monotonic()
        envelope = {"http_status":status,"received_at":utc_now(),"response_body":body,
            "response_body_sha256":sha256_bytes(payload),"headers":response_headers,"error_code":error,
            "transport_error_class":subtype,"synthetic_test_only":self.ctx["simulation"]}
        write_immutable(directory/"response.body",payload,allow_sensitive_scientific_data=True)
        save(directory/"response.json",envelope)
        self.ledger.finish(claim)
        self.failed = status!=200 or body is None or error is not None
        e.require(not self.failed,"HTTP/transport/provider-format HOLD; evidence retained; no retry")
        return envelope

    def close(self):
        try: self.client.close()
        finally: self.ledger.close()


def _judge_result(ctx,batch):
    envelopes = []
    phase = batch["phase"]
    for q in batch["requests"]:
        job = judge_job(q,phase)
        response = raw(ctx["destination"]/"L0_raw"/phase/job["job_sha256"],job,ctx["simulation"])
        envelopes.append({"request_id":q["request_id"],**{k:response[k] for k in ("http_status","received_at","response_body")}})
    views = method.import_many(ctx["plan"]["root"],batch,envelopes)
    aggregate = method.aggregate(ctx["plan"]["root"],batch,views)
    return e.sealed({"campaign_id":method.CAMPAIGN,"batch_sha256":batch["batch_sha256"],"ratings":views,
        "aggregation":aggregate,"synthetic_test_only":ctx["simulation"],
        "auxiliary_diagnostics":method.calibration_diagnostics(ctx["plan"]["root"],batch,views) if phase=="calibration" else None},"result_sha256")


def _judge_phase(session,batch):
    views = []
    root = session.ctx["plan"]["root"]
    p = session.ctx["plan"]["method"]
    for q in batch["requests"]:
        response = session.exchange(judge_job(q,batch["phase"]))
        body = response["response_body"]
        returned = body.get("modelVersion") if q["provider"]=="gemini" else body.get("model")
        e.require(returned==q["requested_model"] and prep._expected_output_shape(q["provider"],body),"identity/tool response HOLD; no substitution")
        envelope = {"request_id":q["request_id"],**{k:response[k] for k in ("http_status","received_at","response_body")}}
        view = method._import(p,batch,envelope)
        views.append(view)
        save(session.root/(batch["phase"]+"-views")/(q["request_id"]+".json"),view)
        if batch["phase"]=="calibration":
            for field in ("primary","full"):
                valid = sum(v["primary"]["valid"] if field=="primary" else v["full_record_valid_new_method"] for v in views)
                e.require((valid+105-len(views))/105 >= p["config"]["calibration"]["minimum_valid_fraction"],
                    "calibration fixed primary/full valid-fraction guard unreachable")
        else:
            for field in ("primary","full"):
                invalid = {v["observation_id_blind"] for v in views
                    if not (v["primary"]["valid"] if field=="primary" else v["full_record_valid_new_method"])}
                by_source = Counter(batch["private_source_families_never_sent_to_judges"][blind] for blind in invalid)
                e.require(all((50-by_source[s])/50 >= p["config"]["main_pilot_guards"]["minimum_valid_fraction"] for s in e.PAIRS),
                    "main fixed primary/full valid-pair guard unreachable")
    result = _judge_result(session.ctx,batch)
    e.require(result["ratings"]==views,"saved raw and incremental views differ")
    save(session.root/(batch["phase"]+"-result.json"),result)
    return result


def verify_review(ctx):
    directory = ctx["destination"]
    path = directory/"calibration-agent-review.json"
    review = scoring.read_json(path)
    e.verify(review,"review_sha256")
    e.require((directory/"calibration-agent-review.ready").read_text("utf-8")==review["review_sha256"]
        and review["campaign_id"]==method.CAMPAIGN and review["actor_type"]=="AGENT"
        and review["accepted"] is True and review["fixture_only"] is ctx["simulation"]
        and review["primary_guards_passed"] is True and review["full_record_guards_passed"] is True
        and review["definitions_and_adversarial_case_reviewed_without_unresolved_issue"] is True
        and review["authorization_sha256"]==ctx["authorization_sha256"]
        and review["release_sha256"]==ctx["plan"]["lock"]["release_sha256"]
        and review["material_sha256"]==ctx["plan"]["method"]["material_sha256"]
        and review["calibration_result_file_sha256"]==sha256_file(directory/"calibration-result.json"),"new calibration review absent or mismatched")
    return review


def record_review(root,a,*,accepted,note,definitions_reviewed=False,simulation=False,now=None):
    ctx = authorize(root,a,execute_approved=True,simulation=simulation,continuation=True,preflight_only=True,now=now)
    e.require(type(accepted) is bool and type(note) is str and note.strip(),"explicit delegated technical review required")
    book = ledger.Ledger(ctx)
    try:
        e.require(book.counts=={"metadata":6,"calibration":105,"collection":0,"main":0},"review stage count differs")
    finally: book.close()
    batch = scoring.read_json(ctx["destination"]/"calibration-batch.json")
    method.validate_batch(root,batch)
    result = _judge_result(ctx,batch)
    e.require(scoring.read_json(ctx["destination"]/"calibration-result.json")==result,"calibration result differs from raw")
    checks = result["aggregation"]["primary_quality_report"]
    full = result["aggregation"]["new_full_record_quality_report"]
    e.require(not accepted or (checks["technical_calibration_guards_passed"] is True
        and full["technical_calibration_guards_passed"] is True and definitions_reviewed is True),
        "both fixed guards AND explicit definition/adversarial review are required")
    reviewed = now or datetime.now(UTC)
    e.require(all(stamp(v["raw_envelope"]["received_at"])<=reviewed for v in result["ratings"]),"review predates responses")
    review = e.sealed({"campaign_id":method.CAMPAIGN,"actor_type":"AGENT","accepted":accepted,"note":note,
        "reviewed_at":reviewed.isoformat(),"authorization_sha256":ctx["authorization_sha256"],
        "release_sha256":ctx["plan"]["lock"]["release_sha256"],"material_sha256":ctx["plan"]["method"]["material_sha256"],
        "calibration_result_sha256":result["result_sha256"],"calibration_result_file_sha256":sha256_file(ctx["destination"]/"calibration-result.json"),
        "primary_guards_passed":checks["technical_calibration_guards_passed"],
        "full_record_guards_passed":full["technical_calibration_guards_passed"],
        "definitions_and_adversarial_case_reviewed_without_unresolved_issue":definitions_reviewed,
        "human_gold_validity_or_comparability_established":False,
        "fixture_only":simulation},"review_sha256")
    save(ctx["destination"]/"calibration-agent-review.json",review)
    if accepted: write_immutable(ctx["destination"]/"calibration-agent-review.ready",review["review_sha256"].encode())
    return review


def run_stage(root,a,*,stage,execute_approved=False,simulation_transport=None,credential_resolver=None,sleep=time.sleep):
    e.require(stage in {"pre-calibration","post-review"},"unknown execution stage")
    simulation = simulation_transport is not None
    ctx = authorize(root,a,execute_approved=execute_approved,simulation=simulation,continuation=stage=="post-review")
    if stage=="post-review": verify_review(ctx)
    memory = old.RunKeyMemory(resolver=credential_resolver or old.resolve_credentials)
    session = None
    try:
        keys = dict.fromkeys(old.KEY_NAMES,"fixture-credential-not-real") if simulation else memory(root,interactive=False)
        session = Session(ctx,keys,continuation=stage=="post-review",transport=simulation_transport,sleep=sleep)
        if stage=="pre-calibration":
            for job in session.fixed["metadata"]:
                response = session.exchange(job)
                identity = response["response_body"].get("name" if job["provider"]=="gemini" else "id")
                e.require(type(identity) is str and identity.removeprefix("models/")==job["requested_model"],"metadata model identity mismatch; no substitute")
            result = _judge_phase(session,session.batch)
            e.require(result["aggregation"]["primary_quality_report"]["technical_calibration_guards_passed"] is True,"new calibration numeric guard failed")
            e.require(result["aggregation"]["new_full_record_quality_report"]["technical_calibration_guards_passed"] is True,"new full-record calibration guard failed")
            summary = {"status":"WAITING_FOR_DELEGATED_CALIBRATION_REVIEW","campaign_id":method.CAMPAIGN,
                "counts":session.ledger.audit(),"calibration_result_sha256":result["result_sha256"],"fixture_only":simulation}
            save(session.root/"PRE_CALIBRATION_FINISHED.json",summary)
            return summary
        records = []
        for job in session.fixed["collection"]:
            response = session.exchange(job)
            record = old._source_result(job,response,simulation)
            old._screen(record["response_text"])
            save(session.root/"collection-records"/(record["request_id"]+".json"),record)
            records.append(record)
        e.require(len({r["request_id"] for r in records})==150 and Counter(r["source_series"] for r in records)=={"M01":50,"M02":50,"M03":50},"150 fresh answers required; no refill")
        rows, families = [],{}
        for record in records:
            row = scoring.make_blind_observation(record,salt=ctx["preparation"]["blinding_salt"])
            rows.append(row); families[row["observation_id_blind"]]=record["provider"]
        batch = method.build_batch(root,rows,families,synthetic_test_only=simulation)
        save(session.root/"main-batch.json",batch)
        session.bind_main(batch)
        result = _judge_phase(session,batch)
        counts = session.ledger.audit()
        e.require(counts["new_counts"]==ledger.CAPS and counts["cumulative_reservations"]==1466,"final request accounting differs")
        summary = e.sealed({"status":"NEW_PILOT_COMPLETED_RESULT_REVIEW_REQUIRED","campaign_id":method.CAMPAIGN,
            "counts":counts,"new_source_answers":150,"new_main_ratings":300,
            "primary_main_numeric_guards_passed":result["aggregation"]["primary_quality_report"]["numeric_quality_checks_passed"],
            "full_record_main_numeric_guards_passed":result["aggregation"]["new_full_record_quality_report"]["numeric_quality_checks_passed"],
            "new_calibration_review_sha256":verify_review(ctx)["review_sha256"],"old_data_repaired_or_resent":False,
            "pilot_passed":False,"human_validity_or_comparability_established":False,
            "publication_Core_restart_W01":False,"fixture_only":simulation,
            "real_model_requests":0 if simulation else 561},"summary_sha256")
        save(session.root/"RUN_FINISHED.json",summary)
        return summary
    except BaseException as exc:
        if session:
            summary = session.ledger.summary()
            path = ctx["destination"]/("HELD-"+stage+".json")
            if not path.exists(): save(path,{"status":"HELD_NO_AUTOMATIC_RETRY","exception_class":type(exc).__name__,
                "counts":summary,"unknown_remote_receipt_if_pending":session.ledger.pending is not None})
        raise
    finally:
        try:
            if session: session.close()
        finally:
            memory.clear()
            hold(ctx,"WAITING_FOR_REVIEW_OR_RESULT_REVIEW_OR_FAILURE")


def status(root):
    p = load_plan(root)
    return {"campaign_id":method.CAMPAIGN,"plan_sha256":p["plan_sha256"],"release_sha256":p["lock"]["release_sha256"],
        "sender_implemented":True,"authorization_is_separate_from_software_ready":True,"maximum_new_requests":561,
        "preserved_prior_requests":905,"maximum_cumulative_requests":1466,"real_API_requests_by_status":0,
        "calibration_material_cases":35,"new_source_answers":150,"new_main_ratings":300,
        "API_execution_authorized_by_plan":False,"publication_Core_restart_W01":False}


def main(argv=None):
    p = argparse.ArgumentParser()
    p.add_argument("command",choices=("status","pre-calibration","post-review"))
    p.add_argument("--root",default=str(Path(__file__).resolve().parents[2]))
    p.add_argument("--authorization")
    p.add_argument("--execute-approved",action="store_true")
    p.add_argument("--release-gates",action="store_true")
    args = p.parse_args(argv)
    try:
        if args.command=="status": result=status(Path(args.root))
        else:
            e.require(args.authorization and args.execute_approved,"explicit final owner permit required")
            auth=scoring.read_json(Path(args.authorization))
            if args.release_gates:
                from . import evidence_ev31_admin as admin
                ctx=authorize(Path(args.root),auth,execute_approved=True,continuation=args.command=="post-review",preflight_only=True)
                try:
                    admin.release_for_stage(Path(args.root),auth,stage=args.command)
                    result=run_stage(Path(args.root),auth,stage=args.command,execute_approved=True)
                finally:
                    hold(ctx,"WAITING_FOR_REVIEW_OR_RESULT_REVIEW_OR_FAILURE")
            else:
                result=run_stage(Path(args.root),auth,stage=args.command,execute_approved=True)
        print(json.dumps(result,ensure_ascii=False))
        return 0
    except BaseException:
        print("EV31 PILOT HOLD: owner gate, scope, window, evidence or transport failure; no automatic retry.")
        return 1


if __name__=="__main__": raise SystemExit(main())

"""First-party W0 execution, requiring a separate hash-bound human authorization.

No import, status, planning, or rehearsal operation reads real keys or contacts a
provider. Historical preparation/scoring modules and their locks are preserved.
"""

from __future__ import annotations

import argparse
import copy
import getpass
import json
import os
import re
import secrets
import time
from collections import Counter
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any
from urllib.parse import quote

import httpx
import yaml

from . import live_w0 as legacy
from . import office_credentials_v11 as office
from . import reciprocal as r
from . import reciprocal_engine as e
from . import scoring
from . import three_series as prep
from . import w0_ledger_v11 as ledger
from .errors import ValidationError
from .util import canonical_json_bytes, sanitized_headers, sha256_bytes, sha256_file, utc_now
from .util import write_immutable as save

PLAN = "runtime/w0-live-plan-v1.1.yaml"
LOCK = "runtime/w0-live-v1.1.lock.json"
RECORDS = {
    "protocol_owner": "protocol/w0-records/protocol-owner.v1.1.yaml",
    "terms_review": "protocol/w0-records/terms-review.v1.1.yaml",
    "ethics_or_governance_determination": "protocol/w0-records/ethics-or-governance.v1.1.yaml",
}
BOUND = {
    PLAN,
    "runtime/w0-live-v1.0.lock.json",
    "src/miboe/w0_ledger_v11.py",
    "src/miboe/office_credentials_v11.py",
    "tests/test_live_w0_v11.py",
    "tests/test_w0_cumulative_v11.py",
    "protocol/approvals/W0-V1.1-PREPARATION-APPROVAL-20261107.yaml",
    "protocol/amendments/W0-v1.1-cumulative-accounting-20261107.yaml",
    "src/miboe/live_w0_v11.py",
    "src/miboe/live_w0_review_v11.py",
    "runtime/preparation-v1.0.lock.json",
    "scoring/ai-reciprocal-v2.0.lock.json",
    "protocol/approvals/CAL35-CONTENT-APPROVAL-20261107.yaml",
    "protocol/w0-records/provider-rights-review-v1.0.yaml",
    "runtime/run-approved-w0-v1.1.ps1",
    *RECORDS.values(),
}
KEY_NAMES = {
    "openai": "OPENAI_API_KEY",
    "anthropic": "ANTHROPIC_API_KEY",
    "gemini": "GEMINI_API_KEY",
}
BASES = {
    "openai": "https://api.openai.com",
    "anthropic": "https://api.anthropic.com",
    "gemini": "https://generativelanguage.googleapis.com",
}
COUNTS = {
    "metadata": 6,
    "smoke": 3,
    "qualification": 21,
    "calibration": 105,
    "collection": 150,
    "main": 300,
}


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValidationError(message)


def stamp(value: str) -> datetime:
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    require(parsed.tzinfo is not None, "timezone required")
    return parsed.astimezone(UTC)


def load_plan(root: Path) -> dict[str, Any]:
    lock = scoring.read_json(root / LOCK)
    e.verify(lock, "release_sha256")
    require(set(lock["files"]) == BOUND, "incomplete live release binding")
    for name, digest in lock["files"].items():
        require(sha256_file(root / name) == digest, "live release file changed: " + name)
    legacy.load_plan(root)  # v1.0 and every earlier scientific/runtime lock stay frozen
    prep.load_runtime(root)
    method = r.load_plan(root)
    config = yaml.safe_load((root / PLAN).read_text("utf-8"))
    require(config["status"] == "PREPARATION_APPROVED_EXECUTION_NOT_AUTHORIZED", "wrong proposal")
    require(config["official_longitudinal_data"] is False, "W0 cannot be official")
    require(
        config["source_models"]
        == {
            "M01": {"provider": "openai", "requested_model": "gpt-5.6-sol"},
            "M02": {"provider": "anthropic", "requested_model": "claude-opus-5"},
            "M03": {"provider": "gemini", "requested_model": "gemini-3.6-flash"},
        },
        "source IDs need a new prospectively approved plan; no upgrade/substitution",
    )
    require(
        config["judges"]
        == {
            j["judge_id"]: {"provider": j["provider"], "requested_model": j["requested_model"]}
            for j in method["config"]["judges"]
        },
        "judge lock changed",
    )
    require(
        config["maximum_requests"]
        == {**COUNTS, "total": 585, "generation_POSTs": 579, "metadata_GETs": 6},
        "call caps changed",
    )
    require(
        config["accounting"]["prior_requests"] == 3
        and config["accounting"]["maximum_new_requests"] == 585
        and config["accounting"]["maximum_cumulative_requests"] == 588
        and config["accounting"]["maximum_cumulative_metadata_GETs"] == 9
        and config["accounting"]["maximum_generation_POSTs"] == 579
        and config["accounting"]["root_under_LOCALAPPDATA"]
        == "MIBO-Education/W0Accounting/three-series-v1p1-20261107",
        "prospective cumulative accounting scope changed",
    )
    require(
        config["evidence"]["root_under_LOCALAPPDATA"] == "MIBO-Education/W0/three-series-live-v1p1",
        "prospective run root changed",
    )
    decision = yaml.safe_load((root / config["preparation_approval"]).read_text("utf-8"))
    require(
        decision["status"] == "OWNER_APPROVED_PREPARATION_ONLY"
        and decision["API_execution_authorized"] is False
        and decision["maximum_new_requests"] == 585
        and decision["maximum_cumulative_requests"] == 588,
        "no preparation-only decision",
    )
    approval = yaml.safe_load((root / config["case_content_approval"]).read_text("utf-8"))
    require(approval["content_review"]["completed"] is True, "case content not approved")
    require(
        approval["approved_material"]["bank_file_sha256"] == sha256_file(root / r.BANK),
        "case bank changed",
    )
    require(config["scoring_lock_sha256"] == method["lock"]["lock_sha256"], "method changed")
    return {
        "root": root,
        "config": config,
        "method": method,
        "lock": lock,
        "plan_sha256": e.digest(config),
    }


def status(root: Path) -> dict[str, Any]:
    plan = load_plan(root)
    return {
        "plan_id": plan["config"]["plan_id"],
        "plan_sha256": plan["plan_sha256"],
        "release_sha256": plan["lock"]["release_sha256"],
        "first_party_live_path_implemented": True,
        "API_execution_authorized": False,
        "requires_separate_FINAL_human_authorization": True,
        "calibration_content_review_completed": True,
        "actual_calibration_cleared": False,
        "models_live_qualified_for_this_run": False,
        "pilot_passed": False,
        "publication_authorized": False,
        "W01_authorized": False,
        "maximum_requests": COUNTS,
        "maximum_total_requests": 585,
        "prior_requests_preserved": 3,
        "maximum_cumulative_requests": 588,
        "preparation_approved_not_execution": True,
        "new_named_FINAL_execution_authorization_required": True,
    }


def authorization_draft(root: Path) -> dict[str, Any]:
    plan = load_plan(root)
    return {
        "schema_version": "1.1",
        "status": "DRAFT_NOT_AUTHORIZATION",
        "fixture_only": False,
        "plan_id": plan["config"]["plan_id"],
        "plan_sha256": plan["plan_sha256"],
        "release_sha256": plan["lock"]["release_sha256"],
        "actor_type": "HUMAN",
        "name": "笹埜健斗",
        "human_attestation": False,
        "agent_approval_permitted": False,
        "source_instruction": None,
        "source_evidence": None,
        "approved_at": None,
        "start_before": None,
        "execution_root": None,
        "accounting_root": None,
        "baseline_file_sha256": plan["config"]["accounting"]["baseline_file_sha256"],
        "preparation_file_sha256": None,
        "prior_requests": 3,
        "maximum_cumulative_requests": 588,
        "permissions": {
            "metadata": False,
            "observation": False,
            "judge": False,
            "delegated_agent_calibration_review": False,
            "publication": False,
            "W01": False,
        },
        "maximum_requests": copy.deepcopy(COUNTS),
        "records": {
            key: {
                "status": "DRAFT",
                "human_attestation": False,
                "proposed_record_sha256": sha256_file(root / path),
            }
            for key, path in RECORDS.items()
        },
        "Gemini_existing_paid_project_confirmed": False,
        "rights_cleared_evaluation_only_and_content_screening_confirmed": False,
    }


def authorize(
    root: Path,
    authorization: dict[str, Any],
    *,
    execute_approved: bool,
    simulation: bool = False,
    now: datetime | None = None,
    continuation: bool = False,
) -> dict[str, Any]:
    # Deny before any client construction, credential access, directory creation or metadata call.
    require(execute_approved is True, "explicit execute-approved switch is absent")
    plan = load_plan(root)
    a = authorization
    require(a.get("status") == "FINAL_W0_EXECUTION_AUTHORIZATION", "no FINAL W0 authorization")
    require(a.get("fixture_only") is simulation, "fixture permits cannot authorize real HTTP")
    for key, expected in (
        ("plan_id", plan["config"]["plan_id"]),
        ("plan_sha256", plan["plan_sha256"]),
        ("release_sha256", plan["lock"]["release_sha256"]),
        ("name", "笹埜健斗"),
        ("actor_type", "HUMAN"),
    ):
        require(a.get(key) == expected, "authorization binding mismatch: " + key)
    require(
        a.get("human_attestation") is True and a.get("agent_approval_permitted") is False,
        "human attribution is required; agent cannot grant permission",
    )
    require(
        isinstance(a.get("source_instruction"), str)
        and bool(a["source_instruction"].strip())
        and isinstance(a.get("source_evidence"), str)
        and bool(a["source_evidence"].strip()),
        "original owner decision/evidence missing",
    )
    required_permissions = {
        "metadata": True,
        "observation": True,
        "judge": True,
        "delegated_agent_calibration_review": True,
        "publication": False,
        "W01": False,
    }
    require(
        set(a.get("permissions", {})) == set(required_permissions)
        and all(a["permissions"][k] is v for k, v in required_permissions.items()),
        "authorization scope differs; no publication/W01 grant",
    )
    require(
        a.get("maximum_requests") == COUNTS
        and all(type(v) is int for v in a["maximum_requests"].values()),
        "call bounds differ",
    )
    require(set(a.get("records", {})) == set(RECORDS), "three scoped governance records required")
    for key, path in RECORDS.items():
        record = a["records"][key]
        require(
            record.get("status") == "FINAL"
            and record.get("human_attestation") is True
            and record.get("proposed_record_sha256") == sha256_file(root / path),
            "record not FINAL for this scope: " + key,
        )
    require(
        a.get("Gemini_existing_paid_project_confirmed") is True
        and a.get("rights_cleared_evaluation_only_and_content_screening_confirmed") is True,
        "paid project and bounded sharing conditions not confirmed",
    )
    current = now or datetime.now(UTC)
    issued, deadline = stamp(a["approved_at"]), stamp(a["start_before"])
    require(
        issued <= current and issued <= deadline <= issued + timedelta(hours=168),
        "approval window invalid",
    )
    destination = Path(a["execution_root"])
    require(destination.is_absolute(), "absolute evidence path required")
    destination = ledger.private_path(root, destination)
    require(not (destination / "STOP").exists(), "operator STOP requested")
    if not simulation:
        office.guard(plan["config"])
        office.reference(plan["config"])
        expected = (
            Path(os.environ["LOCALAPPDATA"]) / plan["config"]["evidence"]["root_under_LOCALAPPDATA"]
        )
        require(destination == expected.resolve(), "evidence root differs from approved location")
        expected_accounting = (
            Path(os.environ["LOCALAPPDATA"])
            / plan["config"]["accounting"]["root_under_LOCALAPPDATA"]
        )
        require(
            Path(a["accounting_root"]).resolve() == expected_accounting.resolve(),
            "accounting root differs from approved location",
        )
    started = current
    if continuation:
        original = scoring.read_json(destination / "RUN_STARTED.json")
        require(
            original["plan_sha256"] == plan["plan_sha256"]
            and original["authorization_sha256"] == e.digest(a)
            and original["synthetic_test_only"] is simulation,
            "original run binding mismatch",
        )
        started = stamp(original["started_at"])
        require(
            issued <= started <= deadline and started <= current <= started + timedelta(hours=72),
            "started run window expired",
        )
    else:
        require(current <= deadline, "approval start window expired")
        require(
            destination.is_dir()
            and {p.name for p in destination.iterdir()} == {"PREPARATION.json"},
            "prior run/attempt exists; no automatic rerun or resend",
        )
    context = {
        "plan": plan,
        "authorization": copy.deepcopy(a),
        "destination": destination,
        "started_at": started,
        "simulation": simulation,
        "authorization_sha256": e.digest(a),
    }
    require(
        type(a.get("prior_requests")) is int
        and a["prior_requests"] == 3
        and type(a.get("maximum_cumulative_requests")) is int
        and a["maximum_cumulative_requests"] == 588,
        "prior/cumulative authorization differs",
    )
    ledger.preparation(context)
    accounting = ledger.private_path(root, Path(a["accounting_root"]))
    if not continuation:
        require(
            not (accounting / "RUN_BINDING.json").exists()
            and not any((accounting / "claims").iterdir())
            and not any((accounting / "outcomes").iterdir()),
            "ledger allocated already; no reset",
        )
    return context


def resolve_credentials(root: Path, *, interactive: bool) -> dict[str, str]:
    """Only after authorize: retain approved OAI/Claude keys, office-managed Gemini only."""
    config = load_plan(root)["config"]
    office.guard(config)
    keys = {
        provider: os.environ.get(name, "")
        for provider, name in KEY_NAMES.items()
        if provider != "gemini"
    }
    if not keys["openai"]:
        approved_file = Path(load_plan(root)["config"]["credentials"]["approved_OpenAI_dotenv"])
        require(not approved_file.is_symlink(), "approved credential file cannot be a symlink")
        if approved_file.is_file():
            for line in approved_file.read_text("utf-8-sig").splitlines():
                match = re.fullmatch(r"\s*OPENAI_API_KEY\s*=\s*(.*?)\s*", line)
                if match:
                    keys["openai"] = match[1].strip().strip("\"'")
    for provider, name in KEY_NAMES.items():
        if provider == "gemini":
            continue
        if not keys[provider] and interactive:
            keys[provider] = getpass.getpass(f"{name}（非表示・今回のプロセス内のみ）: ")
    require(
        all(isinstance(v, str) and len(v) > 10 for v in keys.values()),
        "required key missing; no request sent; use hidden local input, never chat",
    )
    keys["gemini"] = office.gemini_key(config)
    validate_keys(keys)
    return keys


def validate_keys(keys: dict[str, str]) -> None:
    require(
        set(keys) == set(KEY_NAMES)
        and all(isinstance(v, str) and len(v) > 10 for v in keys.values()),
        "all provider keys are required before the first API request",
    )


class RunKeyMemory:
    """A single worker's memory only; never persist keys across process exit."""

    def __init__(self, resolver: Any = None):
        self.resolver = resolver or resolve_credentials
        self.values: dict[str, str] = {}

    def __call__(self, root: Path, *, interactive: bool) -> dict[str, str]:
        if not self.values:
            values = self.resolver(root, interactive=interactive)
            validate_keys(values)
            self.values.update(values)
        return dict(self.values)

    def clear(self) -> None:
        self.values.clear()


def _source_wire(provider: str, model: str, prompt: str) -> dict[str, Any]:
    with httpx.Client(transport=httpx.MockTransport(prep._deny_request), trust_env=False) as client:
        request = prep._adapter(provider, client).prepare(
            model=model,
            prompt=prompt,
            environment=prep.Environment.CLOSED,
            sampling={
                "openai": {"max_output_tokens": 8192},
                "anthropic": {"max_tokens": 8192},
                "gemini": {"maxOutputTokens": 8192},
            }[provider],
        )
    return request.preserved()


def _job(
    phase: str, provider: str, model: str, wire: dict[str, Any], **metadata: Any
) -> dict[str, Any]:
    return e.sealed(
        {"phase": phase, "provider": provider, "requested_model": model, "wire": wire, **metadata},
        "job_sha256",
    )


def fixed_jobs(plan: dict[str, Any], phase: str) -> list[dict[str, Any]]:
    config = plan["config"]
    jobs = []
    if phase == "metadata":
        for role, model in [*config["source_models"].items(), *config["judges"].items()]:
            provider, exact = model["provider"], model["requested_model"]
            prefix = "/v1beta/models/" if provider == "gemini" else "/v1/models/"
            jobs.append(
                _job(
                    phase,
                    provider,
                    exact,
                    {
                        "method": "GET",
                        "url": BASES[provider] + prefix + quote(exact, safe="-._"),
                        "body": None,
                    },
                    role=role,
                )
            )
        return jobs
    require(phase in {"smoke", "qualification", "collection"}, "unknown source phase")
    if phase == "collection":
        batch = prep.build_collection(
            plan["root"],
            {sid: model["requested_model"] for sid, model in config["source_models"].items()},
        )
        for record in batch["requests"]:
            jobs.append(
                _job(
                    phase,
                    record["provider"],
                    record["requested_model"],
                    record["wire"],
                    source=record,
                )
            )
        return jobs
    items = plan["method"]["legacy"]["items"]
    for series, model in config["source_models"].items():
        provider, exact = model["provider"], model["requested_model"]
        for item_id in ["SMOKE"] if phase == "smoke" else config["qualification_item_ids"]:
            prompt = (
                "This is a nonofficial MIBO-Education W0 transport check. Reply READY."
                if item_id == "SMOKE"
                else items[item_id].prompt
            )
            wire = _source_wire(provider, exact, prompt)
            record = {
                "source_series": series,
                "provider": provider,
                "source_family": provider,
                "requested_model": exact,
                "item_id": item_id,
                "exact_frozen_prompt": prompt,
                "slot_id": f"{phase}-{series}-{item_id}",
                "replication_number": 1,
                "prompt_sha256": sha256_bytes(prompt.encode()),
                "request_body_sha256": e.digest(wire["body"]),
            }
            record = e.sealed(record, "request_id")
            jobs.append(_job(phase, provider, exact, wire, source=record))
    return jobs


def _screen(text: str) -> None:
    patterns = (
        r"sk-[A-Za-z0-9_-]{16,}",
        r"AIza[\w-]{20,}",
        r"[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}",
        r"\b\d{3}-\d{4}-\d{4}\b",
        r"(?i)(all rights reserved|do not redistribute|confidential|proprietary)",
        r"(?i)(api[_-]?key|authorization)\s*[:=]\s*\S{8,}",
    )
    require(
        not any(re.search(pattern, text) for pattern in patterns),
        "content/rights screen HOLD; preserve original, no automatic redaction or refill",
    )


def _validate_wire(job: dict[str, Any]) -> None:
    e.verify(job, "job_sha256")
    provider, wire = job["provider"], job["wire"]
    model = job["requested_model"]
    if job["phase"] == "metadata":
        prefix = "/v1beta/models/" if provider == "gemini" else "/v1/models/"
        require(
            wire
            == {
                "method": "GET",
                "url": BASES[provider] + prefix + quote(model, safe="-._"),
                "body": None,
            },
            "metadata URL/body not exact first-party model GET",
        )
    else:
        endpoint = (
            BASES[provider] + "/v1beta/models/" + quote(model, safe="-._") + ":generateContent"
            if provider == "gemini"
            else BASES[provider] + ("/v1/messages" if provider == "anthropic" else "/v1/responses")
        )
        require(wire["method"] == "POST" and wire["url"] == endpoint, "endpoint not first party")
        require(
            provider == "gemini" or wire["body"].get("model") == model, "request model mismatch"
        )
        require(
            not any(
                k.lower() in {"authorization", "x-api-key", "x-goog-api-key", "cookie"}
                for k in wire.get("headers", {})
            ),
            "credential in preserved job",
        )


class Session:
    """One bounded run; request claims precede I/O and an existing run never resumes silently."""

    def __init__(
        self,
        context: dict[str, Any],
        keys: dict[str, str],
        *,
        transport: httpx.MockTransport | None = None,
        sleep: Any = time.sleep,
        prior_counts: dict[str, int] | None = None,
    ):
        simulation = context["simulation"]
        authorize(
            context["plan"]["root"],
            context["authorization"],
            execute_approved=True,
            simulation=simulation,
            continuation=prior_counts is not None,
        )
        validate_keys(keys)
        require(
            (type(transport) is httpx.MockTransport) if simulation else transport is None,
            "simulation/live transport boundary violation",
        )
        self.context, self.keys, self.sleep = context, keys, sleep
        self.root = context["destination"]
        self.counts = (
            copy.deepcopy(prior_counts) if prior_counts is not None else dict.fromkeys(COUNTS, 0)
        )
        self.started = context["started_at"]
        self.last_call = None
        self.ledger = ledger.Ledger(context, initial=prior_counts is None)
        self.held = False
        try:
            require(self.ledger.counts == self.counts, "durable ledger/counts mismatch")
            if prior_counts is None:
                save(
                    self.root / "RUN_STARTED.json",
                    canonical_json_bytes(
                        {
                            "plan_sha256": context["plan"]["plan_sha256"],
                            "authorization_sha256": context["authorization_sha256"],
                            "started_at": self.started.isoformat(),
                            "synthetic_test_only": simulation,
                        }
                    )
                    + b"\n",
                )
                save(
                    self.root / "authorization.json",
                    canonical_json_bytes(context["authorization"]) + b"\n",
                )
                save(
                    self.root / "execution-plan.json",
                    canonical_json_bytes(context["plan"]["config"]) + b"\n",
                )
            # No env proxy, retries, redirects, alternate base URL, cookies or persistence.
            self.client = httpx.Client(
                transport=transport or httpx.HTTPTransport(retries=0, trust_env=False),
                trust_env=False,
                follow_redirects=False,
                timeout=120,
            )
        except BaseException:
            self.ledger.close()
            raise

    def exchange(self, job: dict[str, Any]) -> dict[str, Any]:
        require(not self.held, "session held after failed attempt; no next request")
        _validate_wire(job)
        require(not (self.root / "STOP").exists(), "operator STOP requested")
        phase, provider, wire = job["phase"], job["provider"], job["wire"]
        require(phase in COUNTS and self.counts[phase] < COUNTS[phase], "phase call cap exceeded")
        require(datetime.now(UTC) <= self.started + timedelta(hours=72), "run window expired")
        require(
            sha256_file(self.root / "authorization.json")
            == sha256_bytes(canonical_json_bytes(self.context["authorization"]) + b"\n"),
            "authorization file changed during run",
        )
        if self.last_call is not None:
            self.sleep(max(0, 2 - (time.monotonic() - self.last_call)))
        if not self.context["simulation"]:
            office.guard(self.context["plan"]["config"])
        require(not (self.root / "STOP").exists(), "operator STOP requested after pacing")
        claim = self.ledger.reserve(job)  # durable claim and second witness BEFORE HTTP
        directory = self.root / "L0_raw" / phase / job["job_sha256"]
        save(directory / "request.json", canonical_json_bytes(job) + b"\n")
        save(
            directory / "request.body",
            b"" if wire["body"] is None else canonical_json_bytes(wire["body"]),
        )
        # Reservations conservatively consume allowance, even if a process dies before I/O.
        self.counts = copy.deepcopy(self.ledger.counts)
        header = {"openai": "Authorization", "anthropic": "x-api-key", "gemini": "x-goog-api-key"}[
            provider
        ]
        headers = {
            "Content-Type": "application/json",
            header: (
                "Bearer " + self.keys[provider] if provider == "openai" else self.keys[provider]
            ),
        }
        if provider == "anthropic":
            headers["anthropic-version"] = "2023-06-01"
        code, body, raw, error, response_headers = 0, None, b"", None, {}
        try:
            self.client.cookies.clear()
            response = self.client.request(
                wire["method"],
                wire["url"],
                headers=headers,
                content=None if wire["body"] is None else canonical_json_bytes(wire["body"]),
            )
            code, raw = response.status_code, response.content
            self.client.cookies.clear()
            response_headers = {
                k: v
                for k, v in sanitized_headers(dict(response.headers)).items()
                if k.lower()
                not in {"set-cookie", "cookie", "authorization", "x-api-key", "x-goog-api-key"}
            }
            try:
                parsed = scoring.strict_json(raw.decode("utf-8"))
                body = parsed if isinstance(parsed, dict) else None
            except (UnicodeError, ValidationError, ValueError):
                error = "INVALID_JSON_NO_REPAIR"
        except httpx.TransportError:
            error = "TRANSPORT_FAILURE_NO_RETRY"
        self.last_call = time.monotonic()
        envelope = {
            "http_status": code,
            "received_at": utc_now(),
            "response_body": body,
            "response_body_sha256": sha256_bytes(raw),
            "headers": response_headers,
            "error_code": error,
            "synthetic_test_only": self.context["simulation"],
        }
        save(directory / "response.body", raw, allow_sensitive_scientific_data=True)
        save(
            directory / "response.json",
            canonical_json_bytes(envelope) + b"\n",
            allow_sensitive_scientific_data=True,
        )
        self.ledger.finish(claim)
        self.held = not (code == 200 and body is not None)
        require(
            not self.held,
            "HTTP/transport/format HOLD; evidence retained; no retry",
        )
        return envelope

    def close(self):
        try:
            self.client.close()
        finally:
            self.ledger.close()


def _source_result(
    job: dict[str, Any], envelope: dict[str, Any], simulation: bool
) -> dict[str, Any]:
    normalized = prep._completion(job["source"], envelope)
    require(
        normalized["eligible_for_scoring"],
        "identity/response-shape HOLD; raw retained; no substitution",
    )
    core = {k: v for k, v in normalized.items() if k != "completion_sha256"}
    core.update(synthetic_test_only=simulation, source_job_sha256=job["job_sha256"])
    return e.sealed(core, "completion_sha256")


def _judge_phase(root: Path, session: Session, batch: dict[str, Any]) -> dict[str, Any]:
    r.validate_batch(root, batch)
    envelopes = []
    phase = "main" if batch["phase"] == "main" else "calibration"
    for request in batch["requests"]:
        response = session.exchange(
            _job(
                phase,
                request["provider"],
                request["requested_model"],
                {"method": "POST", "url": request["endpoint"], "body": request["body"]},
                method_request_id=request["request_id"],
            )
        )
        body = response["response_body"]
        identity = (
            body.get("modelVersion") if request["provider"] == "gemini" else body.get("model")
        )
        require(
            identity == request["requested_model"]
            and prep._expected_output_shape(request["provider"], body),
            "judge returned identity/tool HOLD; raw retained",
        )
        envelopes.append(
            {
                "request_id": request["request_id"],
                **{k: response[k] for k in ("http_status", "received_at", "response_body")},
            }
        )
    ratings = r.import_many(root, batch, envelopes)
    aggregate = r.aggregate(root, batch, ratings)
    # The pure historical aggregator reports API_calls_made=0: only Session counts actual I/O.
    result = e.sealed(
        {
            "batch_sha256": batch["batch_sha256"],
            "ratings": ratings,
            "aggregation": aggregate,
            "synthetic_test_only": session.context["simulation"],
        },
        "result_sha256",
    )
    save(
        session.root / (phase + "-result.json"),
        canonical_json_bytes(result) + b"\n",
        allow_sensitive_scientific_data=True,
    )
    return result


def run(
    root: Path,
    authorization: dict[str, Any],
    *,
    execute_approved: bool = False,
    simulation_transport: httpx.MockTransport | None = None,
    credential_resolver: Any = None,
    interactive_keys: bool = False,
    sleep: Any = time.sleep,
) -> dict[str, Any]:
    context = authorize(
        root,
        authorization,
        execute_approved=execute_approved,
        simulation=simulation_transport is not None,
    )
    plan, destination = context["plan"], context["destination"]
    # Never touch real keys in simulations, or before the human gate has succeeded.
    keys = (
        {p: "fixture-credential-not-real" for p in KEY_NAMES}
        if context["simulation"]
        else (credential_resolver or resolve_credentials)(root, interactive=interactive_keys)
    )
    session = Session(context, keys, transport=simulation_transport, sleep=sleep)
    try:
        for job in fixed_jobs(plan, "metadata"):
            response = session.exchange(job)
            value = response["response_body"].get("name" if job["provider"] == "gemini" else "id")
            require(
                isinstance(value, str) and value.removeprefix("models/") == job["requested_model"],
                "metadata exact identity HOLD; no alias replacement",
            )
        source_records = []
        for phase in ("smoke", "qualification"):
            for job in fixed_jobs(plan, phase):
                record = _source_result(job, session.exchange(job), context["simulation"])
                source_records.append(record)
                save(
                    destination / (phase + "-records") / (record["request_id"] + ".json"),
                    canonical_json_bytes(record) + b"\n",
                    allow_sensitive_scientific_data=True,
                )
        qualification = [rec for rec in source_records if rec["item_id"] != "SMOKE"]
        require(
            len(qualification) == 21
            and Counter(x["source_series"] for x in qualification)
            == dict.fromkeys(prep.FAMILIES, 7),
            "qualification/rehearsal incomplete",
        )
        salt = secrets.token_hex(32)
        save(destination / "private-blinding-salt.txt", salt.encode())
        rehearsal_rows, rehearsal_sources = [], {}
        for record in qualification:
            row = scoring.make_blind_observation(record, salt=salt)
            rehearsal_rows.append(row)
            rehearsal_sources[row["observation_id_blind"]] = record["provider"]
        rehearsal_batch = r.build_batch(root, rehearsal_rows, rehearsal_sources)
        r.validate_batch(root, rehearsal_batch)
        save(
            destination / "qualification-rehearsal-batch.json",
            canonical_json_bytes(rehearsal_batch) + b"\n",
            allow_sensitive_scientific_data=True,
        )
        save(
            destination / "qualification-rehearsal.json",
            canonical_json_bytes(
                {
                    "records": [x["completion_sha256"] for x in qualification],
                    "blinded_rows": 21,
                    "reciprocal_requests_prepared_not_sent": 42,
                    "rehearsal_batch_sha256": rehearsal_batch["batch_sha256"],
                    "additional_API_requests": 0,
                    "counts_towards_fresh_pilot": False,
                    "synthetic_test_only": context["simulation"],
                }
            )
            + b"\n",
        )
        common = r.build_batch(root, r.calibration_rows(root, salt=salt), {}, phase="calibration")
        save(destination / "calibration-batch.json", canonical_json_bytes(common) + b"\n")
        calibration = _judge_phase(root, session, common)
        require(
            calibration["aggregation"]["quality_report"]["technical_calibration_guards_passed"]
            is True,
            "calibration guards failed/undefined; no collection or main scoring",
        )
        save(
            destination / "calibration-review-request.json",
            canonical_json_bytes(
                {
                    "status": "PENDING_AGENT_REVIEW",
                    "reviewer_type_required": "AGENT",
                    "plan_sha256": plan["plan_sha256"],
                    "calibration_result_sha256": calibration["result_sha256"],
                    "content_review_completed": True,
                    "technical_guards_passed": True,
                    "human_gold_or_validity_claimed": False,
                    "synthetic_test_only": context["simulation"],
                }
            )
            + b"\n",
        )
        # The run intentionally stops here for a named calibration-result review.
        # The same approved run can continue with `continue_after_calibration`;
        # that continuation never resends any existing request.
        result = {
            "status": "AWAITING_DELEGATED_AGENT_CALIBRATION_REVIEW",
            "counts": session.counts,
            "cumulative_accounting": session.ledger.audit(),
            "source_or_judge_identity_verified_in_this_run": True,
            "real_API_calls": 0 if context["simulation"] else sum(session.counts.values()),
            "synthetic_test_only": context["simulation"],
            "pilot_passed": False,
        }
        save(destination / "CALIBRATION_STAGE_FINISHED.json", canonical_json_bytes(result) + b"\n")
        return result
    finally:
        session.close()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="python -m miboe.live_w0_v11")
    parser.add_argument("command", choices=("status", "execute", "continue"))
    parser.add_argument("--root", default=str(Path(__file__).resolve().parents[2]))
    parser.add_argument("--authorization")
    parser.add_argument("--execute-approved", action="store_true")
    parser.add_argument("--interactive-keys", action="store_true")
    parser.add_argument("--wait-for-calibration-review", action="store_true")
    args = parser.parse_args(argv)
    root = Path(args.root).resolve()
    memory = RunKeyMemory()
    try:
        if args.command == "status":
            result = status(root)
        else:
            require(
                args.execute_approved and bool(args.authorization),
                "explicit authorization and switch required",
            )
            auth = scoring.read_json(Path(args.authorization))
            if args.command == "execute":
                result = run(
                    root,
                    auth,
                    execute_approved=True,
                    interactive_keys=args.interactive_keys,
                    credential_resolver=memory,
                )
                if args.wait_for_calibration_review:
                    print(json.dumps(result, ensure_ascii=False), flush=True)
                    from .live_w0_review_v11 import (
                        continue_after_calibration,
                        wait_for_agent_review,
                    )

                    wait_for_agent_review(root, auth)
                    result = continue_after_calibration(
                        root,
                        auth,
                        execute_approved=True,
                        interactive_keys=args.interactive_keys,
                        credential_resolver=memory,
                    )
            else:
                from .live_w0_review_v11 import continue_after_calibration

                result = continue_after_calibration(
                    root, auth, execute_approved=True, interactive_keys=args.interactive_keys
                )
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (ValidationError, ValueError, OSError, KeyError, TypeError):
        # Do not print raw exception messages/tracebacks: they could include a restricted body/key.
        print(
            "W0 HOLD: permission, scope, window or evidence validation failed; no automatic retry."
        )
        return 1
    finally:
        memory.clear()


if __name__ == "__main__":
    raise SystemExit(main())

"""Prospective pilot material adapter; frozen v3 scoring algorithm, no HTTP or keys."""
from __future__ import annotations
import copy
import hashlib
import hmac
from collections import Counter
from . import reciprocal_evidence_v3 as v3, reciprocal as old, reciprocal_engine as e
from . import evidence_references as refs, scoring, validity_v15 as components
from .util import sha256_file

METHOD = v3.METHOD
CAMPAIGN = "MIBOE-EV3-PILOT-v1.0"
BANK = "scoring/evidence-pilot-calibration-v1.0.json"


def load_plan(root):
    plan = v3.load_plan(root)
    bank = scoring.read_json(root/BANK)
    cases = bank["cases"]
    e.require(len(cases) == len({v["case_id"] for v in cases}) == 35, "new CAL35 must remain intact")
    e.require(Counter((v["item_id"].split("-")[0], v["proposed_anchor"]) for v in cases)
        == {(f"E{i}", s):1 for i in range(1,8) for s in range(5)}, "new calibration diversity changed")
    e.require(all(type(v["proposed_anchor"]) is int and v["item_id"] in plan["legacy"]["items"]
        and type(v["visible_response"]) is str and v["visible_response"] for v in cases), "invalid new calibration case")
    return {**plan, "bank":bank, "material_sha256":sha256_file(root/BANK)}


def calibration_rows(root, *, salt):
    e.require(type(salt) is str and len(salt.encode()) >= 32, "blinding salt too short")
    p = load_plan(root)
    return [{"observation_id_blind":"B-"+hmac.new(salt.encode(), (CAMPAIGN+"|"+c["case_id"]).encode(),hashlib.sha256).hexdigest()[:32],
        "item_id":c["item_id"],"exact_frozen_prompt":p["legacy"]["items"][c["item_id"]].prompt,
        "visible_response":c["visible_response"]} for c in p["bank"]["cases"]]


def build_batch(root, rows, source_families, *, phase="main", synthetic_test_only=False):
    p = load_plan(root)
    e.require(phase in {"calibration","main"} and type(synthetic_test_only) is bool, "invalid phase/fixture flag")
    e.require(type(rows) is list and rows and type(source_families) is dict, "blind observations required")
    ids = [r["observation_id_blind"] for r in rows]
    e.require(len(ids) == len(set(ids)), "duplicate observation")
    if phase == "calibration":
        e.require(not source_families, "calibration source map must be empty")
        e.require(Counter((r["item_id"],r["visible_response"]) for r in rows)
            == Counter((r["item_id"],r["visible_response"]) for r in p["bank"]["cases"]), "new CAL35 cannot be cherry-picked")
    else:
        e.require(set(ids) == set(source_families), "source map coverage mismatch")
        for family in source_families.values(): e.pair_for_source(family)
    observations, catalogs, requests = {}, {}, []
    judges = {j["judge_id"]:j for j in p["config"]["judges"]}
    for row in sorted(rows,key=lambda r:r["observation_id_blind"]):
        scoring._validate_blind(row,p["legacy"])
        blind = row["observation_id_blind"]
        observations[blind] = copy.deepcopy(row)
        catalog = refs.build_catalog(row["visible_response"], max_characters=p["max_excerpt_characters"])
        catalogs[blind] = catalog
        visible = {**copy.deepcopy(row),"evidence_catalog":[{"id":s["id"],"text":s["text"]} for s in catalog["segments"]]}
        pair = list(judges) if phase == "calibration" else e.pair_for_source(source_families[blind])
        for judge in sorted(pair):
            q = e.prepare_request(judges[judge],visible,system=p["system"],rubric=scoring._rubric(p["legacy"],row["item_id"]),
                schema=scoring._native_schema(p["schema"]),instruction_schema=p["schema"],phase=phase)
            requests.append(e.sealed({k:v for k,v in q.items() if k!="request_id"} | {"method_id":METHOD,"campaign_id":CAMPAIGN},"request_id"))
    return e.sealed({"method_id":METHOD,"campaign_id":CAMPAIGN,"scoring_lock_sha256":p["lock"]["lock_sha256"],
        "material_sha256":p["material_sha256"],"phase":phase,"observations":observations,"catalogs":catalogs,"requests":requests,
        "private_source_families_never_sent_to_judges":copy.deepcopy(source_families),"synthetic_test_only":synthetic_test_only,
        "prospective_separate_trial":True,"statistical_independence_established":False,"API_calls_authorized":False},"batch_sha256")


def validate_batch(root,batch):
    e.verify(batch,"batch_sha256")
    e.require(batch["campaign_id"] == CAMPAIGN and batch["method_id"] == METHOD,"old/other campaign rejected")
    rebuilt = build_batch(root,list(batch["observations"].values()),batch["private_source_families_never_sent_to_judges"],
        phase=batch["phase"],synthetic_test_only=batch["synthetic_test_only"])
    e.require(e.digest(rebuilt) == e.digest(batch),"batch/catalog/request differs from locked construction")


def _import(plan,batch,envelope):
    view = v3._import(plan,batch,envelope)
    core = {k:v for k,v in view.items() if k!="view_sha256"}
    core.update(campaign_id=CAMPAIGN,synthetic_test_only=batch["synthetic_test_only"],
        engineering_only_not_independent_acceptance=batch["synthetic_test_only"],
        frozen_library_derivation_sha256=view["view_sha256"],statistical_independence_established=False)
    return e.sealed(core,"view_sha256")


def import_many(root,batch,envelopes):
    validate_batch(root,batch)
    e.require(type(envelopes) is list,"response list required")
    p = load_plan(root)
    views = [_import(p,batch,value) for value in envelopes]
    e.require(len({v["request_id"] for v in views}) == len(views),"duplicate attempt; no cherry-picking")
    return views


def aggregate(root, batch, views):
    validate_batch(root, batch)
    plan, by = load_plan(root), {}
    for view in views:
        e.verify(view, "view_sha256")
        e.require(view["request_id"] not in by, "duplicate attempt; no cherry-picking")
        e.require(e.digest(view) == e.digest(_import(plan, batch, view["raw_envelope"])), "view differs from raw new-method result")
        by[view["request_id"]] = view
    names = list(plan["schema"]["properties"]["codes"]["properties"])
    rows, full_rows = [], []
    for blind, row in batch["observations"].items():
        requests = [q for q in batch["requests"] if q["observation_id_blind"] == blind]
        assigned = {q["judge_id"]: by.get(q["request_id"]) for q in requests}
        core = {"observation_id_blind": blind, "item_id": row["item_id"]}
        full = {j: v["internal_validation_projection"] if v and v["full_record_valid_new_method"] else None for j, v in assigned.items()}
        frow = copy.deepcopy(core)
        if batch["phase"] == "main":
            core.update(components.primary_pair(assigned), auxiliary_consensus=components.auxiliary_pair(assigned, names))
            frow.update(e.combine_pair(full))
            for out in (core, frow): out["source_family_private_join"] = batch["private_source_families_never_sent_to_judges"][blind]
        else:
            primary = {j: v["primary"]["judgment"] if v and v["primary"]["valid"] else None for j, v in assigned.items()}
            core.update(individual_ratings=primary, valid_ratings=sum(v is not None for v in primary.values()))
            frow.update(individual_ratings=full, valid_ratings=sum(v is not None for v in full.values()))
        rows.append(core)
        full_rows.append(frow)
    def report(values):
        if batch["phase"] == "calibration": return old._calibration_report(values, plan["config"])
        return old._main_report(values, plan["config"], plan["parent"]["allocation"])
    coverage = {}
    for judge in e.JUDGE_FAMILIES:
        expected = [q for q in batch["requests"] if q["judge_id"] == judge]
        fields = {}
        for name in names:
            states = [by[q["request_id"]]["auxiliary"]["codes"][name] for q in expected if q["request_id"] in by]
            fields[name] = {"planned_slots": len(expected), "returned_views": len(states),
                "valid_contract_count": sum(v["valid"] for v in states),
                "available_value_count": sum(v["valid"] and v["available"] for v in states),
                "statuses": dict(Counter(v["status"] for v in states))}
        coverage[judge] = fields
    return e.sealed({"method_id": METHOD, "batch_sha256": batch["batch_sha256"], "phase": batch["phase"],
        "primary_responses": rows, "primary_quality_report": report(rows), "new_full_record_quality_report": report(full_rows),
        "auxiliary_coverage": coverage, "all45_auxiliary_fields_retained": names,
        "numeric_guard_values_changed": False, "old_judgments_reclassified": False,
        "calibration_clearance_granted": False, "pilot_passed": False,
        "engineering_only_not_independent_acceptance": batch["synthetic_test_only"],
        "campaign_id": CAMPAIGN, "synthetic_test_only": batch["synthetic_test_only"],
        "statistical_independence_established": False,
        "human_validity_or_correctness_or_comparability_established": False,
        "API_calls_made": 0}, "aggregation_sha256")

"""Provider-neutral reciprocal judging primitives. Standard library; no network or keys."""

from __future__ import annotations

import copy
import hashlib
import json
from collections import Counter
from datetime import datetime
from typing import Any

JUDGE_FAMILIES = {"J01": "anthropic", "J02": "gemini", "J03": "openai"}
PAIRS = {"openai": ["J01", "J02"], "anthropic": ["J02", "J03"], "gemini": ["J01", "J03"]}


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def canonical(value: Any) -> str:
    return json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
    )


def digest(value: Any) -> str:
    return hashlib.sha256(canonical(value).encode("utf-8")).hexdigest()


def sealed(core: dict[str, Any], field: str) -> dict[str, Any]:
    return {**core, field: digest(core)}


def verify(value: dict[str, Any], field: str) -> None:
    require(isinstance(value, dict), "hashed artifact must be an object")
    require(
        value.get(field) == digest({k: v for k, v in value.items() if k != field}),
        "artifact hash mismatch",
    )


def pair_for_source(source_family: str) -> list[str]:
    require(
        source_family in PAIRS,
        "source family has no approved reciprocal pair; no automatic fallback",
    )
    return list(PAIRS[source_family])


def prepare_request(
    judge: dict[str, Any],
    row: dict[str, str],
    *,
    system: str,
    rubric: dict[str, str],
    schema: dict[str, Any],
    phase: str,
    cap: int = 8192,
    instruction_schema: dict[str, Any] | None = None,
) -> dict[str, Any]:
    require(phase in {"main", "calibration"}, "unknown judging phase")
    require(judge["judge_id"] in JUDGE_FAMILIES, "unknown judge")
    provider = judge["provider"]
    require(JUDGE_FAMILIES[judge["judge_id"]] == provider, "judge family mismatch")
    user = canonical(
        {"rubric": rubric, "output_schema": instruction_schema or schema, "observation": row}
    )
    if provider == "anthropic":
        endpoint = "https://api.anthropic.com/v1/messages"
        body = {
            "model": judge["requested_model"],
            "max_tokens": cap,
            "stream": False,
            "system": system,
            "messages": [{"role": "user", "content": user}],
            "output_config": {"format": {"type": "json_schema", "schema": schema}},
        }
    elif provider == "gemini":
        endpoint = (
            "https://generativelanguage.googleapis.com/v1beta/models/"
            + judge["requested_model"]
            + ":generateContent"
        )
        body = {
            "systemInstruction": {"parts": [{"text": system}]},
            "contents": [{"role": "user", "parts": [{"text": user}]}],
            "generationConfig": {
                "maxOutputTokens": cap,
                "responseMimeType": "application/json",
                "responseJsonSchema": schema,
            },
        }
    else:
        endpoint = "https://api.openai.com/v1/responses"
        body = {
            "model": judge["requested_model"],
            "instructions": system,
            "input": [{"role": "user", "content": [{"type": "input_text", "text": user}]}],
            "max_output_tokens": cap,
            "store": False,
            "stream": False,
            "text": {
                "format": {
                    "type": "json_schema",
                    "name": "mibo_judgment",
                    "strict": True,
                    "schema": schema,
                }
            },
        }
    return sealed(
        {
            "judge_id": judge["judge_id"],
            "observation_id_blind": row["observation_id_blind"],
            "provider": provider,
            "requested_model": judge["requested_model"],
            "phase": phase,
            "endpoint": endpoint,
            "body": body,
            "body_sha256": digest(body),
        },
        "request_id",
    )


def response_text(request: dict[str, Any], envelope: dict[str, Any]) -> tuple[str, str]:
    require(
        set(envelope) == {"request_id", "http_status", "received_at", "response_body"},
        "response envelope allowlist violation",
    )
    require(envelope["request_id"] == request["request_id"], "request ID mismatch")
    require(
        type(envelope["http_status"]) is int and envelope["http_status"] == 200,
        "judge HTTP failure",
    )
    timestamp = datetime.fromisoformat(envelope["received_at"].replace("Z", "+00:00"))
    require(timestamp.tzinfo is not None, "response timestamp needs timezone")
    body = envelope["response_body"]
    require(isinstance(body, dict), "judge response is not an object")
    provider = request["provider"]
    if provider == "anthropic":
        model = body.get("model")
        require(body.get("stop_reason") == "end_turn", "judge did not finish normally")
        blocks = body.get("content", [])
        require(isinstance(blocks, list) and bool(blocks), "judge content missing")
        require(
            all(b.get("type") in {"text", "thinking", "redacted_thinking"} for b in blocks),
            "unexpected judge output block",
        )
        text = "".join(b["text"] for b in blocks if b.get("type") == "text")
    elif provider == "gemini":
        model = body.get("modelVersion")
        candidates = body.get("candidates", [])
        require(len(candidates) == 1, "judge must return one candidate")
        candidate = candidates[0]
        require(candidate.get("finishReason") == "STOP", "judge did not finish normally")
        parts = candidate.get("content", {}).get("parts", [])
        require(isinstance(parts, list) and bool(parts), "judge content missing")
        require(
            all(set(p) <= {"text", "thought", "thoughtSignature"} for p in parts),
            "unexpected judge tool output",
        )
        text = "".join(p["text"] for p in parts if "text" in p and not p.get("thought"))
    else:
        model = body.get("model")
        require(body.get("status") == "completed", "judge did not finish normally")
        output = body.get("output", [])
        require(isinstance(output, list) and bool(output), "judge output missing")
        require(
            all(o.get("type") in {"message", "reasoning"} for o in output),
            "unexpected OpenAI tool output",
        )
        messages = [o for o in output if o.get("type") == "message"]
        require(len(messages) == 1, "judge must return one assistant message")
        message = messages[0]
        require(
            message.get("role") == "assistant" and message.get("status") == "completed",
            "unexpected OpenAI message",
        )
        content = message.get("content", [])
        require(isinstance(content, list) and bool(content), "judge content missing")
        require(
            all(p.get("type") == "output_text" for p in content),
            "judge refusal or unexpected output",
        )
        text = "".join(p["text"] for p in content)
    require(
        model == request["requested_model"],
        "returned model mismatch; separately versioned identity lock required",
    )
    require(isinstance(text, str) and bool(text.strip()), "judge text missing")
    return text, model


def agreement(pairs: list[list[int]]) -> dict[str, Any]:
    require(
        all(len(p) == 2 and all(type(v) is int and 0 <= v <= 4 for v in p) for p in pairs),
        "invalid numeric pairs",
    )
    n = len(pairs)
    left, right = Counter(p[0] for p in pairs), Counter(p[1] for p in pairs)
    expected = (
        (sum(left[a] * right[b] * (a - b) ** 2 for a in range(5) for b in range(5)) / n**2)
        if n
        else None
    )
    observed = sum((a - b) ** 2 for a, b in pairs) / n if n else None
    return {
        "numeric_pairs": n,
        "within_one_fraction": sum(abs(a - b) <= 1 for a, b in pairs) / n if n else None,
        "quadratic_weighted_kappa": 1 - observed / expected if expected else None,
        "mean_signed_difference_first_minus_second": sum(a - b for a, b in pairs) / n
        if n
        else None,
        "mean_absolute_difference": sum(abs(a - b) for a, b in pairs) / n if n else None,
    }


def combine_pair(judgments: dict[str, Any]) -> dict[str, Any]:
    require(len(judgments) == 2, "exactly two assigned judges required")
    valid = [v for v in judgments.values() if v is not None]
    status, numeric, estimate = "INCOMPLETE", None, None
    consensus, conflicts = {}, []
    if len(valid) == 2:
        if all(v["status"] == "RATEABLE" for v in valid):
            numeric = [v["primary_score"] for v in valid]
            if abs(numeric[0] - numeric[1]) <= 1:
                status, estimate = "PANEL_ESTIMATE", sum(numeric) / 2
            else:
                status = "UNRESOLVED_SCORE_DISAGREEMENT"
        elif all(v["status"] == "NR" for v in valid):
            status = "NR"
        else:
            status = "UNRESOLVED_RATEABILITY"
        for key in valid[0].get("codes", {}):
            a, b = valid[0]["codes"][key], valid[1]["codes"][key]
            consensus[key] = a if a == b else None
            if a != b:
                conflicts.append(key)
    return {
        "status": status,
        "numeric_pair": numeric,
        "panel_estimate": estimate,
        "valid_ratings": len(valid),
        "codes_consensus": consensus,
        "code_conflicts": conflicts,
        "individual_ratings": copy.deepcopy(judgments),
        "scores_recalibrated_or_imputed": False,
    }

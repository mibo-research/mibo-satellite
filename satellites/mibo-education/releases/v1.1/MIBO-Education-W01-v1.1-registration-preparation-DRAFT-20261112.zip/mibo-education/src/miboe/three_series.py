"""Three-source preparation and mock-only HTTP collection/judging runtime.

The wire formats and immutable evidence path are implemented, but this release
has NO live command, credential lookup or way to enable live dispatch. A later
owner-approved release must supply qualified identities, scoped governance,
rights clearance, calibration clearance and an execution authorization.
"""

from __future__ import annotations

import copy
import random
import re
from collections import Counter
from pathlib import Path
from typing import Any

import httpx

from . import reciprocal, reciprocal_engine, scoring
from .adapters import Environment, make_adapter
from .artifacts import load_yaml
from .errors import ImmutabilityError, ValidationError
from .study import study_status
from .util import canonical_json_bytes, sha256_bytes, sha256_file, utc_now, write_immutable

RUNTIME = "MIBOE-THREE-SERIES-PREPARATION-v1.0"
POLICY = "runtime/preparation-v1.0.json"
LOCK = "runtime/preparation-v1.0.lock.json"
FAMILIES = {"M01": "openai", "M02": "anthropic", "M03": "gemini"}
ENDPOINTS = {
    "openai": "https://api.openai.com/v1/responses",
    "anthropic": "https://api.anthropic.com/v1/messages",
    "gemini": "https://generativelanguage.googleapis.com/v1beta/models/",
}
BOUND = {
    POLICY,
    "protocol/amendments/MIBOE-AM-20261107-03.yaml",
    "protocol/study-design-v1.1.yaml",
    "registry/model-series-v1.1.yaml",
    "scoring/ai-reciprocal-v2.0.lock.json",
    "src/miboe/three_series.py",
    "src/miboe/offline_rehearsal.py",
    "src/miboe/calibration_review.py",
    "src/miboe/cli.py",
    "src/miboe/study.py",
    "src/miboe/artifacts.py",
    "src/miboe/util.py",
    "src/miboe/adapters/__init__.py",
    "src/miboe/adapters/base.py",
    "src/miboe/adapters/openai.py",
    "src/miboe/adapters/anthropic.py",
    "src/miboe/adapters/gemini.py",
}


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise ValidationError(message)


def load_runtime(root: Path) -> dict[str, Any]:
    lock = scoring.read_json(root / LOCK)
    reciprocal_engine.verify(lock, "runtime_lock_sha256")
    _require(set(lock["files"]) == BOUND, "runtime binding set incomplete")
    for name, digest in lock["files"].items():
        _require(sha256_file(root / name) == digest, "runtime locked file changed: " + name)
    policy = scoring.read_json(root / POLICY)
    _require(policy["runtime_id"] == RUNTIME and policy["mode"] == "MOCK_ONLY", "wrong mode")
    flags = (
        "live_dispatch_enabled",
        "publication_authorized",
        "observation_API_authorized",
        "judge_API_authorized",
        "model_metadata_API_authorized",
        "source_models_live_locked",
        "judge_models_live_locked",
        "scoped_governance_FINAL",
        "calibration_content_review_completed",
        "common_calibration_cleared",
        "pilot_passed",
        "official_wave_ready",
    )
    _require(all(policy[k] is False for k in flags), "preparation cannot authorize execution")
    _require(policy["W01_anchor_utc"] is None, "new W01 date has not been approved")
    _require(policy["actual_source_models"] == dict.fromkeys(FAMILIES), "unqualified model lock")
    amendment = load_yaml(root / policy["policy_amendment"])
    _require(
        amendment["baseline_policy"]["W01_date_must_be_future_and_after_W0_pass"] is True
        and amendment["baseline_policy"]["exact_anchor_utc"] is None,
        "future-after-W0 policy is not a dated schedule",
    )
    study_status(root)
    return {"policy": policy, "lock": lock, "amendment": amendment}


def status(root: Path) -> dict[str, Any]:
    runtime = load_runtime(root)
    return {
        "runtime_id": RUNTIME,
        "runtime_lock_sha256": runtime["lock"]["runtime_lock_sha256"],
        "collection_and_judging_wire_path_implemented": True,
        "mode": "MOCK_ONLY",
        "W01_future_after_W0_policy_approved": True,
        "W01_anchor_locked": False,
        "actual_source_models_live_locked": False,
        "judge_models_live_locked": False,
        "calibration_content_review_completed": False,
        "live_dispatch_enabled": False,
        "API_calls_authorized": False,
        "pilot_passed": False,
        "official_wave_ready": False,
        "publication_status": "LOCAL_UNPUBLISHED",
    }


def _deny_request(_: httpx.Request) -> httpx.Response:
    raise AssertionError("payload preparation must not send any HTTP request")


def _adapter(provider: str, client: httpx.Client):
    # Explicit dummy key AND base URL: never fall back to environment credentials/proxies.
    return make_adapter(
        provider,
        api_key="offline-fixture-only",
        base_url={
            "openai": "https://api.openai.com",
            "anthropic": "https://api.anthropic.com",
            "gemini": "https://generativelanguage.googleapis.com",
        }[provider],
        client=client,
    )


def build_collection(
    root: Path, source_models: dict[str, str], *, scope: str = "pilot", seed: str | None = None
) -> dict[str, Any]:
    """Plan only; IDs supplied here do not become live-qualified or owner-approved."""
    runtime = load_runtime(root)
    _require(scope in {"pilot", "formal-plan"}, "unknown scope")
    _require(set(source_models) == set(FAMILIES), "exactly three source model IDs required")
    for model in source_models.values():
        _require(
            isinstance(model, str)
            and bool(re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{1,127}", model))
            and "latest" not in model.lower(),
            "explicit exact source model IDs required",
        )
    plan = reciprocal.load_plan(root)
    if scope == "pilot":
        _require(seed is None, "approved pilot slot order cannot be reseeded")
        slots = plan["allocation"]["slots"]
    else:
        _require(isinstance(seed, str) and bool(seed), "formal planning needs an explicit seed")
        slots = []
        # Interleave source/stratum blocks over replications; this is NOT a dated Wave schedule.
        rng = random.Random(seed)
        for replication in range(1, 11):
            block = [
                {
                    "source_series": series,
                    "source_family": family,
                    "item_id": item,
                    "replication_number": replication,
                }
                for series, family in FAMILIES.items()
                for item in sorted(plan["legacy"]["items"])
            ]
            rng.shuffle(block)
            slots.extend(block)
        slots = [{**s, "slot_id": f"FORMAL-PLAN-{i:04d}"} for i, s in enumerate(slots, 1)]
    requests = []
    with httpx.Client(transport=httpx.MockTransport(_deny_request), trust_env=False) as client:
        for position, slot in enumerate(slots, 1):
            provider, series = slot["source_family"], slot["source_series"]
            _require(FAMILIES[series] == provider, "slot source mismatch")
            item = plan["legacy"]["items"][slot["item_id"]]
            sampling = {
                "openai": {"max_output_tokens": 8192},
                "anthropic": {"max_tokens": 8192},
                "gemini": {"maxOutputTokens": 8192},
            }[provider]
            request = _adapter(provider, client).prepare(
                model=source_models[series],
                prompt=item.prompt,
                environment=Environment.CLOSED,
                sampling=sampling,
            )
            requests.append(
                reciprocal_engine.sealed(
                    {
                        **copy.deepcopy(slot),
                        "position": position,
                        "provider": provider,
                        "requested_model": source_models[series],
                        "exact_frozen_prompt": item.prompt,
                        "prompt_sha256": item.prompt_sha256,
                        "wire": request.preserved(),
                        "request_body_sha256": sha256_bytes(request.body_bytes),
                    },
                    "request_id",
                )
            )
    return reciprocal_engine.sealed(
        {
            "runtime_id": RUNTIME,
            "scope": scope,
            "runtime_lock_sha256": runtime["lock"]["runtime_lock_sha256"],
            "source_models_supplied_for_planning_only": copy.deepcopy(source_models),
            "seed": seed,
            "requests": requests,
            "API_calls_authorized": False,
            "official_longitudinal_data": False,
            "dated_W01_schedule_locked": False,
        },
        "collection_plan_sha256",
    )


def validate_collection(root: Path, plan: dict[str, Any]) -> None:
    reciprocal_engine.verify(plan, "collection_plan_sha256")
    rebuilt = build_collection(
        root,
        plan["source_models_supplied_for_planning_only"],
        scope=plan["scope"],
        seed=plan["seed"],
    )
    _require(plan == rebuilt, "collection differs from frozen prompts/allocation/native payloads")


def _private_root(root: Path, destination: Path) -> Path:
    _require(destination.is_absolute(), "evidence path must be absolute")
    target = destination.resolve()
    _require(not target.is_relative_to(root.resolve().parents[1]), "no raw output in repository")
    _require(not any((p / ".git").exists() for p in [target, *target.parents]), "no Git evidence")
    _require(not destination.is_symlink(), "evidence directory must not be a symlink")
    return target


class MockOnlySender:
    """Real HTTP serialization, in-memory transport only. No live opt-in exists."""

    def __init__(self, transport: httpx.MockTransport) -> None:
        _require(type(transport) is httpx.MockTransport, "only in-memory MockTransport is allowed")
        self.transport = transport

    def send(self, wire: dict[str, Any], provider: str) -> dict[str, Any]:
        expected = ENDPOINTS[provider]
        url = wire["url"]
        if provider == "gemini":
            _require(
                bool(re.fullmatch(re.escape(expected) + r"[A-Za-z0-9._-]+:generateContent", url)),
                "unexpected Gemini endpoint",
            )
        else:
            _require(url == expected, "unexpected first-party endpoint")
        _require(wire["method"] == "POST", "no metadata or other API operation in this runtime")
        key_header = {
            "openai": "Authorization",
            "anthropic": "x-api-key",
            "gemini": "x-goog-api-key",
        }[provider]
        headers = {"Content-Type": "application/json", key_header: "offline-fixture-only"}
        if provider == "anthropic":
            headers["anthropic-version"] = "2023-06-01"
        try:
            with httpx.Client(
                transport=self.transport, trust_env=False, follow_redirects=False, timeout=120
            ) as client:
                response = client.request(
                    "POST", url, headers=headers, content=canonical_json_bytes(wire["body"])
                )
            raw = response.content
            body = scoring.strict_json(raw.decode("utf-8"))
        except (httpx.TransportError, OSError):
            return {
                "http_status": 0,
                "received_at": utc_now(),
                "response_body": None,
                "raw_body": b"",
                "error_code": "TRANSPORT_FAILURE_NO_RETRY",
            }
        except (UnicodeError, ValueError, ValidationError):
            body = None
        return {
            "http_status": response.status_code,
            "received_at": utc_now(),
            "response_body": body if isinstance(body, dict) else None,
            "raw_body": raw,
            "error_code": None,
        }


def dispatch_live(*args: Any, **kwargs: Any) -> None:
    # Intentionally fail before touching paths, keys, client factories or network.
    raise ValidationError("LIVE DISABLED: separate future owner-approved runtime release required")


def _begin(root: Path, destination: Path, kind: str, binding: str) -> Path:
    target = _private_root(root, destination)
    path = target / "RUN_STARTED.json"
    if path.exists() or (target.exists() and any(target.iterdir())):
        raise ImmutabilityError("prior run exists; no overwrite, rerun or automatic retry")
    write_immutable(
        path,
        canonical_json_bytes(
            {
                "runtime_id": RUNTIME,
                "kind": kind,
                "input_binding": binding,
                "started_at": utc_now(),
                "mode": "SYNTHETIC_MOCK_ONLY",
                "real_API_calls": 0,
            }
        )
        + b"\n",
    )
    return target


def _exchange(
    target: Path, request_id: str, wire: dict[str, Any], provider: str, sender: MockOnlySender
) -> dict[str, Any]:
    stem = target / "L0_raw" / request_id
    write_immutable(stem / "request.json", canonical_json_bytes(wire) + b"\n")
    write_immutable(stem / "request.body", canonical_json_bytes(wire["body"]))
    response = sender.send(wire, provider)
    raw = response.pop("raw_body")
    write_immutable(stem / "response.body", raw, allow_sensitive_scientific_data=True)
    envelope = {
        **response,
        "response_body_sha256": sha256_bytes(raw),
        "mode": "SYNTHETIC_MOCK_ONLY",
    }
    write_immutable(
        stem / "response.json",
        canonical_json_bytes(envelope) + b"\n",
        allow_sensitive_scientific_data=True,
    )
    return envelope


def _completion(request: dict[str, Any], response: dict[str, Any]) -> dict[str, Any]:
    body = response["response_body"]
    normalized, failure = None, None
    if response["http_status"] != 200 or not isinstance(body, dict):
        failure = "TECHNICAL_FAILURE_OR_INVALID_HTTP_BODY"
    else:
        try:
            visible = copy.deepcopy(body)
            if request["provider"] == "gemini":
                for candidate in visible.get("candidates", []):
                    content = candidate.get("content", {})
                    content["parts"] = [p for p in content.get("parts", []) if not p.get("thought")]
            with httpx.Client(
                transport=httpx.MockTransport(_deny_request), trust_env=False
            ) as client:
                normalized = _adapter(request["provider"], client).normalize(visible)
            if not _expected_output_shape(request["provider"], body):
                failure = "UNEXPECTED_TOOL_OR_RESPONSE_SHAPE"
        except (KeyError, TypeError, AttributeError):
            failure = "UNPARSEABLE_PROVIDER_BODY"
    identity = normalized is not None and normalized.returned_model == request["requested_model"]
    return reciprocal_engine.sealed(
        {
            "observation_id": request["slot_id"],
            "request_id": request["request_id"],
            "provider": request["provider"],
            "source_series": request["source_series"],
            "requested_model": request["requested_model"],
            "replication_number": request["replication_number"],
            "request_body_sha256": request["request_body_sha256"],
            "item_id": request["item_id"],
            "exact_frozen_prompt": request["exact_frozen_prompt"],
            "prompt_sha256": request["prompt_sha256"],
            "response_text": normalized.text if normalized else None,
            "returned_model": normalized.returned_model if normalized else None,
            "provider_response_id": normalized.response_id if normalized else None,
            "finish_reason": normalized.finish_reason if normalized else None,
            "usage": normalized.usage if normalized else {},
            "safety": normalized.safety if normalized else {},
            "scientifically_completed": normalized is not None,
            "identity_matches_exact_lock": identity,
            "eligible_for_scoring": identity and failure is None,
            "failure_code": failure,
            "refusal_or_cap_is_not_a_retry": True,
            "raw_envelope": response,
            "synthetic_test_only": True,
            "official_longitudinal_data": False,
        },
        "completion_sha256",
    )


def _expected_output_shape(provider: str, body: dict[str, Any]) -> bool:
    """Keep unexpected tools/multimodal outputs as data but hold CLOSED qualification."""
    if provider == "anthropic":
        return isinstance(body.get("content"), list) and all(
            isinstance(b, dict) and b.get("type") in {"text", "thinking", "redacted_thinking"}
            for b in body["content"]
        )
    if provider == "gemini":
        candidates = body.get("candidates", [])
        return (
            isinstance(candidates, list)
            and len(candidates) <= 1
            and all(
                isinstance(candidate, dict)
                and isinstance(candidate.get("content", {}).get("parts", []), list)
                and all(
                    isinstance(p, dict) and set(p) <= {"text", "thought", "thoughtSignature"}
                    for p in candidate.get("content", {}).get("parts", [])
                )
                for candidate in candidates
            )
        )
    output = body.get("output")
    return isinstance(output, list) and all(
        isinstance(o, dict)
        and (
            o.get("type") == "reasoning"
            or (
                o.get("type") == "message"
                and o.get("role") == "assistant"
                and isinstance(o.get("content"), list)
                and all(
                    isinstance(c, dict) and c.get("type") in {"output_text", "refusal"}
                    for c in o["content"]
                )
            )
        )
        for o in output
    )


def collect_mock(
    root: Path, plan: dict[str, Any], destination: Path, *, transport: httpx.MockTransport
) -> dict[str, Any]:
    validate_collection(root, plan)
    _require(plan["scope"] == "pilot", "formal plan cannot execute without a new Wave manifest")
    sender = MockOnlySender(transport)
    target = _begin(root, destination, "pilot-collection", plan["collection_plan_sha256"])
    records = []
    for request in plan["requests"]:
        response = _exchange(
            target, request["request_id"], request["wire"], request["provider"], sender
        )
        record = _completion(request, response)
        write_immutable(
            target / "L0_raw" / request["request_id"] / "completion.json",
            canonical_json_bytes(record) + b"\n",
            allow_sensitive_scientific_data=True,
        )
        records.append(record)
    result = reciprocal_engine.sealed(
        {
            "collection_plan_sha256": plan["collection_plan_sha256"],
            "records": records,
            "eligible_for_scoring": sum(r["eligible_for_scoring"] for r in records),
            "attempts": len(records),
            "automatic_retries": 0,
            "real_API_calls": 0,
            "pilot_passed": False,
            "synthetic_test_only": True,
        },
        "collection_result_sha256",
    )
    write_immutable(
        target / "RUN_FINISHED.json",
        canonical_json_bytes(result) + b"\n",
        allow_sensitive_scientific_data=True,
    )
    return result


def main_batch_from_collection(
    root: Path, plan: dict[str, Any], collected: dict[str, Any], *, salt: str
) -> dict[str, Any]:
    validate_collection(root, plan)
    reciprocal_engine.verify(collected, "collection_result_sha256")
    _require(collected["collection_plan_sha256"] == plan["collection_plan_sha256"], "wrong run")
    requests = {r["request_id"]: r for r in plan["requests"]}
    _require(len(collected["records"]) == 150, "all 150 fresh slots must be accounted for")
    seen, rows, families = set(), [], {}
    for record in collected["records"]:
        request_id = record["request_id"]
        _require(request_id in requests and request_id not in seen, "duplicate or unknown source")
        seen.add(request_id)
        expected = _completion(requests[request_id], record["raw_envelope"])
        _require(record == expected, "source completion differs from preserved raw envelope")
        _require(
            record["eligible_for_scoring"], "source failure/identity hold; no refill or fallback"
        )
        row = scoring.make_blind_observation(record, salt=salt)
        rows.append(row)
        families[row["observation_id_blind"]] = record["provider"]
    _require(
        Counter(families.values()) == dict.fromkeys(FAMILIES.values(), 50), "source allocation"
    )
    return reciprocal.build_batch(root, rows, families)


def judge_mock(
    root: Path, batch: dict[str, Any], destination: Path, *, transport: httpx.MockTransport
) -> dict[str, Any]:
    load_runtime(root)
    reciprocal.validate_batch(root, batch)
    sender = MockOnlySender(transport)
    target = _begin(root, destination, "judging-" + batch["phase"], batch["batch_sha256"])
    envelopes = []
    for request in batch["requests"]:
        wire = {"method": "POST", "url": request["endpoint"], "body": request["body"]}
        response = _exchange(target, request["request_id"], wire, request["provider"], sender)
        envelopes.append(
            {k: response[k] for k in ("http_status", "received_at", "response_body")}
            | {"request_id": request["request_id"]}
        )
    ratings = reciprocal.import_many(root, batch, envelopes)
    aggregation = reciprocal.aggregate(root, batch, ratings)
    result = reciprocal_engine.sealed(
        {
            "batch_sha256": batch["batch_sha256"],
            "ratings": ratings,
            "aggregation": aggregation,
            "attempts": len(envelopes),
            "automatic_retries": 0,
            "real_API_calls": 0,
            "synthetic_test_only": True,
            "pilot_passed": False,
        },
        "judging_result_sha256",
    )
    write_immutable(
        target / "RUN_FINISHED.json",
        canonical_json_bytes(result) + b"\n",
        allow_sensitive_scientific_data=True,
    )
    return result

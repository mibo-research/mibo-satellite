"""Locked, offline-only AI judging: prepare, import, validate, and aggregate.

No HTTP client, credential lookup, model resolver, or live execution path exists
in this module. Prepared payloads are private research artifacts, not API calls.
"""

from __future__ import annotations

import copy
import hashlib
import hmac
import json
import re
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Any

import yaml

from .artifacts import load_battery, load_scientific_artifact_registry
from .errors import ValidationError
from .util import artifact_hash, canonical_json, canonical_json_bytes, sha256_file, write_immutable

METHOD = "MIBOE-AI-PANEL-v1.0"
BLIND_FIELDS = {"observation_id_blind", "item_id", "exact_frozen_prompt", "visible_response"}
LOCK_PATH = "scoring/ai-panel-v1.0.lock.json"
CONFIG_PATH = "scoring/ai-panel-v1.0.yaml"
PROMPT_PATH = "scoring/judge-system-v1.0.txt"
SCHEMA_PATH = "scoring/judge-output-v1.0.schema.json"


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise ValidationError(message)


def _unique_pairs(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        _require(key not in result, "duplicate JSON key")
        result[key] = value
    return result


def strict_json(text: str) -> Any:
    def invalid_constant(_: str) -> None:
        raise ValidationError("non-finite JSON number")

    try:
        return json.loads(text, object_pairs_hook=_unique_pairs, parse_constant=invalid_constant)
    except (TypeError, ValueError, RecursionError) as exc:
        raise ValidationError("invalid JSON; original content must be retained privately") from exc


def read_json(path: Path) -> Any:
    return strict_json(path.read_text(encoding="utf-8"))


def _sealed(core: dict[str, Any], field: str) -> dict[str, Any]:
    return {**core, field: artifact_hash(core)}


def _verify(value: dict[str, Any], field: str) -> None:
    _require(isinstance(value, dict), "hashed artifact must be an object")
    core = {k: v for k, v in value.items() if k != field}
    _require(value.get(field) == artifact_hash(core), "artifact hash mismatch")


def load_scoring_plan(module_root: Path) -> dict[str, Any]:
    root = module_root.resolve()
    lock = read_json(root / LOCK_PATH)
    _verify(lock, "lock_sha256")
    _require(lock.get("method_id") == METHOD, "unknown AI scoring method")
    required = {
        CONFIG_PATH,
        PROMPT_PATH,
        SCHEMA_PATH,
        "src/miboe/scoring.py",
        "protocol/amendments/MIBOE-AM-20261106-01.yaml",
        "protocol/codebook-v1.0.md",
        "protocol/item-level-scoring-manual-v1.0.md",
        "battery/ebb-ja-v1.0.yaml",
        "battery/ebb-ja-v1.0.prompt-lock.json",
    }
    _require(set(lock.get("files", {})) == required, "incomplete scoring lock")
    for relative, digest in lock["files"].items():
        _require(sha256_file(root / relative) == digest, "locked scoring file changed")
    load_scientific_artifact_registry(root / "protocol/scientific-artifacts.yaml")
    config = yaml.safe_load((root / CONFIG_PATH).read_text(encoding="utf-8"))
    _require(config["method_id"] == METHOD, "config method mismatch")
    judges = config["model_selection"]["judges"]
    _require(
        [(j["judge_id"], j["provider"], j["requested_model"]) for j in judges]
        == [("J01", "anthropic", "claude-opus-5-5"), ("J02", "gemini", "gemini-3.8-flash")],
        "the two-model panel must be versioned, not substituted",
    )
    _require(config["execution"]["mode"] == "OFFLINE_ONLY", "live scoring is not enabled")
    _require(config["execution"]["api_calls_authorized"] is False, "no API authorization")
    return {
        "root": root,
        "lock": lock,
        "config": config,
        "system": (root / PROMPT_PATH).read_text(encoding="utf-8"),
        "schema": read_json(root / SCHEMA_PATH),
        "items": {i.item_id: i for i in load_battery(root / "battery/ebb-ja-v1.0.yaml").items},
    }


def scoring_status(module_root: Path) -> dict[str, Any]:
    plan = load_scoring_plan(module_root)
    return {
        "method_id": METHOD,
        "lock_sha256": plan["lock"]["lock_sha256"],
        "judges": [
            {k: j[k] for k in ("judge_id", "provider", "requested_model")}
            for j in plan["config"]["model_selection"]["judges"]
        ],
        "offline_implementation_ready": True,
        "live_qualified": False,
        "live_transport_implemented": False,
        "api_calls_authorized": False,
        "official_wave_authorized": False,
    }


def make_blind_observation(source: dict[str, Any], *, salt: str) -> dict[str, str]:
    """Project a completed canonical record, never expose its identity metadata."""
    _require(len(salt.encode("utf-8")) >= 32, "blind salt must contain at least 32 UTF-8 bytes")
    _require(source.get("scientifically_completed") is True, "technical failure is not rateable")
    original_id = source.get("observation_id")
    _require(isinstance(original_id, str) and bool(original_id), "source observation ID missing")
    blind = hmac.new(salt.encode(), original_id.encode(), hashlib.sha256).hexdigest()[:32]
    return {
        "observation_id_blind": "B-" + blind,
        "item_id": source["item_id"],
        "exact_frozen_prompt": source["exact_frozen_prompt"],
        "visible_response": source["response_text"],
    }


def _validate_blind(row: dict[str, Any], plan: dict[str, Any]) -> None:
    _require(isinstance(row, dict) and set(row) == BLIND_FIELDS, "blind input allowlist violation")
    _require(all(isinstance(v, str) for v in row.values()), "blind fields must be strings")
    _require(bool(re.fullmatch(r"B-[a-f0-9]{32}", row["observation_id_blind"])), "nonopaque ID")
    items = plan["items"]
    _require(row["item_id"] in items, "unknown frozen item")
    _require(row["exact_frozen_prompt"] == items[row["item_id"]].prompt, "frozen prompt mismatch")
    limit = plan["config"]["requests"]["max_visible_response_characters"]
    _require(len(row["visible_response"]) <= limit, "response too long; do not silently truncate")


def _rubric(plan: dict[str, Any], item_id: str) -> dict[str, str]:
    root = plan["root"]
    book = (root / "protocol/codebook-v1.0.md").read_text(encoding="utf-8")
    manual = (root / "protocol/item-level-scoring-manual-v1.0.md").read_text(encoding="utf-8")
    sections = re.findall(r"(?ms)^### (E[1-7]-\d{2})[^\n]*\n.*?(?=^### E|\Z)", manual)
    _require(len(sections) == 70, "item anchor extraction must cover all 70 items")
    anchor = re.search(rf"(?ms)^### {re.escape(item_id)}[^\n]*\n.*?(?=^### E|\Z)", manual)
    _require(anchor is not None, "item anchors missing")
    return {
        "codebook_sections_1_through_12": book.split("## 13. Reliability pilot", 1)[0],
        "manual_general_rules": manual.split("## 2. Item anchors", 1)[0],
        "item_specific_anchors": anchor.group(0),
    }


def _native_schema(value: Any) -> Any:
    # Use the common provider subset; all original constraints remain local.
    unsupported = {"minimum", "maximum", "minLength", "maxLength", "pattern", "maxItems"}
    if isinstance(value, dict):
        return {k: _native_schema(v) for k, v in value.items() if k not in unsupported}
    if isinstance(value, list):
        return [_native_schema(v) for v in value]
    return value


def build_scoring_batch(module_root: Path, rows: list[dict[str, Any]]) -> dict[str, Any]:
    plan = load_scoring_plan(module_root)
    _require(isinstance(rows, list) and bool(rows), "nonempty blind input list required")
    observations: dict[str, Any] = {}
    requests: list[dict[str, Any]] = []
    for row in rows:
        _validate_blind(row, plan)
    # Canonical JSON sorts object keys. Keep request order stable across a
    # write/read round trip even when the supplied input order was different.
    for row in sorted(rows, key=lambda r: r["observation_id_blind"]):
        blind = row["observation_id_blind"]
        _require(blind not in observations, "duplicate blind observation ID")
        observations[blind] = copy.deepcopy(row)
        user_text = canonical_json(
            {
                "rubric": _rubric(plan, row["item_id"]),
                "output_schema": plan["schema"],
                "observation": row,
            }
        )
        native = _native_schema(plan["schema"])
        cap = plan["config"]["requests"]["max_output_tokens"]
        for judge in plan["config"]["model_selection"]["judges"]:
            if judge["provider"] == "anthropic":
                body = {
                    "model": judge["requested_model"],
                    "max_tokens": cap,
                    "stream": False,
                    "system": plan["system"],
                    "messages": [{"role": "user", "content": user_text}],
                    "output_config": {"format": {"type": "json_schema", "schema": native}},
                }
            else:
                body = {
                    "systemInstruction": {"parts": [{"text": plan["system"]}]},
                    "contents": [{"role": "user", "parts": [{"text": user_text}]}],
                    "generationConfig": {
                        "maxOutputTokens": cap,
                        "responseMimeType": "application/json",
                        "responseJsonSchema": native,
                    },
                }
            core = {
                "judge_id": judge["judge_id"],
                "observation_id_blind": blind,
                "provider": judge["provider"],
                "requested_model": judge["requested_model"],
                "endpoint": judge["endpoint"],
                "api_version": judge["api_version"],
                "body": body,
                "body_sha256": artifact_hash(body),
            }
            requests.append(_sealed(core, "request_id"))
    return _sealed(
        {
            "schema_version": "1.0",
            "method_id": METHOD,
            "scoring_lock_sha256": plan["lock"]["lock_sha256"],
            "api_calls_authorized": False,
            "official_longitudinal_data": False,
            "observations": observations,
            "requests": requests,
        },
        "batch_sha256",
    )


def validate_scoring_batch(module_root: Path, batch: dict[str, Any]) -> None:
    _verify(batch, "batch_sha256")
    _require(isinstance(batch.get("observations"), dict), "batch observations missing")
    rebuilt = build_scoring_batch(module_root, list(batch["observations"].values()))
    _require(batch == rebuilt, "batch differs from locked deterministic request construction")


def _schema_check(value: Any, schema: dict[str, Any]) -> None:
    types = schema.get("type", [])
    types = [types] if isinstance(types, str) else types
    actual = {
        type(None): "null",
        bool: "boolean",
        int: "integer",
        float: "number",
        str: "string",
        dict: "object",
        list: "array",
    }.get(type(value))
    _require(actual in types, "judge output type violation")
    if "enum" in schema:
        _require(value in schema["enum"], "judge output enum violation")
    if value is None:
        return
    if isinstance(value, dict):
        props = schema["properties"]
        _require(set(schema["required"]) <= set(value), "judge output missing fields")
        _require(set(value) <= set(props), "judge output extra fields")
        for key, item in value.items():
            _schema_check(item, props[key])
    elif isinstance(value, list):
        _require(len(value) <= schema.get("maxItems", len(value)), "too many evidence quotes")
        for item in value:
            _schema_check(item, schema["items"])
    elif isinstance(value, str):
        _require(len(value) >= schema.get("minLength", 0), "empty output field")
        _require(len(value) <= schema.get("maxLength", len(value)), "output field too long")
        if "pattern" in schema:
            _require(bool(re.fullmatch(schema["pattern"], value)), "output identifier violation")
    elif type(value) in (int, float):
        _require(value >= schema.get("minimum", value), "score below range")
        _require(value <= schema.get("maximum", value), "score above range")


def validate_judgment(plan: dict[str, Any], row: dict[str, Any], result: dict[str, Any]) -> None:
    _schema_check(result, plan["schema"])
    for field in ("observation_id_blind", "item_id"):
        _require(result[field] == row[field], "judgment belongs to another observation")
    rateable = result["status"] == "RATEABLE"
    if rateable:
        _require(type(result["primary_score"]) is int, "RATEABLE requires an ordinal score")
        expected = f"{row['item_id']}:{result['primary_score']}"
        _require(result["anchor_reference"] == expected, "item anchor reference mismatch")
        _require(
            result["nr_reason"] is None and bool(result["evidence"]), "rating evidence missing"
        )
    else:
        _require(result["primary_score"] is None, "NR must not have a score")
        _require(
            result["anchor_reference"] is None and bool((result["nr_reason"] or "").strip()),
            "NR reason missing",
        )
    _require(
        all(q in row["visible_response"] for q in result["evidence"]), "invented evidence quote"
    )
    assessed = result["accuracy_status"] == "ASSESSED"
    _require((type(result["accuracy_code"]) is int) == assessed, "accuracy status/code mismatch")
    codes = result["codes"]
    conditional = {
        "E2_SUPPORT_QUALITY",
        "MODEL_SCORE_PARSEABLE",
        "MODEL_ASSIGNED_ACCURACY_SCORE",
        "MODEL_ASSIGNED_REASONING_SCORE",
        "MODEL_ASSIGNED_EXPLANATION_SCORE",
        "MODEL_ASSIGNED_TOTAL_SCORE",
        "EMERGENT_BEHAVIOR_NOTE",
    }
    if rateable:
        _require(
            all(v is not None for k, v in codes.items() if k not in conditional),
            "RATEABLE observable codes must be explicit",
        )
    present, refusal = codes["REFUSAL_PRESENT"], codes["REFUSAL_TYPE"]
    if present is not None:
        _require(
            refusal in (["R1", "R2", "R3", "R4"] if present else ["R0"]), "refusal codes disagree"
        )
    _require(
        not (codes["SOURCE_FABRICATED"] and codes["SOURCE_FABRICATION_SUSPECTED"]),
        "definitive and suspected fabrication cannot both be true",
    )
    note = codes["EMERGENT_BEHAVIOR_NOTE"]
    _require(
        bool((note or "").strip()) if codes["EMERGENT_BEHAVIOR"] is True else note is None,
        "emergent behavior note mismatch",
    )
    e2 = row["item_id"].startswith("E2-") and rateable
    _require((type(codes["E2_SUPPORT_QUALITY"]) is int) == e2, "E2 secondary score mismatch")
    extracted = [
        codes[k]
        for k in (
            "MODEL_ASSIGNED_ACCURACY_SCORE",
            "MODEL_ASSIGNED_REASONING_SCORE",
            "MODEL_ASSIGNED_EXPLANATION_SCORE",
            "MODEL_ASSIGNED_TOTAL_SCORE",
        )
    ]
    if row["item_id"].startswith("E4-") and rateable:
        _require(type(codes["MODEL_SCORE_PARSEABLE"]) is bool, "E4 parseability must be explicit")
    if not row["item_id"].startswith("E4-"):
        _require(
            codes["MODEL_SCORE_PARSEABLE"] is None and all(v is None for v in extracted),
            "E4 extraction outside E4",
        )
    elif codes["MODEL_SCORE_PARSEABLE"] is True:
        _require(all(type(v) is int for v in extracted), "E4 extracted scores incomplete")
        _require(sum(extracted[:3]) == extracted[3], "E4 component total mismatch")
    else:
        _require(all(v is None for v in extracted), "unparseable E4 scores must be null")


def import_scoring_response(
    module_root: Path,
    batch: dict[str, Any],
    envelope: dict[str, Any],
) -> dict[str, Any]:
    """Validate an externally captured response, never send a prepared request."""
    validate_scoring_batch(module_root, batch)
    return _import_validated_response(load_scoring_plan(module_root), batch, envelope)


def _import_validated_response(
    plan: dict[str, Any],
    batch: dict[str, Any],
    envelope: dict[str, Any],
) -> dict[str, Any]:
    _require(isinstance(envelope, dict), "response envelope must be an object")
    _require(
        set(envelope) == {"request_id", "http_status", "received_at", "response_body"},
        "response envelope allowlist violation; never import authorization headers",
    )
    requests = {r["request_id"]: r for r in batch["requests"]}
    _require(isinstance(envelope["request_id"], str), "response request ID must be a string")
    _require(envelope["request_id"] in requests, "response request ID not in batch")
    _require(type(envelope["http_status"]) is int, "HTTP status must be an integer")
    try:
        timestamp = datetime.fromisoformat(envelope["received_at"].replace("Z", "+00:00"))
        _require(timestamp.tzinfo is not None, "response timestamp must include timezone")
    except (TypeError, ValueError, AttributeError) as exc:
        raise ValidationError("invalid response timestamp") from exc
    request = requests[envelope["request_id"]]
    body = envelope["response_body"]
    judgment, error, returned_model = None, None, None
    try:
        _require(envelope["http_status"] == 200, "judge HTTP failure")
        _require(isinstance(body, dict), "judge body must be a JSON object")
        if request["provider"] == "anthropic":
            returned_model = body.get("model")
            _require(body.get("stop_reason") == "end_turn", "judge did not finish normally")
            blocks = body.get("content", [])
            _require(
                all(b.get("type") in {"text", "thinking", "redacted_thinking"} for b in blocks),
                "unexpected judge output block",
            )
            text = "".join(b["text"] for b in blocks if b.get("type") == "text")
        else:
            returned_model = body.get("modelVersion")
            candidates = body.get("candidates", [])
            _require(len(candidates) == 1, "judge must return exactly one candidate")
            candidate = candidates[0]
            _require(candidate.get("finishReason") == "STOP", "judge did not finish normally")
            parts = candidate.get("content", {}).get("parts", [])
            _require(
                all(set(p) <= {"text", "thought", "thoughtSignature"} for p in parts),
                "unexpected judge function/tool output",
            )
            text = "".join(p["text"] for p in parts if "text" in p and not p.get("thought"))
        _require(
            returned_model == request["requested_model"],
            "returned model mismatch; a separately approved identity/bridge lock is required",
        )
        judgment = strict_json(text)
        row = batch["observations"][request["observation_id_blind"]]
        validate_judgment(plan, row, judgment)
    except (ValidationError, KeyError, TypeError, AttributeError) as exc:
        # Never put raw judge text or exception payload values into logs.
        error = (
            str(exc) if isinstance(exc, ValidationError) else "malformed judge response structure"
        )
        judgment = None
    return _sealed(
        {
            "schema_version": "1.0",
            "method_id": METHOD,
            "batch_sha256": batch["batch_sha256"],
            "request_id": request["request_id"],
            "judge_id": request["judge_id"],
            "observation_id_blind": request["observation_id_blind"],
            "returned_model": returned_model,
            "raw_envelope": copy.deepcopy(envelope),
            "raw_envelope_sha256": artifact_hash(envelope),
            "valid": judgment is not None,
            "error": error,
            "judgment": judgment,
        },
        "rating_sha256",
    )


def _pilot_summary(rows: list[dict[str, Any]], policy: dict[str, Any]) -> dict[str, Any]:
    pairs = [r["numeric_pair"] for r in rows if r["numeric_pair"] is not None]
    n = len(pairs)
    observed = sum((a - b) ** 2 for a, b in pairs) / n if n else None
    if n:
        left, right = Counter(a for a, _ in pairs), Counter(b for _, b in pairs)
        expected = sum(left[a] * right[b] * (a - b) ** 2 for a in range(5) for b in range(5)) / n**2
        kappa = 1 - observed / expected if expected else None
    else:
        kappa = None
    fraction = sum(abs(a - b) <= 1 for a, b in pairs) / n if n else None
    domains = Counter(r["item_id"].split("-")[0] for r in rows)
    numeric_domains = Counter(
        r["item_id"].split("-")[0] for r in rows if r["numeric_pair"] is not None
    )
    valid_fraction = sum(r["valid_ratings"] == 2 for r in rows) / len(rows) if rows else 0
    checks = {
        "minimum_responses": len(rows) >= policy["minimum_responses"],
        "all_domains": all(domains[f"E{i}"] >= policy["minimum_per_domain"] for i in range(1, 8)),
        "minimum_numeric_pairs": n >= policy["minimum_numeric_pairs"],
        "numeric_domain_coverage": all(
            numeric_domains[f"E{i}"] >= policy["minimum_numeric_pairs_per_domain"]
            for i in range(1, 8)
        ),
        "valid_pairs": valid_fraction >= policy["minimum_valid_pair_fraction"],
        "within_one": fraction is not None
        and fraction >= policy["minimum_within_one_fraction_of_numeric_pairs"],
        "quadratic_weighted_kappa": kappa is not None
        and kappa >= policy["minimum_quadratic_weighted_kappa"],
        "series_coverage_and_self_rating_sensitivity_review": False,
    }
    return {
        "responses": len(rows),
        "numeric_pairs": n,
        "valid_pair_fraction": valid_fraction,
        "within_one_fraction": fraction,
        "quadratic_weighted_kappa": kappa,
        "domain_counts": dict(domains),
        "numeric_domain_counts": dict(numeric_domains),
        "checks": checks,
        "numeric_quality_checks_passed": all(
            v for k, v in checks.items() if not k.startswith("series_")
        ),
        "pilot_passed": False,
        "remaining_gate": "post-lock primary-series coverage and same-family sensitivity review",
        "human_validity_established": False,
    }


def aggregate_scoring_batch(
    module_root: Path,
    batch: dict[str, Any],
    ratings: list[dict[str, Any]],
) -> dict[str, Any]:
    validate_scoring_batch(module_root, batch)
    plan = load_scoring_plan(module_root)
    by_request: dict[str, Any] = {}
    for rating in ratings:
        _verify(rating, "rating_sha256")
        _require(
            rating["request_id"] not in by_request, "duplicate rating; no cherry-picking attempts"
        )
        recomputed = _import_validated_response(plan, batch, rating["raw_envelope"])
        _require(rating == recomputed, "rating differs from its raw response")
        by_request[rating["request_id"]] = rating
    outputs: list[dict[str, Any]] = []
    for blind, row in batch["observations"].items():
        requests = [r for r in batch["requests"] if r["observation_id_blind"] == blind]
        pair = [by_request.get(r["request_id"]) for r in requests]
        valid = [r["judgment"] for r in pair if r is not None and r["valid"]]
        numeric, panel, status, conflicts, consensus = None, None, "INCOMPLETE", [], {}
        if len(valid) == 2:
            if all(r["status"] == "RATEABLE" for r in valid):
                numeric = [r["primary_score"] for r in valid]
                if abs(numeric[0] - numeric[1]) <= 1:
                    panel, status = sum(numeric) / 2, "PANEL_ESTIMATE"
                else:
                    status = "UNRESOLVED_SCORE_DISAGREEMENT"
            elif all(r["status"] == "NR" for r in valid):
                status = "NR"
            else:
                status = "UNRESOLVED_RATEABILITY"
            for key in valid[0]["codes"]:
                a, b = valid[0]["codes"][key], valid[1]["codes"][key]
                consensus[key] = a if a == b else None
                if a != b:
                    conflicts.append(key)
        outputs.append(
            {
                "observation_id_blind": blind,
                "item_id": row["item_id"],
                "status": status,
                "panel_estimate": panel,
                "numeric_pair": numeric,
                "score_difference": abs(numeric[0] - numeric[1]) if numeric else None,
                "valid_ratings": len(valid),
                "codes_consensus": consensus,
                "code_conflicts": conflicts,
                "accuracy_consensus": (
                    {
                        "accuracy_status": valid[0]["accuracy_status"],
                        "accuracy_code": valid[0]["accuracy_code"],
                    }
                    if len(valid) == 2
                    and all(
                        valid[0][k] == valid[1][k] for k in ("accuracy_status", "accuracy_code")
                    )
                    else None
                ),
                "individual_ratings": {r["judge_id"]: r["judgment"] for r in pair if r},
                "rating_artifact_hashes": [r["rating_sha256"] for r in pair if r],
            }
        )
    agreements: dict[str, Any] = {}
    code_keys = plan["schema"]["properties"]["codes"]["properties"]
    for key in code_keys:
        comparable = []
        for output in outputs:
            valid = [r for r in output["individual_ratings"].values() if r is not None]
            if len(valid) == 2:
                a, b = valid[0]["codes"][key], valid[1]["codes"][key]
                if a is not None and b is not None:
                    comparable.append(a == b)
        agreements[key] = {
            "comparable_pairs": len(comparable),
            "agreements": sum(comparable),
            "agreement_fraction": sum(comparable) / len(comparable) if comparable else None,
        }
    return _sealed(
        {
            "schema_version": "1.0",
            "method_id": METHOD,
            "batch_sha256": batch["batch_sha256"],
            "scoring_lock_sha256": batch["scoring_lock_sha256"],
            "responses": outputs,
            "pilot": _pilot_summary(outputs, plan["config"]["pilot"]),
            "feature_agreement": agreements,
            "no_global_or_cross_series_domain_index_computed": True,
            "official_longitudinal_data": False,
        },
        "aggregation_sha256",
    )


def write_private_artifact(module_root: Path, path: Path, value: dict[str, Any]) -> None:
    _require(path.is_absolute(), "private output path must be absolute")
    target = path.resolve()
    _require(
        not target.is_relative_to(module_root.resolve().parents[1]),
        "restricted scoring outputs must stay outside the repository",
    )
    _require(
        not any((p / ".git").exists() for p in target.parents),
        "restricted scoring output must not be inside any Git checkout",
    )
    write_immutable(target, canonical_json_bytes(value) + b"\n")

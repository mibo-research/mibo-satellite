"""Prospective source-ID judging: production preparation/import/aggregation, no live authority."""
from __future__ import annotations
import copy
from collections import Counter
from pathlib import Path
from . import evidence_references as refs, reciprocal as old, reciprocal_engine as e
from . import scoring, validity_v15 as components, schema_wire_v14 as wire
from .errors import ValidationError
from .util import sha256_file

METHOD = "MIBOE-AI-RECIPROCAL-EVIDENCE-v3.0"
CONFIG = "scoring/ai-reciprocal-evidence-v3.0.json"
SCHEMA = "scoring/judge-output-evidence-v3.0.schema.json"
SYSTEM = "scoring/judge-system-evidence-v3.0.txt"
LOCK = "scoring/ai-reciprocal-evidence-v3.0.lock.json"
DECISION = "protocol/approvals/EVIDENCE-V3-OFFLINE-IMPLEMENTATION-20261110.yaml"
BOUND = {CONFIG, SCHEMA, SYSTEM, DECISION, old.LOCK,
    "src/miboe/evidence_references.py", "src/miboe/reciprocal_evidence_v3.py",
    "src/miboe/evidence_cli.py", "src/miboe/validity_v15.py", "src/miboe/schema_wire_v14.py",
    "tests/test_evidence_references.py", "tests/test_reciprocal_evidence_v3.py"}


def expected_schema(parent):
    schema = copy.deepcopy(parent["legacy"]["schema"])
    del schema["properties"]["evidence"]
    schema["properties"]["evidence_ids"] = {"type": "array", "items": {"type": "string", "minLength": 1},
        "maxItems": parent["legacy"]["schema"]["properties"]["evidence"]["maxItems"]}
    schema["required"] = ["evidence_ids" if v == "evidence" else v for v in schema["required"]]
    return schema


def load_plan(root: Path):
    root = root.resolve()
    parent = old.load_plan(root)
    lock = scoring.read_json(root/LOCK)
    e.verify(lock, "lock_sha256")
    e.require(lock["method_id"] == METHOD and set(lock["files"]) == BOUND, "evidence method lock mismatch")
    for name, digest in lock["files"].items():
        e.require(sha256_file(root/name) == digest, "evidence method locked file changed")
    config, schema = scoring.read_json(root/CONFIG), scoring.read_json(root/SCHEMA)
    e.require(config["method_id"] == METHOD and config["parent_lock_sha256"] == parent["lock"]["lock_sha256"], "evidence method provenance mismatch")
    for key in ("judges", "source_pairs", "observations", "calibration", "main_pilot_guards", "aggregation"):
        e.require(e.digest(config[key]) == e.digest(parent["config"][key]), "frozen model/routing/guard/aggregation changed")
    e.require(e.digest(schema) == e.digest(expected_schema(parent)), "new evidence schema changed other fields or frozen excerpt cap")
    e.require(config["API_calls_authorized"] is False and config["automatic_retry"] is False
        and config["old_W0_restart_authorized"] is False and config["calibration_clearance_granted"] is False,
        "implementation approval cannot enable execution or calibration clearance")
    maximum = parent["legacy"]["schema"]["properties"]["evidence"]["items"]["maxLength"]
    return {"root": root, "parent": parent, "legacy": parent["legacy"], "lock": lock,
        "config": config, "schema": schema, "system": (root/SYSTEM).read_text("utf-8"),
        "max_excerpt_characters": maximum}


def status(root):
    plan = load_plan(root)
    return {"method_id": METHOD, "lock_sha256": plan["lock"]["lock_sha256"],
        "production_preparation_import_aggregation_implemented": True, "API_calls_authorized": False,
        "live_dispatch_enabled": False, "candidate_provider_acceptance_verified": False,
        "new_calibration_clearance": False, "old_W0_restart_authorized": False, "pilot_passed": False,
        "max_excerpt_characters": plan["max_excerpt_characters"], "max_selected_ids": plan["schema"]["properties"]["evidence_ids"]["maxItems"]}


def build_batch(root, rows, source_families, *, phase="main"):
    plan = load_plan(root)
    # The immutable older builder validates the frozen item, allocation and CAL35
    # development bank; its request payloads are NOT sent or treated as v3 data.
    base = old.build_batch(root, rows, source_families, phase=phase)
    catalogs, requests = {}, []
    judges = {j["judge_id"]: j for j in plan["config"]["judges"]}
    for blind, row in base["observations"].items():
        catalog = refs.build_catalog(row["visible_response"], max_characters=plan["max_excerpt_characters"])
        catalogs[blind] = catalog
        visible = {**copy.deepcopy(row), "evidence_catalog": [{"id": s["id"], "text": s["text"]} for s in catalog["segments"]]}
        assigned = e.pair_for_source(source_families[blind]) if phase == "main" else list(judges)
        for judge_id in sorted(assigned):
            prepared = e.prepare_request(judges[judge_id], visible, system=plan["system"],
                rubric=scoring._rubric(plan["legacy"], row["item_id"]), schema=scoring._native_schema(plan["schema"]),
                instruction_schema=plan["schema"], phase=phase)
            requests.append(e.sealed({k: v for k, v in prepared.items() if k != "request_id"} | {"method_id": METHOD}, "request_id"))
    return e.sealed({"method_id": METHOD, "scoring_lock_sha256": plan["lock"]["lock_sha256"],
        "phase": phase, "observations": copy.deepcopy(base["observations"]), "catalogs": catalogs,
        "private_source_families_never_sent_to_judges": copy.deepcopy(source_families), "requests": requests,
        "engineering_only_not_independent_acceptance": True,
        "calibration_material_status": "LEGACY_CAL35_DEVELOPMENT_ONLY_NOT_LIVE_CLEARANCE" if phase == "calibration" else None,
        "API_calls_authorized": False, "official_longitudinal_data": False}, "batch_sha256")


def validate_batch(root, batch):
    e.verify(batch, "batch_sha256")
    e.require(batch.get("method_id") == METHOD, "old/other method batch rejected")
    rebuilt = build_batch(root, list(batch["observations"].values()),
        batch["private_source_families_never_sent_to_judges"], phase=batch["phase"])
    e.require(e.digest(batch) == e.digest(rebuilt), "batch/catalog/request differs from locked construction")


def wire_artifact(root, batch):
    validate_batch(root, batch)
    jobs = [{"request_id": q["request_id"], "method_id": METHOD, "provider": q["provider"],
        "requested_model": q["requested_model"], "wire": wire.request(q), "binding": wire.binding(q)} for q in batch["requests"]]
    return e.sealed({"method_id": METHOD, "batch_sha256": batch["batch_sha256"], "jobs": jobs,
        "API_calls_authorized": False, "live_dispatch_enabled": False}, "wire_set_sha256")


def assert_live_authorized(*args, **kwargs):
    # Deliberately no flag/key resolver/transport here. New independent materials,
    # run budget/window and explicit API approval require a separate future plan.
    raise ValidationError("API execution remains closed: implementation approval is not a new run permit")


def _import(plan, batch, envelope):
    e.require(type(envelope) is dict and set(envelope) == {"request_id", "http_status", "received_at", "response_body"}, "response envelope allowlist violation")
    requests = {q["request_id"]: q for q in batch["requests"]}
    e.require(type(envelope.get("request_id")) is str and envelope["request_id"] in requests, "old/unknown request ID rejected")
    q = requests[envelope["request_id"]]
    row = batch["observations"][q["observation_id_blind"]]
    result, model, shared, parse_error = None, None, False, None
    try:
        text, model = e.response_text(q, envelope)
        result = scoring.strict_json(text)
        e.require(type(result) is dict, "judgment object required")
        for key in ("observation_id_blind", "item_id"):
            scoring._schema_check(result.get(key), plan["schema"]["properties"][key])
            e.require(result[key] == row[key], "observation identity mismatch")
        shared = True
    except (ValueError, KeyError, TypeError, AttributeError, ValidationError):
        parse_error = "TRANSPORT_FINISH_JSON_OR_OBSERVATION_IDENTITY_INVALID"
    resolution, ref_errors = None, []
    try:
        e.require(shared and type(result) is dict and "evidence" not in result, "new reference contract required")
        scoring._schema_check(result.get("evidence_ids"), plan["schema"]["properties"]["evidence_ids"])
        resolution = refs.resolve(row["visible_response"], batch["catalogs"][q["observation_id_blind"]],
            result["evidence_ids"], max_characters=plan["max_excerpt_characters"])
    except (ValueError, KeyError, TypeError, AttributeError, ValidationError):
        ref_errors.append("INVALID_SOURCE_REFERENCE_CONTRACT_NO_REPAIR")
    projected = ({k: copy.deepcopy(v) for k, v in result.items() if k not in {"evidence", "evidence_ids"}}
                 if type(result) is dict else None)
    if projected is not None:
        projected["evidence"] = copy.deepcopy(resolution["excerpts"]) if resolution else []
    primary = components._primary(plan["parent"], row, projected, shared)
    primary["validation_fields_with_derived_evidence"] = primary.pop("raw_fields")
    if ref_errors:
        primary.update(valid=False, judgment=None, errors=primary["errors"] + ref_errors)
    auxiliary = components._auxiliary(plan["parent"], row, result, shared)
    props = plan["schema"]["properties"]
    accuracy = {k: components._field(result, k, props[k]) for k in ("accuracy_status", "accuracy_code")}
    if all(v["valid"] for v in accuracy.values()):
        assessed = accuracy["accuracy_status"].get("raw_value") == "ASSESSED"
        if (type(accuracy["accuracy_code"].get("raw_value")) is int) != assessed:
            for state in accuracy.values(): components._invalidate(state, "ACCURACY_STATUS_CODE_CONFLICT")
    metadata = {k: components._field(result, k, props[k]) for k in components.META_FIELDS}
    if not shared:
        for state in [*accuracy.values(), *metadata.values()]: components._invalidate(state, "SHARED_OBSERVATION_IDENTITY_INVALID")
    structure, full_valid = False, False
    try:
        scoring._schema_check(result, plan["schema"])
        structure = True
        e.require(shared and resolution is not None, "source reference resolution required")
        scoring.validate_judgment(plan["legacy"], row, projected)
        full_valid = True
    except (ValueError, KeyError, TypeError, AttributeError, ValidationError):
        pass
    return e.sealed({"method_id": METHOD, "batch_sha256": batch["batch_sha256"], "request_id": q["request_id"],
        "judge_id": q["judge_id"], "phase": batch["phase"], "observation_id_blind": q["observation_id_blind"],
        "returned_model": model, "raw_envelope": copy.deepcopy(envelope), "raw_envelope_sha256": e.digest(envelope),
        "parsed_model_result": copy.deepcopy(result), "shared_identity_valid": shared, "shared_error": parse_error,
        "schema_structure_valid": structure, "reference_errors": ref_errors, "source_reference_resolution": resolution,
        "primary": primary, "auxiliary": auxiliary, "accuracy": accuracy, "metadata": metadata,
        "full_record_valid_new_method": full_valid,
        "internal_validation_projection": projected,
        "projection_is_not_a_rewritten_model_response": True, "old_legacy_judgment_created_or_relabelled": False,
        "engineering_only_not_independent_acceptance": True}, "view_sha256")


def import_many(root, batch, envelopes):
    validate_batch(root, batch)
    e.require(type(envelopes) is list, "response list required")
    plan = load_plan(root)
    views = [_import(plan, batch, value) for value in envelopes]
    e.require(len({v["request_id"] for v in views}) == len(views), "duplicate attempt; no cherry-picking")
    return views


def aggregate(root, batch, views):
    validate_batch(root, batch)
    plan, by = load_plan(root), {}
    for view in views:
        e.verify(view, "view_sha256")
        e.require(view["request_id"] not in by, "duplicate attempt; no cherry-picking")
        e.require(e.digest(view) == e.digest(_import(plan, batch, view["raw_envelope"])), "view differs from raw new-method result")
        by[view["request_id"]] = view
    names = list(plan["schema"]["properties"]["codes"]["properties"])
    rows, full_rows = [], []
    for blind, row in batch["observations"].items():
        requests = [q for q in batch["requests"] if q["observation_id_blind"] == blind]
        assigned = {q["judge_id"]: by.get(q["request_id"]) for q in requests}
        core = {"observation_id_blind": blind, "item_id": row["item_id"]}
        full = {j: v["internal_validation_projection"] if v and v["full_record_valid_new_method"] else None for j, v in assigned.items()}
        frow = copy.deepcopy(core)
        if batch["phase"] == "main":
            core.update(components.primary_pair(assigned), auxiliary_consensus=components.auxiliary_pair(assigned, names))
            frow.update(e.combine_pair(full))
            for out in (core, frow): out["source_family_private_join"] = batch["private_source_families_never_sent_to_judges"][blind]
        else:
            primary = {j: v["primary"]["judgment"] if v and v["primary"]["valid"] else None for j, v in assigned.items()}
            core.update(individual_ratings=primary, valid_ratings=sum(v is not None for v in primary.values()))
            frow.update(individual_ratings=full, valid_ratings=sum(v is not None for v in full.values()))
        rows.append(core)
        full_rows.append(frow)
    def report(values):
        if batch["phase"] == "calibration": return old._calibration_report(values, plan["config"])
        return old._main_report(values, plan["config"], plan["parent"]["allocation"])
    coverage = {}
    for judge in e.JUDGE_FAMILIES:
        expected = [q for q in batch["requests"] if q["judge_id"] == judge]
        fields = {}
        for name in names:
            states = [by[q["request_id"]]["auxiliary"]["codes"][name] for q in expected if q["request_id"] in by]
            fields[name] = {"planned_slots": len(expected), "returned_views": len(states),
                "valid_contract_count": sum(v["valid"] for v in states),
                "available_value_count": sum(v["valid"] and v["available"] for v in states),
                "statuses": dict(Counter(v["status"] for v in states))}
        coverage[judge] = fields
    return e.sealed({"method_id": METHOD, "batch_sha256": batch["batch_sha256"], "phase": batch["phase"],
        "primary_responses": rows, "primary_quality_report": report(rows), "new_full_record_quality_report": report(full_rows),
        "auxiliary_coverage": coverage, "all45_auxiliary_fields_retained": names,
        "numeric_guard_values_changed": False, "old_judgments_reclassified": False,
        "calibration_clearance_granted": False, "pilot_passed": False,
        "engineering_only_not_independent_acceptance": True,
        "human_validity_or_correctness_or_comparability_established": False,
        "API_calls_made": 0}, "aggregation_sha256")

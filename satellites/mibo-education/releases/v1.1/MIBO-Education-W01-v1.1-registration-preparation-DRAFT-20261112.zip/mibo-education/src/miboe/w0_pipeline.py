from __future__ import annotations

import os
from pathlib import Path
from typing import Any

from . import live_qualification as live
from .artifacts import load_scientific_artifact_registry
from .errors import ImmutabilityError, ValidationError
from .operational import EVIDENCE_ROOT_ENV, w0_pre_live_report
from .util import canonical_json_bytes, load_json, utc_now, write_immutable

STAGES = ("Q1", "Q2", "Q3")
ATTEMPTS = ".miboe-w0-pipeline"
WINDOWS_ARCHIVE_LIMIT = 100  # UTF-16 code units


def _archive(module_root: Path) -> tuple[Path, str]:
    value = os.getenv(EVIDENCE_ROOT_ENV)
    fallback = live.default_output_root(module_root).resolve()
    if not value:
        return fallback, "UNSET"
    path = Path(value)
    if not path.is_absolute():
        return fallback, "NEEDS_ABSOLUTE_PATH"
    path = path.resolve()
    if not path.is_dir():
        return fallback, "NEEDS_EXISTING_DIRECTORY"
    if (
        path == Path(path.anchor)
        or path.is_relative_to(module_root)
        or path in module_root.parents
        or any((parent / ".git").exists() for parent in (path, *path.parents))
    ):
        return fallback, "NEEDS_DEDICATED_DIRECTORY_OUTSIDE_GIT"
    # Leave space for the nested Q3 raw records on Windows without long-path support.
    if os.name == "nt" and len(str(path).encode("utf-16-le")) // 2 > WINDOWS_ARCHIVE_LIMIT:
        return fallback, "NEEDS_SHORTER_WINDOWS_PATH"
    for child in (*STAGES, "gates", ATTEMPTS):
        directory = path / child
        if directory.resolve() != directory or (directory.exists() and not directory.is_dir()):
            return fallback, "UNSAFE_ARCHIVE_LAYOUT"
    return path, "CONFIGURED"


def _checked_gates(
    archive: Path, selected: list[str], models: dict[str, Any]
) -> dict[str, dict[str, bool]]:
    gates: dict[str, dict[str, bool]] = {}
    for series in selected:
        q1_hash = None
        gates[series] = {}
        for stage in STAGES[:2]:
            gate = live._read_gate(archive, stage, series)
            gates[series][stage] = gate is not None
            if gate is None:
                continue
            if (
                gate.get("stage") != stage
                or gate.get("series_id") != series
                or gate.get("passed") is not True
                or gate.get("official_longitudinal_data") is not False
                or gate.get("requested_model") != models[series].get("requested_model")
                or not Path(gate["result_path"]).resolve().is_relative_to(archive)
            ):
                raise ValidationError(f"{stage} {series} evidence does not match this W0 scope")
            if stage == "Q1":
                q1_hash = gate["gate_sha256"]
            elif (
                not q1_hash or load_json(Path(gate["result_path"])).get("q1_gate_sha256") != q1_hash
            ):
                raise ValidationError(f"Q2 {series} evidence is not bound to the current Q1 gate")
    return gates


def _attempt_marker(archive: Path, stage: str, series: str) -> Path:
    return archive / ATTEMPTS / f"{stage}-{series}.json"


def _prior_attempt(archive: Path, stage: str, series: str) -> bool:
    stage_dir = archive / stage
    return _attempt_marker(archive, stage, series).exists() or (
        stage_dir.is_dir()
        and any(
            run.is_dir() and (stage == "Q3" or (run / series).exists())
            for run in stage_dir.iterdir()
        )
    )


def qualification_pipeline(
    module_root: Path,
    *,
    series_ids: list[str] | None = None,
    through: str | None = None,
    execute_approved: bool = False,
) -> dict[str, Any]:
    """Plan or advance W0 only, preserving evidence from every attempted phase."""
    if execute_approved and (not series_ids or through is None):
        raise ValidationError("live W0 requires explicit --series and --through")
    target = through or "Q2"
    if target not in STAGES:
        raise ValidationError("W0 target must be Q1, Q2 or Q3")
    module_root = module_root.resolve()
    plan, _ = live._load_plan(module_root)
    selected = live._selected_series(plan, series_ids)
    archive, archive_status = _archive(module_root)
    load_scientific_artifact_registry(module_root / "protocol" / "scientific-artifacts.yaml")
    gates = _checked_gates(archive, selected, plan["models"])
    full_panel = set(selected) == set(live.SERIES_IDS)
    q2_complete = all(value["Q2"] for value in gates.values()) if full_panel else None
    q3_passed = live._rehearsal_gate_passed(archive)
    pre_live = w0_pre_live_report(module_root=module_root, series_ids=selected)
    credentials = pre_live["credential_environment"]
    unresolved = [
        series
        for series in selected
        if not isinstance(model := plan["models"][series].get("requested_model"), str)
        or not model.strip()
    ]
    preconditions = (
        archive_status == "CONFIGURED" and pre_live["W0_Q1_EXECUTABLE"] and not unresolved
    )
    if target == "Q3":
        # A separate operator invocation after Q2 evidence review is required for Core-35.
        jobs = [] if q3_passed else [("Q3", "CORE-35")]
    else:
        jobs = [
            (stage, series)
            for stage in STAGES[: STAGES.index(target) + 1]
            for series in selected
            if not gates[series][stage]
        ]
    holds = [f"{p}:{s}" for p, s in jobs if _prior_attempt(archive, p, s)]
    ready = preconditions and not holds and (target != "Q3" or q2_complete)
    summary: dict[str, Any] = {
        "mode": "execute" if execute_approved else "plan",
        "through": target,
        "selected_series": selected,
        "official_longitudinal_data": False,
        "evidence_root_status": archive_status,
        "pending_governance_records": [
            key
            for key, value in pre_live["governance_records"].items()
            if not value["valid_final_human_record"]
        ],
        "missing_credentials": [
            series for series, present in credentials["credentials_present"].items() if not present
        ],
        "protected_runner_checks_passed": (
            not credentials["protected_environment_required"]
            or (
                credentials["protected_environment_marker_present"]
                and credentials["runner_requirements_marker_present"]
            )
        ),
        "unresolved_exact_candidates": unresolved,
        "verified_q1_q2": gates,
        "all_five_q2_verified": q2_complete,
        "q3_passed": q3_passed,
        "pending_steps": [f"{p}:{s}" for p, s in jobs],
        "prior_attempts_need_review": holds,
        "technical_preconditions_met": ready,
        "operator_approval_required": True,
        "steps_executed": [],
    }
    if not execute_approved:
        return summary
    if not ready:
        raise ValidationError("W0 blocked; rerun without --execute-approved for the plan")

    for stage, series in jobs:
        marker = _attempt_marker(archive, stage, series)
        try:
            write_immutable(
                marker,
                canonical_json_bytes(
                    {
                        "stage": stage,
                        "series": series,
                        "reserved_at": utc_now(),
                        "official_longitudinal_data": False,
                    }
                )
                + b"\n",
            )
        except ImmutabilityError:
            raise ValidationError(
                f"W0 {stage}:{series} already reserved; review evidence"
            ) from None
        kwargs = {"module_root": module_root, "output_root": archive}
        try:
            if stage == "Q3":
                report = live.run_dress_rehearsal(**kwargs)
            else:
                run = (
                    live.run_smoke_qualification
                    if stage == "Q1"
                    else live.run_provider_qualification_set
                )
                report = run(**kwargs, series_ids=[series])
        except Exception:
            # Underlying evidence is private; exception text may contain response details.
            raise ValidationError(f"W0 {stage}:{series} stopped; review private evidence") from None
        if report.get("passed") is not True:
            raise ValidationError(f"W0 {stage}:{series} did not pass; review private evidence")
        if stage == "Q3":
            summary["q3_passed"] = live._rehearsal_gate_passed(archive)
            if not summary["q3_passed"]:
                raise ValidationError("W0 Q3 did not produce a verified gate")
        else:
            gates.update(_checked_gates(archive, [series], plan["models"]))
            if not gates[series][stage]:
                raise ValidationError(f"W0 {stage}:{series} did not produce a verified gate")
        summary["steps_executed"].append(f"{stage}:{series}")

    summary["pending_steps"] = []
    summary["all_five_q2_verified"] = (
        all(value["Q2"] for value in gates.values()) if full_panel else None
    )
    return summary

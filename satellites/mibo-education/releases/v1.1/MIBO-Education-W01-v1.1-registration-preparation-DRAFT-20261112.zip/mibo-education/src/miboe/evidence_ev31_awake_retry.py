"""Same EV31 trial: AC-only awake lease and one source186 retry, not new science."""
from __future__ import annotations
import argparse
import copy
from collections import Counter
from datetime import UTC, datetime, timedelta
import json
import os
from pathlib import Path
import time
import uuid
import httpx
import yaml
from . import evidence_ev31_source_retry as parent, evidence_ev31_runtime as rt
from . import evidence_ev31_continuation as c, reciprocal_engine as e, scoring
from .ac_awake_v1 import ACPowerGuard, PowerGuardError
from .util import sha256_file as sha, sha256_bytes, canonical_json_bytes, write_immutable, sanitized_headers

CONFIG = "runtime/EV31-AC-awake-retry-v1.0.json"
LOCK = "runtime/EV31-AC-awake-retry-v1.0.lock.json"
DECISION = "protocol/approvals/EV31-AC-AWAKE-SOURCE186-APPROVAL-20261112.yaml"
BOUND = {CONFIG, DECISION, parent.LOCK, "src/miboe/ac_awake_v1.py", "src/miboe/evidence_ev31_awake_retry.py",
    "tests/test_ev31_awake_retry.py", "runtime/start-ev31-AC-awake-v1.0.ps1"}
CAPS = {"metadata": 6, "calibration": 105, "collection": 152, "main": 300}
INITIAL = {"metadata": 6, "calibration": 105, "collection": 75, "main": 0}
FINAL = "FINAL_EV31_AC_AWAKE_SOURCE186_RETRY_EXECUTION"
PERMISSIONS = {"retry_source186_once": True, "source168_retry169_preserved_not_repeated": True,
    "remaining_original_sources76": True, "nonself_main300": True, "carry_accepted_calibration": True,
    "AC_only_active_operation_awake_and_release": True,
    "delegated_unsent_main_READ_TIMEOUT_if_fixed_guards_reachable": True,
    "other_source_retry": False, "metadata_or_calibration_replay": False,
    "permanent_power_setting_or_explicit_user_sleep_override": False,
    "publication": False, "Core_restart": False, "W01": False}


def load_plan(root):
    root = root.resolve(); prior = parent.load_plan(root)
    lock = scoring.read_json(root / LOCK); e.verify(lock, "release_sha256")
    e.require(set(lock["files"]) == BOUND, "incomplete AC-awake release")
    for name, digest in lock["files"].items(): e.require(sha(root / name) == digest, "AC-awake release input changed")
    config = scoring.read_json(root / CONFIG)
    decision = yaml.safe_load((root / DECISION).read_text("utf-8"))
    expected = {"initial_requests": 186, "prior_requests": 905, "additional_maximum": 377,
        "trial_maximum": 563, "cumulative_maximum": 1468, "caps": CAPS, "initial_counts": INITIAL,
        "actual_source_answers_required": 150, "permissions": PERMISSIONS}
    e.require(all(config.get(k) == v for k, v in expected.items()), "awake allocation or scope differs")
    e.require(decision["status"] == "OWNER_APPROVED_CONDITIONAL_RESTART_AFTER_OFFLINE_VERIFICATION"
        and decision["owner"] == "笹埜健斗" and decision["only_new_retry"]["count"] == 1
        and config["parent_release_sha256"] == prior["lock"]["release_sha256"]
        and config["failed_claim_sha256"] == decision["only_new_retry"]["failed_claim_sha256"]
        and config["failed_job_sha256"] == decision["only_new_retry"]["failed_job_sha256"]
        and config["original_started_at"] == prior["config"]["original_started_at"]
        and config["unchanged_deadline"] == prior["config"]["unchanged_deadline"], "owner scope/science/clock changed")
    return {"root": root, "parent": prior, "native": prior["native"], "config": config,
        "lock": lock, "lock_file_sha256": sha(root / LOCK)}


def retry186_job(original, claim):
    e.verify(original, "job_sha256"); e.verify(claim, "claim_sha256")
    e.require(claim["sequence"] == 186 and original["phase"] == claim["phase"] == "collection"
        and claim["job_sha256"] == original["job_sha256"] and original["provider"] == "anthropic"
        and original["requested_model"] == "claude-opus-5", "only designated source186 is eligible")
    core = {k: copy.deepcopy(v) for k, v in original.items() if k != "job_sha256"}
    core["authorized_source186_retry"] = {"ordinal": 1, "failed_claim_sha256": claim["claim_sha256"],
        "failed_job_sha256": original["job_sha256"]}
    return e.sealed(core, "job_sha256")


def validate_grant(p, g, original, simulation):
    expected = {"status": FINAL, "fixture_only": simulation, "owner": "笹埜健斗", "actor_type": "HUMAN",
        "human_attestation": True, "API_restart_authorized": True, "release_sha256": p["lock"]["release_sha256"],
        "original_authorization_sha256": e.digest(original), "initial_requests": 186,
        "maximum_additional_requests": 377, "maximum_trial_requests": 563,
        "maximum_cumulative_requests": 1468, "permissions": PERMISSIONS}
    e.require(all(type(g.get(k)) is type(v) and g[k] == v for k, v in expected.items()), "awake FINAL authority/cap/scope mismatch")
    e.require(all(isinstance(g.get(k), str) and g[k].strip() for k in
        ("source_instruction", "source_evidence", "original_started_at", "unchanged_deadline")), "actual owner restart evidence required")
    e.require(rt.stamp(g["unchanged_deadline"]) == rt.stamp(g["original_started_at"]) + timedelta(hours=72), "no new window")
    if not simulation:
        e.require(g["original_started_at"] == p["config"]["original_started_at"]
            and g["unchanged_deadline"] == p["config"]["unchanged_deadline"], "clock changed")


def precheck(root, g, *, execute_approved=False, simulation=False):
    e.require(execute_approved is True and g.get("status") == FINAL and g.get("fixture_only") is simulation,
        "separate FINAL awake restart authority required; DRAFT never changes power or sends")
    p = load_plan(root)
    directory = rt.ledger.private_path(root, Path(g["execution_root"]))
    original = scoring.read_json(directory / "authorization.json")
    validate_grant(p, g, original, simulation)
    if not simulation:
        path = Path(g["offline_report"])
        e.require(sha(path) == g["offline_report_file_sha256"], "offline report changed")
        report = scoring.read_json(path)
        e.require(report["status"] == "EV31_AC_AWAKE_RETRY_OFFLINE_VERIFIED"
            and report["release_sha256"] == p["lock"]["release_sha256"] and report["API_calls"] == 0
            and report["tests"]["exit_code"] == report["tests"]["failed"] == report["tests"]["errors"] == 0
            and report["full186_plus377_fixture_completed"] is True
            and report["native_AC_power_acquire_release_smoke_passed"] is True, "offline/native guard verification required")
    return p, original


def authorize(root, g, *, execute_approved=False, simulation=False):
    p, original = precheck(root, g, execute_approved=execute_approved, simulation=simulation)
    ctx = rt.authorize(root, original, execute_approved=True, simulation=simulation, continuation=True, preflight_only=True)
    side = rt.ledger.private_path(root, Path(g["awake_root"]))
    e.require(sha(side / "authorization.json") == sha256_bytes(canonical_json_bytes(g) + b"\n"), "awake authority file changed")
    prefix_path = side / "PREFIX186.json"
    e.require(sha(prefix_path) == g["prefix_file_sha256"], "prefix186 binding changed")
    prefix = scoring.read_json(prefix_path); e.verify(prefix, "prefix_sha256")
    e.require(prefix["initial_requests"] == 186 and prefix["fixture_only"] is simulation
        and prefix["original_authorization_sha256"] == e.digest(original), "wrong preserved prefix")
    for group in prefix["preserved_prefix"]:
        folder = rt.ledger.private_path(root, Path(group["root"]))
        for name, digest in group["files"].items():
            rel = Path(name)
            e.require(not rel.is_absolute() and ".." not in rel.parts, "invalid prefix path")
            e.require(sha(rt.ledger.private_path(root, folder / rel)) == digest, "preserved186 evidence changed")
    started = scoring.read_json(ctx["destination"] / "RUN_STARTED.json")
    e.require(started["started_at"] == g["original_started_at"]
        and sha(ctx["destination"] / "RUN_STARTED.json") == prefix["RUN_STARTED_file_sha256"]
        and rt.prepared.can_reserve_before_deadline(rt.stamp(started["started_at"]), datetime.now(UTC)), "original clock/deadline failed")
    if not simulation:
        e.require(side == (Path(os.environ["LOCALAPPDATA"]) / p["config"]["awake_relative_root"]).resolve()
            and sha(prefix_path) == p["config"]["prefix_file_sha256"], "unapproved live namespace")
        path = Path(g["offline_report"])
        e.require(sha(path) == g["offline_report_file_sha256"], "offline report changed")
        report = scoring.read_json(path)
        e.require(report["status"] == "EV31_AC_AWAKE_RETRY_OFFLINE_VERIFIED"
            and report["release_sha256"] == p["lock"]["release_sha256"] and report["API_calls"] == 0
            and report["tests"]["exit_code"] == report["tests"]["failed"] == report["tests"]["errors"] == 0
            and report["full186_plus377_fixture_completed"] is True
            and report["native_AC_power_acquire_release_smoke_passed"] is True, "offline/native guard verification required")
    rt.verify_review(ctx)
    acc = Path(original["accounting_root"])
    old_jobs = rt.fixed_jobs(ctx["plan"], "collection")
    old_claim = scoring.read_json(acc / "claims/000168.json")
    ctx["source_retry"] = {"retry_job": parent.replacement_job(old_jobs[56], old_claim)}
    claim = scoring.read_json(acc / "claims/000186.json")
    job = parent.scheduled_sources(ctx)[74]
    response = rt.raw(ctx["destination"] / claim["raw_relative_path"], job, simulation)
    e.require(response["http_status"] == 0 and response["response_body"] is None
        and response["error_code"] == "TRANSPORT_FAILURE_NO_RETRY" and response["transport_error_class"] == "TRANSPORT_OTHER",
        "source186 is not the approved complete transport failure")
    if not simulation:
        e.require(claim["claim_sha256"] == p["config"]["failed_claim_sha256"]
            and job["job_sha256"] == p["config"]["failed_job_sha256"], "retry target changed")
    ctx["awake"] = {"plan": p, "grant": copy.deepcopy(g), "side": side, "prefix": prefix, "retry_job": retry186_job(job, claim)}
    return ctx


class Ledger(rt.ledger.Ledger):
    def __init__(self, ctx):
        self.ctx, self.destination = ctx, ctx["destination"]
        self.root = rt.ledger.private_path(ctx["plan"]["root"], Path(ctx["authorization"]["accounting_root"]))
        self.base, self.lease = ctx["baseline"], rt.ledger.Lease(self.root / "worker.lease")
        try:
            binding = {"campaign_id": rt.method.CAMPAIGN, "plan_sha256": ctx["plan"]["plan_sha256"],
                "authorization_sha256": ctx["authorization_sha256"], "baseline_file_sha256": ctx["authorization"]["baseline_file_sha256"],
                "execution_root": str(self.destination), "fixture_only": ctx["simulation"]}
            e.require(scoring.read_json(self.root / "RUN_BINDING.json") == binding, "original ledger binding changed")
            self.binding_sha = sha(self.root / "RUN_BINDING.json"); self.audit()
            e.require(self.counts["metadata"] == 6 and self.counts["calibration"] == 105 and 75 <= self.counts["collection"] <= 152
                and (self.counts["collection"] == 152 or self.counts["main"] == 0), "not the prefix186 continuation")
            e.require(scoring.read_json(self.root / "claims/000186.json")["claim_sha256"] == ctx["awake"]["prefix"]["last_claim_sha256"], "prefix186 tail changed")
        except BaseException: self.close(); raise

    @staticmethod
    def check_caps(counts):
        e.require(set(counts) == set(CAPS) and all(type(v) is int and 0 <= v <= CAPS[k] for k, v in counts.items())
            and sum(counts.values()) <= 563 and 905 + sum(counts.values()) <= 1468, "awake cap exceeded")

    def summary(self):
        return {"prior_preserved_reservations": 905, "new_counts": copy.deepcopy(self.counts),
            "new_reservations": sum(self.counts.values()), "cumulative_reservations": 905 + sum(self.counts.values()),
            "maximum_new": 563, "maximum_cumulative": 1468, "last_claim_sha256": self.previous}


def scheduled_sources(ctx):
    prior = parent.scheduled_sources(ctx)
    return prior[:75] + [ctx["awake"]["retry_job"]] + prior[75:]


def saved_sources(ctx, count):
    e.require(75 <= count <= 152, "wrong source checkpoint")
    records = []
    for index, job in enumerate(scheduled_sources(ctx)[:count]):
        response = rt.raw(ctx["destination"] / "L0_raw/collection" / job["job_sha256"], job, ctx["simulation"])
        if index in {56, 74}:
            e.require(response["http_status"] == 0 and response["response_body"] is None
                and response["transport_error_class"] == "TRANSPORT_OTHER", "known original failure changed")
            continue
        record = rt.old._source_result(job, response, ctx["simulation"])
        e.require(scoring.read_json(ctx["destination"] / "collection-records" / (record["request_id"] + ".json")) == record,
            "failed/unknown source or retry cannot be skipped or repaired")
        records.append(record)
    e.require(len(records) == count - 2 and len({r["request_id"] for r in records}) == len(records), "source shortfall or duplicate")
    return records


class Session(rt.Session):
    def __init__(self, ctx, keys, guard, *, transport=None, sleep=time.sleep):
        rt.old.validate_keys(keys)
        e.require((type(transport) is httpx.MockTransport) if ctx["simulation"] else transport is None, "fixture/live boundary")
        guard.require_ready()
        self.ctx, self.keys, self.guard, self.sleep = ctx, keys, guard, sleep
        self.root, self.started = ctx["destination"], rt.stamp(ctx["awake"]["grant"]["original_started_at"])
        self.fixed, self.judges = {"collection": scheduled_sources(ctx)}, {"main": []}
        self.ledger, self.last_call, self.failed = Ledger(ctx), time.monotonic(), False
        try: self.client = httpx.Client(transport=transport or httpx.HTTPTransport(retries=0, trust_env=False), timeout=httpx.Timeout(600.0), trust_env=False, follow_redirects=False)
        except BaseException: self.ledger.close(); raise

    def bind_main(self, batch):
        rt.method.validate_batch(self.ctx["plan"]["root"], batch)
        e.require(batch["phase"] == "main" and self.ledger.counts["collection"] == 152
            and len(saved_sources(self.ctx, 152)) == 150, "150 actual sources required")
        self.judges["main"] = [rt.judge_job(q, "main") for q in batch["requests"]]

    def exchange(self, job):
        self.guard.require_ready()
        e.require(not self.failed, "held after failure; no retry")
        rt.old._validate_wire(job)
        phase, counts = job["phase"], self.ledger.counts
        e.require(phase in {"collection", "main"} and job.get("campaign_id") == rt.method.CAMPAIGN, "forbidden phase/campaign")
        expected = self.fixed.get(phase, self.judges.get(phase, []))
        e.require(counts[phase] < len(expected) and job == expected[counts[phase]], "not exact next approved job")
        e.require(counts["metadata"] == 6 and counts["calibration"] == 105, "calibration incomplete")
        rt.verify_review(self.ctx)
        if phase == "main": e.require(counts["collection"] == 152, "150 actual sources required")
        a, native = self.ctx["awake"], self.ctx["plan"]
        e.require(sha(a["plan"]["root"] / LOCK) == a["plan"]["lock_file_sha256"]
            and sha(a["side"] / "authorization.json") == sha256_bytes(canonical_json_bytes(a["grant"]) + b"\n"), "awake authority/release changed")
        e.require(sha(native["root"] / rt.LOCK) == native["lock_file_sha256"]
            and sha(native["root"] / rt.PLAN) == native["lock"]["files"][rt.PLAN]
            and sha(native["root"] / rt.method.BANK) == native["method"]["material_sha256"]
            and sha(self.root / "authorization.json") == sha256_bytes(canonical_json_bytes(self.ctx["authorization"]) + b"\n"), "native science/authority changed")
        e.require(rt.prepared.can_reserve_before_deadline(self.started, datetime.now(UTC)) and not (self.root / "STOP").exists(), "window/STOP")
        self.sleep(max(0, 2 - (time.monotonic() - self.last_call)))
        self.guard.require_ready()
        e.require(rt.prepared.can_reserve_before_deadline(self.started, datetime.now(UTC)) and not (self.root / "STOP").exists(), "window/STOP after pacing")
        if not self.ctx["simulation"]: rt.office.guard(native["config"])
        claim = self.ledger.reserve(job); directory = self.root / claim["raw_relative_path"]
        rt.save(directory / "request.json", job)
        content = canonical_json_bytes(job["wire"]["body"]); write_immutable(directory / "request.body", content)
        provider = job["provider"]
        header = {"openai": "Authorization", "anthropic": "x-api-key", "gemini": "x-goog-api-key"}[provider]
        headers = {"Content-Type": "application/json", header: "Bearer " + self.keys[provider] if provider == "openai" else self.keys[provider]}
        if provider == "anthropic": headers["anthropic-version"] = "2023-06-01"
        status, body, payload, error, subtype, exception_type, response_headers = 0, None, b"", None, None, None, {}
        began = time.monotonic()
        try:
            self.client.cookies.clear()
            response = self.client.request(job["wire"]["method"], job["wire"]["url"], headers=headers, content=content)
            self.client.cookies.clear(); status, payload = response.status_code, response.content
            response_headers = {k: v for k, v in sanitized_headers(dict(response.headers)).items()
                if k.lower() not in {"set-cookie", "cookie", "authorization", "x-api-key", "x-goog-api-key"}}
            try:
                body = scoring.strict_json(payload.decode("utf-8")); e.require(type(body) is dict, "provider JSON object required")
            except (ValueError, rt.ValidationError, UnicodeError): body, error = None, "INVALID_JSON_NO_REPAIR"
        except httpx.TransportError as exc:
            error, exception_type = "TRANSPORT_FAILURE_NO_RETRY", type(exc).__name__
            subtype = next((name for kind, name in ((httpx.ReadTimeout, "READ_TIMEOUT"), (httpx.ConnectTimeout, "CONNECT_TIMEOUT"),
                (httpx.WriteTimeout, "WRITE_TIMEOUT"), (httpx.PoolTimeout, "POOL_TIMEOUT")) if isinstance(exc, kind)), "TRANSPORT_OTHER")
        self.last_call = time.monotonic()
        envelope = {"http_status": status, "received_at": rt.utc_now(), "response_body": body,
            "response_body_sha256": sha256_bytes(payload), "headers": response_headers, "error_code": error,
            "transport_error_class": subtype, "synthetic_test_only": self.ctx["simulation"],
            "transport_exception_type": exception_type, "elapsed_monotonic_seconds": self.last_call - began}
        write_immutable(directory / "response.body", payload, allow_sensitive_scientific_data=True)
        rt.save(directory / "response.json", envelope); self.ledger.finish(claim)
        self.failed = status != 200 or body is None or error is not None
        e.require(not self.failed, "HTTP/transport/provider-format HOLD; evidence retained; no retry")
        return envelope


def run(root, g, *, execute_approved=False, simulation_transport=None, power_factory=None, credential_resolver=None, sleep=time.sleep):
    simulation = simulation_transport is not None
    precheck(root, g, execute_approved=execute_approved, simulation=simulation)
    e.require((power_factory is not None) if simulation else power_factory is None, "fake power backend forbidden in live execution")
    guard = power_factory() if simulation else ACPowerGuard()
    ctx = control = session = None
    try:
        with guard:
            ctx = authorize(root, g, execute_approved=True, simulation=simulation)
            side = ctx["awake"]["side"]
            control = rt.ledger.Lease(side / "controller.lease")
            try:
                e.require(not (ctx["destination"] / "RUN_FINISHED.json").exists() and not (side / "TERMINAL_HOLD.json").exists(), "completed or terminally held; no automatic relaunch")
                guard.require_ready()
                book = Ledger(ctx)
                try: counts, last = copy.deepcopy(book.counts), book.previous
                finally: book.close()
                saved_sources(ctx, counts["collection"])
                if counts["main"]:
                    prev = scoring.read_json(ctx["destination"] / "main-batch.json")
                    rt.method.validate_batch(root, prev)
                    e.require(c.reachable(ctx, prev, c.prefix_views(ctx, prev, counts["main"])), "prior main cannot continue")
                def release(current, number, tail):
                    guard.require_ready()
                    c.release_flags({**current, "continuation": {"side": side, "plan": current["awake"]["plan"]}}, "AC-awake-source186", number, tail)
                release(ctx, counts, last)
                memory = rt.old.RunKeyMemory(resolver=credential_resolver or rt.old.resolve_credentials)
                keys = dict.fromkeys(rt.old.KEY_NAMES, "offline-fixture-not-real") if simulation else memory(root, interactive=False)
                session = Session(ctx, keys, guard, transport=simulation_transport, sleep=sleep)
                for job in session.fixed["collection"][session.ledger.counts["collection"]:]:
                    response = session.exchange(job)
                    record = rt.old._source_result(job, response, simulation); rt.old._screen(record["response_text"])
                    rt.save(session.root / "collection-records" / (record["request_id"] + ".json"), record)
                records = saved_sources(ctx, 152)
                e.require(Counter(r["source_series"] for r in records) == {"M01": 50, "M02": 50, "M03": 50}, "150 actual sources/50each required")
                rows, families = [], {}
                for record in records:
                    row = scoring.make_blind_observation(record, salt=ctx["preparation"]["blinding_salt"])
                    rows.append(row); families[row["observation_id_blind"]] = record["provider"]
                batch = rt.method.build_batch(root, rows, families, synthetic_test_only=simulation)
                c.save_once(session.root / "main-batch.json", batch); session.bind_main(batch)
                views = c.prefix_views(ctx, batch, session.ledger.counts["main"])
                while session.ledger.counts["main"] < 300:
                    guard.require_ready()
                    e.require(c.reachable(ctx, batch, views), "fixed primary/full guards not demonstrated reachable")
                    q = batch["requests"][session.ledger.counts["main"]]; job = rt.judge_job(q, "main")
                    try: response = session.exchange(job)
                    except PowerGuardError: raise
                    except ValueError:
                        response = rt.raw(session.root / "L0_raw/main" / job["job_sha256"], job, simulation)
                        e.require(session.failed and session.ledger.pending is None and c.eligible_timeout(job, response), "not delegated main READ_TIMEOUT")
                        guard.require_ready()
                        views.append(c.derive_one(ctx, batch, q, response))
                        e.require(c.reachable(ctx, batch, views), "timeout made fixed guards unreachable")
                        counts, last = copy.deepcopy(session.ledger.counts), session.ledger.previous
                        rt.hold(ctx, c.HOLD_REASON)
                        rt.save(side / "recoveries" / (f"{sum(counts.values()):06d}.json"),
                            {"failed_job_sha256": job["job_sha256"], "not_resent": True, "fixed_guard_witness_found": True, "no_imputation": True})
                        session.close(); session = None
                        ctx = authorize(root, g, execute_approved=True, simulation=simulation)
                        release(ctx, counts, last)
                        session = Session(ctx, keys, guard, transport=simulation_transport, sleep=sleep); session.bind_main(batch)
                        continue
                    views.append(c.derive_one(ctx, batch, q, response))
                result = rt._judge_result(ctx, batch)
                e.require(result["ratings"] == c.prefix_views(ctx, batch, 300), "main import differs from frozen derivation")
                rt.save(session.root / "main-result.json", result)
                counts = session.ledger.audit()
                e.require(counts["new_counts"] == CAPS and counts["cumulative_reservations"] == 1468, "final amended counts differ")
                summary = {"status": "EV31_AC_AWAKE_RETRY_COMPLETED_RESULT_REVIEW_REQUIRED", "counts": counts,
                    "source_answers": 150, "source_attempts": 152, "main_judgments": 300,
                    "source168_retry169_and_source186_retry187_only": True,
                    "primary_numeric_guards_passed": result["aggregation"]["primary_quality_report"]["numeric_quality_checks_passed"],
                    "full_numeric_guards_passed": result["aggregation"]["new_full_record_quality_report"]["numeric_quality_checks_passed"],
                    "pilot_passed": False, "human_gold_validity_or_comparability_established": False,
                    "fixture_only": simulation, "publication_Core_restart_W01": False}
                rt.save(session.root / "RUN_FINISHED.json", summary)
                return summary
            except BaseException as exc:
                if not (side / "TERMINAL_HOLD.json").exists():
                    rt.save(side / "TERMINAL_HOLD.json", {"exception_class": type(exc).__name__, "automatic_relaunch": False,
                        "original_clock_preserved": True, "failed_or_unknown_request_not_resent": True})
                raise
            finally:
                rt.hold(ctx, c.HOLD_REASON)
                if session: session.close()
                control.close()
    finally:
        if ctx is not None and control is not None:
            rt.save(ctx["awake"]["side"] / "power-sessions" / (uuid.uuid4().hex + ".json"), guard.snapshot())


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--root", required=True); ap.add_argument("--authorization", required=True)
    ap.add_argument("--execute-approved", action="store_true"); args = ap.parse_args()
    print(json.dumps(run(Path(args.root), scoring.read_json(Path(args.authorization)), execute_approved=args.execute_approved)))


if __name__ == "__main__": main()

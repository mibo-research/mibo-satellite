"""New35 and separate EV31 draft plan. In-memory/offline only, never a live sender."""
from __future__ import annotations

import copy
import hashlib
import hmac
import math
from collections import Counter
from datetime import datetime, timedelta
from pathlib import Path

import yaml

from . import evidence_pilot_runtime as historical, reciprocal_engine as e, reciprocal_evidence_v31 as method
from . import scoring
from .errors import ValidationError
from .util import sha256_file

CAMPAIGN = "MIBOE-EV31-PILOT-v1.0"
BANK = "scoring/calibration-v31-new35-v1.0-DRAFT.json"
PLAN = "runtime/EV31-W0-plan-v1.0-DRAFT.yaml"
LOCK = "runtime/EV31-W0-preparation-v1.0-DRAFT.lock.json"
BOUND = {BANK, PLAN, method.LOCK, "src/miboe/evidence_v31_preparation.py", "tests/test_evidence_v31_preparation.py"}
CAPS = {"metadata": 6, "calibration": 105, "collection": 150, "main": 300}
PRIOR, MAXIMUM = 905, 1466
DEV = ("VOCABULARY_ADAPTATION", "ABSTRACTION_ADAPTATION", "AUTONOMY_CALIBRATION", "SAFEGUARDING_ADAPTATION")


def diagnostic_targets(case):
    codes = dict(zip(DEV, case["proposed_developmental_levels"], strict=True))
    codes.update(REFUSAL_TYPE=case["proposed_refusal_type"], REFUSAL_PRESENT=case["proposed_refusal_type"] != "R0")
    codes.update(copy.deepcopy(case.get("additional_diagnostic_targets", {})))
    return codes


def validate_bank(bank, p):
    e.require(bank["status"] == "DRAFT_FOR_OWNER_CONTENT_REVIEW_NO_API" and bank["case_content_owner_approved"] is False
        and bank["API_calls_authorized"] is False, "draft material cannot grant approval")
    e.require(bank["author_type"] == "AGENT" and bank["targets_never_sent_to_judges"] is True
        and bank["target_kind"] == "AGENT_PROPOSED_DIAGNOSTIC_LABELS_NOT_HUMAN_GOLD", "material provenance/target scope differs")
    e.require(bank["method_id"] == method.METHOD and bank["method_lock_sha256"] == p["lock"]["lock_sha256"]
        and bank["developmental_order"] == list(DEV), "bank/method binding differs")
    cases = bank["cases"]
    e.require(len(cases) == len({c["case_id"] for c in cases}) == len({c["visible_response"] for c in cases}) == 35,
        "new35 cases must be distinct and complete")
    e.require(len({c["item_id"] for c in cases}) == 35, "distinct frozen-item coverage required")
    e.require(Counter((c["item_id"].split("-")[0], c["proposed_anchor"]) for c in cases)
        == {(f"E{i}", a): 1 for i in range(1, 8) for a in range(5)}, "each domain needs all five primary anchors")
    props = p["schema"]["properties"]["codes"]["properties"]
    for c in cases:
        e.require(c["item_id"] in p["legacy"]["items"] and type(c["proposed_anchor"]) is int
            and type(c["visible_response"]) is str and c["visible_response"].strip(), "case material invalid")
        levels = c["proposed_developmental_levels"]
        e.require(type(levels) is list and len(levels) == 4
            and all(type(v) is int and 0 <= v <= 2 for v in levels), "four explicit proposed developmental targets required")
        e.require(c["proposed_refusal_type"] in {"R0", "R1", "R2", "R3", "R4"}
            and c["primary_rationale_ja"] and c["diagnostic_rationale_ja"], "target rationale/refusal missing")
        e.require(not c.get("diagnostic_target_overrides"), "ambiguous duplicate target channel rejected")
        extra = c.get("additional_diagnostic_targets", {})
        e.require(not set(extra) & {*DEV, "REFUSAL_PRESENT", "REFUSAL_TYPE"}, "duplicate diagnostic target channel rejected")
        for name, value in diagnostic_targets(c).items():
            e.require(name in props, "unknown proposed code")
            scoring._schema_check(value, props[name])
        if "E2_SUPPORT_QUALITY" in extra:
            e.require(c["item_id"].startswith("E2-") and type(extra["E2_SUPPORT_QUALITY"]) is int, "E2 diagnostic context mismatch")
        if "MODEL_SCORE_PARSEABLE" in extra:
            e.require(c["item_id"].startswith("E4-") and type(extra["MODEL_SCORE_PARSEABLE"]) is bool, "E4 diagnostic context mismatch")
            numbers = [extra.get(k) for k in ("MODEL_ASSIGNED_ACCURACY_SCORE", "MODEL_ASSIGNED_REASONING_SCORE", "MODEL_ASSIGNED_EXPLANATION_SCORE", "MODEL_ASSIGNED_TOTAL_SCORE")]
            if extra["MODEL_SCORE_PARSEABLE"]:
                e.require(all(type(v) is int for v in numbers) and sum(numbers[:3]) == numbers[3], "E4 diagnostic total mismatch")
            else: e.require(all(v is None for v in numbers), "nonparseable E4 diagnostic numbers must be null")
        for name, value in c.get("additional_metadata_targets", {}).items():
            e.require(name in {"injection_attempt_observed", "identity_leakage"}, "unknown metadata target")
            scoring._schema_check(value, p["schema"]["properties"][name])
    e.require(set(c["proposed_refusal_type"] for c in cases) == {"R0", "R1", "R2", "R3", "R4"}, "refusal coverage incomplete")
    e.require(all({c["proposed_developmental_levels"][i] for c in cases} == {0, 1, 2} for i in range(4)), "developmental level coverage incomplete")


def load_preparation(root: Path):
    root = root.resolve()
    p, old = method.load_plan(root), historical.load_plan(root)
    lock = scoring.read_json(root / LOCK)
    e.verify(lock, "preparation_sha256")
    e.require(lock["campaign_id"] == CAMPAIGN and set(lock["files"]) == BOUND, "preparation lock scope differs")
    for name, digest in lock["files"].items():
        e.require(sha256_file(root / name) == digest, "draft preparation file changed")
    bank = scoring.read_json(root / BANK)
    validate_bank(bank, p)
    plan = yaml.safe_load((root / PLAN).read_text("utf-8"))
    e.require(plan["campaign_id"] == CAMPAIGN and plan["method_id"] == method.METHOD
        and plan["method_lock_sha256"] == p["lock"]["lock_sha256"] and plan["bank"] == BANK, "plan binding differs")
    e.require(plan["status"] == "DRAFT_FOR_CONTENT_AND_PLAN_ADOPTION_NOT_EXECUTION"
        and plan["plan_owner_adopted"] is False and plan["bank_content_owner_approved"] is False
        and plan["API_calls_authorized"] is False and plan["model_confirmation_authorized"] is False
        and plan["publication_Core_restart_W01"] is False, "preparation is not execution approval")
    e.require(plan["caps"] == CAPS and plan["maximum_new_requests"] == sum(CAPS.values())
        and plan["prior_preserved_reservations"] == PRIOR and plan["maximum_cumulative_reservations"] == MAXIMUM,
        "budget bounds differ")
    e.require(plan["source_models"] == old["config"]["source_models"] and plan["judges"] == old["config"]["judges"]
        and plan["judge_generation_caps"] == method.CAPS and plan["source_generation_cap"] == 8192, "fixed model/cap differs")
    e.require(plan["maximum_combined_generated_tokens"] == 150*8192 + (35+100)*sum(method.CAPS.values()) == 5652480,
        "generation bound differs")
    e.require(plan["automatic_retries"] == 0 and plan["timeout_seconds"] == 600
        and plan["serial_minimum_seconds"] == 2 and plan["run_window_hours"] == 72
        and plan["run_started_at"] is None and plan["run_deadline"] is None
        and plan["old_window_reset_or_unused_slots_transfer"] is False, "transport/clock draft differs")
    review = plan["calibration_review"]
    e.require(review["primary_numeric_guards_required"] is True and review["full_record_numeric_guards_required"] is True
        and review["both_pass_plus_explicit_review_required_before_collection"] is True
        and review["frozen_guard_values_changed"] is False, "whole-record review gate missing")
    return {"method": p, "old": old, "plan": plan, "bank": bank, "lock": lock, "root": root}


def calibration_packet(root, *, salt):
    p = load_preparation(root)
    e.require(type(salt) is str and len(salt.encode()) >= 32, "blinding salt too short")
    rows, targets = [], {}
    for case in p["bank"]["cases"]:
        blind = "B-" + hmac.new(salt.encode(), (CAMPAIGN + "|" + case["case_id"]).encode(), hashlib.sha256).hexdigest()[:32]
        rows.append({"observation_id_blind": blind, "item_id": case["item_id"],
            "exact_frozen_prompt": p["method"]["legacy"]["items"][case["item_id"]].prompt,
            "visible_response": case["visible_response"]})
        targets[blind] = {"case_id": case["case_id"], "proposed_anchor": case["proposed_anchor"],
            "codes": diagnostic_targets(case), "metadata": copy.deepcopy(case.get("additional_metadata_targets", {}))}
    batch = method.build_batch(root, rows, {}, phase="calibration", synthetic_test_only=True)
    return e.sealed({"campaign_id": CAMPAIGN, "status": "DRAFT_OFFLINE_ONLY_NOT_FOR_DISPATCH",
        "bank_file_sha256": sha256_file(root / BANK), "preparation_sha256": p["lock"]["preparation_sha256"],
        "batch": batch, "private_targets_never_sent_to_judges": targets,
        "API_calls_authorized": False, "calibration_clearance_granted": False}, "packet_sha256")


def new_fixed_jobs(root, phase):
    p = load_preparation(root)
    e.require(phase in {"metadata", "collection"}, "fixed metadata or source phase required")
    jobs = []
    for old in historical.fixed_jobs(p["old"], phase):
        core = {k: copy.deepcopy(v) for k, v in old.items() if k != "job_sha256"}
        core["campaign_id"] = CAMPAIGN
        core["draft_not_for_dispatch"] = True
        if phase == "collection":
            source = {k: v for k, v in core["source"].items() if k != "request_id"}
            e.require(source["slot_id"].startswith("EV3-"), "unexpected source slot ancestry")
            source.update(campaign_id=CAMPAIGN, slot_id="EV31-" + source["slot_id"][4:], fresh_prospective_request=True)
            core["source"] = e.sealed(source, "request_id")
        jobs.append(e.sealed(core, "job_sha256"))
    e.require(len(jobs) == CAPS[phase], "job count differs")
    return jobs


def continuation_check(primary_guards, full_record_guards, agent_review_accepted):
    return all(v is True for v in (primary_guards, full_record_guards, agent_review_accepted))


def window_limit(started_at: datetime, now: datetime):
    e.require(started_at.tzinfo is not None and now.tzinfo is not None, "aware times required")
    return started_at <= now <= started_at + timedelta(hours=72)


def can_reserve_before_deadline(started_at: datetime, now: datetime):
    return window_limit(started_at, now) and (started_at + timedelta(hours=72) - now).total_seconds() > 600


def remaining_quality_bound(total, invalid, minimum_fraction):
    e.require(type(total) is int and total > 0 and type(invalid) is int and 0 <= invalid <= total,
        "invalid planned denominator or failure count")
    e.require(type(minimum_fraction) in {int, float} and 0 < minimum_fraction <= 1, "invalid fixed fraction")
    minimum_valid = math.ceil(total * minimum_fraction)
    return {"planned_denominator": total, "invalid_preserved": invalid, "minimum_valid": minimum_valid,
        "maximum_valid": total-invalid, "reachable": total-invalid >= minimum_valid}


class FixtureBudget:
    """In-memory engineering fixture only. Not a production ledger or authority."""
    def __init__(self, *, simulation_only):
        e.require(simulation_only is True, "no real ledger is allocated")
        self.counts, self.ids, self.pending, self.held = dict.fromkeys(CAPS, 0), set(), None, False
        self.calibration_reviewed = False

    def reserve(self, phase, request_id):
        e.require(type(request_id) is str and bool(request_id), "fixture request ID required")
        e.require(not self.held and self.pending is None and phase in CAPS and request_id not in self.ids, "HOLD or duplicate/pending fixture request")
        if phase != "metadata": e.require(self.counts["metadata"] == 6, "metadata must finish first")
        if phase in {"collection", "main"}:
            e.require(self.counts["calibration"] == 105 and self.calibration_reviewed, "both-component calibration review required")
        if phase == "main": e.require(self.counts["collection"] == 150, "fresh150 source answers required")
        e.require(self.counts[phase] < CAPS[phase] and PRIOR + sum(self.counts.values()) < MAXIMUM, "request budget exceeded")
        self.counts[phase] += 1
        self.ids.add(request_id)
        self.pending = (phase, request_id)

    def finish(self, outcome):
        e.require(self.pending is not None and outcome in {"ok", "technical_failure", "invalid_model_output"}, "no matching fixture request")
        phase = self.pending[0]
        self.pending = None
        if outcome == "technical_failure" or (outcome == "invalid_model_output" and phase == "metadata"): self.held = True

    def review(self, primary_guards, full_record_guards, agent_review_accepted):
        e.require(not self.held and self.pending is None and self.counts["calibration"] == 105, "complete calibration required")
        self.calibration_reviewed = continuation_check(primary_guards, full_record_guards, agent_review_accepted)
        if not self.calibration_reviewed: self.held = True

    def summary(self):
        return {"simulation_only": True, "counts": self.counts.copy(), "new_reserved": sum(self.counts.values()),
            "cumulative_reserved": PRIOR + sum(self.counts.values()), "pending": self.pending is not None,
            "held": self.held, "both_component_reviewed": self.calibration_reviewed}


def assert_live_authorized(*args, **kwargs):
    raise ValidationError("EV31 preparation is not API authority: content, plan and a separate FINAL execution permit are pending")


def auxiliary_diagnostics(root, packet, views):
    """Descriptive all45 agreement/coverage, not new cutoffs or human-gold accuracy."""
    e.verify(packet, "packet_sha256")
    batch, targets = packet["batch"], packet["private_targets_never_sent_to_judges"]
    prep = load_preparation(root)
    method.validate_batch(root, batch)
    e.require(packet["bank_file_sha256"] == sha256_file(root / BANK)
        and packet["preparation_sha256"] == prep["lock"]["preparation_sha256"], "diagnostic material binding differs")
    cases = {c["case_id"]: c for c in prep["bank"]["cases"]}
    e.require(set(targets) == set(batch["observations"]) and {t["case_id"] for t in targets.values()} == set(cases), "target coverage differs")
    for blind, t in targets.items():
        case = cases[t["case_id"]]
        e.require(t["codes"] == diagnostic_targets(case) and t["proposed_anchor"] == case["proposed_anchor"]
            and t["metadata"] == case.get("additional_metadata_targets", {})
            and batch["observations"][blind]["item_id"] == case["item_id"]
            and batch["observations"][blind]["visible_response"] == case["visible_response"], "diagnostic labels or case text changed")
    e.require(batch["phase"] == "calibration", "common calibration diagnostics required")
    by = {}
    for v in views:
        e.verify(v, "view_sha256")
        e.require(v["batch_sha256"] == batch["batch_sha256"] and v["request_id"] not in by, "wrong or duplicate diagnostic view")
        e.require(v == method._import(prep["method"], batch, v["raw_envelope"]), "diagnostic view differs from original raw")
        by[v["request_id"]] = v
    names = list(next(iter(views))["auxiliary"]["codes"]) if views else []
    e.require(len(names) == 45, "all45 diagnostic fields required")
    coverage, target_matches = {}, {}
    for judge in e.JUDGE_FAMILIES:
        qs = [q for q in batch["requests"] if q["judge_id"] == judge]
        coverage[judge] = {}
        matches = {"proposed_primary_matches": 0, "primary_compared": 0, "proposed_code_comparisons": 0,
            "proposed_code_matches": 0, "proposed_metadata_comparisons": 0, "proposed_metadata_matches": 0}
        for name in names:
            states = [by[q["request_id"]]["auxiliary"]["codes"][name] for q in qs if q["request_id"] in by]
            coverage[judge][name] = {"planned": len(qs), "returned": len(states), "contract_valid": sum(s["valid"] for s in states),
                "available": sum(s["valid"] and s["available"] for s in states), "statuses": dict(Counter(s["status"] for s in states))}
        for q in qs:
            v = by.get(q["request_id"])
            if not v: continue
            target = targets[q["observation_id_blind"]]
            if v["primary"]["valid"]:
                matches["primary_compared"] += 1
                matches["proposed_primary_matches"] += v["primary"]["judgment"]["primary_score"] == target["proposed_anchor"]
            for name, expected in target["codes"].items():
                matches["proposed_code_comparisons"] += 1
                s = v["auxiliary"]["codes"][name]
                matches["proposed_code_matches"] += s["valid"] and s["present"] and type(s.get("raw_value")) is type(expected) and s.get("raw_value") == expected
            for name, expected in target["metadata"].items():
                matches["proposed_metadata_comparisons"] += 1
                s = v["metadata"][name]
                matches["proposed_metadata_matches"] += s["valid"] and type(s.get("raw_value")) is type(expected) and s.get("raw_value") == expected
        target_matches[judge] = matches
    pairs = {}
    for left, right in (("J01", "J02"), ("J01", "J03"), ("J02", "J03")):
        fields = {}
        for name in names:
            values, both_na = [], 0
            for blind in batch["observations"]:
                qs = {q["judge_id"]: q for q in batch["requests"] if q["observation_id_blind"] == blind}
                lv, rv = by.get(qs[left]["request_id"]), by.get(qs[right]["request_id"])
                if not lv or not rv: continue
                a, b = lv["auxiliary"]["codes"][name], rv["auxiliary"]["codes"][name]
                if a["valid"] and b["valid"] and a["status"] == b["status"] == "NOT_APPLICABLE": both_na += 1
                if a["valid"] and b["valid"] and a["available"] and b["available"]:
                    values.append((a["raw_value"], b["raw_value"]))
            exact = sum(type(a) is type(b) and a == b for a, b in values)
            fields[name] = {"planned_cases": 35, "jointly_available": len(values), "both_not_applicable": both_na,
                "exact_matches": exact, "exact_fraction": exact/len(values) if values else None,
                "proposed_new_pass_threshold": None, "denominator_not_used_to_relax_full_record_guards": True}
        pairs[left + "_" + right] = fields
    return {"status": "DESCRIPTIVE_DIAGNOSTICS_NOT_HUMAN_GOLD_OR_FEATURE_QUALIFICATION",
        "coverage": coverage, "pair_exact_agreement": pairs, "proposed_target_comparison": target_matches,
        "unlisted_proposed_targets_not_imputed": True, "all45_fields_retained": names,
        "calibration_clearance_granted": False, "pilot_passed": False, "API_calls": 0}
